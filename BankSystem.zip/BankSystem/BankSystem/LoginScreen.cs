﻿using System;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private static bool _ValidateInputs(string UserName, string Password)
        {
            return string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var UserName = txtUserName.Text.Trim();
            var Password = txtPassword.Text.Trim();

            if (_ValidateInputs(UserName, Password))
            {
                MessageBox.Show("Enter Username, Password !");
                return;
            }

            if (UsersBusinessLayer.IsFound(UserName, clsGlobal.EncryptText(Password)))
            {
                var User1 = UsersBusinessLayer.FindUser(UserName);

                if (((Control)sender).Tag == "Admin")
                {
                    if (User1.UserName == "Taha579")
                    {
                        var fr = new UsersScreen();
                        fr.ShowDialog();
                    }

                    else
                    {
                        MessageBox.Show("You Are Not Admin.", "Not Admin",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

                else
                {
                    clsGlobal.CurrentUser = User1;

                    Hide();
                    var fr = new MainMenuScreen(User1.Permissions);
                    fr.ShowDialog();

                    Show();
                }
            }

            else
            {
                txtUserName.Focus();

                MessageBox.Show("Invalid Username/Password.", "Wrong Credintials",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblSignup_Click(object sender, EventArgs e)
        {
            AddEditUserScreen fr = new AddEditUserScreen();
            fr.action += _GetNewUser;
            fr.ShowDialog();
        }

        private void _GetNewUser(string UserName, string Password)
        {
            txtUserName.Text = UserName;
            txtPassword.Text = Password;
        }
    }
}