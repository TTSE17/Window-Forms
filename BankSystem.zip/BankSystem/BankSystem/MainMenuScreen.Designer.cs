﻿using System.ComponentModel;
using System.Drawing;

namespace BankSystem
{
    partial class MainMenuScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainContainer = new System.Windows.Forms.Panel();
            this.TransactionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.depositToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.withDrawToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transferHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.clientsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.currenciesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currenciesManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.currenciesExchangeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainContainer
            // 
            this.MainContainer.BackColor = System.Drawing.Color.Navy;
            this.MainContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainContainer.Location = new System.Drawing.Point(0, 85);
            this.MainContainer.Name = "MainContainer";
            this.MainContainer.Size = new System.Drawing.Size(956, 480);
            this.MainContainer.TabIndex = 5;
            // 
            // TransactionsToolStripMenuItem
            // 
            this.TransactionsToolStripMenuItem.AutoSize = false;
            this.TransactionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.depositToolStripMenuItem, this.withDrawToolStripMenuItem, this.transferToolStripMenuItem, this.transferHistoryToolStripMenuItem });
            this.TransactionsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.TransactionsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.TransactionsToolStripMenuItem.Image = global::BankSystem.Properties.Resources.bank_transaction;
            this.TransactionsToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TransactionsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.TransactionsToolStripMenuItem.Name = "TransactionsToolStripMenuItem";
            this.TransactionsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 11, 4, 0);
            this.TransactionsToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.TransactionsToolStripMenuItem.Text = "Transactions";
            this.TransactionsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // depositToolStripMenuItem
            // 
            this.depositToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.depositToolStripMenuItem.Image = global::BankSystem.Properties.Resources.payment;
            this.depositToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.depositToolStripMenuItem.Name = "depositToolStripMenuItem";
            this.depositToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 13, 0, 1);
            this.depositToolStripMenuItem.Size = new System.Drawing.Size(278, 82);
            this.depositToolStripMenuItem.Tag = "2";
            this.depositToolStripMenuItem.Text = "Deposit ";
            this.depositToolStripMenuItem.Click += new System.EventHandler(this.depositToolStripMenuItem_Click);
            // 
            // withDrawToolStripMenuItem
            // 
            this.withDrawToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.withDrawToolStripMenuItem.Image = global::BankSystem.Properties.Resources.payment__1_;
            this.withDrawToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.withDrawToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.withDrawToolStripMenuItem.Name = "withDrawToolStripMenuItem";
            this.withDrawToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 13, 0, 1);
            this.withDrawToolStripMenuItem.Size = new System.Drawing.Size(278, 82);
            this.withDrawToolStripMenuItem.Tag = "4";
            this.withDrawToolStripMenuItem.Text = "WithDraw";
            this.withDrawToolStripMenuItem.Click += new System.EventHandler(this.withDrawToolStripMenuItem_Click);
            // 
            // transferToolStripMenuItem
            // 
            this.transferToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.transferToolStripMenuItem.Image = global::BankSystem.Properties.Resources.loan;
            this.transferToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.transferToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.transferToolStripMenuItem.Name = "transferToolStripMenuItem";
            this.transferToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 13, 0, 1);
            this.transferToolStripMenuItem.Size = new System.Drawing.Size(278, 82);
            this.transferToolStripMenuItem.Tag = "8";
            this.transferToolStripMenuItem.Text = "Transfer";
            this.transferToolStripMenuItem.Click += new System.EventHandler(this.transferToolStripMenuItem_Click);
            // 
            // transferHistoryToolStripMenuItem
            // 
            this.transferHistoryToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.transferHistoryToolStripMenuItem.Image = global::BankSystem.Properties.Resources.essay;
            this.transferHistoryToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.transferHistoryToolStripMenuItem.Name = "transferHistoryToolStripMenuItem";
            this.transferHistoryToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 13, 0, 1);
            this.transferHistoryToolStripMenuItem.Size = new System.Drawing.Size(278, 82);
            this.transferHistoryToolStripMenuItem.Tag = "16";
            this.transferHistoryToolStripMenuItem.Text = "Transfers History";
            this.transferHistoryToolStripMenuItem.Click += new System.EventHandler(this.transferHistoryToolStripMenuItem_Click);
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTime.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDateTime.Location = new System.Drawing.Point(12, 460);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(0, 29);
            this.lblDateTime.TabIndex = 4;
            // 
            // clientsToolStripMenuItem
            // 
            this.clientsToolStripMenuItem.AutoSize = false;
            this.clientsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.clientsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.clientsToolStripMenuItem.Image = global::BankSystem.Properties.Resources.People_64;
            this.clientsToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.clientsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.clientsToolStripMenuItem.Margin = new System.Windows.Forms.Padding(7, 0, 0, 0);
            this.clientsToolStripMenuItem.Name = "clientsToolStripMenuItem";
            this.clientsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 11, 4, 0);
            this.clientsToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.clientsToolStripMenuItem.Tag = "1";
            this.clientsToolStripMenuItem.Text = "  Clients";
            this.clientsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.clientsToolStripMenuItem.Click += new System.EventHandler(this.clientsToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.clientsToolStripMenuItem, this.TransactionsToolStripMenuItem, this.currenciesToolStripMenuItem, this.logoutToolStripMenuItem });
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(956, 85);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // currenciesToolStripMenuItem
            // 
            this.currenciesToolStripMenuItem.AutoSize = false;
            this.currenciesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.currenciesManagementToolStripMenuItem, this.currenciesExchangeToolStripMenuItem });
            this.currenciesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.currenciesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.currenciesToolStripMenuItem.Image = global::BankSystem.Properties.Resources.opportunity_cost;
            this.currenciesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.currenciesToolStripMenuItem.Name = "currenciesToolStripMenuItem";
            this.currenciesToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.currenciesToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.currenciesToolStripMenuItem.Text = "Currencies";
            // 
            // currenciesManagementToolStripMenuItem
            // 
            this.currenciesManagementToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.currenciesManagementToolStripMenuItem.Image = global::BankSystem.Properties.Resources.coins;
            this.currenciesManagementToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.currenciesManagementToolStripMenuItem.Name = "currenciesManagementToolStripMenuItem";
            this.currenciesManagementToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 13, 0, 1);
            this.currenciesManagementToolStripMenuItem.Size = new System.Drawing.Size(339, 82);
            this.currenciesManagementToolStripMenuItem.Tag = "32";
            this.currenciesManagementToolStripMenuItem.Text = "Currencies Management";
            this.currenciesManagementToolStripMenuItem.Click += new System.EventHandler(this.currenciesManagementToolStripMenuItem_Click);
            // 
            // currenciesExchangeToolStripMenuItem
            // 
            this.currenciesExchangeToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.currenciesExchangeToolStripMenuItem.Image = global::BankSystem.Properties.Resources.currency_exchange;
            this.currenciesExchangeToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.currenciesExchangeToolStripMenuItem.Name = "currenciesExchangeToolStripMenuItem";
            this.currenciesExchangeToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 13, 0, 1);
            this.currenciesExchangeToolStripMenuItem.Size = new System.Drawing.Size(339, 82);
            this.currenciesExchangeToolStripMenuItem.Text = "Currencies Exchange";
            this.currenciesExchangeToolStripMenuItem.Click += new System.EventHandler(this.currenciesExchangeToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.AutoSize = false;
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.logoutToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.logoutToolStripMenuItem.Image = global::BankSystem.Properties.Resources.sign_out;
            this.logoutToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.logoutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.logoutToolStripMenuItem.Text = "Log Out";
            this.logoutToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // MainMenuScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 565);
            this.Controls.Add(this.MainContainer);
            this.Controls.Add(this.lblDateTime);
            this.Controls.Add(this.menuStrip1);
            this.Name = "MainMenuScreen";
            this.Text = "MainMenuScreen";
            this.Load += new System.EventHandler(this.MainMenuScreen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ToolStripMenuItem transferHistoryToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem transferToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem currenciesExchangeToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem currenciesManagementToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem currenciesToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem withDrawToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem depositToolStripMenuItem;


        private System.Windows.Forms.Panel MainContainer;
        private System.Windows.Forms.ToolStripMenuItem TransactionsToolStripMenuItem;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.ToolStripMenuItem clientsToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;

        #endregion
    }
}