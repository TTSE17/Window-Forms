﻿using System;
using System.Threading;
using BankSystemBusinessLayer;

namespace BankSystem
{
    public class clsGlobal
    {
        public static UsersBusinessLayer CurrentUser = null;
        public static string EncryptText(string Text, int EncryptionKey = 2)
        {
            var CharArray = Text.ToCharArray();
            var len = CharArray.Length;
            for (var i = 0; i < len; i++)
            {
                CharArray[i] = Convert.ToChar(CharArray[i] + EncryptionKey);
            }

            return new string(CharArray);
        }

        public static string DecryptText(string Text, int EncryptionKey = 2)
        {
            var CharArray = Text.ToCharArray();
            var len = CharArray.Length;
            for (var i = 0; i < len; i++)
            {
                CharArray[i] = Convert.ToChar(CharArray[i] - EncryptionKey);
            }

            return new string(CharArray);
        }

        public static string GetRandomPinCode()
        {
            // 48 , 57 /65 , 90 / 97 , 122

            string PinCode;

            do
            {
                PinCode = "";

                for (var i = 0; i < 4; i++)
                {
                    PinCode += Convert.ToChar(RandomNumber(48, 57));
                }
            } while (ClientsBusinessLayer.ExistPinCode(PinCode));

            return PinCode;
        }

        public static bool AllNumber(string Number)
        {
            var len = Number.Length;

            for (var i = 0; i < len; i++)
                if (!(char.IsNumber(Number[i])))
                    return false;

            return true;
        }

        public static bool AllLetter(string Name)
        {
            var len = Name.Length;

            for (var i = 0; i < len; i++)
                if (!(char.IsLetter(Name[i])))
                    return false;

            return true;
        }
        
        private static readonly Random random = new Random();
        private static readonly object syncLock = new object();

        private static int RandomNumber(int min, int max)
        {
            lock (syncLock)
            {
                // synchronize
                return random.Next(min, max);
            }
        }
    }
}