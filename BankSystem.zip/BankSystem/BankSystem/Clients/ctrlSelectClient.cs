﻿using System;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Clients
{
    public partial class ctrlSelectClient : UserControl
    {
        public event Action<int> OnSelectionComplete;

        // Create a protected method to raise the event with a parameter
        protected virtual void SelectionComplete(int PersonID)
        {
            var handler = OnSelectionComplete;
            handler?.Invoke(PersonID); // Raise the event with the parameter
        }

        public ctrlSelectClient()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _ClientID = -1;
        private ClientsBusinessLayer _Client1;

        public void LoadControl()
        {
            RefreshData();
            GridViewClientsList.ClearSelection();
        }


        private void RefreshData()
        {
            _DataTable = ClientsBusinessLayer.GetAllClients();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            groupBox1.Enabled = textBox1.Enabled = btnSelect.Enabled = true;


            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Client ID", typeof(int));
            _DataTable.Columns.Add("Pin Code", typeof(string));
            _DataTable.Columns.Add("First Name", typeof(string));
            _DataTable.Columns.Add("Last Name", typeof(string));
            _DataTable.Columns.Add("Balance", typeof(decimal));
            _DataTable.Columns.Add("Email", typeof(string));
            _DataTable.Columns.Add("Phone", typeof(string));
            _DataTable.Columns.Add("Date Of Birth", typeof(DateTime));

            GridViewClientsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewClientsList.Rows.Count > 0)
                GridViewClientsList.Rows.RemoveAt(0);


            groupBox1.Enabled = textBox1.Enabled = btnSelect.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewClientsList.Columns[0].Width = 71;
            GridViewClientsList.Columns[1].Width = 71;
            GridViewClientsList.Columns[2].Width = 79;
            GridViewClientsList.Columns[3].Width = 91;
            GridViewClientsList.Columns[4].Width = 71;
            GridViewClientsList.Columns[5].Width = 71;
            GridViewClientsList.Columns[6].Width = 99;
            GridViewClientsList.Columns[7].Width = 99;
        }

        private void LoadData(string Type = "Client ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Client ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "Unacceptable Key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewClientsList.DataSource = _DataView1;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = rbClientID.Checked ? "Client ID" : "Pin Code";
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
            GridViewClientsList.ClearSelection();
        }

        private void rbClientID_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Client ID :";
        }

        private void rbPicCode_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Pin Code :";
        }

        private void GridViewClientsList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                _ClientID = -1;
                return;
            }

            UpdateClientInfo(Convert.ToInt32(GridViewClientsList.CurrentRow.Cells[0].Value));
        }

        private void GridViewClientsList_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            GridViewClientsList.ClearSelection();
            _ClientID = -1;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (OnSelectionComplete != null)
                SelectionComplete(_ClientID);
        }

        private void UpdateClientInfo(int ID)
        {
            _ClientID = ID;
            _Client1 = ClientsBusinessLayer.FindClient(_ClientID);
        }
    }
}