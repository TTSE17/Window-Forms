﻿using System.ComponentModel;

namespace BankSystem.Transactions
{
    partial class SelectClientScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlSelectClient1 = new BankSystem.Clients.ctrlSelectClient();
            this.SuspendLayout();
            // 
            // ctrlSelectClient1
            // 
            this.ctrlSelectClient1.BackColor = System.Drawing.Color.Navy;
            this.ctrlSelectClient1.Location = new System.Drawing.Point(1, -1);
            this.ctrlSelectClient1.Name = "ctrlSelectClient1";
            this.ctrlSelectClient1.Size = new System.Drawing.Size(793, 408);
            this.ctrlSelectClient1.TabIndex = 0;
            this.ctrlSelectClient1.OnSelectionComplete += new System.Action<int>(this.ctrlSelectClient1_OnSelectionComplete);
            // 
            // SelectClientScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(792, 440);
            this.Controls.Add(this.ctrlSelectClient1);
            this.Name = "SelectClientScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SelectClientScreen";
            this.Load += new System.EventHandler(this.SelectClientScreen_Load);
            this.ResumeLayout(false);
        }

        private BankSystem.Clients.ctrlSelectClient ctrlSelectClient1;

        #endregion
    }
}