﻿using System.ComponentModel;

namespace BankSystem.Clients
{
    partial class ctrlSelectClient
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblSearch = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbClientID = new System.Windows.Forms.RadioButton();
            this.rbPicCode = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.GridViewClientsList = new System.Windows.Forms.DataGridView();
            this.btnSelect = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewClientsList)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSearch
            // 
            this.lblSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearch.ForeColor = System.Drawing.Color.White;
            this.lblSearch.Location = new System.Drawing.Point(22, 26);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(106, 23);
            this.lblSearch.TabIndex = 128;
            this.lblSearch.Text = "Client ID :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbClientID);
            this.groupBox1.Controls.Add(this.rbPicCode);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Goldenrod;
            this.groupBox1.Location = new System.Drawing.Point(472, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 60);
            this.groupBox1.TabIndex = 127;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search By";
            // 
            // rbClientID
            // 
            this.rbClientID.AutoSize = true;
            this.rbClientID.Checked = true;
            this.rbClientID.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbClientID.ForeColor = System.Drawing.Color.White;
            this.rbClientID.Location = new System.Drawing.Point(6, 27);
            this.rbClientID.Name = "rbClientID";
            this.rbClientID.Size = new System.Drawing.Size(88, 24);
            this.rbClientID.TabIndex = 113;
            this.rbClientID.TabStop = true;
            this.rbClientID.Text = "Client ID";
            this.rbClientID.UseVisualStyleBackColor = true;
            this.rbClientID.CheckedChanged += new System.EventHandler(this.rbClientID_CheckedChanged);
            // 
            // rbPicCode
            // 
            this.rbPicCode.AutoSize = true;
            this.rbPicCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbPicCode.ForeColor = System.Drawing.Color.White;
            this.rbPicCode.Location = new System.Drawing.Point(100, 27);
            this.rbPicCode.Name = "rbPicCode";
            this.rbPicCode.Size = new System.Drawing.Size(91, 24);
            this.rbPicCode.TabIndex = 114;
            this.rbPicCode.Text = "Pin Code";
            this.rbPicCode.UseVisualStyleBackColor = true;
            this.rbPicCode.CheckedChanged += new System.EventHandler(this.rbPicCode_CheckedChanged);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(134, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(189, 27);
            this.textBox1.TabIndex = 126;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // GridViewClientsList
            // 
            this.GridViewClientsList.AllowUserToAddRows = false;
            this.GridViewClientsList.AllowUserToDeleteRows = false;
            this.GridViewClientsList.AllowUserToResizeColumns = false;
            this.GridViewClientsList.AllowUserToResizeRows = false;
            this.GridViewClientsList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewClientsList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.GridViewClientsList.BackgroundColor = System.Drawing.Color.Navy;
            this.GridViewClientsList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridViewClientsList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewClientsList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridViewClientsList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewClientsList.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.InfoText;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GridViewClientsList.DefaultCellStyle = dataGridViewCellStyle2;
            this.GridViewClientsList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.GridViewClientsList.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.GridViewClientsList.Location = new System.Drawing.Point(0, 85);
            this.GridViewClientsList.Margin = new System.Windows.Forms.Padding(0);
            this.GridViewClientsList.Name = "GridViewClientsList";
            this.GridViewClientsList.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewClientsList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.GridViewClientsList.RowHeadersVisible = false;
            this.GridViewClientsList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.GridViewClientsList.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.GridViewClientsList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridViewClientsList.Size = new System.Drawing.Size(792, 252);
            this.GridViewClientsList.TabIndex = 125;
            this.GridViewClientsList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GridViewClientsList_CellClick);
            this.GridViewClientsList.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.GridViewClientsList_ColumnHeaderMouseClick);
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnSelect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelect.FlatAppearance.BorderSize = 0;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.ForeColor = System.Drawing.Color.White;
            this.btnSelect.Location = new System.Drawing.Point(335, 366);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(126, 39);
            this.btnSelect.TabIndex = 130;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // ctrlSelectClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.GridViewClientsList);
            this.Name = "ctrlSelectClient";
            this.Size = new System.Drawing.Size(792, 408);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewClientsList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnSelect;

        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbClientID;
        private System.Windows.Forms.RadioButton rbPicCode;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView GridViewClientsList;

        #endregion
    }
}