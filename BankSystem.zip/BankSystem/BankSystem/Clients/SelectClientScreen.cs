﻿using System;
using System.Windows.Forms;

namespace BankSystem.Transactions
{
    public partial class SelectClientScreen : Form
    {
        public SelectClientScreen()
        {
            InitializeComponent();
        }

        public delegate void DataBackEventHandler(int PersonID);

        public event DataBackEventHandler DataBack;

        private void ctrlSelectClient1_OnSelectionComplete(int ClientID)
        {
            if (ClientID == -1)
            {
                MessageBox.Show("Please Select A Client!");
                return;
            }

            DataBack?.Invoke(ClientID);

            Close();
        }

        private void SelectClientScreen_Load(object sender, EventArgs e)
        {
            ctrlSelectClient1.LoadControl();
        }
    }
}