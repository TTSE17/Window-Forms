﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Clients
{
    public partial class ClientsScreen : Form
    {
        public ClientsScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _ClientID;
        private ClientsBusinessLayer _Client1;

        private void ClientsScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = ClientsBusinessLayer.GetAllClients();


            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            btnDelete.Enabled = btnUpdate.Enabled = comboBox1.Enabled = textBox1.Enabled = true;
            comboBox1.SelectedIndex = 0;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Client ID", typeof(int));
            _DataTable.Columns.Add("Pin Code", typeof(string));
            _DataTable.Columns.Add("First Name", typeof(string));
            _DataTable.Columns.Add("Last Name", typeof(string));
            _DataTable.Columns.Add("Balance", typeof(decimal));
            _DataTable.Columns.Add("Email", typeof(string));
            _DataTable.Columns.Add("Phone", typeof(string));
            _DataTable.Columns.Add("Date Of Birth", typeof(DateTime));

            GridViewClientsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewClientsList.Rows.Count > 0)
                GridViewClientsList.Rows.RemoveAt(0);

            btnDelete.Enabled = btnUpdate.Enabled = comboBox1.Enabled = textBox1.Enabled = false;
            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewClientsList.Columns[0].Width = 71;
            GridViewClientsList.Columns[1].Width = 71;
            GridViewClientsList.Columns[2].Width = 79;
            GridViewClientsList.Columns[3].Width = 91;
            GridViewClientsList.Columns[4].Width = 71;
            GridViewClientsList.Columns[5].Width = 71;
            GridViewClientsList.Columns[6].Width = 99;
            GridViewClientsList.Columns[7].Width = 99;
        }

        private void LoadData(string Type = "Client ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Client ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewClientsList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewClientsList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var fr = new AddEditClientScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateClientInfo(Convert.ToInt32(GridViewClientsList.CurrentRow.Cells[0].Value));

            var fr = new AddEditClientScreen(_ClientID);
            fr.ShowDialog();

            RefreshData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            UpdateClientInfo(Convert.ToInt32(GridViewClientsList.CurrentRow.Cells[0].Value));


            if (MessageBox.Show("Are you sure you want to delete [" + _ClientID + "]", "Confirm Deletion",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_Client1.Delete())
            {
                MessageBox.Show("Student Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Student, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void UpdateClientInfo(int ID)
        {
            _ClientID = ID;
            _Client1 = ClientsBusinessLayer.FindClient(_ClientID);
        }
    }
}