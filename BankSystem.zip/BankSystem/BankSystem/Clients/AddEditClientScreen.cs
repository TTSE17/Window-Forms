﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BankSystem.Properties;
using BankSystemBusinessLayer;

namespace BankSystem.Clients
{
    public partial class AddEditClientScreen : Form
    {
        private int _ClientID;
        private ClientsBusinessLayer _Client1;

        public AddEditClientScreen(int ClientId = -1)
        {
            InitializeComponent();
            _ClientID = ClientId;
        }

        private void AddEditClientScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dateTimePicker1.MaxDate = DateTime.Now.AddYears(-18);
            dateTimePicker1.MinDate = DateTime.Now.AddYears(-100);

            pbClient.ImageLocation = null;


            if (_ClientID == -1)
            {
                txtFirstName.Focus();
                _Client1 = new ClientsBusinessLayer();
                lblClientID.Text = "N/A";
                lblPinCode.Text = clsGlobal.GetRandomPinCode();
                lblBalance.Text = "0";
                pbClient.Image = Resources.Question_32;
                lilRemoveImage.Visible = false;
            }

            else
            {
                _Client1 = ClientsBusinessLayer.FindClient(_ClientID);

                if (_Client1 == null) return;

                lblClientID.Text = Convert.ToString(_ClientID);
                lblPinCode.Text = _Client1.PinCode;
                txtFirstName.Text = _Client1.FirstName;
                txtLastName.Text = _Client1.LastName;
                txtEmail.Text = _Client1.Email;
                txtPhone.Text = _Client1.Phone;
                lblBalance.Text = Convert.ToString(_Client1.Balance);
                dateTimePicker1.Value = _Client1.DateOfBirth;

                if (_Client1.ImagePath != "" && File.Exists(_Client1.ImagePath))
                {
                    pbClient.ImageLocation = _Client1.ImagePath;
                    lilRemoveImage.Visible = true;
                }
                else
                {
                    pbClient.Image = Resources.Question_32;
                    lilRemoveImage.Visible = false;
                }
            }
        }

        private void lilSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;

            var selectedFilePath = openFileDialog1.FileName;

            pbClient.ImageLocation = selectedFilePath;

            lilRemoveImage.Visible = true;
        }

        private void lilRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pbClient.Image = Resources.Question_32;
            pbClient.ImageLocation = null;

            lilRemoveImage.Visible = false;
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = (TextBox)sender;
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
                return;
            }
            else
            {
                errorProvider1.SetError(Temp, null);
            }

            if (Temp.Name == "txtPhone")
            {
                if (!clsGlobal.AllNumber(Temp.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(Temp, "Just Numbers!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }

            else if (Temp.Name == "txtFirstName" || Temp.Name == "txtLastName")
            {
                if (!clsGlobal.AllLetter(Temp.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(Temp, "Just Letters!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are not valid!, put the mouse over the red icon(s) to see the error",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var PinCode = lblPinCode.Text;
            var firstName = txtFirstName.Text.Trim();
            var lastName = txtLastName.Text.Trim();
            var Email = txtEmail.Text.Trim();
            var Phone = txtPhone.Text.Trim();
            var BirthDate = dateTimePicker1.Value;

            _Client1.PinCode = PinCode;
            _Client1.FirstName = firstName;
            _Client1.LastName = lastName;
            _Client1.Phone = Phone;
            _Client1.Email = Email;
            _Client1.DateOfBirth = BirthDate;

            _HandleImage();

            _Client1.ImagePath = pbClient.ImageLocation ?? "";

            MessageBox.Show(_Client1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");

            lblClientID.Text = Convert.ToString(_Client1.ClientID);

            _ClientID = _Client1.ClientID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void _HandleImage()
        {
            if (_Client1.ImagePath == pbClient.ImageLocation) return;

            if (_Client1.ImagePath != "")
            {
                try
                {
                    File.Delete(_Client1.ImagePath);
                }
                catch (IOException ee)
                {
                    // MessageBox.Show(ee + "");
                }
            }

            if (pbClient.ImageLocation != null)
            {
                var SourceImageFile = pbClient.ImageLocation;

                var CurrentPath = Directory.GetCurrentDirectory()+"\\Images\\"+
                                  Guid.NewGuid() + Path.GetExtension(SourceImageFile);

                File.Copy(SourceImageFile, CurrentPath, true);

                pbClient.ImageLocation = CurrentPath;
            }
        }
    }
}