﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using BankSystem.Properties;
using BankSystemBusinessLayer;

namespace BankSystem
{
    public partial class AddEditUserScreen : Form
    {
        private int _UserID;
        private UsersBusinessLayer _User1;


        public Action<string, string> action;

        public AddEditUserScreen(int userId = -1)
        {
            InitializeComponent();
            _UserID = userId;
            txtUserName.Focus();

            AutoValidate = AutoValidate.EnableAllowFocusChange;
        }

        private void AddEditUserScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dateTimePicker1.MaxDate = DateTime.Now.AddYears(-18);
            dateTimePicker1.MinDate = DateTime.Now.AddYears(-100);

            pbUser.ImageLocation = null;

            if (_UserID == -1)
            {
                txtFirstName.Focus();
                _User1 = new UsersBusinessLayer();
                lblUserID.Text = "N/A";
                pbUser.Image = Resources.Question_32;
                lilRemoveImage.Visible = false;
            }

            else
            {
                _User1 = UsersBusinessLayer.FindUser(_UserID);

                if (_User1 == null) return;

                lblUserID.Text = Convert.ToString(_UserID);
                txtUserName.Text = Convert.ToString(_User1.UserName);
                txtPassword.Text = Convert.ToString(clsGlobal.DecryptText(_User1.Password));
                txtFirstName.Text = _User1.FirstName;
                txtLastName.Text = _User1.LastName;
                txtEmail.Text = _User1.Email;
                txtPhone.Text = _User1.Phone;
                dateTimePicker1.Value = _User1.DateOfBirth;

                if (_User1.ImagePath != "" && File.Exists(_User1.ImagePath))
                {
                    pbUser.ImageLocation = _User1.ImagePath;
                    lilRemoveImage.Visible = true;
                }
                else
                {
                    pbUser.Image = Resources.Question_32;
                    lilRemoveImage.Visible = false;
                }
            }
        }

        private void lilSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;

            var selectedFilePath = openFileDialog1.FileName;

            pbUser.ImageLocation = selectedFilePath;

            lilRemoveImage.Visible = true;
        }

        private void lilRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pbUser.Image = Resources.Question_32;
            pbUser.ImageLocation = null;

            lilRemoveImage.Visible = false;
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = (TextBox)sender;

            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
                return;
            }

            errorProvider1.SetError(Temp, null);

            if (Temp.Name == "txtPhone")
            {
                if (!clsGlobal.AllNumber(Temp.Text.Trim()))
                {
                    e.Cancel = true;

                    errorProvider1.SetError(Temp, "Only Numbers!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }

            else if (Temp.Name == "txtFirstName" || Temp.Name == "txtLastName")
            {
                if (!clsGlobal.AllLetter(Temp.Text.Trim()))
                {
                    e.Cancel = true;

                    errorProvider1.SetError(Temp, "Only Letters!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }

            else if (Temp.Name == "txtUserName")
            {
                if (_User1.UserID != -1 && _User1.UserName.ToLower() == txtUserName.Text.Trim().ToLower()) return;

                if (UsersBusinessLayer.ExistUserName(Temp.Text.Trim()))
                {
                    e.Cancel = true;

                    errorProvider1.SetError(Temp, "User Name Already Used !");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }

            else if (Temp.Name == "txtPassword")
            {
                if (Temp.Text.Trim().Length < 5)
                {
                    e.Cancel = true;

                    errorProvider1.SetError(Temp, "Password Must be At Least 5 !");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are Invalid!, Hover over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var userName = txtUserName.Text.Trim();
            var password = txtPassword.Text.Trim();
            var firstName = txtFirstName.Text.Trim();
            var lastName = txtLastName.Text.Trim();
            var Email = txtEmail.Text.Trim();
            var Phone = txtPhone.Text.Trim();
            var BirthDate = dateTimePicker1.Value;

            _User1.UserName = userName;
            _User1.Password = clsGlobal.EncryptText(password);
            _User1.FirstName = firstName;
            _User1.LastName = lastName;
            _User1.Phone = Phone;
            _User1.Email = Email;
            _User1.DateOfBirth = BirthDate;

            _HandleImage();

            _User1.ImagePath = pbUser.ImageLocation ?? "";

            MessageBox.Show(_User1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");

            lblUserID.Text = Convert.ToString(_User1.UserID);

            _UserID = _User1.UserID;
        }

        private void _HandleImage()
        {
            if (_User1.ImagePath == pbUser.ImageLocation) return;

            if (_User1.ImagePath != "")
            {
                try
                {
                    File.Delete(_User1.ImagePath);
                }
                catch (IOException ee)
                {
                    // MessageBox.Show(ee + "");
                }
            }

            if (pbUser.ImageLocation != null)
            {
                var SourceImageFile = pbUser.ImageLocation;

                var CurrentPath =
                    "C:\\Users\\Taha\\Documents\\ProgrammingAdvices\\18 - C# & Database Connectivity\\Projects\\BankSystem\\Images\\"
                    + Guid.NewGuid() + Path.GetExtension(SourceImageFile);

                File.Copy(SourceImageFile, CurrentPath, true);

                pbUser.ImageLocation = CurrentPath;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (_UserID == -1) return;

            action?.Invoke(_User1.UserName, clsGlobal.DecryptText(_User1.Password));
            Close();
        }

        private void AddEditUserScreen_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_UserID == -1) return;

            action?.Invoke(_User1.UserName, clsGlobal.DecryptText(_User1.Password));
        }
    }
}