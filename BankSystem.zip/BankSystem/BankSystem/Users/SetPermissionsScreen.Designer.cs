﻿using System.ComponentModel;

namespace BankSystem
{
    partial class SetPermissionsScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.User_Permissions = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblUserName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbWithdrawScreen = new System.Windows.Forms.CheckBox();
            this.cbClientsScreen = new System.Windows.Forms.CheckBox();
            this.cbTransfersHistoryScreen = new System.Windows.Forms.CheckBox();
            this.cbCurrenciesScreen = new System.Windows.Forms.CheckBox();
            this.cbTransferScreen = new System.Windows.Forms.CheckBox();
            this.cbDepositScreen = new System.Windows.Forms.CheckBox();
            this.checkBoxAll = new System.Windows.Forms.CheckBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.groupBox11.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(288, 404);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(99, 34);
            this.btnClose.TabIndex = 142;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // User_Permissions
            // 
            this.User_Permissions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.User_Permissions.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.User_Permissions.ForeColor = System.Drawing.Color.DarkRed;
            this.User_Permissions.FormattingEnabled = true;
            this.User_Permissions.ItemHeight = 20;
            this.User_Permissions.Location = new System.Drawing.Point(288, 108);
            this.User_Permissions.Name = "User_Permissions";
            this.User_Permissions.Size = new System.Drawing.Size(210, 262);
            this.User_Permissions.TabIndex = 141;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label3.ForeColor = System.Drawing.Color.Goldenrod;
            this.label3.Location = new System.Drawing.Point(288, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 28);
            this.label3.TabIndex = 140;
            this.label3.Text = "User Name :";
            // 
            // lblUserName
            // 
            this.lblUserName.AutoSize = true;
            this.lblUserName.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblUserName.ForeColor = System.Drawing.Color.White;
            this.lblUserName.Location = new System.Drawing.Point(411, 22);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(30, 28);
            this.lblUserName.TabIndex = 139;
            this.lblUserName.Text = "??";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(288, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 20);
            this.label2.TabIndex = 138;
            this.label2.Text = "Selected Permissions:";
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Transparent;
            this.groupBox11.Controls.Add(this.panel3);
            this.groupBox11.Controls.Add(this.checkBoxAll);
            this.groupBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.ForeColor = System.Drawing.Color.White;
            this.groupBox11.Location = new System.Drawing.Point(28, 81);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox11.Size = new System.Drawing.Size(230, 288);
            this.groupBox11.TabIndex = 134;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Edit User Permissions:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cbWithdrawScreen);
            this.panel3.Controls.Add(this.cbClientsScreen);
            this.panel3.Controls.Add(this.cbTransfersHistoryScreen);
            this.panel3.Controls.Add(this.cbCurrenciesScreen);
            this.panel3.Controls.Add(this.cbTransferScreen);
            this.panel3.Controls.Add(this.cbDepositScreen);
            this.panel3.Location = new System.Drawing.Point(17, 55);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(199, 219);
            this.panel3.TabIndex = 1;
            // 
            // cbWithdrawScreen
            // 
            this.cbWithdrawScreen.AutoSize = true;
            this.cbWithdrawScreen.BackColor = System.Drawing.Color.Transparent;
            this.cbWithdrawScreen.Location = new System.Drawing.Point(13, 74);
            this.cbWithdrawScreen.Name = "cbWithdrawScreen";
            this.cbWithdrawScreen.Size = new System.Drawing.Size(140, 24);
            this.cbWithdrawScreen.TabIndex = 9;
            this.cbWithdrawScreen.Tag = "4";
            this.cbWithdrawScreen.Text = "Withdraw Screen";
            this.cbWithdrawScreen.UseVisualStyleBackColor = false;
            this.cbWithdrawScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbClientsScreen
            // 
            this.cbClientsScreen.AutoSize = true;
            this.cbClientsScreen.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbClientsScreen.Location = new System.Drawing.Point(13, 5);
            this.cbClientsScreen.Name = "cbClientsScreen";
            this.cbClientsScreen.Size = new System.Drawing.Size(120, 24);
            this.cbClientsScreen.TabIndex = 8;
            this.cbClientsScreen.Tag = "1";
            this.cbClientsScreen.Text = "Clients Screen";
            this.cbClientsScreen.UseVisualStyleBackColor = true;
            this.cbClientsScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbTransfersHistoryScreen
            // 
            this.cbTransfersHistoryScreen.AutoSize = true;
            this.cbTransfersHistoryScreen.Location = new System.Drawing.Point(13, 147);
            this.cbTransfersHistoryScreen.Name = "cbTransfersHistoryScreen";
            this.cbTransfersHistoryScreen.Size = new System.Drawing.Size(185, 24);
            this.cbTransfersHistoryScreen.TabIndex = 7;
            this.cbTransfersHistoryScreen.Tag = "16";
            this.cbTransfersHistoryScreen.Text = "Transfers History Screen";
            this.cbTransfersHistoryScreen.UseVisualStyleBackColor = true;
            this.cbTransfersHistoryScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbCurrenciesScreen
            // 
            this.cbCurrenciesScreen.AutoSize = true;
            this.cbCurrenciesScreen.Location = new System.Drawing.Point(13, 184);
            this.cbCurrenciesScreen.Name = "cbCurrenciesScreen";
            this.cbCurrenciesScreen.Size = new System.Drawing.Size(144, 24);
            this.cbCurrenciesScreen.TabIndex = 6;
            this.cbCurrenciesScreen.Tag = "32";
            this.cbCurrenciesScreen.Text = "Currencies Screen";
            this.cbCurrenciesScreen.UseVisualStyleBackColor = true;
            this.cbCurrenciesScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbTransferScreen
            // 
            this.cbTransferScreen.AutoSize = true;
            this.cbTransferScreen.Location = new System.Drawing.Point(13, 110);
            this.cbTransferScreen.Name = "cbTransferScreen";
            this.cbTransferScreen.Size = new System.Drawing.Size(128, 24);
            this.cbTransferScreen.TabIndex = 4;
            this.cbTransferScreen.Tag = "8";
            this.cbTransferScreen.Text = "Transfer Screen";
            this.cbTransferScreen.UseVisualStyleBackColor = true;
            this.cbTransferScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbDepositScreen
            // 
            this.cbDepositScreen.AutoSize = true;
            this.cbDepositScreen.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbDepositScreen.Location = new System.Drawing.Point(13, 40);
            this.cbDepositScreen.Name = "cbDepositScreen";
            this.cbDepositScreen.Size = new System.Drawing.Size(128, 24);
            this.cbDepositScreen.TabIndex = 0;
            this.cbDepositScreen.Tag = "2";
            this.cbDepositScreen.Text = "Deposit Screen";
            this.cbDepositScreen.UseVisualStyleBackColor = true;
            this.cbDepositScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // checkBoxAll
            // 
            this.checkBoxAll.AutoSize = true;
            this.checkBoxAll.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxAll.Location = new System.Drawing.Point(17, 25);
            this.checkBoxAll.Name = "checkBoxAll";
            this.checkBoxAll.Size = new System.Drawing.Size(46, 24);
            this.checkBoxAll.TabIndex = 0;
            this.checkBoxAll.Tag = "-1";
            this.checkBoxAll.Text = "All";
            this.checkBoxAll.UseVisualStyleBackColor = true;
            this.checkBoxAll.CheckedChanged += new System.EventHandler(this.checkBoxAll_CheckedChanged);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(399, 404);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 34);
            this.btnSave.TabIndex = 137;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.label1.ForeColor = System.Drawing.Color.Goldenrod;
            this.label1.Location = new System.Drawing.Point(28, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 28);
            this.label1.TabIndex = 136;
            this.label1.Text = "ID:";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.lblUserID.ForeColor = System.Drawing.Color.White;
            this.lblUserID.Location = new System.Drawing.Point(65, 22);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(30, 28);
            this.lblUserID.TabIndex = 135;
            this.lblUserID.Text = "??";
            // 
            // SetPermissionsScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(527, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.User_Permissions);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblUserID);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SetPermissionsScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "  Set Permissions Screen";
            this.Load += new System.EventHandler(this.SetPermissionsScreen_Load);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ListBox User_Permissions;
        private System.Windows.Forms.Button btnClose;


        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox cbWithdrawScreen;
        private System.Windows.Forms.CheckBox cbClientsScreen;
        private System.Windows.Forms.CheckBox cbTransfersHistoryScreen;
        private System.Windows.Forms.CheckBox cbCurrenciesScreen;
        private System.Windows.Forms.CheckBox cbTransferScreen;
        private System.Windows.Forms.CheckBox cbDepositScreen;
        private System.Windows.Forms.CheckBox checkBoxAll;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUserID;

        #endregion
    }
}