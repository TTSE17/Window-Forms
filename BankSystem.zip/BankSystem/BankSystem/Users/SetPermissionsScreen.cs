﻿using System;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem
{
    public partial class SetPermissionsScreen : Form
    {
        private bool _Checked;
        private readonly int _UserID = -1;
        private UsersBusinessLayer _User1;

        public SetPermissionsScreen(int userId)
        {
            InitializeComponent();
            _UserID = userId;
        }

        private void SetPermissionsScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _User1 = UsersBusinessLayer.FindUser(_UserID);

            lblUserID.Text = Convert.ToString(_User1.UserID);
            lblUserName.Text = _User1.UserName;

            SetPermission(_User1.Permissions);
        }

        private void SetPermission(int Permission)
        {
            CheckBox[] ArrayBoxes =
            {
                cbClientsScreen, cbDepositScreen, cbWithdrawScreen,
                cbTransferScreen, cbTransfersHistoryScreen, cbCurrenciesScreen
            };

            foreach (var Box in ArrayBoxes)
            {
                if ((Permission & Convert.ToInt32(Box.Tag)) == Convert.ToInt32(Box.Tag))
                    Box.Checked = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var Permission = GetPermission();

            _User1.Permissions = Permission;

            MessageBox.Show(_User1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");
        }

        private int GetPermission()
        {
            if (checkBoxAll.Checked)
                return -1;

            var Permission = 0;

            CheckBox[] ArrayBoxes =
            {
                cbDepositScreen, cbClientsScreen, cbWithdrawScreen,
                cbTransferScreen, cbCurrenciesScreen, cbTransfersHistoryScreen
            };

            foreach (var Box in ArrayBoxes)
            {
                if (Box.Checked)
                    Permission += Convert.ToInt32(Box.Tag);
            }

            return Permission;
        }

        private void checkBoxAll_CheckedChanged(object sender, EventArgs e)
        {
            if (_Checked) return;

            cbDepositScreen.Checked = cbTransferScreen.Checked = cbCurrenciesScreen.Checked =
                cbWithdrawScreen.Checked = cbTransfersHistoryScreen.Checked =
                    cbClientsScreen.Checked = checkBoxAll.Checked;
        }

        private void CheckedBoxAdmin()
        {
            _Checked = true;

            checkBoxAll.Checked = (cbDepositScreen.Checked && cbTransferScreen.Checked &&
                                   cbCurrenciesScreen.Checked && cbWithdrawScreen.Checked &&
                                   cbTransfersHistoryScreen.Checked && cbClientsScreen.Checked);

            _Checked = false;
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            PushAllCheckedItemInList();

            var checkBox = (CheckBox)sender;

            if (checkBox.Checked)
                CheckedBoxAdmin();

            else
            {
                _Checked = true;
                checkBoxAll.Checked = false;
                _Checked = false;
            }
        }

        private void PushAllCheckedItemInList()
        {
            User_Permissions.Items.Clear();

            CheckBox[] ArrayBoxes =
            {
                cbClientsScreen, cbDepositScreen, cbWithdrawScreen,
                cbTransferScreen, cbTransfersHistoryScreen, cbCurrenciesScreen
            };

            foreach (var Box in ArrayBoxes)
            {
                if (Box.Checked)
                    User_Permissions.Items.Add(Box.Text);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}