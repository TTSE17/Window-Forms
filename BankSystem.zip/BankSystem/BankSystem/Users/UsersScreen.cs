﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem
{
    public partial class UsersScreen : Form
    {
        public UsersScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _UserID;
        private UsersBusinessLayer _User1;

        private void UsersScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = UsersBusinessLayer.GetAllUsers();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            btnDelete.Enabled = btnUpdate.Enabled = comboBox1.Enabled = textBox1.Enabled = true;
            comboBox1.SelectedIndex = 0;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("User ID", typeof(int));
            _DataTable.Columns.Add("User Name", typeof(string));
            _DataTable.Columns.Add("Password", typeof(string));
            _DataTable.Columns.Add("Permissions", typeof(int));
            _DataTable.Columns.Add("First Name", typeof(string));
            _DataTable.Columns.Add("Last Name", typeof(string));
            _DataTable.Columns.Add("Balance", typeof(decimal));
            _DataTable.Columns.Add("Email", typeof(string));
            _DataTable.Columns.Add("Phone", typeof(string));
            _DataTable.Columns.Add("Date Of Birth", typeof(DateTime));

            GridViewUsersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewUsersList.Rows.Count > 0)
                GridViewUsersList.Rows.RemoveAt(0);

            btnDelete.Enabled = btnUpdate.Enabled = comboBox1.Enabled = textBox1.Enabled = false;
            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewUsersList.Columns[0].Width = 59;
            GridViewUsersList.Columns[1].Width = 75;
            GridViewUsersList.Columns[2].Width = 75;
            GridViewUsersList.Columns[3].Width = 51;
            GridViewUsersList.Columns[4].Width = 71;
            GridViewUsersList.Columns[5].Width = 71;
            GridViewUsersList.Columns[6].Width = 99;
            GridViewUsersList.Columns[7].Width = 99;
            GridViewUsersList.Columns[8].Width = 99;
        }

        private void LoadData(string Type = "User ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "User ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewUsersList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewUsersList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var fr = new AddEditUserScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateUserInfo(Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value));

            var fr = new AddEditUserScreen(_UserID);
            fr.ShowDialog();

            RefreshData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            UpdateUserInfo(Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value));


            if (MessageBox.Show("Are you sure you want to delete [" + _UserID + "]", "Confirm Deletion",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_User1.Delete())
            {
                MessageBox.Show("Student Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Student, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = GridViewUsersList.Rows.Count <= 0;
        }

        private void setPermissionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateUserInfo(Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value));

            var fr = new SetPermissionsScreen(_UserID);
            fr.ShowDialog();

            RefreshData();
        }

        private void UpdateUserInfo(int ID)
        {
            _UserID = ID;
            _User1 = UsersBusinessLayer.FindUser(_UserID);
        }
    }
}