﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using BankSystem.Properties;
using BankSystemBusinessLayer;

namespace BankSystem.Currencies
{
    public partial class EditCurrencyScreen : Form
    {
        public EditCurrencyScreen(int currencyID)
        {
            InitializeComponent();
            _CurrencyID = currencyID;
        }

        private readonly int _CurrencyID;
        private CurrenciesBusinessLayer _Currency1;

        private void EditCurrencyScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _Currency1 = CurrenciesBusinessLayer.FindCurrency(_CurrencyID);

            if (_Currency1 == null) return;

            lblCurrencyID.Text = Convert.ToString(_CurrencyID);
            lblCurrecnyCode.Text = _Currency1.CurrencyCode;
            lblCurrencyName.Text = _Currency1.CurrencyName;
            numericUpDown1.Value = _Currency1.Rate;
        }

        private void numericUpDown1_Validating(object sender, CancelEventArgs e)
        {
            var value = numericUpDown1.Value;
            if (value == 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(numericUpDown1, "Zero Is Not Allowed!");
            }
            else
            {
                errorProvider1.SetError(numericUpDown1, null);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are invalid!,Hover over the red icon(s) to see the error",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var Rate = numericUpDown1.Value;
            _Currency1.Rate = Rate;

            MessageBox.Show(_Currency1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}