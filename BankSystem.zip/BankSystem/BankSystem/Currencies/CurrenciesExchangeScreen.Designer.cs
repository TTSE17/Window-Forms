﻿using System.ComponentModel;

namespace BankSystem.Currencies
{
    partial class CurrenciesExchangeScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblFromCurrencyName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFormCurrencyRate = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cbFromCurrency = new System.Windows.Forms.ComboBox();
            this.lblFromCurrencyCode = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
            this.btnExchange = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblToCurrencyName = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblToCurrencyRate = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cbToCurrency = new System.Windows.Forms.ComboBox();
            this.lblToCurrencyCode = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblFromCurrencyExchange = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblToCurrencyExchange = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblFromCurrencyName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblFormCurrencyRate);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.cbFromCurrency);
            this.groupBox1.Controls.Add(this.lblFromCurrencyCode);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Goldenrod;
            this.groupBox1.Location = new System.Drawing.Point(47, 57);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(305, 212);
            this.groupBox1.TabIndex = 134;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "From Currency";
            // 
            // lblFromCurrencyName
            // 
            this.lblFromCurrencyName.ForeColor = System.Drawing.Color.White;
            this.lblFromCurrencyName.Location = new System.Drawing.Point(77, 133);
            this.lblFromCurrencyName.Name = "lblFromCurrencyName";
            this.lblFromCurrencyName.Size = new System.Drawing.Size(222, 20);
            this.lblFromCurrencyName.TabIndex = 140;
            this.lblFromCurrencyName.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 20);
            this.label3.TabIndex = 139;
            this.label3.Text = "Name :";
            // 
            // lblFormCurrencyRate
            // 
            this.lblFormCurrencyRate.ForeColor = System.Drawing.Color.White;
            this.lblFormCurrencyRate.Location = new System.Drawing.Point(77, 174);
            this.lblFormCurrencyRate.Name = "lblFormCurrencyRate";
            this.lblFormCurrencyRate.Size = new System.Drawing.Size(79, 20);
            this.lblFormCurrencyRate.TabIndex = 138;
            this.lblFormCurrencyRate.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 20);
            this.label4.TabIndex = 137;
            this.label4.Text = "Rate :";
            // 
            // cbFromCurrency
            // 
            this.cbFromCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFromCurrency.FormattingEnabled = true;
            this.cbFromCurrency.Location = new System.Drawing.Point(19, 33);
            this.cbFromCurrency.Name = "cbFromCurrency";
            this.cbFromCurrency.Size = new System.Drawing.Size(271, 28);
            this.cbFromCurrency.TabIndex = 136;
            this.cbFromCurrency.SelectedIndexChanged += new System.EventHandler(this.cbFromCurrency_SelectedIndexChanged);
            // 
            // lblFromCurrencyCode
            // 
            this.lblFromCurrencyCode.AutoSize = true;
            this.lblFromCurrencyCode.ForeColor = System.Drawing.Color.White;
            this.lblFromCurrencyCode.Location = new System.Drawing.Point(77, 90);
            this.lblFromCurrencyCode.Name = "lblFromCurrencyCode";
            this.lblFromCurrencyCode.Size = new System.Drawing.Size(35, 20);
            this.lblFromCurrencyCode.TabIndex = 133;
            this.lblFromCurrencyCode.Text = "N/A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 132;
            this.label1.Text = "Code :";
            // 
            // dataGridTextBoxColumn1
            // 
            this.dataGridTextBoxColumn1.Format = "";
            this.dataGridTextBoxColumn1.FormatInfo = null;
            this.dataGridTextBoxColumn1.Width = -1;
            // 
            // btnExchange
            // 
            this.btnExchange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnExchange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExchange.FlatAppearance.BorderSize = 0;
            this.btnExchange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExchange.ForeColor = System.Drawing.Color.White;
            this.btnExchange.Location = new System.Drawing.Point(432, 302);
            this.btnExchange.Name = "btnExchange";
            this.btnExchange.Size = new System.Drawing.Size(153, 39);
            this.btnExchange.TabIndex = 135;
            this.btnExchange.Text = "Exchange";
            this.btnExchange.UseVisualStyleBackColor = false;
            this.btnExchange.Click += new System.EventHandler(this.btnExchange_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 1;
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Increment = new decimal(new int[] { 10, 0, 0, 0 });
            this.numericUpDown1.Location = new System.Drawing.Point(260, 312);
            this.numericUpDown1.Maximum = new decimal(new int[] { 9999999, 0, 0, 0 });
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(126, 24);
            this.numericUpDown1.TabIndex = 137;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            this.numericUpDown1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.numericUpDown1_ValueChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblToCurrencyName);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.lblToCurrencyRate);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cbToCurrency);
            this.groupBox2.Controls.Add(this.lblToCurrencyCode);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Goldenrod;
            this.groupBox2.Location = new System.Drawing.Point(451, 57);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(305, 212);
            this.groupBox2.TabIndex = 138;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "To Currency";
            // 
            // lblToCurrencyName
            // 
            this.lblToCurrencyName.ForeColor = System.Drawing.Color.White;
            this.lblToCurrencyName.Location = new System.Drawing.Point(77, 133);
            this.lblToCurrencyName.Name = "lblToCurrencyName";
            this.lblToCurrencyName.Size = new System.Drawing.Size(222, 20);
            this.lblToCurrencyName.TabIndex = 140;
            this.lblToCurrencyName.Text = "N/A";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 20);
            this.label5.TabIndex = 139;
            this.label5.Text = "Name :";
            // 
            // lblToCurrencyRate
            // 
            this.lblToCurrencyRate.ForeColor = System.Drawing.Color.White;
            this.lblToCurrencyRate.Location = new System.Drawing.Point(77, 174);
            this.lblToCurrencyRate.Name = "lblToCurrencyRate";
            this.lblToCurrencyRate.Size = new System.Drawing.Size(79, 20);
            this.lblToCurrencyRate.TabIndex = 138;
            this.lblToCurrencyRate.Text = "N/A";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 174);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 20);
            this.label7.TabIndex = 137;
            this.label7.Text = "Rate :";
            // 
            // cbToCurrency
            // 
            this.cbToCurrency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbToCurrency.FormattingEnabled = true;
            this.cbToCurrency.Location = new System.Drawing.Point(19, 33);
            this.cbToCurrency.Name = "cbToCurrency";
            this.cbToCurrency.Size = new System.Drawing.Size(271, 28);
            this.cbToCurrency.TabIndex = 136;
            this.cbToCurrency.SelectedIndexChanged += new System.EventHandler(this.cbToCurrency_SelectedIndexChanged);
            // 
            // lblToCurrencyCode
            // 
            this.lblToCurrencyCode.AutoSize = true;
            this.lblToCurrencyCode.ForeColor = System.Drawing.Color.White;
            this.lblToCurrencyCode.Location = new System.Drawing.Point(77, 90);
            this.lblToCurrencyCode.Name = "lblToCurrencyCode";
            this.lblToCurrencyCode.Size = new System.Drawing.Size(35, 20);
            this.lblToCurrencyCode.TabIndex = 133;
            this.lblToCurrencyCode.Text = "N/A";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 20);
            this.label9.TabIndex = 132;
            this.label9.Text = "Code :";
            // 
            // lblFromCurrencyExchange
            // 
            this.lblFromCurrencyExchange.AutoEllipsis = true;
            this.lblFromCurrencyExchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFromCurrencyExchange.Location = new System.Drawing.Point(260, 383);
            this.lblFromCurrencyExchange.Name = "lblFromCurrencyExchange";
            this.lblFromCurrencyExchange.Size = new System.Drawing.Size(128, 23);
            this.lblFromCurrencyExchange.TabIndex = 139;
            this.lblFromCurrencyExchange.Text = "N/A";
            this.lblFromCurrencyExchange.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Goldenrod;
            this.label2.Location = new System.Drawing.Point(399, 383);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(21, 24);
            this.label2.TabIndex = 140;
            this.label2.Text = "=";
            // 
            // lblToCurrencyExchange
            // 
            this.lblToCurrencyExchange.AutoEllipsis = true;
            this.lblToCurrencyExchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToCurrencyExchange.Location = new System.Drawing.Point(431, 383);
            this.lblToCurrencyExchange.Name = "lblToCurrencyExchange";
            this.lblToCurrencyExchange.Size = new System.Drawing.Size(128, 23);
            this.lblToCurrencyExchange.TabIndex = 141;
            this.lblToCurrencyExchange.Text = "N/A";
            this.lblToCurrencyExchange.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CurrenciesExchangeScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(805, 450);
            this.Controls.Add(this.lblToCurrencyExchange);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblFromCurrencyExchange);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExchange);
            this.Controls.Add(this.numericUpDown1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "CurrenciesExchangeScreen";
            this.Text = "CurrenciesExchangeScreen";
            this.Load += new System.EventHandler(this.CurrenciesExchangeScreen_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblToCurrencyExchange;

        private System.Windows.Forms.Label lblFromCurrencyExchange;
        private System.Windows.Forms.Label label2;

        private System.Windows.Forms.Label lblFromCurrencyName;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblToCurrencyRate;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbToCurrency;
        private System.Windows.Forms.Label lblToCurrencyCode;
        private System.Windows.Forms.Label label9;

        private System.Windows.Forms.Label lblToCurrencyName;
        private System.Windows.Forms.Label label3;

        private System.Windows.Forms.ComboBox cbFromCurrency;
        private System.Windows.Forms.Label lblFormCurrencyRate;

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblFromCurrencyCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
        private System.Windows.Forms.Button btnExchange;
        private System.Windows.Forms.NumericUpDown numericUpDown1;

        #endregion
    }
}