﻿using System;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Currencies
{
    public partial class CurrenciesScreen : Form
    {
        public CurrenciesScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _CurrencyID = -1;
        private CurrenciesBusinessLayer _Currency1 = null;

        private void CurrenciesScreen_Load(object sender, EventArgs e)
        {
            RefreshData();

            comboBox1.SelectedIndex = 0;
        }

        private void RefreshData()
        {
            _DataTable = CurrenciesBusinessLayer.GetAllCurrencies();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            btnUpdate.Enabled = comboBox1.Enabled = textBox1.Enabled = true;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Currency ID", typeof(int));
            _DataTable.Columns.Add("Country Code", typeof(string));
            _DataTable.Columns.Add("Country Name", typeof(string));
            _DataTable.Columns.Add("Rate", typeof(decimal));

            GridViewCurrenciesList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewCurrenciesList.Rows.Count > 0)
                GridViewCurrenciesList.Rows.RemoveAt(0);

            btnUpdate.Enabled = comboBox1.Enabled = textBox1.Enabled = false;
            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewCurrenciesList.Columns[0].Width = 71;
            GridViewCurrenciesList.Columns[1].Width = 71;
            GridViewCurrenciesList.Columns[2].Width = 131;
            GridViewCurrenciesList.Columns[3].Width = 71;
        }

        private void LoadData(string Type = "Currency ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Currency ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "Unacceptable Key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewCurrenciesList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewCurrenciesList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            UpdateCurrencyInfo(Convert.ToInt32(GridViewCurrenciesList.CurrentRow.Cells[0].Value));

            var fr = new EditCurrencyScreen(_CurrencyID);
            fr.ShowDialog();

            var SelectedIndex = comboBox1.SelectedIndex;
            var Text = textBox1.Text.Trim();

            textBox1.Text = "";

            RefreshData();

            textBox1.Text = Text;
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void UpdateCurrencyInfo(int ID)
        {
            _CurrencyID = ID;
            _Currency1 = CurrenciesBusinessLayer.FindCurrency(_CurrencyID);
        }
    }
}