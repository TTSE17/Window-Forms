﻿using System;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Currencies
{
    public partial class CurrenciesExchangeScreen : Form
    {
        public CurrenciesExchangeScreen()
        {
            InitializeComponent();
        }

        private int _FromCurrencyID = -1;
        private CurrenciesBusinessLayer _FromCurrencyInfo;

        private int _ToCurrencyID = -1;
        private CurrenciesBusinessLayer _ToCurrencyInfo;

        private void CurrenciesExchangeScreen_Load(object sender, EventArgs e)
        {
            numericUpDown1.Enabled = btnExchange.Enabled = false;

            LoadCurrenciesNames();
        }

        private void LoadCurrenciesNames()
        {
            var DT = CurrenciesBusinessLayer.GetAllCurrenciesNames();

            foreach (DataRow row in DT.Rows)
            {
                cbFromCurrency.Items.Add(row[0]);
                cbToCurrency.Items.Add(row[0]);
            }
        }

        private void cbFromCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            _FromCurrencyInfo = CurrenciesBusinessLayer.FindCurrency(cbFromCurrency.Text);
            _FromCurrencyID = _FromCurrencyInfo.CurrencyID;

            _LoadFromCurrencyInfo();
        }

        private void _LoadFromCurrencyInfo()
        {
            lblFromCurrencyCode.Text = _FromCurrencyInfo.CurrencyCode;
            lblFromCurrencyName.Text = _FromCurrencyInfo.CurrencyName;
            lblFormCurrencyRate.Text = Convert.ToString(_FromCurrencyInfo.Rate);
            lblFromCurrencyExchange.Text = numericUpDown1.Value.ToString("0.0") + " " + _FromCurrencyInfo.CurrencyCode;

            CheckSelectFromCurrencyAndToCurrency();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            lblFromCurrencyExchange.Text = numericUpDown1.Value.ToString("0.0") + " " + _FromCurrencyInfo.CurrencyCode;
        }

        private void cbToCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            _ToCurrencyInfo = CurrenciesBusinessLayer.FindCurrency(cbToCurrency.Text);
            _ToCurrencyID = _ToCurrencyInfo.CurrencyID;

            _LoadToCurrencyInfo();
        }

        private void _LoadToCurrencyInfo()
        {
            lblToCurrencyCode.Text = _ToCurrencyInfo.CurrencyCode;
            lblToCurrencyName.Text = _ToCurrencyInfo.CurrencyName;
            lblToCurrencyRate.Text = Convert.ToString(_ToCurrencyInfo.Rate);
            lblToCurrencyExchange.Text = numericUpDown1.Value.ToString("0.0") + " " + _ToCurrencyInfo.CurrencyCode;

            CheckSelectFromCurrencyAndToCurrency();
        }

        private void CheckSelectFromCurrencyAndToCurrency()
        {
            if (_FromCurrencyID == -1 || _ToCurrencyID == -1) return;

            btnExchange.Enabled = numericUpDown1.Enabled = true;
            btnExchange.PerformClick();
        }

        private void btnExchange_Click(object sender, EventArgs e)
        {
            if (_FromCurrencyID == -1 || _ToCurrencyID == -1)
            {
                MessageBox.Show("Please Select A Currency!");
                return;
            }

            var Amount = numericUpDown1.Value;

            lblToCurrencyExchange.Text =
                _FromCurrencyInfo.ConvertToOtherCurrency(Amount, _ToCurrencyInfo).ToString("0.0")
                + " " + _ToCurrencyInfo.CurrencyCode;
        }
    }
}