﻿using System;
using System.Drawing;
using System.Windows.Forms;
using BankSystem.Clients;
using BankSystem.Currencies;
using BankSystem.Transactions;

namespace BankSystem
{
    public partial class MainMenuScreen : Form
    {
        private class BlueRenderer : ToolStripProfessionalRenderer
        {
            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                Color c = Color.Black;
                using (SolidBrush brush = new SolidBrush(c))
                    e.Graphics.FillRectangle(brush, rc);
            }
        }

        private int _Permissions;

        public MainMenuScreen(int Permissions)
        {
            InitializeComponent();

            menuStrip1.Renderer = new BlueRenderer();

            OpenForm.MainPanel = MainContainer;
            OpenForm.LastForm = "";
            OpenForm.activeForm = null;

            _Permissions = Permissions;
        }

        private Form fr;

        private void MainMenuScreen_Load(object sender, EventArgs e)
        {
            // clientsToolStripMenuItem.PerformClick();
        }

        private void clientsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_HasPermission(ref clientsToolStripMenuItem))
            {
                MessageBox.Show("You Don't Have Permission");
                return;
            }

            Form fr = new ClientsScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void depositToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_HasPermission(ref depositToolStripMenuItem))
            {
                MessageBox.Show("You Don't Have Permission");
                return;
            }

            Form fr = new DepositScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void withDrawToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_HasPermission(ref withDrawToolStripMenuItem))
            {
                MessageBox.Show("You Don't Have Permission");
                return;
            }

            Form fr = new WithdrawScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void transferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_HasPermission(ref transferToolStripMenuItem))
            {
                MessageBox.Show("You Don't Have Permission");
                return;
            }

            Form fr = new TransferScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void transferHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_HasPermission(ref transferHistoryToolStripMenuItem))
            {
                MessageBox.Show("You Don't Have Permission");
                return;
            }

            Form fr = new TransfersHistoryScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void currenciesManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_HasPermission(ref currenciesManagementToolStripMenuItem))
            {
                MessageBox.Show("You Don't Have Permission");
                return;
            }

            Form fr = new CurrenciesScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void currenciesExchangeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fr = new CurrenciesExchangeScreen();

            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
            clsGlobal.CurrentUser = null;
        }

        private bool _HasPermission(ref ToolStripMenuItem Section)
        {
            var SectionPermission = Convert.ToInt32(Section.Tag);
            return (SectionPermission & _Permissions) == SectionPermission || _Permissions == -1;
        }
    }
}