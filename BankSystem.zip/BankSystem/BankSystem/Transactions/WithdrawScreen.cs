﻿using System;
using System.Windows.Forms;

namespace BankSystem.Transactions
{
    public partial class WithdrawScreen : Form
    {
        public WithdrawScreen()
        {
            InitializeComponent();
        }

        private void WithdrawScreen_Load(object sender, EventArgs e)
        {
            ctrlSelectClient1.LoadControl(false);
        }
    }
}