﻿using System;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Transactions
{
    public partial class ctrlSelectClient : UserControl
    {
        public ctrlSelectClient()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _ClientID = -1;
        private ClientsBusinessLayer _Client1;

        public void LoadControl(bool status = true)
        {
            btnDeposit.Visible = status;
            btnWithdraw.Visible = !status;

            RefreshData();
            GridViewClientsList.ClearSelection();
        }

        private void RefreshData()
        {
            _DataTable = ClientsBusinessLayer.GetAllClients();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            _DataTable = _DataTable.DefaultView.ToTable(false, "Client ID", "Pin Code", "Balance");

            groupBox1.Enabled = textBox1.Enabled = btnDeposit.Enabled = numericUpDown1.Enabled = true;


            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Client ID", typeof(int));
            _DataTable.Columns.Add("Pin Code", typeof(string));
            _DataTable.Columns.Add("Balance", typeof(decimal));
            GridViewClientsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewClientsList.Rows.Count > 0)
                GridViewClientsList.Rows.RemoveAt(0);

            groupBox1.Enabled = textBox1.Enabled = btnDeposit.Enabled = numericUpDown1.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewClientsList.Columns[0].Width = 71;
            GridViewClientsList.Columns[1].Width = 71;
            GridViewClientsList.Columns[2].Width = 75;
        }

        private void LoadData(string Type = "Client ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Client ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewClientsList.DataSource = _DataView1;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = rbClientID.Checked ? "Client ID" : "Pin Code";
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
            GridViewClientsList.ClearSelection();
        }

        private void rbClientID_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Client ID :";
        }

        private void rbPicCode_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Pin Code :";
        }

        private void GridViewClientsList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                return;
            }

            UpdateClientInfo(Convert.ToInt32(GridViewClientsList.CurrentRow.Cells[0].Value));
            lblClientID.Text = Convert.ToString(_ClientID);
        }

        private void GridViewClientsList_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            GridViewClientsList.ClearSelection();
            lblClientID.Text = "N/A";
        }

        private void btnDepositOrWithdraw_Click(object sender, EventArgs e)
        {
            if (_ClientID == -1)
            {
                MessageBox.Show("Please Select A Client!");
                return;
            }

            var Amount = numericUpDown1.Value;

            if (Amount == 0)
            {
                MessageBox.Show("Please Enter The Amount!");
                return;
            }

            if (!_PerformTransaction(Amount, btnDeposit.Visible))
            {
                MessageBox.Show("You Don't Have Enough In Your Balance");
                return;
            }

            MessageBox.Show("The Operation completed Successfully");

            RefreshData();

            GridViewClientsList.ClearSelection();
            numericUpDown1.Value = 0;
            lblClientID.Text = "N/A";
            _ClientID = -1;
            _Client1 = null;
        }

        private bool _PerformTransaction(decimal Amount, bool status)
        {
            return (status) ? _Client1.Deposit(Amount) : _Client1.Withdraw(Amount);
        }

        private void UpdateClientInfo(int ID)
        {
            _ClientID = ID;
            _Client1 = ClientsBusinessLayer.FindClient(_ClientID);
        }
    }
}