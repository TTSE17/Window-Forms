﻿using System;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Transactions
{
    public partial class TransferScreen : Form
    {
        public TransferScreen()
        {
            InitializeComponent();
        }

        private int _FromClientID = -1;
        private ClientsBusinessLayer _FromClientInfo;

        private int _ToClientID = -1;
        private ClientsBusinessLayer _ToClientInfo;

        private void TransferScreen_Load(object sender, EventArgs e)
        {
            numericUpDown1.Enabled = btnTransfer.Enabled = false;
        }

        private void btnSelectFromClient_Click(object sender, EventArgs e)
        {
            SelectClientScreen fr = new SelectClientScreen();
            fr.DataBack += GetFromClientID;
            fr.ShowDialog();
        }

        private void GetFromClientID(int ClientID)
        {
            _FromClientID = ClientID;
            _FromClientInfo = ClientsBusinessLayer.FindClient(_FromClientID);

            _LoadFromClientInfo();
        }

        private void _LoadFromClientInfo()
        {
            lblFromClientPinCode.Text = _FromClientInfo.PinCode;
            lblFromClientBalance.Text = Convert.ToString(_FromClientInfo.Balance);

            CheckSelectFromClientAndToClient();
        }

        private void btnSelectToClient_Click(object sender, EventArgs e)
        {
            SelectClientScreen fr = new SelectClientScreen();
            fr.DataBack += GetToClientID;
            fr.ShowDialog();
        }

        private void GetToClientID(int ClientID)
        {
            _ToClientID = ClientID;
            _ToClientInfo = ClientsBusinessLayer.FindClient(_ToClientID);

            _LoadToClientInfo();
        }

        private void _LoadToClientInfo()
        {
            lblToClientPinCode.Text = _ToClientInfo.PinCode;
            lblToClientBalance.Text = Convert.ToString(_ToClientInfo.Balance);

            CheckSelectFromClientAndToClient();
        }

        private void CheckSelectFromClientAndToClient()
        {
            if (_FromClientID == -1 || _ToClientID == -1) return;

            btnTransfer.Enabled = numericUpDown1.Enabled = true;
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            if (_FromClientID == -1 || _ToClientID == -1)
            {
                MessageBox.Show("Please Select A Client!");
                return;
            }

            if (_FromClientID == _ToClientID)
            {
                MessageBox.Show("You Selected The Same Client!");
                return;
            }

            var Amount = numericUpDown1.Value;

            if (Amount == 0)
            {
                MessageBox.Show("Please Enter The Amount!");
                return;
            }

            if (!_FromClientInfo.Transfer(Amount, _ToClientInfo, clsGlobal.CurrentUser.UserID))
            {
                MessageBox.Show("You Don't Have Eough in Your Balance");
                return;
            }

            MessageBox.Show("The Opertaion Completed Successfully");

            btnTransfer.Enabled = numericUpDown1.Enabled = false;
            numericUpDown1.Value = 0;

            _LoadFromClientInfo();
            _LoadToClientInfo();
        }
    }
}