﻿using System;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Transactions
{
    public partial class DepositScreen : Form
    {
        public DepositScreen()
        {
            InitializeComponent();
        }

        private void DepositScreen_Load(object sender, EventArgs e)
        {
            ctrlSelectClient1.LoadControl();
        }
    }
}