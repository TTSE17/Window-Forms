﻿using System;
using System.Data;
using System.Windows.Forms;
using BankSystemBusinessLayer;

namespace BankSystem.Transactions
{
    public partial class TransfersHistoryScreen : Form
    {
        public TransfersHistoryScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private void TransfersHistoryScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = TransfersBusinessLayer.GetAllTransfers();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            comboBox1.Enabled = textBox1.Enabled = true;

            comboBox1.SelectedIndex = 0;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Transfer ID", typeof(int));
            _DataTable.Columns.Add("From Client", typeof(string));
            _DataTable.Columns.Add("To Client", typeof(string));
            _DataTable.Columns.Add("Amount", typeof(decimal));
            _DataTable.Columns.Add("Transfer Date", typeof(DateTime));
            _DataTable.Columns.Add("User ID", typeof(int));

            GridViewTransfersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewTransfersList.Rows.Count > 0)
                GridViewTransfersList.Rows.RemoveAt(0);

            comboBox1.Enabled = textBox1.Enabled = false;
            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewTransfersList.Columns[0].Width = 71;
            GridViewTransfersList.Columns[1].Width = 71;
            GridViewTransfersList.Columns[2].Width = 71;
            GridViewTransfersList.Columns[3].Width = 75;
            GridViewTransfersList.Columns[4].Width = 99;
            GridViewTransfersList.Columns[5].Width = 71;
        }

        private void LoadData(string Type = "Transfer ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Transfer ID" || Type == "User ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewTransfersList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewTransfersList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void lblRecords_Click(object sender, EventArgs e)
        {
            GridViewTransfersList.DataSource = TransfersBusinessLayer.GetOneColumn();
        }
    }
}