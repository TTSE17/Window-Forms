﻿using System.ComponentModel;

namespace BankSystem.Transactions
{
    partial class TransferScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblFromClientBalance = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFromClientPinCode = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectFromClient = new System.Windows.Forms.Button();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSelectToClient = new System.Windows.Forms.Button();
            this.lblToClientBalance = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblToClientPinCode = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblFromClientBalance);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblFromClientPinCode);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSelectFromClient);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Goldenrod;
            this.groupBox1.Location = new System.Drawing.Point(54, 53);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 177);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "From Client";
            // 
            // lblFromClientBalance
            // 
            this.lblFromClientBalance.ForeColor = System.Drawing.Color.White;
            this.lblFromClientBalance.Location = new System.Drawing.Point(90, 140);
            this.lblFromClientBalance.Name = "lblFromClientBalance";
            this.lblFromClientBalance.Size = new System.Drawing.Size(79, 20);
            this.lblFromClientBalance.TabIndex = 135;
            this.lblFromClientBalance.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 20);
            this.label3.TabIndex = 134;
            this.label3.Text = "Balance :";
            // 
            // lblFromClientPinCode
            // 
            this.lblFromClientPinCode.AutoSize = true;
            this.lblFromClientPinCode.ForeColor = System.Drawing.Color.White;
            this.lblFromClientPinCode.Location = new System.Drawing.Point(103, 96);
            this.lblFromClientPinCode.Name = "lblFromClientPinCode";
            this.lblFromClientPinCode.Size = new System.Drawing.Size(35, 20);
            this.lblFromClientPinCode.TabIndex = 133;
            this.lblFromClientPinCode.Text = "N/A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 20);
            this.label1.TabIndex = 132;
            this.label1.Text = "Pin Code :";
            // 
            // btnSelectFromClient
            // 
            this.btnSelectFromClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnSelectFromClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectFromClient.FlatAppearance.BorderSize = 0;
            this.btnSelectFromClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectFromClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectFromClient.ForeColor = System.Drawing.Color.White;
            this.btnSelectFromClient.Location = new System.Drawing.Point(31, 31);
            this.btnSelectFromClient.Name = "btnSelectFromClient";
            this.btnSelectFromClient.Size = new System.Drawing.Size(111, 39);
            this.btnSelectFromClient.TabIndex = 131;
            this.btnSelectFromClient.Text = "Select";
            this.btnSelectFromClient.UseVisualStyleBackColor = false;
            this.btnSelectFromClient.Click += new System.EventHandler(this.btnSelectFromClient_Click);
            // 
            // btnTransfer
            // 
            this.btnTransfer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnTransfer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTransfer.FlatAppearance.BorderSize = 0;
            this.btnTransfer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransfer.ForeColor = System.Drawing.Color.White;
            this.btnTransfer.Location = new System.Drawing.Point(244, 315);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(126, 39);
            this.btnTransfer.TabIndex = 131;
            this.btnTransfer.Text = "Transfer";
            this.btnTransfer.UseVisualStyleBackColor = false;
            this.btnTransfer.Click += new System.EventHandler(this.btnTransfer_Click);
            // 
            // dataGridTextBoxColumn1
            // 
            this.dataGridTextBoxColumn1.Format = "";
            this.dataGridTextBoxColumn1.FormatInfo = null;
            this.dataGridTextBoxColumn1.Width = -1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnSelectToClient);
            this.groupBox2.Controls.Add(this.lblToClientBalance);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.lblToClientPinCode);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Goldenrod;
            this.groupBox2.Location = new System.Drawing.Point(374, 53);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(175, 177);
            this.groupBox2.TabIndex = 132;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "To Client";
            // 
            // btnSelectToClient
            // 
            this.btnSelectToClient.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnSelectToClient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectToClient.FlatAppearance.BorderSize = 0;
            this.btnSelectToClient.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectToClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectToClient.ForeColor = System.Drawing.Color.White;
            this.btnSelectToClient.Location = new System.Drawing.Point(37, 31);
            this.btnSelectToClient.Name = "btnSelectToClient";
            this.btnSelectToClient.Size = new System.Drawing.Size(111, 39);
            this.btnSelectToClient.TabIndex = 136;
            this.btnSelectToClient.Text = "Select";
            this.btnSelectToClient.UseVisualStyleBackColor = false;
            this.btnSelectToClient.Click += new System.EventHandler(this.btnSelectToClient_Click);
            // 
            // lblToClientBalance
            // 
            this.lblToClientBalance.ForeColor = System.Drawing.Color.White;
            this.lblToClientBalance.Location = new System.Drawing.Point(90, 140);
            this.lblToClientBalance.Name = "lblToClientBalance";
            this.lblToClientBalance.Size = new System.Drawing.Size(79, 20);
            this.lblToClientBalance.TabIndex = 135;
            this.lblToClientBalance.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 20);
            this.label4.TabIndex = 134;
            this.label4.Text = "Balance :";
            // 
            // lblToClientPinCode
            // 
            this.lblToClientPinCode.AutoSize = true;
            this.lblToClientPinCode.ForeColor = System.Drawing.Color.White;
            this.lblToClientPinCode.Location = new System.Drawing.Point(103, 96);
            this.lblToClientPinCode.Name = "lblToClientPinCode";
            this.lblToClientPinCode.Size = new System.Drawing.Size(35, 20);
            this.lblToClientPinCode.TabIndex = 133;
            this.lblToClientPinCode.Text = "N/A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 96);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 20);
            this.label6.TabIndex = 132;
            this.label6.Text = "Pin Code :";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 1;
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numericUpDown1.Location = new System.Drawing.Point(244, 260);
            this.numericUpDown1.Maximum = new decimal(new int[] { 9999999, 0, 0, 0 });
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(126, 24);
            this.numericUpDown1.TabIndex = 133;
            // 
            // TransferScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Navy;
            this.ClientSize = new System.Drawing.Size(594, 396);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.groupBox1);
            this.Name = "TransferScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TransferScreen";
            this.Load += new System.EventHandler(this.TransferScreen_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button button1;

        private System.Windows.Forms.Label lblFromClientPinCode;
        private System.Windows.Forms.Label lblFromClientBalance;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblToClientBalance;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblToClientPinCode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDown1;

        private System.Windows.Forms.Button btnTransfer;
        private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
        private System.Windows.Forms.Label label1;

        private System.Windows.Forms.Button btnSelectFromClient;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSelectToClient;

        private System.Windows.Forms.GroupBox groupBox1;

        #endregion
    }
}