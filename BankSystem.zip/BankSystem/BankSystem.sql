--ALTER TABLE Clients
--ADD CONSTRAINT FK_PersonClient
--FOREIGN KEY (PersonID) REFERENCES People(PersonID);


select * from people;

select * from clients;

select 'Client ID'=ClientID ,'Pin Code'=PinCode ,'First Name'=FirstName ,'Last Name'=LastName ,
Balance , Email , Phone ,'Date Of Birth'=DateOfBirth from Clients
Inner Join People On People.PersonID = Clients.PersonID;

select * from Transfers;


select TransferID,'From Client' = (select PinCode from Clients Where Clients.ClientID=FromClientID) , 
       'To Clien'=(select PinCode from Clients Where Clients.ClientID=ToClientID),
	    Amount ,TransferDate ,ByUserID from Transfers;


select 'User ID'=UserID ,'User Name'=UserName,Password,Permissions ,
                        'First Name'=FirstName,'Last Name'=LastName , Email , Phone ,
                        'Date Of Birth'=DateOfBirth from Users
                        Inner Join People On People.PersonID = Users.PersonID