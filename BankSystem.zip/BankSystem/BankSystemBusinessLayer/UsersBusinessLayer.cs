﻿using System.Data;
using BankSystemDataAccessLayer;


namespace BankSystemBusinessLayer
{
    public class UsersBusinessLayer : PeopleBusinessLayer
    {
        public int UserID { get; set; }

        public string UserName { get; set; }
        public string Password { get; set; }
        public int Permissions { get; set; }


        public UsersBusinessLayer()
        {
            UserID = PersonID = -1;
            Permissions = 0;
            UserName = ImagePath = "";
        }

        private UsersBusinessLayer(int UserId, string userName, string password, int permissions, int personId)
        {
            UserID = UserId;
            UserName = userName;
            Password = password;
            Permissions = permissions;
            PersonID = personId;
            var PersonInfo = FindPerson(PersonID);
            FirstName = PersonInfo.FirstName;
            LastName = PersonInfo.LastName;
            Email = PersonInfo.Email;
            Phone = PersonInfo.Phone;
            DateOfBirth = PersonInfo.DateOfBirth;
            ImagePath = PersonInfo.ImagePath;
        }

        public static DataTable GetAllUsers()
        {
            return UsersDataAccessLayer.GetAllUsers();
        }

        public static bool IsFound(string UserName, string Password)
        {
            return UsersDataAccessLayer.IsFound(UserName, Password);
        }

        public static UsersBusinessLayer FindUser(int ID)
        {
            string userName = "", password = "";
            var permissions = -1;
            var personID = -1;

            if (UsersDataAccessLayer.GetUserByID(ID, ref userName, ref password, ref permissions, ref personID))
                return new UsersBusinessLayer(ID, userName, password, permissions, personID);

            return null;
        }

        public static UsersBusinessLayer FindUser(string userName)
        {
            var password = "";
            int userID = -1, permissions = -1, personID = -1;

            if (UsersDataAccessLayer.GetUserByUserName(ref userID, userName, ref password,
                    ref permissions, ref personID))
                return new UsersBusinessLayer(userID, userName, password, permissions, personID);

            return null;
        }


        private int _AddNewUser()
        {
            return UsersDataAccessLayer.AddNewUser(UserName, Password, Permissions, PersonID);
        }

        private bool _UpdateUser()
        {
            return UsersDataAccessLayer.UpdateUser(UserID, UserName, Password, Permissions, PersonID);
        }

        public bool Save()
        {
            if (!base.Save())
                return false;

            if (this.UserID != -1) return _UpdateUser();

            UserID = _AddNewUser();
            return true;
        }

        public bool Delete()
        {
            var IsUserDeleted = UsersDataAccessLayer.DeleteUser(UserID);


            if (!IsUserDeleted)
                return false;

            var IsPersonDeleted = DeletePerson(PersonID);
            return IsPersonDeleted;
        }

        public static bool ExistUserName(string userName)
        {
            return UsersDataAccessLayer.ExistUserName(userName);
        }
    }
}