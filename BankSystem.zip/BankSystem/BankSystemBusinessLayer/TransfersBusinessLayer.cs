﻿using System;
using System.Data;
using BankSystemDataAccessLayer;

namespace BankSystemBusinessLayer
{
    public class TransfersBusinessLayer
    {
        public int TransferID { get; set; }
        public int FromClientID { get; set; }
        public ClientsBusinessLayer FromClientInfo;
        public int ToClientID { get; set; }
        public ClientsBusinessLayer ToClientInfo;
        public decimal Amount { get; set; }
        public DateTime TransferDate { get; set; }

        public int ByUserID { get; set; }
        // public UsersBusinessLayer UserInfo

        public TransfersBusinessLayer()
        {
            TransferID = FromClientID = ToClientID = ByUserID = -1;
            FromClientInfo = ToClientInfo = new ClientsBusinessLayer();
        }

        private TransfersBusinessLayer(int transferId, int fromClientId, int toClientId,
            decimal amount, DateTime transferDate, int byUserId)
        {
            TransferID = transferId;
            FromClientID = fromClientId;
            FromClientInfo = ClientsBusinessLayer.FindClient(FromClientID);
            ToClientID = toClientId;
            ToClientInfo = ClientsBusinessLayer.FindClient(ToClientID);
            Amount = amount;
            TransferDate = transferDate;
            ByUserID = byUserId;
            // UserInfo = UsersBusinessLayer.FincUser(ByUserID);
        }

        public static DataTable GetAllTransfers()
        {
            return TransfersDataAccessLayer.GetAllTransfers();
        }

        private int _AddNewTransfer()
        {
            return TransfersDataAccessLayer.AddNewTransfer(FromClientID, ToClientID, Amount, TransferDate, ByUserID);
        }

        public bool Save()
        {
            TransferID = _AddNewTransfer();
            return true;
        }

        public static DataTable GetOneColumn()
        {
            return TransfersDataAccessLayer.GetOneColumn();
        }
    }
}