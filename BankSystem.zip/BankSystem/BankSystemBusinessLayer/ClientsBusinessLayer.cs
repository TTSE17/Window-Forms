﻿using System;
using System.Data;
using BankSystemDataAccessLayer;

namespace BankSystemBusinessLayer
{
    public class ClientsBusinessLayer : PeopleBusinessLayer
    {
        public int ClientID { get; set; }

        public string PinCode { get; set; }
        public decimal Balance { get; set; }


        public ClientsBusinessLayer()
        {
            ClientID = PersonID = -1;
            Balance = 0;
            ImagePath = "";
        }

        private ClientsBusinessLayer(int ClientId, string pinCode, decimal balance, int personId)
        {
            ClientID = ClientId;
            PinCode = pinCode;
            Balance = balance;
            PersonID = personId;
            var PersonInfo = FindPerson(PersonID);
            FirstName = PersonInfo.FirstName;
            LastName = PersonInfo.LastName;
            Email = PersonInfo.Email;
            Phone = PersonInfo.Phone;
            DateOfBirth = PersonInfo.DateOfBirth;
            ImagePath = PersonInfo.ImagePath;
        }

        public static DataTable GetAllClients()
        {
            return ClientsDataAccessLayer.GetAllClients();
        }

        // public static DataTable GetAllClientsNames()
        // {
        //     return ClientsDataAccessLayer.GetAllClientsNames();
        // }
        //
        // public static DataTable GetAllClientCourses(int ClientID)
        // {
        //     return ClientsDataAccessLayer.GetAllClientCourses(ClientID);
        // }

        public static ClientsBusinessLayer FindClient(int ID)
        {
            var pinCode = "";
            decimal balance = -1;
            var personID = -1;

            if (ClientsDataAccessLayer.GetClientByID(ID, ref pinCode, ref balance, ref personID))
                return new ClientsBusinessLayer(ID, pinCode, balance, personID);

            return null;
        }

        public static ClientsBusinessLayer FindClient(string pinCode)
        {
            decimal balance = -1;
            var personID = -1;
            var ClientID = -1;

            if (ClientsDataAccessLayer.GetClientByPinCode(pinCode, ref ClientID, ref balance, ref personID))
                return new ClientsBusinessLayer(ClientID, pinCode, balance, personID);

            return null;
        }

        private int _AddNewClient()
        {
            return ClientsDataAccessLayer.AddNewClient(PinCode, Balance, PersonID);
        }

        private bool _UpdateClient()
        {
            return ClientsDataAccessLayer.UpdateClient(ClientID, PinCode, Balance, PersonID);
        }

        public bool Save()
        {
            if (!base.Save())
                return false;

            if (this.ClientID != -1) return _UpdateClient();

            ClientID = _AddNewClient();
            return true;
        }

        public bool Delete()
        {
            var IsClientDeleted = ClientsDataAccessLayer.DeleteClient(ClientID);


            if (!IsClientDeleted)
                return false;

            var IsPersonDeleted = DeletePerson(PersonID);
            return IsPersonDeleted;
        }

        public static bool ExistPinCode(string pinCode)
        {
            return ClientsDataAccessLayer.ExistPinCode(pinCode);
        }

        public bool Deposit(decimal Amount)
        {
            Balance += Amount;
            Save();

            return true;
        }

        public bool Withdraw(decimal Amount)
        {
            if (Amount > Balance)
                return false;

            Balance -= Amount;
            Save();
            return true;
        }

        public bool Transfer(decimal Amount, ClientsBusinessLayer DestinationClient, int UserID)
        {
            if (Amount > Balance) return false;

            Withdraw(Amount);
            DestinationClient.Deposit(Amount);

            var _Transfer1 = new TransfersBusinessLayer
            {
                FromClientID = ClientID,
                ToClientID = DestinationClient.ClientID,
                Amount = Amount,
                TransferDate = DateTime.Now,
                ByUserID = UserID
            };

            return _Transfer1.Save();
        }
    }
}