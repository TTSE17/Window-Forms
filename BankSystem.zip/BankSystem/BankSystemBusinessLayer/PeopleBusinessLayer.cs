﻿using System;
using System.Data;
using BankSystemDataAccessLayer;

namespace BankSystemBusinessLayer
{
    public class PeopleBusinessLayer
    {
        public int PersonID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string ImagePath { get; set; }

        public PeopleBusinessLayer()
        {
            PersonID = -1;
        }

        private PeopleBusinessLayer(int personID, string firstName, string lastName, string email,
            string phone, DateTime dateOfBirth, string imagePath)
        {
            PersonID = personID;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Phone = phone;
            DateOfBirth = dateOfBirth;
            ImagePath = imagePath;
        }


        public static DataTable GetAllPeople()
        {
            return PeopleDataAccessLayer.GetAllPeople();
        }

        public static PeopleBusinessLayer FindPerson(int ID)
        {
            string firstName = "", lastName = "", email = "", phone = "", imagePath = "";
            var dateOfBirth = default(DateTime);

            if (PeopleDataAccessLayer.GetPersonByID(ID, ref firstName, ref lastName, ref email, ref phone,
                    ref dateOfBirth, ref imagePath))
                return new PeopleBusinessLayer(ID, firstName, lastName, email, phone, dateOfBirth, imagePath);

            return null;
        }

        private int _AddNewPerson()
        {
            return PeopleDataAccessLayer.AddNewPerson(FirstName, LastName, Email, Phone, DateOfBirth, ImagePath);
        }

        private bool _UpdatePerson()
        {
            return PeopleDataAccessLayer.UpdatePerson(PersonID, FirstName, LastName, Email, Phone,
                DateOfBirth, ImagePath);
        }

        public bool Save()
        {
            if (this.PersonID != -1) return _UpdatePerson();

            PersonID = _AddNewPerson();
            return true;
        }

        public bool DeletePerson(int ID)
        {
            return PeopleDataAccessLayer.DeletePerson(ID);
        }
    }
}