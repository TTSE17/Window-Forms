﻿using System.Data;
using BankSystemDataAccessLayer;

namespace BankSystemBusinessLayer
{
    public class CurrenciesBusinessLayer
    {
        public int CurrencyID { get; set; }
        public string CurrencyCode { get; set; }
        public string CurrencyName { get; set; }
        public decimal Rate { get; set; }

        private CurrenciesBusinessLayer(int currencyId, string currencyCode, string currencyName, decimal rate)
        {
            CurrencyID = currencyId;
            CurrencyCode = currencyCode;
            CurrencyName = currencyName;
            Rate = rate;
        }

        public static DataTable GetAllCurrencies()
        {
            return CurrenciesDataAccessLayer.GetAllCurrencies();
        }

        public static DataTable GetAllCurrenciesNames()
        {
            return CurrenciesDataAccessLayer.GetAllCurrenciesNames();
        }

        public static CurrenciesBusinessLayer FindCurrency(int ID)
        {
            string CurrencyCode = "", CurrencyName = "";
            decimal rate = 0;

            if (CurrenciesDataAccessLayer.GetCurrencyByID(ID, ref CurrencyCode, ref CurrencyName, ref rate))
                return new CurrenciesBusinessLayer(ID, CurrencyCode, CurrencyName, rate);

            return null;
        }

        public static CurrenciesBusinessLayer FindCurrency(string Name)
        {
            var cuurencyID = -1;
            var CurrencyCode = "";
            decimal rate = 0;

            if (CurrenciesDataAccessLayer.GetCurrencyByName(ref cuurencyID, ref CurrencyCode, Name, ref rate))
                return new CurrenciesBusinessLayer(cuurencyID, CurrencyCode, Name, rate);

            return null;
        }


        private bool _UpdateCurrency()
        {
            return CurrenciesDataAccessLayer.UpdateCurrency(CurrencyID, CurrencyCode, CurrencyName, Rate);
        }

        public bool Save()
        {
            return _UpdateCurrency();
        }

        private decimal ConvertToUSD(decimal Amount)
        {
            return Amount / Rate;
        }

        public decimal ConvertToOtherCurrency(decimal Amount, CurrenciesBusinessLayer Currency2)
        {
            var AmountInUSD = ConvertToUSD(Amount);

            if (Currency2.CurrencyCode.Contains("USD"))
            {
                return AmountInUSD;
            }

            return AmountInUSD * Currency2.Rate;
        }
    }
}