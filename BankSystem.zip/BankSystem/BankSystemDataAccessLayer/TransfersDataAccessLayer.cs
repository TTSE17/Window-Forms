﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BankSystemDataAccessLayer
{
    public class TransfersDataAccessLayer
    {
        public static DataTable GetAllTransfers()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select 'Transfer ID'=TransferID,'From Client' = (Select PinCode From Clients Where Clients.ClientID=FromClientID) , 
                             'To Client'=(Select PinCode From Clients Where Clients.ClientID=ToClientID),
	                          Amount ,'Transfer Date'=TransferDate ,'User ID'=ByUserID from Transfers;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable GetOneColumn()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = String.Format(@"Select * from Transfers Where {0}={1}","TransferID","7");

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static int AddNewTransfer(int fromClientId, int toClientId,
            decimal amount, DateTime transferDate, int byUserId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Transfers
                             VALUES (@fromClientId,@toClientId,@amount,@transferDate,@byUserId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@fromClientId", fromClientId);
            command.Parameters.AddWithValue("@toClientId", toClientId);
            command.Parameters.AddWithValue("@amount", amount);
            command.Parameters.AddWithValue("@transferDate", transferDate);
            command.Parameters.AddWithValue("@byUserId", byUserId);
            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }
    }
}