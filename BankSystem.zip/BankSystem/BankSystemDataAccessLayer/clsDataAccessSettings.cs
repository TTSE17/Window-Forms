﻿namespace BankSystemDataAccessLayer
{
    public class clsDataAccessSettings
    {
        public const string ConnectionString = " ";
    }
}