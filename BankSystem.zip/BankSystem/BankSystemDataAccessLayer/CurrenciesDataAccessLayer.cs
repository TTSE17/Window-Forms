﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BankSystemDataAccessLayer
{
    public static class CurrenciesDataAccessLayer
    {
        public static DataTable GetAllCurrencies()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select 'Currency ID'=CurrencyID , 'Currency Code'=CurrencyCode,
                                    'Currency Name' =CurrencyName ,Rate   From Currencies;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable GetAllCurrenciesNames()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select CurrencyName From Currencies Order BY CurrencyName;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetCurrencyByID(int ID, ref string CurrencyCode, ref string CurrencyName, ref decimal rate)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Currencies Where CurrencyID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    CurrencyCode = Convert.ToString(reader[1]);
                    CurrencyName = Convert.ToString(reader[2]);
                    rate = Convert.ToDecimal(reader[3]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetCurrencyByName(ref int CurrencyID, ref string CurrencyCode, string CurrencyName,
            ref decimal rate)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Currencies Where CurrencyName=@CurrencyName";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@CurrencyName", CurrencyName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    CurrencyID = Convert.ToInt32(reader[0]);
                    CurrencyCode = Convert.ToString(reader[1]);
                    rate = Convert.ToDecimal(reader[3]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }
        
        public static bool UpdateCurrency(int CurrencyId, string CurrencyCode, string CurrencyName, decimal Rate)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Currencies
                            set CurrencyCode=@CurrencyCode,CurrencyName=@CurrencyName,Rate=@Rate
                            where CurrencyId = @CurrencyId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@CurrencyId", CurrencyId);
            command.Parameters.AddWithValue("@CurrencyCode", CurrencyCode);
            command.Parameters.AddWithValue("@CurrencyName", CurrencyName);
            command.Parameters.AddWithValue("@Rate", Rate);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }
    }
}