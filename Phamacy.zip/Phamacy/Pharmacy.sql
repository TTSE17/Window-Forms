/*

SQL Server does not allow to update the identity column unlike what you can do with other columns with an update statement.

*/

use Pharmacy;

--use Pharmacy EXEC sp_changedbowner 'sa'

Select * From Categories;

Select 'ID' = CategoryID , Type = CategoryName From Categories

Select * From Pharmacists;

Select * From Dealers;

--Delete  From Dealers;
 --DBCC CHECKIDENT (Dealers, RESEED,0);

Select * From Medicines;

--Delete  From Medicines;
 --DBCC CHECKIDENT (Medicines, RESEED,0);

 Declare @OrderID INt = NULL;

		Select 'Medicine ID' = MedicineID , 'Medicine Name' = MedicineName ,
          Category =(Select CategoryName From Categories Where Categories.CategoryID=Medicines.CategoryID),
		  Quantity , ExpirationDate ,Price = cast(Price as decimal(10,2)),
          Selected = (Select Count(1) From OrdersDetails Where OrdersDetails.MedicineID=Medicines.MedicineID),
		  'Required Quantity'= IsNull((Select RequiredQuantity From OrdersDetails Where
										OrdersDetails.MedicineID= Medicines.MedicineID ANd OrderID=ISNULL(@OrderID,OrderID)),0)
        From Medicines  Where DealerID  = DealerID ;

Select * From Orders;

--Delete  From Orders Where OrderID=2;
 --DBCC CHECKIDENT (Orders, RESEED,0);

Select 'Order ID'=OrderID ,Status ,'IsPaid'= Case When Paid = 1 then 'Yes' Else 'No' End,
     OrderDate ,'Medicines'=(Select Count(1) From OrdersDetails Where Orders.OrderID=OrdersDetails.OrderID)
     From Orders
     Inner Join Pharmacists on Pharmacists.PharmacistID =Orders.PharmacistID
      where Orders.PharmacistID  = isnull(1,Orders.PharmacistID)

--ALTER TABLE orders ADD DEFAULT 'Preparing' FOR Status;

Select * From OrdersDetails;

EXEC SP_IsDealerExists @DealerName = 'dd' , @Password='55555';

EXEC SP_GetDealerByID @DealerID=41;

EXEC SP_GetDealerByDealerName @DealerName='Tha';

EXEC SP_AddNewDealer @DealerName='Ali' ,@Password='99999';

Exec SP_UpdateDealer @DealerName ='TAHA' , @Password='77777' , @DealerId=1;

Exec SP_ExistDealerName @DealerName ='JaMAL';

/*

Pharmacist : Not Selected && Required Quantity
Dealers : Not Dealer Name && Required Quantity
Orders : Not Selected && Dealer Name 

*/

Exec SP_GetAllMedicines @DealerID=null;
Exec SP_GetAllMedicines 1;
Exec SP_GetAllMedicines @DealerID=null , @orderId=null;

Select 'Medicine ID' = MedicineID , 'Medicine Name' = MedicineName ,
		Category =(Select CategoryName From Categories Where Categories.CategoryID=Medicines.CategoryID),
		Quantity , ExpirationDate ,Price = cast(Price as decimal(10,2)),
		'Dealer Name'=(Select DealerName From Dealers Where Dealers.DealerID=Medicines.DealerID),
		Selected = (Select Count(1) From OrdersDetails Where OrdersDetails.MedicineID=Medicines.MedicineID),
		'Required Quantity'= ISNULL((Select Top 1 RequiredQuantity From OrdersDetails Where
									OrdersDetails.MedicineID= Medicines.MedicineID AND OrderID=ISNULL(1,OrderID)),0)
From Medicines  Where DealerID  = ISNULL(1,DealerID) Order By [Required Quantity] DESC , Selected DESC;

Select * From Orders;
Select * From OrdersDetails;
Select * From Orders Inner Join OrdersDetails On Orders.OrderID=OrdersDetails.OrderID;
Select * From Medicines;
Select * From Medicines Inner Join OrdersDetails On OrdersDetails.MedicineID=Medicines.MedicineID;

Exec SP_GetAllCategories ;

Exec SP_GetMedicineByMedicineID @MedicineID=1;

Exec SP_ExistMedicineName @MedicineName='A';

Exec SP_AddNewMedicine @MedicineName='M3' ,@CategoryID=1 ,
         @Quantity ='111' ,@ExpirationDate ='2033/3/3' , @Price =2500.5, @DealerID=1;

Exec SP_UpdateMedicine @MedicineID=1,  @MedicineName='M' ,@CategoryID='1' ,
         @Quantity ='111' ,@ExpirationDate ='2033/3/3' , @Price =250.5, @DealerID=1 

Exec SP_DeleteMedicine @MedicineID =-1;

Exec SP_GetPharmacistByID @PharmacistID=1;

Exec SP_ExistPharmacistPhone @Phone ='A';

Exec SP_IsPharmacistExists @phone ='a' , @Password ='a';

Exec SP_GetPharmacistByPharmacistPhone @Phone ='77777';

Exec SP_GetAllOrders @PharmacistID = 1 , @DealerID=null;
Exec SP_GetAllOrders null , 1;

Exec SP_GetAllDealers;

EXEC SP_AddNewOrder @PharmacistID =1 , @DealerID=1;

Exec SP_AddNewOrderDetails @RequiredQuantity = 11, @price =1, @orderId=1, @medicineId= 1;

Exec SP_GetOrderByID 1;

Exec SP_DeleteOrderDetailsByOrderID @orderId=1;

EXEC SP_UpdateOrder @orderId =1 ,@Status='Preparing',@Paid=1, @DealerID=1;

EXEC SP_DeleteOrder 4;