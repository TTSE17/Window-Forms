﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer;

public class MedicinesDataAccessLayer
{
    public static DataTable GetAllMedicines(int? DealerID, int?OrderID)
    {
        DataTable dt = new DataTable();

        try
        {
            using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
            {
                string Query = @"Exec SP_GetAllMedicines @DealerID=@DealerID,@OrderID=@OrderID;";

                using (SqlCommand command = new SqlCommand(Query, connection))
                {
                    command.Parameters.AddWithValue("@DealerID", DealerID.HasValue ? DealerID.Value : DBNull.Value);
                    command.Parameters.AddWithValue("@OrderID", OrderID.HasValue ? OrderID.Value : DBNull.Value);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            dt.Load(reader);
                        }
                        else
                        {
                            var tableSchema = reader.GetSchemaTable();

                            foreach (DataRow row in tableSchema.Rows)
                            {
                                dt.Columns.Add(row["ColumnName"].ToString());
                            }
                        }
                    }
                }
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }

        return dt;
    }

    public static bool GetMedicineByMedicineID(int medicineID, ref string medicineName, ref int categoryID,
        ref int quantity, ref DateTime expirationDate, ref decimal price, ref int dealerID)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = "Exec SP_GetMedicineByMedicineID @MedicineID=@MedicineID";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@MedicineID", medicineID);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isFound = true;
                medicineName = Convert.ToString(reader[1]);
                categoryID = Convert.ToInt32(reader[2]);
                quantity = Convert.ToInt32(reader[3]);
                expirationDate = Convert.ToDateTime(reader[4]);
                price = Convert.ToDecimal(reader[5]);
                dealerID = Convert.ToInt32(reader[6]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isFound = false;
        }
        finally
        {
            connection.Close();
        }

        return isFound;
    }

    public static int AddNewMedicine(string medicineName, int categoryID,
        int quantity, DateTime expirationDate, decimal price, int dealerID)
    {
        int Id = 0;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"Exec SP_AddNewMedicine @MedicineName=@medicineName ,@CategoryID=@categoryID ,
                            @Quantity =@quantity,@ExpirationDate =@expirationDate, @Price =@price, @DealerID=@dealerID;";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@medicineName", medicineName);
        command.Parameters.AddWithValue("@categoryID", categoryID);
        command.Parameters.AddWithValue("@quantity", quantity);
        command.Parameters.AddWithValue("@expirationDate", expirationDate);
        command.Parameters.AddWithValue("@price", price);
        command.Parameters.AddWithValue("@dealerID", dealerID);

        try
        {
            connection.Open();
            var result = command.ExecuteScalar();

            if (result != null && int.TryParse(result.ToString(), out int insertedID))
            {
                Id = insertedID;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
        }
        finally
        {
            connection.Close();
        }

        return Id;
    }

    public static bool UpdateMedicine(int MedicineID, string medicineName, int categoryID,
        int quantity, DateTime expirationDate, decimal price, int dealerID)
    {
        bool isUpdated = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"Exec SP_UpdateMedicine @MedicineID=@MedicineID, @MedicineName=@medicineName , 
                                    @CategoryID=@categoryID , @Quantity =@quantity,@ExpirationDate =@expirationDate,
                                    @Price =@price, @DealerID=@dealerID ";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@MedicineID", MedicineID);
        command.Parameters.AddWithValue("@medicineName", medicineName);
        command.Parameters.AddWithValue("@categoryID", categoryID);
        command.Parameters.AddWithValue("@quantity", quantity);
        command.Parameters.AddWithValue("@expirationDate", expirationDate);
        command.Parameters.AddWithValue("@price", price);
        command.Parameters.AddWithValue("@dealerID", dealerID);

        try
        {
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();

            isUpdated = rowsAffected > 0;

            connection.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex + "");
            isUpdated = false;
        }

        finally
        {
            connection.Close();
        }

        return isUpdated;
    }

    public static bool DeleteMedicine(int MedicineID)
    {
        bool isDeleted;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @"Exec SP_DeleteMedicine @MedicineID = @MedicineID";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@MedicineID", MedicineID);

        try
        {
            connection.Open();
            var rows = command.ExecuteNonQuery();
            isDeleted = rows > 0;
        }
        catch (Exception e)
        {
            // MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }

    public static bool ExistMedicineName(string MedicineName)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"Exec SP_ExistMedicineName @MedicineName = @MedicineName";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@MedicineName", MedicineName);

        try
        {
            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                isFound = reader.HasRows;
            }

            connection.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex + "");
            isFound = false;
        }

        finally
        {
            connection.Close();
        }

        return isFound;
    }
}