﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer;

public class OrdersDataAccessLayer
{
    public static DataTable GetAllOrders(int? PharmacistID, int? DealerID)
    {
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @"SP_GetAllOrders @PharmacistID = @PharmacistID , @DealerID = @DealerID;";

        DataTable dt = new DataTable();

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@PharmacistID", PharmacistID.HasValue ? PharmacistID : DBNull.Value);
        command.Parameters.AddWithValue("@DealerID", DealerID.HasValue ? DealerID : DBNull.Value);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                dt.Load(reader);
            }

            else
            {
                var tableSchema = reader.GetSchemaTable();

                foreach (DataRow row in tableSchema.Rows)
                {
                    dt.Columns.Add(row["ColumnName"].ToString());
                }
            }

            reader.Close();
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }
        finally
        {
            connection.Close();
        }

        return dt;
    }

    public static int AddNewOrder(int PharmacistID, int DealerID)
    {
        int Id = 0;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"EXEC SP_AddNewOrder @PharmacistID = @PharmacistID , @DealerID=@DealerID";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@PharmacistID", PharmacistID);
        command.Parameters.AddWithValue("@DealerID", DealerID);

        try
        {
            connection.Open();
            var result = command.ExecuteScalar();

            if (result != null && int.TryParse(result.ToString(), out int insertedID))
            {
                Id = insertedID;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
        }
        finally
        {
            connection.Close();
        }

        return Id;
    }

    public static bool UpdateOrder(int? OrderID,string Status, bool Paid, int DealerID)
    {
        bool isUpdated = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"SP_UpdateOrder @orderId =@orderId ,@Status=@Status,@Paid=@Paid, @DealerID=@DealerID";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@OrderID", OrderID);
        command.Parameters.AddWithValue("@Status", Status);
        command.Parameters.AddWithValue("@Paid", Paid);
        command.Parameters.AddWithValue("@DealerID", DealerID);

        try
        {
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();

            isUpdated = rowsAffected > 0;

            connection.Close();
        }
        catch (Exception ex)
        {
            // MessageBox.Show(ex + "");
            isUpdated = false;
        }

        finally
        {
            connection.Close();
        }

        // MessageBox.Show(isUpdated + "");
        return isUpdated;
    }

    public static bool GetOrderByID(int? orderID, ref int PharmacistID, ref string Status, ref bool Paid,
        ref DateTime orderDate, ref int DealerID)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = "Exec SP_GetOrderByID @orderID";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@orderID", orderID);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isFound = true;
                PharmacistID = Convert.ToInt32(reader[1]);
                Status = Convert.ToString(reader[2]);
                Paid = Convert.ToBoolean(reader[3]);
                orderDate = Convert.ToDateTime(reader[4]);
                DealerID = Convert.ToInt32(reader[5]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isFound = false;
        }
        finally
        {
            connection.Close();
        }

        return isFound;
    }

    public static bool DeleteOrder(int OrderID)
    {
        bool isDeleted = false;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @"EXEC SP_DeleteOrder @OrderID ;";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@OrderID", OrderID);

        try
        {
            connection.Open();
            var rows = command.ExecuteNonQuery();
            isDeleted = rows > 0;
        }
        catch (Exception e)
        {
            // MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }


    public static bool GetOrderByDescription(ref int OrderID, string OrderDescription)
    {
        bool isDeleted = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = "Select * from Orders Where OrderDescription=@OrderDescription";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@OrderDescription", OrderDescription);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isDeleted = true;
                OrderID = Convert.ToInt32(reader[1]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }
}