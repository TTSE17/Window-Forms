﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer;
public class CategoriesDataAccessLayer
{
    public static DataTable GetAllCategories() // SP
    {
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string Query = "Select 'ID' = CategoryID , Type = CategoryName From Categories Order By ID";
        
        string Query = "Exec SP_GetAllCategories ;";

        DataTable dt = new DataTable();

        SqlCommand command = new SqlCommand(Query, connection);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                dt.Load(reader);
            }

            reader.Close();
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }
        finally
        {
            connection.Close();
        }

        return dt;
    }

    public static int AddNewCategory(string CategoryName)
    {
        int Id = 0;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"INSERT INTO Categories VALUES (@CategoryName);
                             SELECT SCOPE_IDENTITY();";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@CategoryName", CategoryName);

        try
        {
            connection.Open();
            var result = command.ExecuteScalar();

            if (result != null && int.TryParse(result.ToString(), out int insertedID))
            {
                Id = insertedID;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
        }
        finally
        {
            connection.Close();
        }

        return Id;
    }

    public static bool UpdateCategory(int categoryID, string CategoryName)
    {
        bool isUpdated = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"Update Categories
                            set CategoryName=@CategoryName
                            where categoryID = @categoryID";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@categoryID", categoryID);
        command.Parameters.AddWithValue("@CategoryName", CategoryName);

        try
        {
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();

            isUpdated = rowsAffected > 0;

            connection.Close();
        }
        catch (Exception ex)
        {
            //   MessageBox.Show(ex + "");
            isUpdated = false;
        }

        finally
        {
            connection.Close();
        }

        // MessageBox.Show(isUpdated + "");
        return isUpdated;
    }

    public static bool GetCategoryByID(int categoryID, ref string CategoryName)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = "Select * From Categories Where categoryID=@categoryID";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@categoryID", categoryID);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isFound = true;
                CategoryName = Convert.ToString(reader[1]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isFound = false;
        }
        finally
        {
            connection.Close();
        }

        return isFound;
    }

    public static bool DeleteCategory(int categoryID)
    {
        bool isDeleted = false;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @" Delete From Categories Where categoryID =@categoryID ;";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@categoryID", categoryID);

        try
        {
            connection.Open();
            var rows = command.ExecuteNonQuery();
            isDeleted = rows > 0;
        }
        catch (Exception e)
        {
            // MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }

    public static bool GetCategoryByName(ref int categoryID, string CategoryName)
    {
        bool isDeleted = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = "Select * from Categories Where CategoryName=@CategoryName";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@CategoryName", CategoryName);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isDeleted = true;
                categoryID = Convert.ToInt32(reader[1]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }

    public static DataTable FindCategoryByName(string CategoryName)
    {
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @"select * from Categories
                  where CategoryName = @CategoryName";

        DataTable dt = new DataTable();

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@CategoryName", CategoryName);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                dt.Load(reader);
            }

            reader.Close();
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }
        finally
        {
            connection.Close();
        }

        return dt;
    }
}