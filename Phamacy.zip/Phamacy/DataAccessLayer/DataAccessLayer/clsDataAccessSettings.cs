﻿namespace DataAccessLayer
{
    public class clsDataAccessSettings
    {
        public const string ConnectionString = "Server=.;Database=Pharmacy;User Id= ;Password= ;";

    }
}