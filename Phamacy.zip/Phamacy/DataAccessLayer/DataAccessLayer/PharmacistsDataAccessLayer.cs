﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer;

public class PharmacistsDataAccessLayer
{
    public static DataTable GetAllPharmacists()
    {
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query =
            @"select 'Pharmacist ID'=PharmacistID ,'Pharmacist Name'=PharmacistName,Password From Pharmacists;";

        DataTable dt = new DataTable();

        SqlCommand command = new SqlCommand(Query, connection);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                dt.Load(reader);
            }

            reader.Close();
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }
        finally
        {
            connection.Close();
        }

        return dt;
    }

    public static bool IsFound(string Phone, string Password)
    {
        bool IsFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string Query = "Select * from Pharmacists Where Pharmacistname=@Pharmacistname and Password=@Password";

        string Query = " EXEC  SP_IsPharmacistExists @phone= @Phone , @Password=@Password";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@Phone", Phone);
        command.Parameters.AddWithValue("@Password", Password);

        try
        {
            connection.Open();

            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                IsFound = reader.HasRows;
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            IsFound = false;
        }
        finally
        {
            connection.Close();
        }

        return IsFound;
    }

    public static bool GetPharmacistByID(int ID, ref string PharmacistName, ref string phone, ref string password)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string Query = "Select * From Pharmacists Where PharmacistID=@ID";

        string Query = "Exec SP_GetPharmacistByID @PharmacistID=@ID";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@ID", ID);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isFound = true;
                PharmacistName = Convert.ToString(reader[1]);
                phone = Convert.ToString(reader[2]);
                password = Convert.ToString(reader[3]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isFound = false;
        }
        finally
        {
            connection.Close();
        }

        return isFound;
    }

    public static bool GetPharmacistByPharmacistPhone(ref int PharmacistID, ref string PharmacistName,
        string phone, ref string password)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string Query = "Select * From Pharmacists Where Phone=@Phone";

        string Query = "EXEC SP_GetPharmacistByPharmacistPhone @Phone=@phone";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@phone", phone);

        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.Read())
            {
                isFound = true;
                PharmacistID = Convert.ToInt32(reader[0]);
                PharmacistName = Convert.ToString(reader[1]);
                password = Convert.ToString(reader[3]);
            }
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isFound = false;
        }
        finally
        {
            connection.Close();
        }

        return isFound;
    }

    public static int AddNewPharmacist(string PharmacistName, string Phone, string password)
    {
        int Id = 0;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string query = @"INSERT INTO Pharmacists
        //                  VALUES (@PharmacistName,@password)
        //                  SELECT SCOPE_IDENTITY();";   

        string query = @"EXEC SP_AddNewPharmacist @PharmacistName=@PharmacistName,@Phone=@Phone ,@Password=@password;";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@PharmacistName", PharmacistName);
        command.Parameters.AddWithValue("@Phone", Phone);
        command.Parameters.AddWithValue("@password", password);

        try
        {
            connection.Open();
            var result = command.ExecuteScalar();

            if (result != null && int.TryParse(result.ToString(), out int insertedID))
            {
                Id = insertedID;
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
        }
        finally
        {
            connection.Close();
        }

        return Id;
    }

    public static bool UpdatePharmacist(int PharmacistId, string PharmacistName, string Phone, string password)
    {
        bool isUpdated = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string query = @"Update Pharmacists
        //                   set PharmacistName=@PharmacistName,password=@password
        //                   where PharmacistId = @PharmacistId";

        string query = @"Exec SP_UpdatePharmacist @PharmacistName =@PharmacistName ,@Phone=@Phone,
                                 @Password=@password , @PharmacistId=@PharmacistId;";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@PharmacistId", PharmacistId);
        command.Parameters.AddWithValue("@PharmacistName", PharmacistName);
        command.Parameters.AddWithValue("@Phone", Phone);
        command.Parameters.AddWithValue("@password", password);

        try
        {
            connection.Open();

            int rowsAffected = command.ExecuteNonQuery();

            isUpdated = rowsAffected > 0;

            connection.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex + "");
            isUpdated = false;
        }

        finally
        {
            connection.Close();
        }

        // MessageBox.Show(isUpdated + "");
        return isUpdated;
    }

    public static bool DeletePharmacist(int PharmacistID)
    {
        bool isDeleted = false;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @" Delete From Pharmacists Where PharmacistID =@PharmacistID ;";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@PharmacistID", PharmacistID);

        try
        {
            connection.Open();
            var rows = command.ExecuteNonQuery();
            isDeleted = rows > 0;
        }
        catch (Exception e)
        {
            // MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }

    public static bool ExistPharmacistPhone(string Phone)
    {
        bool isFound = false;

        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        // string query = @"Select Found='1' From Pharmacists
        //                   Where PharmacistName = @PharmacistName";    

        string query = @"Exec SP_ExistPharmacistPhone @Phone = @Phone";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@Phone", Phone);

        try
        {
            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                isFound = reader.HasRows;
            }

            connection.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex + "");
            isFound = false;
        }

        finally
        {
            connection.Close();
        }

        return isFound;
    }
}