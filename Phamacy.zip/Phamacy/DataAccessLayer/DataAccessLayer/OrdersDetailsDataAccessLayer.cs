﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer;

public class OrdersDetailsDataAccessLayer
{
    public static DataTable GetAllOrderDetails(int? OrderID)
    {
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = "Select * From OrdersDetails Where OrderID=@orderId";

        DataTable dt = new DataTable();

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@orderId", OrderID);
        try
        {
            connection.Open();
            SqlDataReader reader = command.ExecuteReader();

            if (reader.HasRows)
            {
                dt.Load(reader);
            }

            reader.Close();
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
        }
        finally
        {
            connection.Close();
        }

        return dt;
    }

    public static bool AddNewOrderDetails( int RequiredQuantity, decimal price,int OrderID , int MedicineID)
    {
        var isAdded = false;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string query = @"Exec SP_AddNewOrderDetails @RequiredQuantity = @RequiredQuantity, @price =@price,
                                                    @orderId=@OrderID, @medicineId= @MedicineID;";

        SqlCommand command = new SqlCommand(query, connection);

        command.Parameters.AddWithValue("@RequiredQuantity", RequiredQuantity);
        command.Parameters.AddWithValue("@price", price);
        command.Parameters.AddWithValue("@OrderID", OrderID);
        command.Parameters.AddWithValue("@MedicineID", MedicineID);

        try
        {
            connection.Open();
            command.ExecuteNonQuery();
            isAdded = true;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Error: " + ex.Message);
            isAdded = false;
        }
        finally
        {
            connection.Close();
        }

        return isAdded;
    }

    public static bool DeleteOrderDetailsByOrderID(int? OrderID)
    {
        bool isDeleted;
        SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

        string Query = @"Exec SP_DeleteOrderDetailsByOrderID @orderId=@OrderID;";

        SqlCommand command = new SqlCommand(Query, connection);
        command.Parameters.AddWithValue("@OrderID", OrderID);

        try
        {
            connection.Open();
            var rows = command.ExecuteNonQuery();
            isDeleted = rows > 0;
        }
        catch (Exception e)
        {
            MessageBox.Show(e.ToString());
            isDeleted = false;
        }
        finally
        {
            connection.Close();
        }

        return isDeleted;
    }
}