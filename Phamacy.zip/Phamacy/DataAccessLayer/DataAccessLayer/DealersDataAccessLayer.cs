﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class DealersDataAccessLayer
    {
        public static DataTable GetAllDealers()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Exec SP_GetAllDealers;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }
                else
                {
                    var tableSchema = reader.GetSchemaTable();

                    foreach (DataRow row in tableSchema.Rows)
                    {
                        dt.Columns.Add(row["ColumnName"].ToString());
                    }
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool IsFound(string DealerName, string Password)
        {
            bool IsFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // string Query = "Select * from Dealers Where Dealername=@Dealername and Password=@Password";

            string Query = " EXEC  SP_IsDealerExists @DealerName = @DealerName , @Password=@Password";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@DealerName", DealerName);
            command.Parameters.AddWithValue("@Password", Password);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    IsFound = reader.HasRows;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                IsFound = false;
            }
            finally
            {
                connection.Close();
            }

            return IsFound;
        }

        public static bool GetDealerByID(int ID, ref string DealerName, ref string password)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // string Query = "Select * From Dealers Where DealerID=@ID";

            string Query = "EXEC SP_GetDealerByID @DealerID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    DealerName = Convert.ToString(reader[1]);
                    password = Convert.ToString(reader[2]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetDealerByDealerName(ref int DealerID, string DealerName, ref string password)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // string Query = "Select * From Dealers Where DealerName=@DealerName";

            string Query = "EXEC SP_GetDealerByDealerName @DealerName=@DealerName";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@DealerName", DealerName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    DealerID = Convert.ToInt32(reader[0]);
                    password = Convert.ToString(reader[2]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewDealer(string DealerName, string password)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // string query = @"INSERT INTO Dealers
            //                  VALUES (@DealerName,@password)
            //                  SELECT SCOPE_IDENTITY();";   

            string query = @"EXEC SP_AddNewDealer @DealerName=@DealerName ,@Password=@password;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DealerName", DealerName);
            command.Parameters.AddWithValue("@password", password);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateDealer(int DealerId, string DealerName, string password)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // string query = @"Update Dealers
            //                   set DealerName=@DealerName,password=@password
            //                   where DealerId = @DealerId";

            string query =
                @"Exec SP_UpdateDealer @DealerName =@DealerName , @Password=@password , @DealerId=@DealerId;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DealerId", DealerId);
            command.Parameters.AddWithValue("@DealerName", DealerName);
            command.Parameters.AddWithValue("@password", password);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteDealer(int DealerID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @" Delete From Dealers Where DealerID =@DealerID ;";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@DealerID", DealerID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool ExistDealerName(string DealerName)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // string query = @"Select Found='1' From Dealers
            //                   Where DealerName = @DealerName";    

            string query = @"Exec SP_ExistDealerName @DealerName =@DealerName";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DealerName", DealerName);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = reader.HasRows;
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isFound = false;
            }

            finally
            {
                connection.Close();
            }

            return isFound;
        }
    }
}