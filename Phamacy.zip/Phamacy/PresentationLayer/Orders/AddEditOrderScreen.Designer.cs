﻿using System.ComponentModel;

namespace PresentationLayer.Orders;

partial class AddEditOrderScreen
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
        this.groupBox2 = new System.Windows.Forms.GroupBox();
        this.lblOrderDate = new System.Windows.Forms.Label();
        this.label9 = new System.Windows.Forms.Label();
        this.lblDealerName = new System.Windows.Forms.Label();
        this.lblPharmacistName = new System.Windows.Forms.Label();
        this.label4 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.lblOrderID = new System.Windows.Forms.Label();
        this.label15 = new System.Windows.Forms.Label();
        this.btnNewOrder = new System.Windows.Forms.Button();
        this.btnSaveOrder = new System.Windows.Forms.Button();
        this.groupBox4 = new System.Windows.Forms.GroupBox();
        this.dgvMedicines = new System.Windows.Forms.DataGridView();
        this.btnClearAll = new System.Windows.Forms.Button();
        this.lblTotal = new System.Windows.Forms.Label();
        this.label5 = new System.Windows.Forms.Label();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.dgvDealers = new System.Windows.Forms.DataGridView();
        this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
        this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
        this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.groupBox2.SuspendLayout();
        this.groupBox4.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.dgvMedicines)).BeginInit();
        this.groupBox1.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.dgvDealers)).BeginInit();
        this.contextMenuStrip1.SuspendLayout();
        this.SuspendLayout();
        // 
        // groupBox2
        // 
        this.groupBox2.Controls.Add(this.lblOrderDate);
        this.groupBox2.Controls.Add(this.label9);
        this.groupBox2.Controls.Add(this.lblDealerName);
        this.groupBox2.Controls.Add(this.lblPharmacistName);
        this.groupBox2.Controls.Add(this.label4);
        this.groupBox2.Controls.Add(this.label2);
        this.groupBox2.Controls.Add(this.lblOrderID);
        this.groupBox2.Controls.Add(this.label15);
        this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox2.Location = new System.Drawing.Point(12, 12);
        this.groupBox2.Name = "groupBox2";
        this.groupBox2.Size = new System.Drawing.Size(973, 156);
        this.groupBox2.TabIndex = 3;
        this.groupBox2.TabStop = false;
        this.groupBox2.Text = "Order Info";
        // 
        // lblOrderDate
        // 
        this.lblOrderDate.AutoEllipsis = true;
        this.lblOrderDate.ForeColor = System.Drawing.Color.Crimson;
        this.lblOrderDate.Location = new System.Drawing.Point(592, 51);
        this.lblOrderDate.Name = "lblOrderDate";
        this.lblOrderDate.Size = new System.Drawing.Size(369, 25);
        this.lblOrderDate.TabIndex = 154;
        this.lblOrderDate.Text = "N/A";
        // 
        // label9
        // 
        this.label9.AutoSize = true;
        this.label9.Location = new System.Drawing.Point(506, 104);
        this.label9.Name = "label9";
        this.label9.Size = new System.Drawing.Size(80, 25);
        this.label9.TabIndex = 148;
        this.label9.Text = "Dealer :";
        // 
        // lblDealerName
        // 
        this.lblDealerName.AutoEllipsis = true;
        this.lblDealerName.ForeColor = System.Drawing.Color.Crimson;
        this.lblDealerName.Location = new System.Drawing.Point(592, 107);
        this.lblDealerName.Name = "lblDealerName";
        this.lblDealerName.Size = new System.Drawing.Size(268, 25);
        this.lblDealerName.TabIndex = 149;
        this.lblDealerName.Text = "N/A";
        // 
        // lblPharmacistName
        // 
        this.lblPharmacistName.AutoEllipsis = true;
        this.lblPharmacistName.BackColor = System.Drawing.SystemColors.Control;
        this.lblPharmacistName.ForeColor = System.Drawing.Color.Crimson;
        this.lblPharmacistName.Location = new System.Drawing.Point(136, 107);
        this.lblPharmacistName.Name = "lblPharmacistName";
        this.lblPharmacistName.Size = new System.Drawing.Size(329, 25);
        this.lblPharmacistName.TabIndex = 153;
        this.lblPharmacistName.Text = "N/A";
        // 
        // label4
        // 
        this.label4.AutoSize = true;
        this.label4.Location = new System.Drawing.Point(10, 106);
        this.label4.Name = "label4";
        this.label4.Size = new System.Drawing.Size(120, 25);
        this.label4.TabIndex = 152;
        this.label4.Text = "Pharmacist :";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Location = new System.Drawing.Point(467, 50);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(119, 25);
        this.label2.TabIndex = 150;
        this.label2.Text = "Order Date :";
        // 
        // lblOrderID
        // 
        this.lblOrderID.AutoSize = true;
        this.lblOrderID.ForeColor = System.Drawing.Color.Crimson;
        this.lblOrderID.Location = new System.Drawing.Point(136, 51);
        this.lblOrderID.Name = "lblOrderID";
        this.lblOrderID.Size = new System.Drawing.Size(46, 25);
        this.lblOrderID.TabIndex = 143;
        this.lblOrderID.Text = "N/A";
        // 
        // label15
        // 
        this.label15.AutoSize = true;
        this.label15.Location = new System.Drawing.Point(33, 50);
        this.label15.Name = "label15";
        this.label15.Size = new System.Drawing.Size(97, 25);
        this.label15.TabIndex = 142;
        this.label15.Text = "Order ID :";
        // 
        // btnNewOrder
        // 
        this.btnNewOrder.AutoSize = true;
        this.btnNewOrder.BackColor = System.Drawing.SystemColors.Control;
        this.btnNewOrder.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnNewOrder.Enabled = false;
        this.btnNewOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnNewOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.btnNewOrder.ForeColor = System.Drawing.Color.Black;
        this.btnNewOrder.Location = new System.Drawing.Point(295, 179);
        this.btnNewOrder.Name = "btnNewOrder";
        this.btnNewOrder.Size = new System.Drawing.Size(169, 39);
        this.btnNewOrder.TabIndex = 151;
        this.btnNewOrder.Text = "New Order";
        this.btnNewOrder.UseVisualStyleBackColor = false;
        this.btnNewOrder.Click += new System.EventHandler(this.btnNewOrder_Click);
        // 
        // btnSaveOrder
        // 
        this.btnSaveOrder.AutoSize = true;
        this.btnSaveOrder.BackColor = System.Drawing.SystemColors.Control;
        this.btnSaveOrder.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnSaveOrder.Enabled = false;
        this.btnSaveOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnSaveOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.btnSaveOrder.ForeColor = System.Drawing.Color.Black;
        this.btnSaveOrder.Location = new System.Drawing.Point(530, 179);
        this.btnSaveOrder.Name = "btnSaveOrder";
        this.btnSaveOrder.Size = new System.Drawing.Size(169, 39);
        this.btnSaveOrder.TabIndex = 152;
        this.btnSaveOrder.Text = "Save Order";
        this.btnSaveOrder.UseVisualStyleBackColor = false;
        this.btnSaveOrder.Click += new System.EventHandler(this.btnSaveOrder_Click);
        // 
        // groupBox4
        // 
        this.groupBox4.Controls.Add(this.dgvMedicines);
        this.groupBox4.Controls.Add(this.btnClearAll);
        this.groupBox4.Controls.Add(this.lblTotal);
        this.groupBox4.Controls.Add(this.label5);
        this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox4.Location = new System.Drawing.Point(12, 456);
        this.groupBox4.Name = "groupBox4";
        this.groupBox4.Size = new System.Drawing.Size(967, 327);
        this.groupBox4.TabIndex = 157;
        this.groupBox4.TabStop = false;
        this.groupBox4.Text = "Medicines In Repository";
        // 
        // dgvMedicines
        // 
        this.dgvMedicines.AllowUserToAddRows = false;
        this.dgvMedicines.AllowUserToDeleteRows = false;
        this.dgvMedicines.AllowUserToResizeColumns = false;
        this.dgvMedicines.AllowUserToResizeRows = false;
        this.dgvMedicines.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.dgvMedicines.BackgroundColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F);
        dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
        dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
        dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.dgvMedicines.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
        this.dgvMedicines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F);
        dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
        dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
        dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
        this.dgvMedicines.DefaultCellStyle = dataGridViewCellStyle2;
        this.dgvMedicines.EnableHeadersVisualStyles = false;
        this.dgvMedicines.Font = new System.Drawing.Font("Arial", 9F);
        this.dgvMedicines.Location = new System.Drawing.Point(10, 28);
        this.dgvMedicines.MultiSelect = false;
        this.dgvMedicines.Name = "dgvMedicines";
        dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9F);
        dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
        dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
        dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.dgvMedicines.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
        this.dgvMedicines.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.dgvMedicines.ShowCellToolTips = false;
        this.dgvMedicines.Size = new System.Drawing.Size(951, 223);
        this.dgvMedicines.TabIndex = 216;
        this.dgvMedicines.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMedicines_SelectMedicine);
        this.dgvMedicines.CurrentCellDirtyStateChanged += new System.EventHandler(this.dgvMedicines_CurrentCellDirtyStateChanged);
        this.dgvMedicines.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvMedicines_InvalidData);
        // 
        // btnClearAll
        // 
        this.btnClearAll.BackColor = System.Drawing.Color.Crimson;
        this.btnClearAll.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnClearAll.FlatAppearance.BorderSize = 0;
        this.btnClearAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnClearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.btnClearAll.ForeColor = System.Drawing.Color.White;
        this.btnClearAll.Location = new System.Drawing.Point(794, 277);
        this.btnClearAll.Name = "btnClearAll";
        this.btnClearAll.Size = new System.Drawing.Size(167, 33);
        this.btnClearAll.TabIndex = 154;
        this.btnClearAll.Text = "Clear All";
        this.btnClearAll.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
        this.btnClearAll.UseVisualStyleBackColor = false;
        this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
        // 
        // lblTotal
        // 
        this.lblTotal.AutoEllipsis = true;
        this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.lblTotal.ForeColor = System.Drawing.Color.Crimson;
        this.lblTotal.Location = new System.Drawing.Point(87, 277);
        this.lblTotal.Name = "lblTotal";
        this.lblTotal.Size = new System.Drawing.Size(365, 29);
        this.lblTotal.TabIndex = 156;
        this.lblTotal.Text = "0.00";
        this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
        // 
        // label5
        // 
        this.label5.AutoSize = true;
        this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label5.Location = new System.Drawing.Point(10, 277);
        this.label5.Name = "label5";
        this.label5.Size = new System.Drawing.Size(71, 26);
        this.label5.TabIndex = 155;
        this.label5.Text = "Total :";
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.dgvDealers);
        this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox1.Location = new System.Drawing.Point(9, 224);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(976, 226);
        this.groupBox1.TabIndex = 158;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Select Dealer";
        // 
        // dgvDealers
        // 
        this.dgvDealers.AllowUserToAddRows = false;
        this.dgvDealers.AllowUserToDeleteRows = false;
        this.dgvDealers.AllowUserToResizeColumns = false;
        this.dgvDealers.AllowUserToResizeRows = false;
        this.dgvDealers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.dgvDealers.BackgroundColor = System.Drawing.SystemColors.Window;
        this.dgvDealers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.dgvDealers.Font = new System.Drawing.Font("Arial", 9F);
        this.dgvDealers.Location = new System.Drawing.Point(10, 44);
        this.dgvDealers.MultiSelect = false;
        this.dgvDealers.Name = "dgvDealers";
        this.dgvDealers.ReadOnly = true;
        this.dgvDealers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.dgvDealers.ShowCellToolTips = false;
        this.dgvDealers.Size = new System.Drawing.Size(960, 169);
        this.dgvDealers.TabIndex = 216;
        this.dgvDealers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDealers_SelectDealer);
        // 
        // contextMenuStrip1
        // 
        this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.editToolStripMenuItem, this.toolStripSeparator1, this.deleteToolStripMenuItem });
        this.contextMenuStrip1.Name = "contextMenuStrip1";
        this.contextMenuStrip1.Size = new System.Drawing.Size(123, 58);
        // 
        // editToolStripMenuItem
        // 
        this.editToolStripMenuItem.Name = "editToolStripMenuItem";
        this.editToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
        this.editToolStripMenuItem.Text = "Edit";
        // 
        // toolStripSeparator1
        // 
        this.toolStripSeparator1.Name = "toolStripSeparator1";
        this.toolStripSeparator1.Size = new System.Drawing.Size(119, 6);
        // 
        // deleteToolStripMenuItem
        // 
        this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
        this.deleteToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
        this.deleteToolStripMenuItem.Text = "Delete";
        // 
        // AddEditOrderScreen
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(997, 805);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.groupBox4);
        this.Controls.Add(this.btnSaveOrder);
        this.Controls.Add(this.groupBox2);
        this.Controls.Add(this.btnNewOrder);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        this.Name = "AddEditOrderScreen";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Load += new System.EventHandler(this.AddEditOrderScreen_Load);
        this.groupBox2.ResumeLayout(false);
        this.groupBox2.PerformLayout();
        this.groupBox4.ResumeLayout(false);
        this.groupBox4.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.dgvMedicines)).EndInit();
        this.groupBox1.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.dgvDealers)).EndInit();
        this.contextMenuStrip1.ResumeLayout(false);
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
    private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;

    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.DataGridView dgvMedicines;
    private System.Windows.Forms.Label lblTotal;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Button btnClearAll;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.DataGridView dgvDealers;

    private System.Windows.Forms.Button btnSaveOrder;
    private System.Windows.Forms.Label lblOrderDate;

    private System.Windows.Forms.Button btnNewOrder;

    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label lblPharmacistName;
    private System.Windows.Forms.Label label4;

    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label lblDealerName;
    private System.Windows.Forms.Label label9;
    private System.Windows.Forms.Label lblOrderID;
    private System.Windows.Forms.Label label15;

    #endregion
}