﻿using System.ComponentModel;

namespace PresentationLayer.Orders;

partial class OrderDetailsScreen
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.label2 = new System.Windows.Forms.Label();
        this.lblIsPaid = new System.Windows.Forms.Label();
        this.lblStatus = new System.Windows.Forms.Label();
        this.label12 = new System.Windows.Forms.Label();
        this.lblOrderDate = new System.Windows.Forms.Label();
        this.label3 = new System.Windows.Forms.Label();
        this.lblDealerName = new System.Windows.Forms.Label();
        this.lblPharmacist = new System.Windows.Forms.Label();
        this.label7 = new System.Windows.Forms.Label();
        this.label8 = new System.Windows.Forms.Label();
        this.lblOrderID = new System.Windows.Forms.Label();
        this.label11 = new System.Windows.Forms.Label();
        this.groupBox4 = new System.Windows.Forms.GroupBox();
        this.dgvMedicines = new System.Windows.Forms.DataGridView();
        this.lblTotal = new System.Windows.Forms.Label();
        this.label13 = new System.Windows.Forms.Label();
        this.groupBox1.SuspendLayout();
        this.groupBox4.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.dgvMedicines)).BeginInit();
        this.SuspendLayout();
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.label2);
        this.groupBox1.Controls.Add(this.lblIsPaid);
        this.groupBox1.Controls.Add(this.lblStatus);
        this.groupBox1.Controls.Add(this.label12);
        this.groupBox1.Controls.Add(this.lblOrderDate);
        this.groupBox1.Controls.Add(this.label3);
        this.groupBox1.Controls.Add(this.lblDealerName);
        this.groupBox1.Controls.Add(this.lblPharmacist);
        this.groupBox1.Controls.Add(this.label7);
        this.groupBox1.Controls.Add(this.label8);
        this.groupBox1.Controls.Add(this.lblOrderID);
        this.groupBox1.Controls.Add(this.label11);
        this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox1.Location = new System.Drawing.Point(35, 22);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Size = new System.Drawing.Size(990, 218);
        this.groupBox1.TabIndex = 5;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Order Info";
        // 
        // label2
        // 
        this.label2.AutoSize = true;
        this.label2.Location = new System.Drawing.Point(555, 164);
        this.label2.Name = "label2";
        this.label2.Size = new System.Drawing.Size(82, 25);
        this.label2.TabIndex = 155;
        this.label2.Text = "Is Paid :";
        // 
        // lblIsPaid
        // 
        this.lblIsPaid.AutoEllipsis = true;
        this.lblIsPaid.ForeColor = System.Drawing.Color.Crimson;
        this.lblIsPaid.Location = new System.Drawing.Point(643, 165);
        this.lblIsPaid.Name = "lblIsPaid";
        this.lblIsPaid.Size = new System.Drawing.Size(268, 25);
        this.lblIsPaid.TabIndex = 156;
        this.lblIsPaid.Text = "N/A";
        // 
        // lblStatus
        // 
        this.lblStatus.AutoEllipsis = true;
        this.lblStatus.BackColor = System.Drawing.SystemColors.Control;
        this.lblStatus.ForeColor = System.Drawing.Color.Crimson;
        this.lblStatus.Location = new System.Drawing.Point(136, 165);
        this.lblStatus.Name = "lblStatus";
        this.lblStatus.Size = new System.Drawing.Size(225, 25);
        this.lblStatus.TabIndex = 158;
        this.lblStatus.Text = "N/A";
        // 
        // label12
        // 
        this.label12.AutoSize = true;
        this.label12.Location = new System.Drawing.Point(51, 164);
        this.label12.Name = "label12";
        this.label12.Size = new System.Drawing.Size(79, 25);
        this.label12.TabIndex = 157;
        this.label12.Text = "Status :";
        // 
        // lblOrderDate
        // 
        this.lblOrderDate.AutoEllipsis = true;
        this.lblOrderDate.ForeColor = System.Drawing.Color.Crimson;
        this.lblOrderDate.Location = new System.Drawing.Point(643, 51);
        this.lblOrderDate.Name = "lblOrderDate";
        this.lblOrderDate.Size = new System.Drawing.Size(341, 25);
        this.lblOrderDate.TabIndex = 154;
        this.lblOrderDate.Text = "N/A";
        // 
        // label3
        // 
        this.label3.AutoSize = true;
        this.label3.Location = new System.Drawing.Point(557, 104);
        this.label3.Name = "label3";
        this.label3.Size = new System.Drawing.Size(80, 25);
        this.label3.TabIndex = 148;
        this.label3.Text = "Dealer :";
        // 
        // lblDealerName
        // 
        this.lblDealerName.AutoEllipsis = true;
        this.lblDealerName.ForeColor = System.Drawing.Color.Crimson;
        this.lblDealerName.Location = new System.Drawing.Point(643, 107);
        this.lblDealerName.Name = "lblDealerName";
        this.lblDealerName.Size = new System.Drawing.Size(341, 25);
        this.lblDealerName.TabIndex = 149;
        this.lblDealerName.Text = "N/A";
        // 
        // lblPharmacist
        // 
        this.lblPharmacist.AutoEllipsis = true;
        this.lblPharmacist.BackColor = System.Drawing.SystemColors.Control;
        this.lblPharmacist.ForeColor = System.Drawing.Color.Crimson;
        this.lblPharmacist.Location = new System.Drawing.Point(136, 107);
        this.lblPharmacist.Name = "lblPharmacist";
        this.lblPharmacist.Size = new System.Drawing.Size(371, 25);
        this.lblPharmacist.TabIndex = 153;
        this.lblPharmacist.Text = "N/A";
        // 
        // label7
        // 
        this.label7.AutoSize = true;
        this.label7.Location = new System.Drawing.Point(10, 106);
        this.label7.Name = "label7";
        this.label7.Size = new System.Drawing.Size(120, 25);
        this.label7.TabIndex = 152;
        this.label7.Text = "Pharmacist :";
        // 
        // label8
        // 
        this.label8.AutoSize = true;
        this.label8.Location = new System.Drawing.Point(518, 50);
        this.label8.Name = "label8";
        this.label8.Size = new System.Drawing.Size(119, 25);
        this.label8.TabIndex = 150;
        this.label8.Text = "Order Date :";
        // 
        // lblOrderID
        // 
        this.lblOrderID.AutoSize = true;
        this.lblOrderID.ForeColor = System.Drawing.Color.Crimson;
        this.lblOrderID.Location = new System.Drawing.Point(136, 51);
        this.lblOrderID.Name = "lblOrderID";
        this.lblOrderID.Size = new System.Drawing.Size(46, 25);
        this.lblOrderID.TabIndex = 143;
        this.lblOrderID.Text = "N/A";
        // 
        // label11
        // 
        this.label11.AutoSize = true;
        this.label11.Location = new System.Drawing.Point(33, 50);
        this.label11.Name = "label11";
        this.label11.Size = new System.Drawing.Size(97, 25);
        this.label11.TabIndex = 142;
        this.label11.Text = "Order ID :";
        // 
        // groupBox4
        // 
        this.groupBox4.Controls.Add(this.dgvMedicines);
        this.groupBox4.Controls.Add(this.lblTotal);
        this.groupBox4.Controls.Add(this.label13);
        this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox4.Location = new System.Drawing.Point(35, 267);
        this.groupBox4.Name = "groupBox4";
        this.groupBox4.Size = new System.Drawing.Size(990, 327);
        this.groupBox4.TabIndex = 158;
        this.groupBox4.TabStop = false;
        this.groupBox4.Text = "Medicines In Repository";
        // 
        // dgvMedicines
        // 
        this.dgvMedicines.AllowUserToAddRows = false;
        this.dgvMedicines.AllowUserToDeleteRows = false;
        this.dgvMedicines.AllowUserToResizeColumns = false;
        this.dgvMedicines.AllowUserToResizeRows = false;
        this.dgvMedicines.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.dgvMedicines.BackgroundColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F);
        dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
        dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
        dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.dgvMedicines.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
        this.dgvMedicines.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle2.Font = new System.Drawing.Font("Arial", 9F);
        dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
        dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Window;
        dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
        dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
        this.dgvMedicines.DefaultCellStyle = dataGridViewCellStyle2;
        this.dgvMedicines.EnableHeadersVisualStyles = false;
        this.dgvMedicines.Font = new System.Drawing.Font("Arial", 9F);
        this.dgvMedicines.Location = new System.Drawing.Point(10, 28);
        this.dgvMedicines.MultiSelect = false;
        this.dgvMedicines.Name = "dgvMedicines";
        this.dgvMedicines.ReadOnly = true;
        dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle3.Font = new System.Drawing.Font("Arial", 9F);
        dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
        dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
        dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.dgvMedicines.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
        this.dgvMedicines.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.dgvMedicines.ShowCellToolTips = false;
        this.dgvMedicines.Size = new System.Drawing.Size(971, 223);
        this.dgvMedicines.TabIndex = 216;
        // 
        // lblTotal
        // 
        this.lblTotal.AutoEllipsis = true;
        this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.lblTotal.ForeColor = System.Drawing.Color.Crimson;
        this.lblTotal.Location = new System.Drawing.Point(87, 277);
        this.lblTotal.Name = "lblTotal";
        this.lblTotal.Size = new System.Drawing.Size(864, 29);
        this.lblTotal.TabIndex = 156;
        this.lblTotal.Text = "0.00";
        this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
        // 
        // label13
        // 
        this.label13.AutoSize = true;
        this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label13.Location = new System.Drawing.Point(10, 277);
        this.label13.Name = "label13";
        this.label13.Size = new System.Drawing.Size(71, 26);
        this.label13.TabIndex = 155;
        this.label13.Text = "Total :";
        // 
        // OrderDetailsScreen
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(1059, 621);
        this.Controls.Add(this.groupBox4);
        this.Controls.Add(this.groupBox1);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        this.Name = "OrderDetailsScreen";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Order Details Screen";
        this.Load += new System.EventHandler(this.OrderDetailsScreen_Load);
        this.groupBox1.ResumeLayout(false);
        this.groupBox1.PerformLayout();
        this.groupBox4.ResumeLayout(false);
        this.groupBox4.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.dgvMedicines)).EndInit();
        this.ResumeLayout(false);
    }

    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.DataGridView dgvMedicines;
    private System.Windows.Forms.Label lblTotal;
    private System.Windows.Forms.Label label13;

    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label lblOrderDate;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label lblDealerName;
    private System.Windows.Forms.Label lblPharmacist;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label lblOrderID;
    private System.Windows.Forms.Label label11;
    private System.Windows.Forms.Label label12;

    private System.Windows.Forms.Label lblStatus;
    private System.Windows.Forms.Label lblIsPaid;
    private System.Windows.Forms.Label label2;

    #endregion
}