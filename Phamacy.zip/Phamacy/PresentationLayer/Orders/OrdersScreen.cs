﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using static PresentationLayer.clsGlobal;
using OBL = BusinessLayer.OrdersBusinessLayer;

namespace PresentationLayer.Orders;

public partial class OrdersScreen : Form
{
    public OrdersScreen()
    {
        InitializeComponent();

        if (CurrentPharmacist == null)
            EnMode = Mode.Dealer;
    }

    private enum Mode
    {
        Pharmacist = 0,
        Dealer = 1
    };

    private DataTable _DataTable;
    private Mode EnMode = Mode.Pharmacist;

    private int? _OrderID;
    private OBL _Order1;

    private void OrdersScreen_Load(object sender, EventArgs e)
    {
    }

    private void OrdersScreen_Shown(object sender, EventArgs e)
    {
        _EditScreen();

        RefreshData();
    }

    private void _EditScreen()
    {
        if (EnMode == Mode.Pharmacist)
        {
            comboBox1.Items.Add("Dealer Name");
            GridViewOrdersList.ContextMenuStrip = new ContextMenuStrip();
        }
        else
        {
            comboBox1.Items.Add("Pharmacist Name");
            gbPharmacistOperations.Visible = false;
            ClientSize = new Size(811, 371);
        }
    }

    public void RefreshData()
    {
        _DataTable = OBL.GetAllOrders(
            EnMode == Mode.Pharmacist ? CurrentPharmacist.PharmacistID : null,
            EnMode == Mode.Dealer ? CurrentDealer.DealerID : null
        );

        cmsOperations.Enabled = btnUpdateOrder.Enabled =
            btnDeleteOrder.Enabled = btnDisplayOrder.Enabled = _DataTable.Rows.Count > 0;

        comboBox1.SelectedIndex = 0;

        LoadData();

        _SetWidthColumns();
    }

    private void _SetDefaultColumns()
    {
        _DataTable.Columns.Add("Order ID", typeof(int));
        _DataTable.Columns.Add("Status", typeof(decimal));
        _DataTable.Columns.Add("IsPaid", typeof(bool));
        _DataTable.Columns.Add("OrderDate", typeof(DateTime));
        _DataTable.Columns.Add(EnMode == Mode.Pharmacist ? "Dealer Name" : "Pharmacist Name", typeof(string));
        _DataTable.Columns.Add("Medicines", typeof(int));

        GridViewOrdersList.DataSource = _DataTable;

        _SetWidthColumns();

        if (GridViewOrdersList.Rows.Count > 0)
            GridViewOrdersList.Rows.RemoveAt(0);

        comboBox1.Enabled = textBox1.Enabled = false;

        lblRecords.Text = "0";
    }

    private void _SetWidthColumns()
    {
        GridViewOrdersList.Columns[0].Width = 111;
        GridViewOrdersList.Columns[1].Width = 101;
        GridViewOrdersList.Columns[2].Width = 101;
        GridViewOrdersList.Columns[3].Width = 151;
        GridViewOrdersList.Columns[4].Width = 151;
        GridViewOrdersList.Columns[5].Width = 111;
    }

    private void LoadData(string Type = "Order ID", string Text = "")
    {
        var _DataView1 = _DataTable.DefaultView;
        string DataFilter;

        try
        {
            if (Text == "")
                DataFilter = null;
            else if (Type == "Order ID")
                DataFilter = $"[{Type}] = '{Text}'";
            else
                DataFilter = $"[{Type}] LIKE '{Text}%'";

            _DataView1.RowFilter = DataFilter;
        }
        catch (Exception e)
        {
            MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                MessageBoxButtons.OK, MessageBoxIcon.Error);

            textBox1.Text = Text.Substring(0, Text.Length - 1);

            _DataView1.RowFilter = null;
        }

        GridViewOrdersList.DataSource = _DataView1;

        lblRecords.Text = Convert.ToString(GridViewOrdersList.Rows.Count);
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
        var Type = Convert.ToString(comboBox1.SelectedItem);
        var Text = textBox1.Text.Trim();

        LoadData(Type, Text);
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        textBox1.Text = "";

        textBox1.Focus();
    }

    private void btnAddOrder_Click(object sender, EventArgs e)
    {
        var fr = new AddEditOrderScreen();
        fr.ShowDialog();
    }

    private void btnUpdateOrder_Click(object sender, EventArgs e)
    {
        if (GridViewOrdersList.CurrentRow == null) return;

        var fr = new AddEditOrderScreen(Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value));
        fr.ShowDialog();
    }

    private void btnDeleteOrder_Click(object sender, EventArgs e)
    {
        if (GridViewOrdersList.CurrentRow == null) return;

        var OrderID = Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value);

        if (MessageBox.Show("Are you sure you want to delete [" + OrderID +
                            "] \n\nNote : All Medicines belonging to this Order will be deleted!",
                "Confirm Deletion", MessageBoxButtons.OKCancel) != DialogResult.OK)
            return;

        if (OBL.Delete(OrderID))
        {
            MessageBox.Show("Order Deleted Successfully.", "Done",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }
        else
        {
            MessageBox.Show("There are not Enough Qunatity !",
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnDisplayOrder_Click(object sender, EventArgs e)
    {
        if (GridViewOrdersList.CurrentRow == null) return;

        var fr = new OrderDetailsScreen(Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value));
        fr.ShowDialog();
    }

    private void cmsOperations_Opening(object sender, CancelEventArgs e)
    {
        if (GridViewOrdersList.CurrentRow == null) return;

        _UpdateOrderInfo(Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value));

        deliveringToolStripMenuItem.Enabled = completedToolStripMenuItem.Enabled = true;

        switch (_Order1.Status)
        {
            case "Completed":
                changeStatusToolStripMenuItem.Enabled = false;
                break;
            case "Delivering":
                deliveringToolStripMenuItem.Enabled = false;
                break;
            case "Preparing":
                completedToolStripMenuItem.Enabled = false;
                break;
        }
    }

    private void deliveringToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _Order1.Status = "Delivering";

        if (_Order1.Save())
        {
            MessageBox.Show("Order Saved Successfully.", "Done",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }
        else
        {
            MessageBox.Show("Could not Edit Order, other data depends on it.",
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void completedToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _Order1.Status = "Completed";

        if (_Order1.Save())
        {
            MessageBox.Show("Order Saved Successfully.", "Done",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }
        else
        {
            MessageBox.Show("Could not Edit Order, other data depends on it.",
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void paidToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _Order1.Paid = true;

        if (_Order1.Save())
        {
            MessageBox.Show("Order Saved Successfully.", "Done",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }
        else
        {
            MessageBox.Show("Could not Edit Order, other data depends on it.",
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void notPaidToolStripMenuItem_Click(object sender, EventArgs e)
    {
        _Order1.Paid = false;

        if (_Order1.Save())
        {
            MessageBox.Show("Order Saved Successfully.", "Done",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }
        else
        {
            MessageBox.Show("Could not Edit Order, other data depends on it.",
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void _UpdateOrderInfo(int ID)
    {
        _OrderID = ID;
        _Order1 = OBL.FindOrder(_OrderID);
    }
}