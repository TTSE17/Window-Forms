﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Orders;

public partial class AddEditOrderScreen : Form
{
    public AddEditOrderScreen(int? OrderID = null)
    {
        InitializeComponent();

        _OrderID = OrderID;
    }

    // private CustomersBusinessLayer _Customer1;
    // private int _CustomerID = -1;

    // private ProductsBusinessLayer _Product1;
    // private string _ProductID;

    private DataTable DT = new();

    private int? _OrderID;
    private OrdersBusinessLayer _Order1;

    private int? _DealerID;

    private void AddEditOrderScreen_Load(object sender, EventArgs e)
    {
        lblPharmacistName.Text = clsGlobal.CurrentPharmacist.PharmacistName;
        lblOrderDate.Text = DateTime.Now.ToString("yyyy/MM/dd");

        dgvMedicines.DefaultCellStyle.BackColor = dgvMedicines.DefaultCellStyle.BackColor;
        dgvMedicines.DefaultCellStyle.ForeColor = dgvMedicines.DefaultCellStyle.ForeColor;
        dgvMedicines.RowHeadersVisible = dgvDealers.RowHeadersVisible = false;

        _LoadDealers();

        if (_OrderID.HasValue)
        {
            _LoadData();
        }

        _LoadMedicines();

        _CalculateTotal();
    }

    private void _LoadDealers()
    {
        dgvDealers.DataSource = DealersBusinessLayer.GetAllDealers();

        dgvDealers.ClearSelection();
    }

    private void _LoadData()
    {
        _Order1 = OrdersBusinessLayer.FindOrder(_OrderID);
        lblOrderID.Text = Convert.ToString(_OrderID);

        _SelectDealer();

        btnNewOrder.Enabled = btnSaveOrder.Enabled = true;
    }

    private void _SelectDealer()
    {
        _DealerID = _Order1.DealerID;
        lblDealerName.Text = _Order1.DealerInfo.DealerName;

        foreach (DataGridViewRow row in dgvDealers.Rows)
        {
            if (Convert.ToInt32(row.Cells[0].Value) == _DealerID)
            {
                // dgvDealers.CurrentCell = row.Cells[0];
                row.Selected = true;
                break;
            }
        }
    }

    private void _LoadMedicines()
    {
        DT = MedicinesBusinessLayer.GetAllMedicines(_DealerID ?? 0, _OrderID ?? 0);

        DT.Columns.RemoveAt(7);
        DT.Columns.RemoveAt(6);
        
        DT.Columns[0].ReadOnly = true;
        DT.Columns[1].ReadOnly = true;
        DT.Columns[2].ReadOnly = true;
        DT.Columns[3].ReadOnly = true;
        DT.Columns[4].ReadOnly = true;
        DT.Columns[5].ReadOnly = true;
        DT.Columns[6].ReadOnly = false;

        dgvMedicines.DataSource = DT;

        dgvMedicines.Columns[5].Width = dgvMedicines.Columns[2].Width = dgvMedicines.Columns[3].Width = 71;
        dgvMedicines.Columns[1].Width = 121;
        dgvMedicines.Columns[6].Width = 131;
    }

    private void dgvDealers_SelectDealer(object sender, DataGridViewCellEventArgs e)
    {
        if (dgvDealers.Rows.Count == 0) return;

        lblTotal.Text = "0.00";

        var SelectedID = Convert.ToInt32(dgvDealers.CurrentRow.Cells[0].Value);

        if (_DealerID == SelectedID) return;

        _DealerID = SelectedID;
        lblDealerName.Text = Convert.ToString(dgvDealers.CurrentRow.Cells[1].Value);

        if (Convert.ToInt32(dgvDealers.CurrentRow.Cells[2].Value) == 0)
        {
            btnNewOrder.Enabled = btnSaveOrder.Enabled = false;
            DT.Rows.Clear();
            return;
        }

        btnNewOrder.Enabled = btnSaveOrder.Enabled = true;

        _LoadMedicines();
    }

    private void dgvMedicines_SelectMedicine(object sender, DataGridViewCellEventArgs e)
    {
        if (dgvMedicines.Rows.Count == 0) return;

        // dgvMedicines.ClearSelection();

        dgvMedicines.CurrentCell = dgvMedicines.CurrentRow.Cells[6];
        dgvMedicines.BeginEdit(true);

        // dgvMedicines.CurrentRow.Cells[6].Style.BackColor = Color.LightSkyBlue;
    }

    private void dgvMedicines_CurrentCellDirtyStateChanged(object sender, EventArgs e)
    {
        if (dgvMedicines.IsCurrentCellDirty)
        {
            dgvMedicines.CommitEdit(DataGridViewDataErrorContexts.Commit);
        }

        _CalculateTotal();
    }

    private void _CalculateTotal()
    {
        decimal Total = 0;
        foreach (DataRow Row in DT.Rows)
        {
            Total += Convert.ToDecimal(Row[6] == DBNull.Value ? 0 : Row[6]) * Convert.ToDecimal(Row[5]);
        }

        lblTotal.Text = Total.ToString("0.00");
    }

    private void dgvMedicines_InvalidData(object sender, DataGridViewDataErrorEventArgs e)
    {
        MessageBox.Show("Invalid Data !");

        dgvMedicines.CurrentCell.Value = 0;
        // dgvMedicines[e.ColumnIndex, e.RowIndex].Value = 0;

        dgvMedicines.RefreshEdit();
    }

    private void btnClearAll_Click(object sender, EventArgs e)
    {
        foreach (DataGridViewRow Row in dgvMedicines.Rows)
        {
            Row.Cells[6].Value = 0;
        }

        lblTotal.Text = "0.00";
    }

    private void btnNewOrder_Click(object sender, EventArgs e)
    {
        _Order1 = null;
        _OrderID = _DealerID = null;

        lblOrderID.Text = "N/A";
        lblOrderDate.Text = DateTime.Now.ToString("yyyy/MM/dd");

        dgvDealers.ClearSelection();

        DT.Rows.Clear();

        btnClearAll.PerformClick();
    }

    // Preparing - Delivering - Completed
    private void btnSaveOrder_Click(object sender, EventArgs e)
    {
        if (Convert.ToDecimal(lblTotal.Text) == 0)
        {
            MessageBox.Show("Select At Least One Medicine !", "Zero Selected Medicines");
            return;
        }

        if (_OrderID.HasValue)
        {
            OrdersDetailsDetailsBusinessLayer.DeleteOrderDetailsByOrderID(_OrderID);
        }
        else
        {
            _Order1 = new OrdersBusinessLayer();
            _Order1.PharmacistID = clsGlobal.CurrentPharmacist.PharmacistID.Value;
        }

        _Order1.DealerID = _DealerID.Value;

        MessageBox.Show(_Order1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.",
            "", MessageBoxButtons.OK, MessageBoxIcon.Information);

        _OrderID = _Order1.OrderID;
        lblOrderID.Text = Convert.ToString(_OrderID);

        _SaveOrderDetails();

        (Application.OpenForms["OrdersScreen"] as OrdersScreen)?.RefreshData();
    }

    private void _SaveOrderDetails()
    {
        var OrderDetails1 = new OrdersDetailsDetailsBusinessLayer();

        foreach (DataRow Row in DT.Rows)
        {
            OrderDetails1.RequiredQuantity = Convert.ToInt32(Row[6]);

            if (OrderDetails1.RequiredQuantity == 0) continue;

            OrderDetails1.Price = Convert.ToDecimal(Row[5]);
            OrderDetails1.MedicineID = Convert.ToInt32(Row[0]);
            OrderDetails1.OrderID = _OrderID.Value;

            OrderDetails1.AddNewOrderDetails();
        }
    }
}

// private void dgvMedicines_KeyPress(object sender, KeyPressEventArgs e)
// {
//     // dgvMedicines.RefreshEdit();
//     dgvMedicines.Update();
//     dgvMedicines.Refresh();
//
//     MessageBox.Show(dgvMedicines.CurrentCell.Value + "");
//
//     _CalculateTotal();
//
//     // if (e.KeyChar == (char)Keys.Enter)
//     // {
//     // }
// }
//
// private void dgvMedicines_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
// {
//     e.Control.KeyPress += (dgvMedicines_KeyPress);
// }

//  dgvMedicines.Columns[6].Visible = false;
// DataGridViewTextBoxColumn column = new DataGridViewTextBoxColumn();
// column.Name = "RequiredQuantity";
// column.ValueType = typeof(int);
// column.HeaderText = "Required Quantity";
// column.SortMode = DataGridViewColumnSortMode.Automatic;
// dgvMedicines.Columns.Add(column);

// foreach (DataGridViewRow Row in dgvMedicines.Rows)
// {
//     Row.Cells["Required Quantity"].Value = 0;
// }

// DT.Columns.RemoveAt(6);

// var RequiredQuantityColumn = new DataColumn();
// RequiredQuantityColumn.DataType = typeof(int);
// RequiredQuantityColumn.DefaultValue = 0;
// // dgvMedicines.Columns[6].DefaultCellStyle.NullValue =0; 
// RequiredQuantityColumn.ColumnName = "Required Quantity";
// DT.Columns.Add(RequiredQuantityColumn);