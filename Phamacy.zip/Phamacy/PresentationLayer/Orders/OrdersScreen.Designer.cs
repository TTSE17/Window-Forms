﻿using System.ComponentModel;

namespace PresentationLayer.Orders;

partial class OrdersScreen
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
        this.btnDisplayOrder = new System.Windows.Forms.Button();
        this.gbPharmacistOperations = new System.Windows.Forms.GroupBox();
        this.btnUpdateOrder = new System.Windows.Forms.Button();
        this.btnDeleteOrder = new System.Windows.Forms.Button();
        this.btnAddOrder = new System.Windows.Forms.Button();
        this.panel2 = new System.Windows.Forms.Panel();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.GridViewOrdersList = new System.Windows.Forms.DataGridView();
        this.cmsOperations = new System.Windows.Forms.ContextMenuStrip(this.components);
        this.changeStatusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.preparingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.deliveringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.completedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.changePaidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.paidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.notPaidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.displayOrderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
        this.lblRecords = new System.Windows.Forms.Label();
        this.label1 = new System.Windows.Forms.Label();
        this.comboBox1 = new System.Windows.Forms.ComboBox();
        this.textBox1 = new System.Windows.Forms.TextBox();
        this.gbPharmacistOperations.SuspendLayout();
        this.groupBox1.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.GridViewOrdersList)).BeginInit();
        this.cmsOperations.SuspendLayout();
        this.SuspendLayout();
        // 
        // btnDisplayOrder
        // 
        this.btnDisplayOrder.AutoSize = true;
        this.btnDisplayOrder.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDisplayOrder.Enabled = false;
        this.btnDisplayOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnDisplayOrder.ForeColor = System.Drawing.Color.Black;
        this.btnDisplayOrder.Location = new System.Drawing.Point(815, 51);
        this.btnDisplayOrder.Margin = new System.Windows.Forms.Padding(4);
        this.btnDisplayOrder.Name = "btnDisplayOrder";
        this.btnDisplayOrder.Size = new System.Drawing.Size(175, 42);
        this.btnDisplayOrder.TabIndex = 127;
        this.btnDisplayOrder.Text = "Display Order";
        this.btnDisplayOrder.UseVisualStyleBackColor = true;
        this.btnDisplayOrder.Click += new System.EventHandler(this.btnDisplayOrder_Click);
        // 
        // gbPharmacistOperations
        // 
        this.gbPharmacistOperations.Controls.Add(this.btnDisplayOrder);
        this.gbPharmacistOperations.Controls.Add(this.btnUpdateOrder);
        this.gbPharmacistOperations.Controls.Add(this.btnDeleteOrder);
        this.gbPharmacistOperations.Controls.Add(this.btnAddOrder);
        this.gbPharmacistOperations.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.gbPharmacistOperations.ForeColor = System.Drawing.Color.Crimson;
        this.gbPharmacistOperations.Location = new System.Drawing.Point(13, 435);
        this.gbPharmacistOperations.Margin = new System.Windows.Forms.Padding(4);
        this.gbPharmacistOperations.Name = "gbPharmacistOperations";
        this.gbPharmacistOperations.Padding = new System.Windows.Forms.Padding(4);
        this.gbPharmacistOperations.Size = new System.Drawing.Size(1043, 134);
        this.gbPharmacistOperations.TabIndex = 126;
        this.gbPharmacistOperations.TabStop = false;
        this.gbPharmacistOperations.Text = "The Operations ";
        // 
        // btnUpdateOrder
        // 
        this.btnUpdateOrder.AutoSize = true;
        this.btnUpdateOrder.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnUpdateOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnUpdateOrder.ForeColor = System.Drawing.Color.Black;
        this.btnUpdateOrder.Location = new System.Drawing.Point(306, 51);
        this.btnUpdateOrder.Margin = new System.Windows.Forms.Padding(4);
        this.btnUpdateOrder.Name = "btnUpdateOrder";
        this.btnUpdateOrder.Size = new System.Drawing.Size(199, 42);
        this.btnUpdateOrder.TabIndex = 126;
        this.btnUpdateOrder.Text = "Update Order";
        this.btnUpdateOrder.UseVisualStyleBackColor = true;
        this.btnUpdateOrder.Click += new System.EventHandler(this.btnUpdateOrder_Click);
        // 
        // btnDeleteOrder
        // 
        this.btnDeleteOrder.AutoSize = true;
        this.btnDeleteOrder.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDeleteOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnDeleteOrder.ForeColor = System.Drawing.Color.Black;
        this.btnDeleteOrder.Location = new System.Drawing.Point(565, 51);
        this.btnDeleteOrder.Margin = new System.Windows.Forms.Padding(4);
        this.btnDeleteOrder.Name = "btnDeleteOrder";
        this.btnDeleteOrder.Size = new System.Drawing.Size(191, 42);
        this.btnDeleteOrder.TabIndex = 125;
        this.btnDeleteOrder.Text = "Delete Order";
        this.btnDeleteOrder.UseVisualStyleBackColor = true;
        this.btnDeleteOrder.Click += new System.EventHandler(this.btnDeleteOrder_Click);
        // 
        // btnAddOrder
        // 
        this.btnAddOrder.AutoSize = true;
        this.btnAddOrder.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnAddOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnAddOrder.ForeColor = System.Drawing.Color.Black;
        this.btnAddOrder.Location = new System.Drawing.Point(88, 51);
        this.btnAddOrder.Margin = new System.Windows.Forms.Padding(4);
        this.btnAddOrder.Name = "btnAddOrder";
        this.btnAddOrder.Size = new System.Drawing.Size(164, 42);
        this.btnAddOrder.TabIndex = 121;
        this.btnAddOrder.Text = "Add Order";
        this.btnAddOrder.UseVisualStyleBackColor = true;
        this.btnAddOrder.Click += new System.EventHandler(this.btnAddOrder_Click);
        // 
        // panel2
        // 
        this.panel2.BackColor = System.Drawing.Color.DarkRed;
        this.panel2.Location = new System.Drawing.Point(252, 41);
        this.panel2.Margin = new System.Windows.Forms.Padding(4);
        this.panel2.Name = "panel2";
        this.panel2.Size = new System.Drawing.Size(407, 2);
        this.panel2.TabIndex = 132;
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.GridViewOrdersList);
        this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox1.ForeColor = System.Drawing.Color.Crimson;
        this.groupBox1.Location = new System.Drawing.Point(17, 67);
        this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox1.Size = new System.Drawing.Size(1043, 351);
        this.groupBox1.TabIndex = 131;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Orders List ";
        // 
        // GridViewOrdersList
        // 
        this.GridViewOrdersList.AllowUserToAddRows = false;
        this.GridViewOrdersList.AllowUserToDeleteRows = false;
        this.GridViewOrdersList.AllowUserToResizeColumns = false;
        this.GridViewOrdersList.AllowUserToResizeRows = false;
        dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
        dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
        dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
        this.GridViewOrdersList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
        this.GridViewOrdersList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.GridViewOrdersList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
        this.GridViewOrdersList.BackgroundColor = System.Drawing.Color.White;
        this.GridViewOrdersList.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.GridViewOrdersList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
        dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        dataGridViewCellStyle2.ForeColor = System.Drawing.Color.DimGray;
        dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.GridViewOrdersList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
        this.GridViewOrdersList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.GridViewOrdersList.ContextMenuStrip = this.cmsOperations;
        this.GridViewOrdersList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
        this.GridViewOrdersList.GridColor = System.Drawing.Color.Crimson;
        this.GridViewOrdersList.Location = new System.Drawing.Point(4, 42);
        this.GridViewOrdersList.Margin = new System.Windows.Forms.Padding(0);
        this.GridViewOrdersList.Name = "GridViewOrdersList";
        this.GridViewOrdersList.ReadOnly = true;
        dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
        dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
        dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.GridViewOrdersList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
        this.GridViewOrdersList.RowHeadersVisible = false;
        this.GridViewOrdersList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
        dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
        dataGridViewCellStyle4.ForeColor = System.Drawing.Color.DimGray;
        dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
        dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
        this.GridViewOrdersList.RowsDefaultCellStyle = dataGridViewCellStyle4;
        this.GridViewOrdersList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.GridViewOrdersList.Size = new System.Drawing.Size(1035, 295);
        this.GridViewOrdersList.TabIndex = 110;
        // 
        // cmsOperations
        // 
        this.cmsOperations.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.changeStatusToolStripMenuItem, this.changePaidToolStripMenuItem, this.displayOrderToolStripMenuItem });
        this.cmsOperations.Name = "cmsOperations";
        this.cmsOperations.Size = new System.Drawing.Size(202, 124);
        this.cmsOperations.Opening += new System.ComponentModel.CancelEventHandler(this.cmsOperations_Opening);
        // 
        // changeStatusToolStripMenuItem
        // 
        this.changeStatusToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.preparingToolStripMenuItem, this.deliveringToolStripMenuItem, this.completedToolStripMenuItem });
        this.changeStatusToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
        this.changeStatusToolStripMenuItem.Name = "changeStatusToolStripMenuItem";
        this.changeStatusToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 11, 0, 1);
        this.changeStatusToolStripMenuItem.Size = new System.Drawing.Size(201, 40);
        this.changeStatusToolStripMenuItem.Text = "Change Status";
        // 
        // preparingToolStripMenuItem
        // 
        this.preparingToolStripMenuItem.Enabled = false;
        this.preparingToolStripMenuItem.Name = "preparingToolStripMenuItem";
        this.preparingToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 5);
        this.preparingToolStripMenuItem.Size = new System.Drawing.Size(176, 34);
        this.preparingToolStripMenuItem.Text = "Preparing";
        // 
        // deliveringToolStripMenuItem
        // 
        this.deliveringToolStripMenuItem.Name = "deliveringToolStripMenuItem";
        this.deliveringToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 5);
        this.deliveringToolStripMenuItem.Size = new System.Drawing.Size(176, 34);
        this.deliveringToolStripMenuItem.Text = "Delivering";
        this.deliveringToolStripMenuItem.Click += new System.EventHandler(this.deliveringToolStripMenuItem_Click);
        // 
        // completedToolStripMenuItem
        // 
        this.completedToolStripMenuItem.Name = "completedToolStripMenuItem";
        this.completedToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 5);
        this.completedToolStripMenuItem.Size = new System.Drawing.Size(176, 34);
        this.completedToolStripMenuItem.Text = "Completed";
        this.completedToolStripMenuItem.Click += new System.EventHandler(this.completedToolStripMenuItem_Click);
        // 
        // changePaidToolStripMenuItem
        // 
        this.changePaidToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.paidToolStripMenuItem, this.notPaidToolStripMenuItem });
        this.changePaidToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
        this.changePaidToolStripMenuItem.Name = "changePaidToolStripMenuItem";
        this.changePaidToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 11);
        this.changePaidToolStripMenuItem.Size = new System.Drawing.Size(201, 40);
        this.changePaidToolStripMenuItem.Text = "Change Paid";
        // 
        // paidToolStripMenuItem
        // 
        this.paidToolStripMenuItem.Name = "paidToolStripMenuItem";
        this.paidToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 5);
        this.paidToolStripMenuItem.Size = new System.Drawing.Size(156, 34);
        this.paidToolStripMenuItem.Text = "Paid";
        this.paidToolStripMenuItem.Click += new System.EventHandler(this.paidToolStripMenuItem_Click);
        // 
        // notPaidToolStripMenuItem
        // 
        this.notPaidToolStripMenuItem.Name = "notPaidToolStripMenuItem";
        this.notPaidToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 5);
        this.notPaidToolStripMenuItem.Size = new System.Drawing.Size(156, 34);
        this.notPaidToolStripMenuItem.Text = "Not Paid";
        this.notPaidToolStripMenuItem.Click += new System.EventHandler(this.notPaidToolStripMenuItem_Click);
        // 
        // displayOrderToolStripMenuItem
        // 
        this.displayOrderToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
        this.displayOrderToolStripMenuItem.Name = "displayOrderToolStripMenuItem";
        this.displayOrderToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 11);
        this.displayOrderToolStripMenuItem.Size = new System.Drawing.Size(201, 40);
        this.displayOrderToolStripMenuItem.Text = "Display Order";
        this.displayOrderToolStripMenuItem.Click += new System.EventHandler(this.btnDisplayOrder_Click);
        // 
        // lblRecords
        // 
        this.lblRecords.AutoSize = true;
        this.lblRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.lblRecords.Location = new System.Drawing.Point(1030, 17);
        this.lblRecords.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.lblRecords.Name = "lblRecords";
        this.lblRecords.Size = new System.Drawing.Size(26, 29);
        this.lblRecords.TabIndex = 130;
        this.lblRecords.Text = "0";
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label1.Location = new System.Drawing.Point(861, 17);
        this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(161, 29);
        this.label1.TabIndex = 129;
        this.label1.Text = "Total Orders :";
        // 
        // comboBox1
        // 
        this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.comboBox1.FormattingEnabled = true;
        this.comboBox1.Items.AddRange(new object[] { "Order ID", "Status", "IsPaid" });
        this.comboBox1.Location = new System.Drawing.Point(17, 14);
        this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox1.Name = "comboBox1";
        this.comboBox1.Size = new System.Drawing.Size(207, 32);
        this.comboBox1.TabIndex = 127;
        this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
        // 
        // textBox1
        // 
        this.textBox1.BackColor = System.Drawing.SystemColors.Control;
        this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.textBox1.Location = new System.Drawing.Point(252, 21);
        this.textBox1.Margin = new System.Windows.Forms.Padding(4);
        this.textBox1.Name = "textBox1";
        this.textBox1.Size = new System.Drawing.Size(407, 25);
        this.textBox1.TabIndex = 128;
        this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
        // 
        // OrdersScreen
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(1072, 583);
        this.Controls.Add(this.gbPharmacistOperations);
        this.Controls.Add(this.panel2);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.lblRecords);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.comboBox1);
        this.Controls.Add(this.textBox1);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        this.Name = "OrdersScreen";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Orers Screen";
        this.Load += new System.EventHandler(this.OrdersScreen_Load);
        this.Shown += new System.EventHandler(this.OrdersScreen_Shown);
        this.gbPharmacistOperations.ResumeLayout(false);
        this.gbPharmacistOperations.PerformLayout();
        this.groupBox1.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.GridViewOrdersList)).EndInit();
        this.cmsOperations.ResumeLayout(false);
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.ToolStripMenuItem paidToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem notPaidToolStripMenuItem;

    private System.Windows.Forms.ToolStripMenuItem changeStatusToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem changePaidToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem displayOrderToolStripMenuItem;
    private System.Windows.Forms.ContextMenuStrip cmsOperations;
    private System.Windows.Forms.ToolStripMenuItem preparingToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem deliveringToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem completedToolStripMenuItem;

    private System.Windows.Forms.Button btnDisplayOrder;
    private System.Windows.Forms.GroupBox gbPharmacistOperations;
    private System.Windows.Forms.Button btnUpdateOrder;
    private System.Windows.Forms.Button btnDeleteOrder;
    private System.Windows.Forms.Button btnAddOrder;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.DataGridView GridViewOrdersList;
    private System.Windows.Forms.Label lblRecords;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.TextBox textBox1;

    #endregion
}