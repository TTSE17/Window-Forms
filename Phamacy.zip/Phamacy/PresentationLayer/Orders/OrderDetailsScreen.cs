﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Orders;

public partial class OrderDetailsScreen : Form
{
    private OrdersBusinessLayer _Order1;

    public OrderDetailsScreen(int OrderID)
    {
        InitializeComponent();
        _Order1 = OrdersBusinessLayer.FindOrder(OrderID);
    }

    private void OrderDetailsScreen_Load(object sender, EventArgs e)
    {
        _LoadOrder();

        _LoadOrderDetails();

        _CalculateTotal();
    }

    private void _LoadOrder()
    {
        lblOrderID.Text = Convert.ToString(_Order1.OrderID);
        lblOrderDate.Text = _Order1.OrderData.ToString("yyyy/MM/dd");
        lblPharmacist.Text = _Order1.PharmacistInfo.PharmacistName;
        lblDealerName.Text = _Order1.DealerInfo.DealerName;
        lblStatus.Text = _Order1.Status;
        lblIsPaid.Text = _Order1.Paid ? "Yes" : "No";
    }

    private void _LoadOrderDetails()
    {
        dgvMedicines.RowHeadersVisible = false;

        dgvMedicines.DataSource = MedicinesBusinessLayer.GetAllMedicines(_Order1.DealerID, _Order1.OrderID);

        dgvMedicines.Columns.RemoveAt(6);
        dgvMedicines.Columns.RemoveAt(6);

        dgvMedicines.Columns[5].Width = dgvMedicines.Columns[2].Width = dgvMedicines.Columns[3].Width = 71;
        dgvMedicines.Columns[1].Width = 121;
        dgvMedicines.Columns[6].Width = 131;

        _RemoveNotRequiredMedicines();
    }

    private void _RemoveNotRequiredMedicines()
    {
        foreach (DataGridViewRow Row in dgvMedicines.Rows)
        {
            var RequiredQuantity = Convert.ToInt32(Row.Cells[6].Value);
            if (RequiredQuantity == 0)
                dgvMedicines.Rows.RemoveAt(Row.Index);
        }
    }

    private void _CalculateTotal()
    {
        decimal Total = 0;
        foreach (DataGridViewRow Row in dgvMedicines.Rows)
        {
            Total += Convert.ToDecimal(Row.Cells[6].Value == DBNull.Value
                         ? 0
                         : Row.Cells[6].Value) *
                     Convert.ToDecimal(Row.Cells[5].Value);
        }

        lblTotal.Text = Total.ToString("0.00");
    }
}