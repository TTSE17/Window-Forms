﻿using System.ComponentModel;

namespace PresentationLayer.Medicines;

partial class AddEditMedicineScreen
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        this.panel1 = new System.Windows.Forms.Panel();
        this.groupBox3 = new System.Windows.Forms.GroupBox();
        this.panel6 = new System.Windows.Forms.Panel();
        this.cbCategories = new System.Windows.Forms.ComboBox();
        this.button4 = new System.Windows.Forms.Button();
        this.groupBox4 = new System.Windows.Forms.GroupBox();
        this.panel7 = new System.Windows.Forms.Panel();
        this.dtpExpirationDate = new System.Windows.Forms.DateTimePicker();
        this.button5 = new System.Windows.Forms.Button();
        this.groupBox5 = new System.Windows.Forms.GroupBox();
        this.panel8 = new System.Windows.Forms.Panel();
        this.nudPrice = new System.Windows.Forms.NumericUpDown();
        this.button6 = new System.Windows.Forms.Button();
        this.groupBox2 = new System.Windows.Forms.GroupBox();
        this.panel5 = new System.Windows.Forms.Panel();
        this.button3 = new System.Windows.Forms.Button();
        this.txtMedicineID = new System.Windows.Forms.TextBox();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.panel3 = new System.Windows.Forms.Panel();
        this.button1 = new System.Windows.Forms.Button();
        this.txtMedicineName = new System.Windows.Forms.TextBox();
        this.groupBox_Password = new System.Windows.Forms.GroupBox();
        this.panel4 = new System.Windows.Forms.Panel();
        this.nudQuantity = new System.Windows.Forms.NumericUpDown();
        this.button2 = new System.Windows.Forms.Button();
        this.btnSave = new System.Windows.Forms.Button();
        this.panel2 = new System.Windows.Forms.Panel();
        this.lblTitle = new System.Windows.Forms.Label();
        this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
        this.panel1.SuspendLayout();
        this.groupBox3.SuspendLayout();
        this.panel6.SuspendLayout();
        this.groupBox4.SuspendLayout();
        this.panel7.SuspendLayout();
        this.groupBox5.SuspendLayout();
        this.panel8.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).BeginInit();
        this.groupBox2.SuspendLayout();
        this.panel5.SuspendLayout();
        this.groupBox1.SuspendLayout();
        this.panel3.SuspendLayout();
        this.groupBox_Password.SuspendLayout();
        this.panel4.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).BeginInit();
        this.panel2.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
        this.SuspendLayout();
        // 
        // panel1
        // 
        this.panel1.BackColor = System.Drawing.Color.White;
        this.panel1.Controls.Add(this.groupBox3);
        this.panel1.Controls.Add(this.groupBox4);
        this.panel1.Controls.Add(this.groupBox5);
        this.panel1.Controls.Add(this.groupBox2);
        this.panel1.Controls.Add(this.groupBox1);
        this.panel1.Controls.Add(this.groupBox_Password);
        this.panel1.Controls.Add(this.btnSave);
        this.panel1.Controls.Add(this.panel2);
        this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
        this.panel1.Location = new System.Drawing.Point(0, 0);
        this.panel1.Margin = new System.Windows.Forms.Padding(4);
        this.panel1.Name = "panel1";
        this.panel1.Size = new System.Drawing.Size(798, 448);
        this.panel1.TabIndex = 4;
        // 
        // groupBox3
        // 
        this.groupBox3.BackColor = System.Drawing.Color.Transparent;
        this.groupBox3.Controls.Add(this.panel6);
        this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox3.ForeColor = System.Drawing.Color.DimGray;
        this.groupBox3.Location = new System.Drawing.Point(38, 166);
        this.groupBox3.Margin = new System.Windows.Forms.Padding(0);
        this.groupBox3.Name = "groupBox3";
        this.groupBox3.Padding = new System.Windows.Forms.Padding(0);
        this.groupBox3.Size = new System.Drawing.Size(333, 71);
        this.groupBox3.TabIndex = 83;
        this.groupBox3.TabStop = false;
        this.groupBox3.Text = "Category";
        // 
        // panel6
        // 
        this.panel6.Anchor = System.Windows.Forms.AnchorStyles.None;
        this.panel6.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel6.Controls.Add(this.cbCategories);
        this.panel6.Controls.Add(this.button4);
        this.panel6.Location = new System.Drawing.Point(13, 21);
        this.panel6.Margin = new System.Windows.Forms.Padding(0);
        this.panel6.Name = "panel6";
        this.panel6.Size = new System.Drawing.Size(311, 41);
        this.panel6.TabIndex = 1;
        // 
        // cbCategories
        // 
        this.cbCategories.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.cbCategories.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.cbCategories.FormattingEnabled = true;
        this.cbCategories.Location = new System.Drawing.Point(57, 7);
        this.cbCategories.Name = "cbCategories";
        this.cbCategories.Size = new System.Drawing.Size(229, 28);
        this.cbCategories.TabIndex = 12;
        this.cbCategories.Validating += new System.ComponentModel.CancelEventHandler(this.textBox_Validate);
        // 
        // button4
        // 
        this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button4.FlatAppearance.BorderSize = 0;
        this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.button4.Image = global::PresentationLayer.Properties.Resources.layers;
        this.button4.Location = new System.Drawing.Point(0, 0);
        this.button4.Margin = new System.Windows.Forms.Padding(0);
        this.button4.Name = "button4";
        this.button4.Size = new System.Drawing.Size(48, 41);
        this.button4.TabIndex = 11;
        this.button4.UseVisualStyleBackColor = false;
        // 
        // groupBox4
        // 
        this.groupBox4.BackColor = System.Drawing.Color.Transparent;
        this.groupBox4.Controls.Add(this.panel7);
        this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox4.ForeColor = System.Drawing.Color.DimGray;
        this.groupBox4.Location = new System.Drawing.Point(38, 250);
        this.groupBox4.Margin = new System.Windows.Forms.Padding(0);
        this.groupBox4.Name = "groupBox4";
        this.groupBox4.Padding = new System.Windows.Forms.Padding(0);
        this.groupBox4.Size = new System.Drawing.Size(333, 71);
        this.groupBox4.TabIndex = 82;
        this.groupBox4.TabStop = false;
        this.groupBox4.Text = "Expiration Date";
        // 
        // panel7
        // 
        this.panel7.Anchor = System.Windows.Forms.AnchorStyles.None;
        this.panel7.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel7.Controls.Add(this.dtpExpirationDate);
        this.panel7.Controls.Add(this.button5);
        this.panel7.Location = new System.Drawing.Point(13, 21);
        this.panel7.Margin = new System.Windows.Forms.Padding(0);
        this.panel7.Name = "panel7";
        this.panel7.Size = new System.Drawing.Size(311, 41);
        this.panel7.TabIndex = 1;
        // 
        // dtpExpirationDate
        // 
        this.dtpExpirationDate.Font = new System.Drawing.Font("Segoe UI", 9.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.dtpExpirationDate.Location = new System.Drawing.Point(57, 7);
        this.dtpExpirationDate.Name = "dtpExpirationDate";
        this.dtpExpirationDate.Size = new System.Drawing.Size(229, 29);
        this.dtpExpirationDate.TabIndex = 12;
        // 
        // button5
        // 
        this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button5.FlatAppearance.BorderSize = 0;
        this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.button5.Image = global::PresentationLayer.Properties.Resources.field_date;
        this.button5.Location = new System.Drawing.Point(0, 0);
        this.button5.Margin = new System.Windows.Forms.Padding(0);
        this.button5.Name = "button5";
        this.button5.Size = new System.Drawing.Size(48, 41);
        this.button5.TabIndex = 11;
        this.button5.UseVisualStyleBackColor = false;
        // 
        // groupBox5
        // 
        this.groupBox5.BackColor = System.Drawing.Color.Transparent;
        this.groupBox5.Controls.Add(this.panel8);
        this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox5.ForeColor = System.Drawing.Color.DimGray;
        this.groupBox5.Location = new System.Drawing.Point(420, 250);
        this.groupBox5.Margin = new System.Windows.Forms.Padding(0);
        this.groupBox5.Name = "groupBox5";
        this.groupBox5.Padding = new System.Windows.Forms.Padding(0);
        this.groupBox5.Size = new System.Drawing.Size(333, 71);
        this.groupBox5.TabIndex = 81;
        this.groupBox5.TabStop = false;
        this.groupBox5.Text = "Price";
        // 
        // panel8
        // 
        this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
        this.panel8.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel8.Controls.Add(this.nudPrice);
        this.panel8.Controls.Add(this.button6);
        this.panel8.Location = new System.Drawing.Point(13, 21);
        this.panel8.Margin = new System.Windows.Forms.Padding(0);
        this.panel8.Name = "panel8";
        this.panel8.Size = new System.Drawing.Size(311, 41);
        this.panel8.TabIndex = 1;
        // 
        // nudPrice
        // 
        this.nudPrice.DecimalPlaces = 1;
        this.nudPrice.Font = new System.Drawing.Font("Segoe UI", 9.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.nudPrice.Increment = new decimal(new int[] { 10, 0, 0, 0 });
        this.nudPrice.Location = new System.Drawing.Point(57, 7);
        this.nudPrice.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
        this.nudPrice.Name = "nudPrice";
        this.nudPrice.Size = new System.Drawing.Size(229, 29);
        this.nudPrice.TabIndex = 84;
        // 
        // button6
        // 
        this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button6.FlatAppearance.BorderSize = 0;
        this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.button6.Image = global::PresentationLayer.Properties.Resources.price_tag;
        this.button6.Location = new System.Drawing.Point(0, 0);
        this.button6.Margin = new System.Windows.Forms.Padding(0);
        this.button6.Name = "button6";
        this.button6.Size = new System.Drawing.Size(48, 41);
        this.button6.TabIndex = 11;
        this.button6.UseVisualStyleBackColor = false;
        // 
        // groupBox2
        // 
        this.groupBox2.BackColor = System.Drawing.Color.Transparent;
        this.groupBox2.Controls.Add(this.panel5);
        this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox2.ForeColor = System.Drawing.Color.DimGray;
        this.groupBox2.Location = new System.Drawing.Point(38, 79);
        this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
        this.groupBox2.Name = "groupBox2";
        this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
        this.groupBox2.Size = new System.Drawing.Size(333, 71);
        this.groupBox2.TabIndex = 80;
        this.groupBox2.TabStop = false;
        this.groupBox2.Text = "Medicine ID";
        // 
        // panel5
        // 
        this.panel5.Anchor = System.Windows.Forms.AnchorStyles.None;
        this.panel5.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel5.Controls.Add(this.button3);
        this.panel5.Controls.Add(this.txtMedicineID);
        this.panel5.Location = new System.Drawing.Point(13, 21);
        this.panel5.Margin = new System.Windows.Forms.Padding(0);
        this.panel5.Name = "panel5";
        this.panel5.Size = new System.Drawing.Size(311, 41);
        this.panel5.TabIndex = 1;
        // 
        // button3
        // 
        this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button3.FlatAppearance.BorderSize = 0;
        this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.button3.Image = global::PresentationLayer.Properties.Resources.Lost_Driving_License_32;
        this.button3.Location = new System.Drawing.Point(0, 0);
        this.button3.Margin = new System.Windows.Forms.Padding(0);
        this.button3.Name = "button3";
        this.button3.Size = new System.Drawing.Size(48, 41);
        this.button3.TabIndex = 11;
        this.button3.UseVisualStyleBackColor = false;
        // 
        // txtMedicineID
        // 
        this.txtMedicineID.BackColor = System.Drawing.Color.White;
        this.txtMedicineID.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.txtMedicineID.Enabled = false;
        this.txtMedicineID.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.txtMedicineID.ForeColor = System.Drawing.Color.DimGray;
        this.txtMedicineID.Location = new System.Drawing.Point(57, 9);
        this.txtMedicineID.Margin = new System.Windows.Forms.Padding(0);
        this.txtMedicineID.Name = "txtMedicineID";
        this.txtMedicineID.ReadOnly = true;
        this.txtMedicineID.Size = new System.Drawing.Size(233, 25);
        this.txtMedicineID.TabIndex = 1;
        // 
        // groupBox1
        // 
        this.groupBox1.BackColor = System.Drawing.Color.Transparent;
        this.groupBox1.Controls.Add(this.panel3);
        this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox1.ForeColor = System.Drawing.Color.DimGray;
        this.groupBox1.Location = new System.Drawing.Point(420, 79);
        this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
        this.groupBox1.Size = new System.Drawing.Size(333, 71);
        this.groupBox1.TabIndex = 79;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Medicine Name";
        // 
        // panel3
        // 
        this.panel3.Anchor = System.Windows.Forms.AnchorStyles.None;
        this.panel3.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel3.Controls.Add(this.button1);
        this.panel3.Controls.Add(this.txtMedicineName);
        this.panel3.Location = new System.Drawing.Point(13, 21);
        this.panel3.Margin = new System.Windows.Forms.Padding(0);
        this.panel3.Name = "panel3";
        this.panel3.Size = new System.Drawing.Size(311, 41);
        this.panel3.TabIndex = 1;
        // 
        // button1
        // 
        this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button1.FlatAppearance.BorderSize = 0;
        this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.button1.Image = global::PresentationLayer.Properties.Resources.pills;
        this.button1.Location = new System.Drawing.Point(0, 0);
        this.button1.Margin = new System.Windows.Forms.Padding(0);
        this.button1.Name = "button1";
        this.button1.Size = new System.Drawing.Size(48, 41);
        this.button1.TabIndex = 11;
        this.button1.UseVisualStyleBackColor = false;
        // 
        // txtMedicineName
        // 
        this.txtMedicineName.BackColor = System.Drawing.Color.White;
        this.txtMedicineName.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.txtMedicineName.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.txtMedicineName.ForeColor = System.Drawing.Color.DimGray;
        this.txtMedicineName.Location = new System.Drawing.Point(61, 9);
        this.txtMedicineName.Margin = new System.Windows.Forms.Padding(0);
        this.txtMedicineName.Name = "txtMedicineName";
        this.txtMedicineName.Size = new System.Drawing.Size(229, 25);
        this.txtMedicineName.TabIndex = 1;
        this.txtMedicineName.Validating += new System.ComponentModel.CancelEventHandler(this.textBox_Validate);
        // 
        // groupBox_Password
        // 
        this.groupBox_Password.BackColor = System.Drawing.Color.Transparent;
        this.groupBox_Password.Controls.Add(this.panel4);
        this.groupBox_Password.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.groupBox_Password.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox_Password.ForeColor = System.Drawing.Color.DimGray;
        this.groupBox_Password.Location = new System.Drawing.Point(420, 166);
        this.groupBox_Password.Margin = new System.Windows.Forms.Padding(0);
        this.groupBox_Password.Name = "groupBox_Password";
        this.groupBox_Password.Padding = new System.Windows.Forms.Padding(0);
        this.groupBox_Password.Size = new System.Drawing.Size(333, 71);
        this.groupBox_Password.TabIndex = 78;
        this.groupBox_Password.TabStop = false;
        this.groupBox_Password.Text = "Quantity";
        // 
        // panel4
        // 
        this.panel4.Anchor = System.Windows.Forms.AnchorStyles.None;
        this.panel4.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel4.Controls.Add(this.nudQuantity);
        this.panel4.Controls.Add(this.button2);
        this.panel4.Location = new System.Drawing.Point(13, 21);
        this.panel4.Margin = new System.Windows.Forms.Padding(0);
        this.panel4.Name = "panel4";
        this.panel4.Size = new System.Drawing.Size(311, 41);
        this.panel4.TabIndex = 1;
        // 
        // nudQuantity
        // 
        this.nudQuantity.Font = new System.Drawing.Font("Segoe UI", 9.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.nudQuantity.Location = new System.Drawing.Point(57, 7);
        this.nudQuantity.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
        this.nudQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
        this.nudQuantity.Name = "nudQuantity";
        this.nudQuantity.Size = new System.Drawing.Size(233, 29);
        this.nudQuantity.TabIndex = 85;
        this.nudQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
        // 
        // button2
        // 
        this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button2.FlatAppearance.BorderSize = 0;
        this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.button2.Image = global::PresentationLayer.Properties.Resources.coinstack;
        this.button2.Location = new System.Drawing.Point(0, 0);
        this.button2.Margin = new System.Windows.Forms.Padding(0);
        this.button2.Name = "button2";
        this.button2.Size = new System.Drawing.Size(48, 41);
        this.button2.TabIndex = 11;
        this.button2.UseVisualStyleBackColor = false;
        // 
        // btnSave
        // 
        this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Silver;
        this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.btnSave.ForeColor = System.Drawing.Color.White;
        this.btnSave.Location = new System.Drawing.Point(307, 362);
        this.btnSave.Margin = new System.Windows.Forms.Padding(4);
        this.btnSave.Name = "btnSave";
        this.btnSave.Size = new System.Drawing.Size(174, 47);
        this.btnSave.TabIndex = 77;
        this.btnSave.Text = "Save";
        this.btnSave.UseVisualStyleBackColor = false;
        this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
        // 
        // panel2
        // 
        this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
        this.panel2.Controls.Add(this.lblTitle);
        this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
        this.panel2.Location = new System.Drawing.Point(0, 0);
        this.panel2.Margin = new System.Windows.Forms.Padding(4);
        this.panel2.Name = "panel2";
        this.panel2.Size = new System.Drawing.Size(798, 53);
        this.panel2.TabIndex = 75;
        // 
        // lblTitle
        // 
        this.lblTitle.AutoSize = true;
        this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
        this.lblTitle.ForeColor = System.Drawing.Color.DimGray;
        this.lblTitle.Location = new System.Drawing.Point(307, 9);
        this.lblTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.lblTitle.Name = "lblTitle";
        this.lblTitle.Size = new System.Drawing.Size(184, 35);
        this.lblTitle.TabIndex = 71;
        this.lblTitle.Text = "New Medicine";
        // 
        // errorProvider1
        // 
        this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
        this.errorProvider1.ContainerControl = this;
        // 
        // AddEditMedicineScreen
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(798, 448);
        this.Controls.Add(this.panel1);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        this.Name = "AddEditMedicineScreen";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Add/Edit Medicine Screen";
        this.Load += new System.EventHandler(this.AddEditMedicineScreen_Load);
        this.panel1.ResumeLayout(false);
        this.groupBox3.ResumeLayout(false);
        this.panel6.ResumeLayout(false);
        this.groupBox4.ResumeLayout(false);
        this.panel7.ResumeLayout(false);
        this.groupBox5.ResumeLayout(false);
        this.panel8.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).EndInit();
        this.groupBox2.ResumeLayout(false);
        this.panel5.ResumeLayout(false);
        this.panel5.PerformLayout();
        this.groupBox1.ResumeLayout(false);
        this.panel3.ResumeLayout(false);
        this.panel3.PerformLayout();
        this.groupBox_Password.ResumeLayout(false);
        this.panel4.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)(this.nudQuantity)).EndInit();
        this.panel2.ResumeLayout(false);
        this.panel2.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
        this.ResumeLayout(false);
    }

    private System.Windows.Forms.ErrorProvider errorProvider1;

    private System.Windows.Forms.NumericUpDown nudQuantity;

    private System.Windows.Forms.NumericUpDown nudPrice;

    private System.Windows.Forms.DateTimePicker dtpExpirationDate;

    private System.Windows.Forms.ComboBox cbCategories;

    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel panel5;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.TextBox txtMedicineID;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.TextBox txtMedicineName;
    private System.Windows.Forms.GroupBox groupBox_Password;
    private System.Windows.Forms.Panel panel4;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button btnSave;
    private System.Windows.Forms.Panel panel2;
    private System.Windows.Forms.Label lblTitle;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Panel panel6;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.GroupBox groupBox4;
    private System.Windows.Forms.Panel panel7;
    private System.Windows.Forms.Button button5;
    private System.Windows.Forms.GroupBox groupBox5;
    private System.Windows.Forms.Panel panel8;
    private System.Windows.Forms.Button button6;

    #endregion
}