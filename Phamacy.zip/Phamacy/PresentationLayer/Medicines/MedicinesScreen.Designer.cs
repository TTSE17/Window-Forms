﻿using System.ComponentModel;

namespace PresentationLayer.Medicines;

partial class MedicinesScreen
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
        System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
        this.GridViewMedicinesList = new System.Windows.Forms.DataGridView();
        this.groupBox1 = new System.Windows.Forms.GroupBox();
        this.label1 = new System.Windows.Forms.Label();
        this.lblRecords = new System.Windows.Forms.Label();
        this.comboBox1 = new System.Windows.Forms.ComboBox();
        this.textBox1 = new System.Windows.Forms.TextBox();
        this.panel2 = new System.Windows.Forms.Panel();
        this.btnAddMedicine = new System.Windows.Forms.Button();
        this.btnDeleteMedicine = new System.Windows.Forms.Button();
        this.btnUpdateMedicine = new System.Windows.Forms.Button();
        this.btnPrintMedicine = new System.Windows.Forms.Button();
        this.gbOperations = new System.Windows.Forms.GroupBox();
        ((System.ComponentModel.ISupportInitialize)(this.GridViewMedicinesList)).BeginInit();
        this.groupBox1.SuspendLayout();
        this.gbOperations.SuspendLayout();
        this.SuspendLayout();
        // 
        // GridViewMedicinesList
        // 
        this.GridViewMedicinesList.AllowUserToAddRows = false;
        this.GridViewMedicinesList.AllowUserToDeleteRows = false;
        this.GridViewMedicinesList.AllowUserToResizeColumns = false;
        this.GridViewMedicinesList.AllowUserToResizeRows = false;
        dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
        dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
        dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
        this.GridViewMedicinesList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
        this.GridViewMedicinesList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
        this.GridViewMedicinesList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
        this.GridViewMedicinesList.BackgroundColor = System.Drawing.Color.White;
        this.GridViewMedicinesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.GridViewMedicinesList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
        dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
        dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        dataGridViewCellStyle2.ForeColor = System.Drawing.Color.DimGray;
        dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.GridViewMedicinesList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
        this.GridViewMedicinesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        this.GridViewMedicinesList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
        this.GridViewMedicinesList.GridColor = System.Drawing.Color.Crimson;
        this.GridViewMedicinesList.Location = new System.Drawing.Point(4, 42);
        this.GridViewMedicinesList.Margin = new System.Windows.Forms.Padding(0);
        this.GridViewMedicinesList.MultiSelect = false;
        this.GridViewMedicinesList.Name = "GridViewMedicinesList";
        this.GridViewMedicinesList.ReadOnly = true;
        dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
        dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
        dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
        dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
        this.GridViewMedicinesList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
        this.GridViewMedicinesList.RowHeadersVisible = false;
        this.GridViewMedicinesList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
        dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
        dataGridViewCellStyle4.ForeColor = System.Drawing.Color.DimGray;
        dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
        dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
        this.GridViewMedicinesList.RowsDefaultCellStyle = dataGridViewCellStyle4;
        this.GridViewMedicinesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
        this.GridViewMedicinesList.Size = new System.Drawing.Size(1065, 295);
        this.GridViewMedicinesList.TabIndex = 110;
        // 
        // groupBox1
        // 
        this.groupBox1.Controls.Add(this.GridViewMedicinesList);
        this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.groupBox1.ForeColor = System.Drawing.Color.Crimson;
        this.groupBox1.Location = new System.Drawing.Point(15, 88);
        this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
        this.groupBox1.Name = "groupBox1";
        this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
        this.groupBox1.Size = new System.Drawing.Size(1073, 351);
        this.groupBox1.TabIndex = 124;
        this.groupBox1.TabStop = false;
        this.groupBox1.Text = "Medicines List ";
        // 
        // label1
        // 
        this.label1.AutoSize = true;
        this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.label1.Location = new System.Drawing.Point(814, 38);
        this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.label1.Name = "label1";
        this.label1.Size = new System.Drawing.Size(197, 29);
        this.label1.TabIndex = 122;
        this.label1.Text = "Total Medicines :";
        // 
        // lblRecords
        // 
        this.lblRecords.AutoSize = true;
        this.lblRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.lblRecords.Location = new System.Drawing.Point(1025, 40);
        this.lblRecords.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
        this.lblRecords.Name = "lblRecords";
        this.lblRecords.Size = new System.Drawing.Size(26, 29);
        this.lblRecords.TabIndex = 123;
        this.lblRecords.Text = "0";
        // 
        // comboBox1
        // 
        this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
        this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.comboBox1.FormattingEnabled = true;
        this.comboBox1.Items.AddRange(new object[] { "Medicine ID", "Medicine Name", "Category" });
        this.comboBox1.Location = new System.Drawing.Point(19, 35);
        this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
        this.comboBox1.Name = "comboBox1";
        this.comboBox1.Size = new System.Drawing.Size(207, 32);
        this.comboBox1.TabIndex = 120;
        this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
        // 
        // textBox1
        // 
        this.textBox1.BackColor = System.Drawing.SystemColors.Control;
        this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
        this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.textBox1.Location = new System.Drawing.Point(254, 38);
        this.textBox1.Margin = new System.Windows.Forms.Padding(4);
        this.textBox1.Name = "textBox1";
        this.textBox1.Size = new System.Drawing.Size(407, 25);
        this.textBox1.TabIndex = 121;
        this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
        // 
        // panel2
        // 
        this.panel2.BackColor = System.Drawing.Color.DarkRed;
        this.panel2.Location = new System.Drawing.Point(254, 62);
        this.panel2.Margin = new System.Windows.Forms.Padding(4);
        this.panel2.Name = "panel2";
        this.panel2.Size = new System.Drawing.Size(407, 2);
        this.panel2.TabIndex = 126;
        // 
        // btnAddMedicine
        // 
        this.btnAddMedicine.AutoSize = true;
        this.btnAddMedicine.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnAddMedicine.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnAddMedicine.ForeColor = System.Drawing.Color.Black;
        this.btnAddMedicine.Location = new System.Drawing.Point(88, 48);
        this.btnAddMedicine.Margin = new System.Windows.Forms.Padding(4);
        this.btnAddMedicine.Name = "btnAddMedicine";
        this.btnAddMedicine.Size = new System.Drawing.Size(172, 42);
        this.btnAddMedicine.TabIndex = 121;
        this.btnAddMedicine.Text = "Add Medicine";
        this.btnAddMedicine.UseVisualStyleBackColor = true;
        this.btnAddMedicine.Click += new System.EventHandler(this.btnAddMedicine_Click);
        // 
        // btnDeleteMedicine
        // 
        this.btnDeleteMedicine.AutoSize = true;
        this.btnDeleteMedicine.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnDeleteMedicine.Enabled = false;
        this.btnDeleteMedicine.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnDeleteMedicine.ForeColor = System.Drawing.Color.Black;
        this.btnDeleteMedicine.Location = new System.Drawing.Point(592, 48);
        this.btnDeleteMedicine.Margin = new System.Windows.Forms.Padding(4);
        this.btnDeleteMedicine.Name = "btnDeleteMedicine";
        this.btnDeleteMedicine.Size = new System.Drawing.Size(197, 42);
        this.btnDeleteMedicine.TabIndex = 125;
        this.btnDeleteMedicine.Text = "Delete Medicine";
        this.btnDeleteMedicine.UseVisualStyleBackColor = true;
        this.btnDeleteMedicine.Click += new System.EventHandler(this.btnDeleteMedicine_Click);
        // 
        // btnUpdateMedicine
        // 
        this.btnUpdateMedicine.AutoSize = true;
        this.btnUpdateMedicine.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnUpdateMedicine.Enabled = false;
        this.btnUpdateMedicine.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnUpdateMedicine.ForeColor = System.Drawing.Color.Black;
        this.btnUpdateMedicine.Location = new System.Drawing.Point(322, 48);
        this.btnUpdateMedicine.Margin = new System.Windows.Forms.Padding(4);
        this.btnUpdateMedicine.Name = "btnUpdateMedicine";
        this.btnUpdateMedicine.Size = new System.Drawing.Size(205, 42);
        this.btnUpdateMedicine.TabIndex = 126;
        this.btnUpdateMedicine.Text = "Update Medicine";
        this.btnUpdateMedicine.UseVisualStyleBackColor = true;
        this.btnUpdateMedicine.Click += new System.EventHandler(this.btnUpdateMedicine_Click);
        // 
        // btnPrintMedicine
        // 
        this.btnPrintMedicine.AutoSize = true;
        this.btnPrintMedicine.Cursor = System.Windows.Forms.Cursors.Hand;
        this.btnPrintMedicine.Enabled = false;
        this.btnPrintMedicine.FlatStyle = System.Windows.Forms.FlatStyle.System;
        this.btnPrintMedicine.ForeColor = System.Drawing.Color.Black;
        this.btnPrintMedicine.Location = new System.Drawing.Point(843, 48);
        this.btnPrintMedicine.Margin = new System.Windows.Forms.Padding(4);
        this.btnPrintMedicine.Name = "btnPrintMedicine";
        this.btnPrintMedicine.Size = new System.Drawing.Size(175, 42);
        this.btnPrintMedicine.TabIndex = 127;
        this.btnPrintMedicine.Text = "Print Medicine";
        this.btnPrintMedicine.UseVisualStyleBackColor = true;
        this.btnPrintMedicine.Click += new System.EventHandler(this.btnPrintMedicine_Click);
        // 
        // gbOperations
        // 
        this.gbOperations.Controls.Add(this.btnPrintMedicine);
        this.gbOperations.Controls.Add(this.btnUpdateMedicine);
        this.gbOperations.Controls.Add(this.btnDeleteMedicine);
        this.gbOperations.Controls.Add(this.btnAddMedicine);
        this.gbOperations.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        this.gbOperations.ForeColor = System.Drawing.Color.Crimson;
        this.gbOperations.Location = new System.Drawing.Point(19, 467);
        this.gbOperations.Margin = new System.Windows.Forms.Padding(4);
        this.gbOperations.Name = "gbOperations";
        this.gbOperations.Padding = new System.Windows.Forms.Padding(4);
        this.gbOperations.Size = new System.Drawing.Size(1065, 120);
        this.gbOperations.TabIndex = 125;
        this.gbOperations.TabStop = false;
        this.gbOperations.Text = "The Operations ";
        // 
        // MedicinesScreen
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(1101, 606);
        this.Controls.Add(this.gbOperations);
        this.Controls.Add(this.groupBox1);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.lblRecords);
        this.Controls.Add(this.comboBox1);
        this.Controls.Add(this.textBox1);
        this.Controls.Add(this.panel2);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        this.Name = "MedicinesScreen";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "Medicines Screen";
        this.Load += new System.EventHandler(this.MedicinesScreen_Load);
        ((System.ComponentModel.ISupportInitialize)(this.GridViewMedicinesList)).EndInit();
        this.groupBox1.ResumeLayout(false);
        this.gbOperations.ResumeLayout(false);
        this.gbOperations.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.DataGridView GridViewMedicinesList;
    private System.Windows.Forms.GroupBox gbOperations;
    private System.Windows.Forms.Button btnPrintMedicine;
    private System.Windows.Forms.Button btnUpdateMedicine;
    private System.Windows.Forms.Button btnDeleteMedicine;
    private System.Windows.Forms.Button btnAddMedicine;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label lblRecords;
    private System.Windows.Forms.ComboBox comboBox1;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.Panel panel2;

    #endregion
}