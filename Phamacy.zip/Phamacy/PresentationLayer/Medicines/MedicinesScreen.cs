﻿using System;
using System.Data;
using System.Windows.Forms;
using MBL = BusinessLayer.MedicinesBusinessLayer;
using static PresentationLayer.clsGlobal;

namespace PresentationLayer.Medicines;

public partial class MedicinesScreen : Form
{
    public MedicinesScreen(bool EnableOpertioins = true)
    {
        InitializeComponent();

        if (!EnableOpertioins)
        {
            gbOperations.Visible = false;
            Height = 501;
        }
    }

    private DataTable _DataTable;

    private int _MedicineID;

    private MBL _Medicine1;

    private void MedicinesScreen_Load(object sender, EventArgs e)
    {
        RefreshData();
    }

    public void RefreshData()
    {
        _DataTable = MBL.GetAllMedicines(CurrentDealer?.DealerID, null);

        _DataTable.Columns.RemoveAt(8);

        _DataTable.Columns.RemoveAt(CurrentDealer == null ? 7 : 6);

        btnDeleteMedicine.Enabled = btnUpdateMedicine.Enabled = btnPrintMedicine.Enabled =
            comboBox1.Enabled = textBox1.Enabled = _DataTable.Rows.Count > 0;

        comboBox1.SelectedIndex = 0;

        LoadData();

        _SetWidthColumns();
    }

    private void _SetDefaultColumns()
    {
        // _DataTable.Columns.Add("Medicine ID", typeof(int));
        // _DataTable.Columns.Add("Medicine Name", typeof(string));
        // _DataTable.Columns.Add("Category", typeof(string));
        // _DataTable.Columns.Add("Quantity", typeof(int));
        // _DataTable.Columns.Add("Expiration Date", typeof(DateTime));
        // _DataTable.Columns.Add("Price", typeof(decimal));
        // _DataTable.Columns.Add("Selected", typeof(int));

        GridViewMedicinesList.DataSource = _DataTable;

        _SetWidthColumns();

        if (GridViewMedicinesList.Rows.Count > 0)
            GridViewMedicinesList.Rows.RemoveAt(0);

        btnDeleteMedicine.Enabled = btnUpdateMedicine.Enabled = btnPrintMedicine.Enabled =
            comboBox1.Enabled = textBox1.Enabled = false;

        lblRecords.Text = "0";
    }

    private void _SetWidthColumns()
    {
        GridViewMedicinesList.Columns[0].Width = 111;
        GridViewMedicinesList.Columns[1].Width = GridViewMedicinesList.Columns[6].Width = 135;
        GridViewMedicinesList.Columns[4].Width = 119;
        GridViewMedicinesList.Columns[2].Width = 105;
        GridViewMedicinesList.Columns[3].Width = GridViewMedicinesList.Columns[5].Width = 71;
    }

    private void LoadData(string Type = "Medicine ID", string Text = "")
    {
        var _DataView1 = _DataTable.DefaultView;
        string DataFilter;

        try
        {
            if (Text == "")
                DataFilter = null;
            else if (Type == "Medicine ID")
                DataFilter = $"[{Type}] = '{Text}'";
            else
                DataFilter = $"[{Type}] LIKE '{Text}%'";

            _DataView1.RowFilter = DataFilter;
        }
        catch (Exception e)
        {
            MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
            textBox1.Text = Text.Substring(0, Text.Length - 1);
            _DataView1.RowFilter = null;
        }

        GridViewMedicinesList.DataSource = _DataView1;

//        btnDeleteMedicine.Enabled = btnUpdateMedicine.Enabled =GridViewMedicinesList.Rows.Count != 0;

        lblRecords.Text = Convert.ToString(GridViewMedicinesList.Rows.Count);
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {
        var Type = Convert.ToString(comboBox1.SelectedItem);
        var Text = textBox1.Text.Trim();

        LoadData(Type, Text);
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        textBox1.Text = "";

        textBox1.Focus();
    }

    private void btnAddMedicine_Click(object sender, EventArgs e)
    {
        var fr = new AddEditMedicineScreen();
        fr.ShowDialog();

        // RefreshData();
    }

    private void btnUpdateMedicine_Click(object sender, EventArgs e)
    {
        UpdateMedicineInfo(Convert.ToInt32(GridViewMedicinesList.CurrentRow.Cells[0].Value));

        var fr = new AddEditMedicineScreen(_MedicineID);
        fr.ShowDialog();
    }

    private void btnDeleteMedicine_Click(object sender, EventArgs e)
    {
        UpdateMedicineInfo(Convert.ToInt32(GridViewMedicinesList.CurrentRow.Cells[0].Value));

        if (MessageBox.Show("Are you sure you want to delete [" + _MedicineID + "]", "Confirm Deletion",
                MessageBoxButtons.OKCancel) != DialogResult.OK)
            return;

        if (_Medicine1.Delete())
        {
            MessageBox.Show("Medicine Deleted Successfully.", "Deleted",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }
        else
        {
            MessageBox.Show("Could not delete Medicine, other data depends on it.",
                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void btnPrintMedicine_Click(object sender, EventArgs e)
    {
    }

    private void UpdateMedicineInfo(int ID)
    {
        _MedicineID = ID;
        _Medicine1 = MBL.FindMedicine(_MedicineID);
    }
}