﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using BusinessLayer;
using MBL = BusinessLayer.MedicinesBusinessLayer;

namespace PresentationLayer.Medicines;

public partial class AddEditMedicineScreen : Form
{
    private int? _MedicineId;

    private MBL _Medicine1;

    public AddEditMedicineScreen(int? ID = null)
    {
        InitializeComponent();

        _MedicineId = ID;

        this.AutoValidate = AutoValidate.EnableAllowFocusChange;
    }

    private void AddEditMedicineScreen_Load(object sender, EventArgs e)
    {
        LoadData();
    }

    private void LoadData()
    {
        //dtpExpirationDate.MinDate = DateTime.Now;

        LoadCategories();

        if (!_MedicineId.HasValue)
        {
            _Medicine1 = new MBL();

            txtMedicineID.Text = "N/A";
        }

        else
        {
            _Medicine1 = MBL.FindMedicine(_MedicineId.Value);

            lblTitle.Text = "Edit Medicine";
            txtMedicineName.Text = _Medicine1.MedicineName;
            txtMedicineID.Text = Convert.ToString(_MedicineId);
            cbCategories.SelectedIndex = cbCategories.FindString(_Medicine1.CategoryInfo.CategoryName);
            nudQuantity.Value = Convert.ToDecimal(_Medicine1.Quantity);
            dtpExpirationDate.Value = _Medicine1.ExpirationDate;
            nudPrice.Value = _Medicine1.Price;
        }
    }

    private void LoadCategories()
    {
        cbCategories.DataSource = CategoriesBusinessLayer.GetAllCategories();
        cbCategories.DisplayMember = "Type";
        cbCategories.ValueMember = "ID";
    }

    private void textBox_Validate(object sender, CancelEventArgs e)
    {
        var Temp = (Control)sender;

        if (string.IsNullOrEmpty(Temp.Text.Trim()))
        {
            e.Cancel = true;
            errorProvider1.SetError(Temp, "This field is required!");
            return;
        }

        errorProvider1.SetError(Temp, null);

        if (Temp.Name == "txtMedicineName")
        {
            if (_MedicineId.HasValue && _Medicine1.MedicineName.ToLower() == txtMedicineName.Text.Trim().ToLower())
                return;

            if (MBL.ExistMedicineName(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "Reserved!");
            }
        }
    }

    private void btnSave_Click(object sender, EventArgs e)
    {
        if (!ValidateChildren())
        {
            MessageBox.Show("Some fields are not valid!, put the mouse over the red icon(s) to see the error",
                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        string MedicineName = txtMedicineName.Text.Trim();
        int CategoryID = Convert.ToInt32(cbCategories.SelectedValue);
        int Quantity = Convert.ToInt32(nudQuantity.Value);
        DateTime ExpirationDate = dtpExpirationDate.Value;
        decimal Price = nudPrice.Value;

        _Medicine1.MedicineName = MedicineName;
        _Medicine1.CategoryID = CategoryID;
        _Medicine1.Quantity = Quantity;
        _Medicine1.ExpirationDate = ExpirationDate;
        _Medicine1.Price = Price;
        _Medicine1.DealerID = clsGlobal.CurrentDealer.DealerID.Value;

        MessageBox.Show(_Medicine1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.",
            "", MessageBoxButtons.OK, MessageBoxIcon.Information);

        _MedicineId = _Medicine1.MedicineID;

        lblTitle.Text = "Edit Medicine";

        txtMedicineID.Text = Convert.ToString(_MedicineId);

        // MedicinesScreen.GetForm.RefreshData();
        (Application.OpenForms["MedicinesScreen"] as MedicinesScreen)?.RefreshData();
    }
}