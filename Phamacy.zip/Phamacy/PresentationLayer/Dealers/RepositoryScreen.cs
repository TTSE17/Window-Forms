﻿using System;
using System.Windows.Forms;
using PresentationLayer.Medicines;
using PresentationLayer.Orders;

namespace PresentationLayer.Dealers;

public partial class RepositoryScreen : Form
{
    public RepositoryScreen()
    {
        InitializeComponent();
    }

    private void MedicinesManagementToolStripMenuItem_Click(object sender, EventArgs e)
    {
        var fr = new MedicinesScreen();
        fr.ShowDialog();
    }

    private void AddNewMedicineToolStripMenuItem_Click(object sender, EventArgs e)
    {
        var fr = new AddEditMedicineScreen();
        fr.ShowDialog();
    }

    private void OrdersToolStripMenuItem_Click(object sender, EventArgs e)
    {
        var fr = new OrdersScreen();
        fr.ShowDialog();
    }

    private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
    {
        clsGlobal.CurrentDealer = null;
        Close();
    }
}