﻿using System;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Pharmacists;

namespace PresentationLayer.Dealers
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();

            txtDealerName.Focus();
        }
        
        private static bool _ValidateInputs(string DealerName, string Password)
        {
            return string.IsNullOrEmpty(DealerName) || string.IsNullOrEmpty(Password);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var DealerName = txtDealerName.Text.Trim();
            var Password = txtPassword.Text.Trim();

            if (_ValidateInputs(DealerName, Password))
            {
                MessageBox.Show("Enter Dealername, Password !");
                return;
            }

            if (DealersBusinessLayer.IsFound(DealerName, Password))
            {
                var Dealer1 = DealersBusinessLayer.FindDealer(DealerName);

                clsGlobal.CurrentDealer = Dealer1;

                Hide();
                var fr = new RepositoryScreen();
                fr.ShowDialog();

                Show();
            }

            else
            {

                MessageBox.Show("Invalid Dealername/Password.", "Wrong Credintials",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblSignup_Click(object sender, EventArgs e)
        {
            AddEditDealerScreen fr = new AddEditDealerScreen();
            fr.action += _GetNewDealer;
            fr.ShowDialog();
        }

        private void _GetNewDealer(string DealerName, string Password)
        {
            txtDealerName.Text = DealerName;
            txtPassword.Text = Password;
        }

        private void llPharmacist_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Hide();
            
            if (Application.OpenForms["Pharmacist_Login_Screen"] is Pharmacist_Login_Screen fr)
                fr.Show();

            else
            {
                fr = new Pharmacist_Login_Screen();
                fr.Show();
            }
        }
    }
}