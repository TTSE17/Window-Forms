﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using DDA = BusinessLayer.DealersBusinessLayer;

namespace PresentationLayer.Dealers;

public partial class AddEditDealerScreen : Form
{
    private int? _DealerID;
    private DDA _Dealer1;

    public Action<string, string> action;

    public AddEditDealerScreen(int? DealerID = null)
    {
        InitializeComponent();
        _DealerID = DealerID;

        AutoValidate = AutoValidate.EnableAllowFocusChange;
    }

    private void AddEditDealerScreen_Load(object sender, EventArgs e)
    {
        LoadData();
    }

    private void LoadData()
    {
        if (!_DealerID.HasValue)
        {
            txtDealerName.Focus();
            _Dealer1 = new DDA();
            txtDealerID.Text = "N/A";
        }

        else
        {
            _Dealer1 = DDA.FindDealer(_DealerID.Value);

            if (_Dealer1 == null) return;

            txtDealerID.Text = Convert.ToString(_DealerID);
            txtDealerName.Text = Convert.ToString(_Dealer1.DealerName);
            txtPassword.Text = Convert.ToString(_Dealer1.Password);

            lblTitle.Text = "Edit Dealer";
            btnSignup.Text = "Save";
        }
    }

    private void textBox_Validate(object sender, CancelEventArgs e)
    {
        var Temp = (TextBox)sender;

        if (string.IsNullOrEmpty(Temp.Text.Trim()))
        {
            e.Cancel = true;
            errorProvider1.SetError(Temp, "This field is required!");
            return;
        }

        errorProvider1.SetError(Temp, null);

        if (Temp.Name == "txtDealerName")
        {
            if (!clsGlobal.AllLetter(Temp.Text.Trim()))
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Only Letters!");

                return;
            }

            if (_Dealer1.DealerID.HasValue && _Dealer1.DealerName.ToLower() == txtDealerName.Text.Trim().ToLower()) return;

            if (DDA.ExistDealerName(Temp.Text.Trim()))
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Dealer Name Already Used !");
            }
        }

        else if (Temp.Name == "txtPassword")
        {
            if (Temp.Text.Trim().Length < 5)
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Password Must be At Least 5 !");
            }
        }
    }

    private void btnSignup_Click(object sender, EventArgs e)
    {
        if (!ValidateChildren())
        {
            MessageBox.Show("Some fields are Invalid!, Hover over the red icon(s) to see the erro",
                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        var DealerName = txtDealerName.Text.Trim();
        var password = txtPassword.Text.Trim();

        _Dealer1.DealerName = DealerName;
        _Dealer1.Password = password;

        MessageBox.Show(_Dealer1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");

        txtDealerID.Text = Convert.ToString(_Dealer1.DealerID);

        _DealerID = _Dealer1.DealerID;

        lblTitle.Text = "Edit Dealer";
        btnSignup.Text = "Save";
    }

    private void AddEditDealerScreen_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (_DealerID.HasValue)
            action?.Invoke(_Dealer1.DealerName, _Dealer1.Password);
    }
}