﻿using System.ComponentModel;

namespace PresentationLayer.Pharmacists;

partial class Pharmacist_Login_Screen
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Pharmacist_Login_Screen));
        this.panel4 = new System.Windows.Forms.Panel();
        this.button2 = new System.Windows.Forms.Button();
        this.txtPassword = new System.Windows.Forms.TextBox();
        this.panel3 = new System.Windows.Forms.Panel();
        this.button1 = new System.Windows.Forms.Button();
        this.txtPhone = new System.Windows.Forms.TextBox();
        this.lblSignup = new System.Windows.Forms.Label();
        this.label3 = new System.Windows.Forms.Label();
        this.label2 = new System.Windows.Forms.Label();
        this.label1 = new System.Windows.Forms.Label();
        this.btnLogin = new System.Windows.Forms.Button();
        this.label5 = new System.Windows.Forms.Label();
        this.label6 = new System.Windows.Forms.Label();
        this.label4 = new System.Windows.Forms.Label();
        this.llDealer = new System.Windows.Forms.LinkLabel();
        this.panel4.SuspendLayout();
        this.panel3.SuspendLayout();
        this.SuspendLayout();
        // 
        // panel4
        // 
        resources.ApplyResources(this.panel4, "panel4");
        this.panel4.BackColor = System.Drawing.Color.White;
        this.panel4.Controls.Add(this.button2);
        this.panel4.Controls.Add(this.txtPassword);
        this.panel4.Name = "panel4";
        // 
        // button2
        // 
        this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button2.FlatAppearance.BorderSize = 0;
        resources.ApplyResources(this.button2, "button2");
        this.button2.Image = global::PresentationLayer.Properties.Resources.lock_20px;
        this.button2.Name = "button2";
        this.button2.TabStop = false;
        this.button2.UseVisualStyleBackColor = false;
        // 
        // txtPassword
        // 
        this.txtPassword.BackColor = System.Drawing.Color.White;
        this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
        resources.ApplyResources(this.txtPassword, "txtPassword");
        this.txtPassword.ForeColor = System.Drawing.Color.Black;
        this.txtPassword.Name = "txtPassword";
        // 
        // panel3
        // 
        resources.ApplyResources(this.panel3, "panel3");
        this.panel3.BackColor = System.Drawing.Color.White;
        this.panel3.Controls.Add(this.button1);
        this.panel3.Controls.Add(this.txtPhone);
        this.panel3.Name = "panel3";
        // 
        // button1
        // 
        this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.button1.FlatAppearance.BorderSize = 0;
        resources.ApplyResources(this.button1, "button1");
        this.button1.Image = global::PresentationLayer.Properties.Resources.call_32;
        this.button1.Name = "button1";
        this.button1.TabStop = false;
        this.button1.UseVisualStyleBackColor = false;
        // 
        // txtPhone
        // 
        this.txtPhone.BackColor = System.Drawing.Color.White;
        this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.None;
        resources.ApplyResources(this.txtPhone, "txtPhone");
        this.txtPhone.ForeColor = System.Drawing.Color.Black;
        this.txtPhone.Name = "txtPhone";
        // 
        // lblSignup
        // 
        resources.ApplyResources(this.lblSignup, "lblSignup");
        this.lblSignup.BackColor = System.Drawing.Color.Transparent;
        this.lblSignup.Cursor = System.Windows.Forms.Cursors.Hand;
        this.lblSignup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.lblSignup.Name = "lblSignup";
        this.lblSignup.Click += new System.EventHandler(this.lblSignup_Click);
        // 
        // label3
        // 
        resources.ApplyResources(this.label3, "label3");
        this.label3.Name = "label3";
        // 
        // label2
        // 
        this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
        resources.ApplyResources(this.label2, "label2");
        this.label2.Name = "label2";
        // 
        // label1
        // 
        resources.ApplyResources(this.label1, "label1");
        this.label1.Name = "label1";
        // 
        // btnLogin
        // 
        this.btnLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
        this.btnLogin.Cursor = System.Windows.Forms.Cursors.Hand;
        resources.ApplyResources(this.btnLogin, "btnLogin");
        this.btnLogin.ForeColor = System.Drawing.Color.White;
        this.btnLogin.Name = "btnLogin";
        this.btnLogin.Tag = "Login";
        this.btnLogin.UseVisualStyleBackColor = false;
        this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
        // 
        // label5
        // 
        resources.ApplyResources(this.label5, "label5");
        this.label5.Name = "label5";
        // 
        // label6
        // 
        resources.ApplyResources(this.label6, "label6");
        this.label6.Name = "label6";
        // 
        // label4
        // 
        this.label4.BackColor = System.Drawing.Color.White;
        resources.ApplyResources(this.label4, "label4");
        this.label4.Name = "label4";
        // 
        // llDealer
        // 
        resources.ApplyResources(this.llDealer, "llDealer");
        this.llDealer.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
        this.llDealer.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(149)))), ((int)(((byte)(246)))));
        this.llDealer.Name = "llDealer";
        this.llDealer.TabStop = true;
        this.llDealer.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llDealer_LinkClicked);
        // 
        // Pharmacist_Login_Screen
        // 
        resources.ApplyResources(this, "$this");
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.BackColor = System.Drawing.Color.Black;
        this.Controls.Add(this.llDealer);
        this.Controls.Add(this.label4);
        this.Controls.Add(this.panel4);
        this.Controls.Add(this.panel3);
        this.Controls.Add(this.lblSignup);
        this.Controls.Add(this.label3);
        this.Controls.Add(this.label2);
        this.Controls.Add(this.label1);
        this.Controls.Add(this.btnLogin);
        this.Controls.Add(this.label5);
        this.Controls.Add(this.label6);
        this.ForeColor = System.Drawing.Color.White;
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
        this.Name = "Pharmacist_Login_Screen";
        this.panel4.ResumeLayout(false);
        this.panel4.PerformLayout();
        this.panel3.ResumeLayout(false);
        this.panel3.PerformLayout();
        this.ResumeLayout(false);
        this.PerformLayout();
    }

    private System.Windows.Forms.LinkLabel llDealer;

    private System.Windows.Forms.Label label4;

    private System.Windows.Forms.Panel panel4;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.TextBox txtPassword;
    private System.Windows.Forms.Panel panel3;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.TextBox txtPhone;
    private System.Windows.Forms.Label lblSignup;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button btnLogin;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;

    #endregion
}