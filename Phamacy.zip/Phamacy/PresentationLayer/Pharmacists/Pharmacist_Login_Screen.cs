﻿using System;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Dealers;

namespace PresentationLayer.Pharmacists;

public partial class Pharmacist_Login_Screen : Form
{
    public Pharmacist_Login_Screen()
    {
        InitializeComponent();
    }

    private static bool _ValidateInputs(string Phone, string Password)
    {
        return string.IsNullOrEmpty(Phone) || string.IsNullOrEmpty(Password);
    }

    private void btnLogin_Click(object sender, EventArgs e)
    {
        var Phone = txtPhone.Text.Trim();
        var Password = txtPassword.Text.Trim();

        if (_ValidateInputs(Phone, Password))
        {
            MessageBox.Show("Enter Dealername, Password !");
            return;
        }

        if (PharmacistsBusinessLayer.IsFound(Phone, Password))
        {
            clsGlobal.CurrentPharmacist = PharmacistsBusinessLayer.FindPharmacist(Phone);

            Hide();
            var fr = new PharmacyScreen();
            fr.ShowDialog();

            Show();
        }

        else
        {
            MessageBox.Show("Invalid Dealername/Password.", "Wrong Credintials",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void lblSignup_Click(object sender, EventArgs e)
    {
        AddEditPharmacistScreen fr = new AddEditPharmacistScreen();
        fr.action += _GetNewPharmacist;
        fr.ShowDialog();
    }

    private void _GetNewPharmacist(string Phone, string Password)
    {
        txtPhone.Text = Phone;
        txtPassword.Text = Password;
    }

    private void llDealer_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
        Hide();

        if (Application.OpenForms["LoginScreen"] is LoginScreen fr)
            fr.Show();

        else
        {
            fr = new LoginScreen();
            fr.Show();
        }
    }
}