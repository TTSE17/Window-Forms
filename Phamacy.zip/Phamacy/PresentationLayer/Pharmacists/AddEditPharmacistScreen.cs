﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using PDA = BusinessLayer.PharmacistsBusinessLayer;

namespace PresentationLayer.Pharmacists;

public partial class AddEditPharmacistScreen : Form
{
    private int? _PharmacistID;
    private PDA _Pharmacist1;

    public Action<string, string> action;

    public AddEditPharmacistScreen(int? PharmacistID = null)
    {
        InitializeComponent();
        _PharmacistID = PharmacistID;

        AutoValidate = AutoValidate.EnableAllowFocusChange;
    }

    private void AddEditPharmacistScreen_Load(object sender, EventArgs e)
    {
        LoadData();
    }

    private void LoadData()
    {
        if (!_PharmacistID.HasValue)
        {
            txtPharmacistName.Focus();
            _Pharmacist1 = new PDA();
            txtPharmacistID.Text = "N/A";
        }

        else
        {
            _Pharmacist1 = PDA.FindPharmacist(_PharmacistID.Value);

            if (_Pharmacist1 == null) return;

            txtPharmacistID.Text = Convert.ToString(_PharmacistID);
            txtPharmacistName.Text = (_Pharmacist1.PharmacistName);
            txtPhone.Text = _Pharmacist1.Phone;
            txtPassword.Text = (_Pharmacist1.Password);

            lblTitle.Text = "Edit Pharmacist";
            btnSignup.Text = "Save";
        }
    }

    private void textBox_Validate(object sender, CancelEventArgs e)
    {
        var Temp = (TextBox)sender;

        if (string.IsNullOrEmpty(Temp.Text.Trim()))
        {
            e.Cancel = true;
            errorProvider1.SetError(Temp, "This field is required!");
            return;
        }

        errorProvider1.SetError(Temp, null);

        if (Temp.Name == "txtPharmacistName")
        {
            if (!clsGlobal.AllLetter(Temp.Text.Trim()))
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Only Letters!");

                return;
            }
            
        }
        else if (Temp.Name == "txtPhone")
        {
            if (!clsGlobal.AllNumber(Temp.Text.Trim()))
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Only Numbers!");

                return;
            }

            if (_Pharmacist1.PharmacistID.HasValue &&
                _Pharmacist1.Phone.ToLower() == txtPhone.Text.Trim().ToLower()) return;

            if (PDA.ExistPharmacistPhone(Temp.Text.Trim()))
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Phone Already Used !");
            }
        }
        else if (Temp.Name == "txtPassword")
        {
            if (Temp.Text.Trim().Length < 5)
            {
                e.Cancel = true;

                errorProvider1.SetError(Temp, "Password Must be At Least 5 !");
            }
        }
    }

    private void btnSignup_Click(object sender, EventArgs e)
    {
        if (!ValidateChildren())
        {
            MessageBox.Show("Some fields are Invalid!, Hover over the red icon(s) to see the erro",
                "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        var PharmacistName = txtPharmacistName.Text.Trim();
        var Phone = txtPhone.Text.Trim();
        var password = txtPassword.Text.Trim();

        _Pharmacist1.PharmacistName = PharmacistName;
        _Pharmacist1.Phone = Phone;
        _Pharmacist1.Password = password;

        MessageBox.Show(_Pharmacist1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");

        txtPharmacistID.Text = Convert.ToString(_Pharmacist1.PharmacistID);

        _PharmacistID = _Pharmacist1.PharmacistID;

        lblTitle.Text = "Edit Pharmacist";
        btnSignup.Text = "Save";
    }

    private void AddEditPharmacistScreen_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (_PharmacistID.HasValue)
            action?.Invoke(_Pharmacist1.Phone, _Pharmacist1.Password);
    }
}