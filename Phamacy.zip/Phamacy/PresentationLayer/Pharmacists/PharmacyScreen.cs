﻿using System;
using System.Windows.Forms;
using PresentationLayer.Medicines;
using PresentationLayer.Orders;

namespace PresentationLayer.Pharmacists;

public partial class PharmacyScreen : Form
{
    public PharmacyScreen()
    {
        InitializeComponent();
    }

    private void MedicinesToolStripMenuItem_Click(object sender, EventArgs e)
    {
        var fr = new MedicinesScreen(false);
        fr.ShowDialog();
    }

    private void OrdersToolStripMenuItem_Click(object sender, EventArgs e)
    {
        var fr = new OrdersScreen();
        fr.ShowDialog();
    }

    private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
    {
        clsGlobal.CurrentPharmacist = null;
        Close();
    }
}