﻿using System.Windows.Forms;

namespace ClassLibrary1
{
    public class Class1
    {
    }
}