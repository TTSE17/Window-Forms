﻿using System.Data;
using DataAccessLayer;

namespace BusinessLayer;

public class PharmacistsBusinessLayer
{
    public int? PharmacistID { get; set; }

    public string PharmacistName { get; set; }
    public string Phone { get; set; }
    public string Password { get; set; }

    public PharmacistsBusinessLayer()
    {
        PharmacistID = null;
    }

    private PharmacistsBusinessLayer(int PharmacistId, string pharmacistName, string phone, string password)
    {
        PharmacistID = PharmacistId;
        PharmacistName = pharmacistName;
        Phone = phone;
        Password = password;
    }

    public static DataTable GetAllPharmacists()
    {
        return PharmacistsDataAccessLayer.GetAllPharmacists();
    }

    public static bool IsFound(string Phone, string Password)
    {
        return PharmacistsDataAccessLayer.IsFound(Phone, Password);
    }

    public static PharmacistsBusinessLayer FindPharmacist(int ID)
    {
        string PharmacistName = "", phone = "", password = "";

        if (PharmacistsDataAccessLayer.GetPharmacistByID(ID, ref PharmacistName, ref phone, ref password))
            return new PharmacistsBusinessLayer(ID, PharmacistName, phone, password);

        return null;
    }

    public static PharmacistsBusinessLayer FindPharmacist(string Phone)
    {
        var password = "";
        var pharmacistName = "";
        int PharmacistID = -1;

        if (PharmacistsDataAccessLayer.GetPharmacistByPharmacistPhone(ref PharmacistID, ref pharmacistName,
                Phone, ref password))
            return new PharmacistsBusinessLayer(PharmacistID, pharmacistName, Phone, password);

        return null;
    }

    private int _AddNewPharmacist()
    {
        return PharmacistsDataAccessLayer.AddNewPharmacist(PharmacistName, Phone, Password);
    }

    private bool _UpdatePharmacist()
    {
        return PharmacistsDataAccessLayer.UpdatePharmacist(PharmacistID.Value, PharmacistName, Phone, Password);
    }

    public bool Save()
    {
        if (PharmacistID.HasValue) return _UpdatePharmacist();

        PharmacistID = _AddNewPharmacist();
        return true;
    }

    public bool Delete()
    {
        return PharmacistsDataAccessLayer.DeletePharmacist(PharmacistID.Value);
    }

    public static bool ExistPharmacistPhone(string Phone)
    {
        return PharmacistsDataAccessLayer.ExistPharmacistPhone(Phone);
    }
}