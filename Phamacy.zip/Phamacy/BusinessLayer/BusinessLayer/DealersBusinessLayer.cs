﻿using System.Data;
using DataAccessLayer;

namespace BusinessLayer
{
    public class DealersBusinessLayer
    {
        public int? DealerID { get; set; }

        public string DealerName { get; set; }
        public string Password { get; set; }

        public DealersBusinessLayer()
        {
            DealerID = null;
        }

        private DealersBusinessLayer(int DealerId, string dealerName, string password)
        {
            DealerID = DealerId;
            DealerName = dealerName;
            Password = password;
        }

        public static DataTable GetAllDealers()
        {
            return DealersDataAccessLayer.GetAllDealers();
        }

        public static bool IsFound(string DealerName, string Password)
        {
            return DealersDataAccessLayer.IsFound(DealerName, Password);
        }

        public static DealersBusinessLayer FindDealer(int ID)
        {
            string DealerName = "", password = "";

            if (DealersDataAccessLayer.GetDealerByID(ID, ref DealerName, ref password))
                return new DealersBusinessLayer(ID, DealerName, password);

            return null;
        }

        public static DealersBusinessLayer FindDealer(string DealerName)
        {
            var password = "";
            int DealerID = -1;

            if (DealersDataAccessLayer.GetDealerByDealerName(ref DealerID, DealerName, ref password))
                return new DealersBusinessLayer(DealerID, DealerName, password);

            return null;
        }

        private int _AddNewDealer()
        {
            return DealersDataAccessLayer.AddNewDealer(DealerName, Password);
        }

        private bool _UpdateDealer()
        {
            return DealersDataAccessLayer.UpdateDealer(DealerID.Value, DealerName,Password);
        }

        public bool Save()
        {
            if (DealerID.HasValue) return _UpdateDealer();

            DealerID = _AddNewDealer();
            return true;
        }

        public bool Delete()
        {
            return DealersDataAccessLayer.DeleteDealer(DealerID.Value);
        }

        public static bool ExistDealerName(string DealerName)
        {
            return DealersDataAccessLayer.ExistDealerName(DealerName);
        }
    }
}