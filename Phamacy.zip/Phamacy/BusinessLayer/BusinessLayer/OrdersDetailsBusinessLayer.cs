﻿using System.Data;
using ODDA = DataAccessLayer.OrdersDetailsDataAccessLayer;

namespace BusinessLayer;

public class OrdersDetailsDetailsBusinessLayer
{
    public int RequiredQuantity { get; set; }
    public decimal Price { get; set; }
    public int OrderID { get; set; }
    public OrdersBusinessLayer OrderInfo;
    public int MedicineID { get; set; }
    public MedicinesBusinessLayer MedicineInfo;

    public OrdersDetailsDetailsBusinessLayer()
    {
        MedicineInfo = null;
        OrderInfo = null;
    }

    private OrdersDetailsDetailsBusinessLayer(int requiredQuantity, decimal price, int orderId, int medicineId)
    {
        RequiredQuantity = requiredQuantity;
        Price = price;
        OrderID = orderId;
        OrderInfo = OrdersBusinessLayer.FindOrder(orderId);
        MedicineID = medicineId;
        MedicineInfo = MedicinesBusinessLayer.FindMedicine(MedicineID);
    }

    public static DataTable GetAllOrderDetails(int? orderID)
    {
        return ODDA.GetAllOrderDetails(orderID);
    }

    public bool AddNewOrderDetails()
    {
        return ODDA.AddNewOrderDetails( RequiredQuantity, Price, OrderID, MedicineID);
    }

    public static bool DeleteOrderDetailsByOrderID(int? orderID)
    {
        return ODDA.DeleteOrderDetailsByOrderID(orderID);
    }
}