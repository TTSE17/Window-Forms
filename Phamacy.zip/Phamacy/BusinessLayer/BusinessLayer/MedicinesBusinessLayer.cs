﻿using System;
using System.Data;
using MDA = DataAccessLayer.MedicinesDataAccessLayer;

namespace BusinessLayer;

public class MedicinesBusinessLayer
{
    public enum enMood
    {
        New = 0,
        Update = 1
    }

    public int? MedicineID { get; set; }
    public string MedicineName { get; set; }
    public int CategoryID { get; set; }
    public CategoriesBusinessLayer CategoryInfo { get; set; }
    public int Quantity { get; set; }
    public DateTime ExpirationDate { get; set; }
    public decimal Price { get; set; }

    public int DealerID { get; set; }
    public DealersBusinessLayer DealerInfo;

    public enMood Mood;

    public MedicinesBusinessLayer()
    {
        MedicineID = null;
        Mood = enMood.New;
    }

    private MedicinesBusinessLayer(int medicineID, string medicineName, int categoryID, int quantity,
        DateTime expirationDate, decimal price, int dealerID)
    {
        MedicineID = medicineID;
        MedicineName = medicineName;
        CategoryID = categoryID;
        CategoryInfo = CategoriesBusinessLayer.FindCategory(CategoryID);
        Quantity = quantity;
        ExpirationDate = expirationDate;
        Price = price;
        DealerID = dealerID;
        DealerInfo = DealersBusinessLayer.FindDealer(DealerID);

        Mood = enMood.Update;
    }

    public static DataTable GetAllMedicines(int? DealerID, int? OrderID )
    {
        return MDA.GetAllMedicines(DealerID, OrderID);
    }

    public static MedicinesBusinessLayer FindMedicine(int medicineID)
    {
        var medicineName = "";
        int quantity = -1, categoryID = -1, dealerID = -1;
        decimal price = 0;
        DateTime expirationDate = default;

        if (MDA.GetMedicineByMedicineID(medicineID, ref medicineName, ref categoryID,
                ref quantity, ref expirationDate, ref price, ref dealerID))
            return new MedicinesBusinessLayer(medicineID, medicineName, categoryID, quantity,
                expirationDate, price, dealerID);

        return null;
    }

    private bool _AddNewMedicine()
    {
        MedicineID = MDA.AddNewMedicine(MedicineName, CategoryID, Quantity, ExpirationDate, Price, DealerID);
        Mood = enMood.Update;
        return true;
    }

    private bool _UMDAteMedicine()
    {
        return MDA.UpdateMedicine(MedicineID.Value, MedicineName, CategoryID,
            Quantity, ExpirationDate, Price, DealerID);
    }

    public bool Save()
    {
        return Mood == enMood.New ? _AddNewMedicine() : _UMDAteMedicine();
    }

    public bool Delete()
    {
        return MDA.DeleteMedicine(MedicineID.Value);
    }

    public static bool ExistMedicineName(string MedicineID)
    {
        return MDA.ExistMedicineName(MedicineID);
    }
}