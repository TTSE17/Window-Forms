﻿using System;
using System.Data;
using ODA = DataAccessLayer.OrdersDataAccessLayer;

namespace BusinessLayer;

public class OrdersBusinessLayer
{
    public int? OrderID { get; set; }

    public int PharmacistID { get; set; }

    public PharmacistsBusinessLayer PharmacistInfo { get; set; }

    public string Status { get; set; }

    public bool Paid { get; set; }

    public DateTime OrderData { get; set; }

    public int DealerID { get; set; }

    public DealersBusinessLayer DealerInfo;

    public OrdersBusinessLayer()
    {
        OrderID = null;
        PharmacistInfo = null;
        DealerInfo = null;
        Status = "Preparing";
        Paid = false;
    }

    private OrdersBusinessLayer(int? orderId, int pharmacistID, string status, bool paid,
        DateTime orderData, int dealerID)
    {
        OrderID = orderId;
        PharmacistID = pharmacistID;
        PharmacistInfo = PharmacistsBusinessLayer.FindPharmacist(PharmacistID);
        Status = status;
        Paid = paid;
        OrderData = orderData;
        DealerID = dealerID;
        DealerInfo = DealersBusinessLayer.FindDealer(dealerID);
    }

    public static DataTable GetAllOrders(int? pharmacistID, int? dealerID)
    {
        return ODA.GetAllOrders(pharmacistID, dealerID);
    }

    public static OrdersBusinessLayer FindOrder(int? orderID)
    {
        int PharmacistID = -1, dealerID = -1;
        var status = "";
        var paid = false;
        DateTime orderDate = default;

        if (ODA.GetOrderByID(orderID, ref PharmacistID, ref status, ref paid,
                ref orderDate, ref dealerID))
            return new OrdersBusinessLayer(orderID, PharmacistID, status, paid, orderDate, dealerID);

        return null;
    }

    private int _AddNewOrder()
    {
        return ODA.AddNewOrder(PharmacistID, DealerID);
    }

    private bool _UpdateOrder()
    {
        return ODA.UpdateOrder(OrderID, Status, Paid, DealerID);
    }

    public bool Save()
    {
        if (OrderID.HasValue) return _UpdateOrder();

        OrderID = _AddNewOrder();
        return true;
    }

    public static bool Delete(int OrderID)
    {
        return OrdersDetailsDetailsBusinessLayer.DeleteOrderDetailsByOrderID(OrderID)
            ? ODA.DeleteOrder(OrderID)
            : false;
    }
}