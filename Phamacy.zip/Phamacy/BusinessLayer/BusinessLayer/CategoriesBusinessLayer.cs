﻿using System.Data;

namespace BusinessLayer;
using CDA = DataAccessLayer.CategoriesDataAccessLayer;

public class CategoriesBusinessLayer
{
    public int? CategoryID { get; set; }

    public string CategoryName { get; set; }

    public CategoriesBusinessLayer()
    {
        CategoryID = null;
    }
    
    private CategoriesBusinessLayer(int categoryId, string categoryName)
    {
        CategoryID = categoryId;
        CategoryName = categoryName;
    }

    public static CategoriesBusinessLayer FindCategory(int categoryID)
    {
        var categoryName = "";

        if (CDA.GetCategoryByID(categoryID, ref categoryName))
            return new CategoriesBusinessLayer(categoryID, categoryName);
        return null;
    }

    public static int AddCategory(string CategoryName)
    {
        return CDA.AddNewCategory(CategoryName);
    }

    public static bool UpdateCategory(int categoryID, string CategoryName)
    {
        return CDA.UpdateCategory(categoryID, CategoryName);
    }

    public static bool DeleteCategory(int categoryID)
    {
        return CDA.DeleteCategory(categoryID);
    }

    public static CategoriesBusinessLayer FindCategory(string CategoryName)
    {
        var categoryID = -1;

        if (CDA.GetCategoryByName(ref categoryID, CategoryName))
            return new CategoriesBusinessLayer(categoryID, CategoryName);
        return null;
    }

    public static DataTable GetAllCategories()
    {
        return CDA.GetAllCategories();
    }

    public static DataTable FindCategoryByName(string CategoryName)
    {
        return CDA.FindCategoryByName(CategoryName);
    }

}