﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Customers
{
    public partial class ctrlSelectCustomer : UserControl
    {
        public event Action<int> OnSelectionComplete;

        // Create a protected method to raise the event with a parameter
        protected virtual void SelectionComplete(int PersonID)
        {
            var handler = OnSelectionComplete;
            handler?.Invoke(PersonID); // Raise the event with the parameter
        }

        public ctrlSelectCustomer()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _CustomerID = -1;
        private CustomersBusinessLayer _Customer1;

        public void LoadControl()
        {
            RefreshData();
            GridViewCustomersList.ClearSelection();
        }

        private void RefreshData()
        {
            _DataTable = CustomersBusinessLayer.GetAllCustomers();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            groupBox1.Enabled = textBox1.Enabled = btnSelect.Enabled = true;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Customer ID", typeof(int));
            _DataTable.Columns.Add("First Name", typeof(string));
            _DataTable.Columns.Add("Last Name", typeof(string));
            _DataTable.Columns.Add("Phone", typeof(string));
            _DataTable.Columns.Add("Orders", typeof(int));
            _DataTable.Columns.Add("Email", typeof(string));

            GridViewCustomersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewCustomersList.Rows.Count > 0)
                GridViewCustomersList.Rows.RemoveAt(0);


            groupBox1.Enabled = textBox1.Enabled = btnSelect.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewCustomersList.Columns[0].Width = 31;
            GridViewCustomersList.Columns[1].Width = 31;
            GridViewCustomersList.Columns[2].Width = 31;
            GridViewCustomersList.Columns[3].Width = 31;
            GridViewCustomersList.Columns[4].Width = 31;
            GridViewCustomersList.Columns[5].Width = 111;
        }

        private void LoadData(string Type = "Customer ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Customer ID")
                    DataFilter = $"[{Type}]  = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "Unacceptable Key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewCustomersList.DataSource = _DataView1;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = rbCustomerID.Checked ? "Customer ID" : "Email";
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
            GridViewCustomersList.ClearSelection();
        }

        private void rbCustomerID_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Customer ID :";
        }

        private void rbEmail_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Email :";
        }

        private void GridViewCustomersList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                _CustomerID = -1;
                return;
            }

            UpdateCustomerInfo(Convert.ToInt32(GridViewCustomersList.CurrentRow.Cells[0].Value));
        }

        private void GridViewCustomersList_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            GridViewCustomersList.ClearSelection();
            _CustomerID = -1;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (OnSelectionComplete != null)
                SelectionComplete(_CustomerID);
        }

        private void UpdateCustomerInfo(int ID)
        {
            _CustomerID = ID;
            _Customer1 = CustomersBusinessLayer.FindCustomer(_CustomerID);
        }
    }
}