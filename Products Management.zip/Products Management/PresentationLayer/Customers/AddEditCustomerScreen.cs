﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using PresentationLayer.Properties;
using CBL = BusinessLayer.CustomersBusinessLayer;

namespace PresentationLayer.Customers
{
    public partial class AddEditCustomerScreen : Form
    {
        private int? _CustomerId;

        private CBL _Customer1;

        public AddEditCustomerScreen(int? ID = null)
        {
            InitializeComponent();

            _CustomerId = ID;

            this.AutoValidate = AutoValidate.EnableAllowFocusChange;
        }

        private void AddEditCustomerScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            pbCustomer.ImageLocation = null;
            btnRemoveImage.Visible = false;

            if (_CustomerId == null)
            {
                _Customer1 = new CBL();
                lblTitle.Text = "Add Customer";
            }

            else
            {
                _Customer1 = CBL.FindCustomer(_CustomerId);

                lblTitle.Text = "Edit Customer";

                lblCustomerID.Text = Convert.ToString(_CustomerId);
                txtFirstName.Text = _Customer1.FirstName;
                txtLastName.Text = _Customer1.LastName;
                txtPhone.Text = _Customer1.Phone;
                txtEmail.Text = _Customer1.Email;

                if (_Customer1.PathImage == null) return;

                var ms = new MemoryStream(_Customer1.PathImage);
                pbCustomer.Image = Image.FromStream(ms);
                btnRemoveImage.Visible = true;
            }
        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            var openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;

            pbCustomer.ImageLocation = openFileDialog1.FileName;

            btnRemoveImage.Visible = true;
        }

        private void btnRemoveImage_Click(object sender, EventArgs e)
        {
            pbCustomer.Image = Resources.Male_512;
            pbCustomer.ImageLocation = null;

            btnRemoveImage.Visible = false;
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = (Control)sender;

            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
                return;
            }

            errorProvider1.SetError(Temp, null);


            if (Temp.Name == "txtPhone")
            {
                if (!clsGlobal.AllNumber(Temp.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(Temp, "Just Numbers!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }

            else if (Temp.Name == "txtFirstName" || Temp.Name == "txtLastName")
            {
                if (!clsGlobal.AllLetter(Temp.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(Temp, "Just Letters!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are not valid!, put the mouse over the red icon(s) to see the error",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var FirstName = txtFirstName.Text.Trim();
            var LastName = txtLastName.Text.Trim();
            var Phone = txtPhone.Text.Trim();
            var Email = txtEmail.Text.Trim();
            var PathImage = pbCustomer.ImageLocation;

            lblTitle.Text = "Edit Customer";

            _Customer1.FirstName = FirstName;
            _Customer1.LastName = LastName;
            _Customer1.Phone = Phone;
            _Customer1.Email = Email;

            _Customer1.PathImage = _HandleImage();

            MessageBox.Show(_Customer1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.",
                "", MessageBoxButtons.OK, MessageBoxIcon.Information);

            _CustomerId = _Customer1.CustomerID;

            lblCustomerID.Text = Convert.ToString(_CustomerId);

            (Application.OpenForms["CustomersScreen"] as CustomersScreen)?.RefreshData();
        }

        private byte[] _HandleImage()
        {
            if (pbCustomer.ImageLocation == null) return null;

            var ms = new MemoryStream();
            pbCustomer.Image.Save(ms, pbCustomer.Image.RawFormat);
            return ms.ToArray();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}