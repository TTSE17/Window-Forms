﻿using System;
using System.Windows.Forms;

namespace PresentationLayer.Customers
{
    public partial class SelectCustomerScreen : Form
    {
        public SelectCustomerScreen()
        {
            InitializeComponent();
        }

        public delegate void DataBackEventHandler(int CustomerID);

        public event DataBackEventHandler DataBack;

        private void SelectCustomerScreen_Load(object sender, EventArgs e)
        {
            ctrlSelectCustomer1.LoadControl();
        }

        private void ctrlSelectCustomer1_OnSelectionComplete(int CustomerID)
        {
            if (CustomerID == -1)
            {
                MessageBox.Show("Please Select A Customer!");
                return;
            }

            DataBack?.Invoke(CustomerID);

            Close();
        }
    }
}