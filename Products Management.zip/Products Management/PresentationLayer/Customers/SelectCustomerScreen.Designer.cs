﻿using System.ComponentModel;

namespace PresentationLayer.Customers
{
    partial class SelectCustomerScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlSelectCustomer1 = new PresentationLayer.Customers.ctrlSelectCustomer();
            this.SuspendLayout();
            // 
            // ctrlSelectCustomer1
            // 
            this.ctrlSelectCustomer1.Location = new System.Drawing.Point(16, 15);
            this.ctrlSelectCustomer1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.ctrlSelectCustomer1.Name = "ctrlSelectCustomer1";
            this.ctrlSelectCustomer1.Size = new System.Drawing.Size(915, 509);
            this.ctrlSelectCustomer1.TabIndex = 0;
            this.ctrlSelectCustomer1.OnSelectionComplete += new System.Action<int>(this.ctrlSelectCustomer1_OnSelectionComplete);
            // 
            // SelectCustomerScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(947, 538);
            this.Controls.Add(this.ctrlSelectCustomer1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "SelectCustomerScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Select Customer Screen";
            this.Load += new System.EventHandler(this.SelectCustomerScreen_Load);
            this.ResumeLayout(false);
        }

        private PresentationLayer.Customers.ctrlSelectCustomer ctrlSelectCustomer1;

        #endregion
    }
}