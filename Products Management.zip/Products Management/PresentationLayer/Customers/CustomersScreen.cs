﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Orders;

namespace PresentationLayer.Customers
{
    public partial class CustomersScreen : Form
    {
        public CustomersScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private void CustomersScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        public void RefreshData()
        {
            _DataTable = CustomersBusinessLayer.GetAllCustomers();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            comboBox1.Enabled = textBox1.Enabled = true;

            comboBox1.SelectedIndex = 0;

            textBox1.Text = "";

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Customer ID", typeof(int));
            _DataTable.Columns.Add("FistName", typeof(string));
            _DataTable.Columns.Add("LastName", typeof(string));
            _DataTable.Columns.Add("Phone", typeof(string));
            _DataTable.Columns.Add("Orders", typeof(int));
            _DataTable.Columns.Add("Email", typeof(string));
            GridViewCustomersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewCustomersList.Rows.Count > 0)
                GridViewCustomersList.Rows.RemoveAt(0);

            comboBox1.Enabled = textBox1.Enabled = false;

            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewCustomersList.Columns[0].Width = 31;
            GridViewCustomersList.Columns[1].Width = 31;
            GridViewCustomersList.Columns[2].Width = 31;
            GridViewCustomersList.Columns[3].Width = 31;
            GridViewCustomersList.Columns[4].Width = 31;
            GridViewCustomersList.Columns[5].Width = 111;
        }

        private void LoadData(string Type = "Customer ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Customer ID")
                    DataFilter = $"[{Type}] = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only" + e, "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewCustomersList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewCustomersList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void btnAddCustomer_Click(object sender, EventArgs e)
        {
            var fr = new AddEditCustomerScreen();
            fr.ShowDialog();
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new OrdersScreen(Convert.ToInt32(GridViewCustomersList.CurrentRow.Cells[0].Value));
            fr.ShowDialog();
        }

        private void editCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddEditCustomerScreen(Convert.ToInt32(GridViewCustomersList.CurrentRow.Cells[0].Value));
            fr.ShowDialog();
        }

        private void deleteCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var CustomerID = (Convert.ToInt32(GridViewCustomersList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to delete [" + CustomerID + "]", "Confirm Deletion",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (CustomersBusinessLayer.Delete(CustomerID))
            {
                MessageBox.Show("Customer Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Customer, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}