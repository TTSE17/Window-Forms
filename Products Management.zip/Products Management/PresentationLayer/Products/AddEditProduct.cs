﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Properties;
using PBL = BusinessLayer.ProductsBusinessLayer;

namespace PresentationLayer.Products
{
    public partial class AddEditProduct : Form
    {
        private string _ProductId;

        private PBL _Product1;

        public AddEditProduct(string ID = null)
        {
            InitializeComponent();

            _ProductId = ID;

            this.AutoValidate = AutoValidate.EnableAllowFocusChange;
        }

        private void AddEditProduct_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadCategories();

            pictureBox1.ImageLocation = null;
            btnRemoveImage.Visible = false;

            if (_ProductId == null)
            {
                _Product1 = new PBL();
                lblTitle.Text = "Add Product";
            }

            else
            {
                _Product1 = PBL.FindProduct(_ProductId);

                lblTitle.Text = "Edit Product";
                txtProductID.Text = Convert.ToString(_ProductId);
                cbCategories.SelectedIndex = cbCategories.FindString(_Product1.CategoryInfo.CategoryDescription);
                txtDescription.Text = _Product1.ProductLabel;
                nQuantity.Value = Convert.ToDecimal(_Product1.Quantity);
                nPrice.Value = _Product1.Price;

                txtProductID.Enabled = false;

                if (_Product1.PathImage == null) return;

                var ms = new MemoryStream(_Product1.PathImage);
                pictureBox1.Image = Image.FromStream(ms);
                btnRemoveImage.Visible = true;
            }
        }

        private void LoadCategories()
        {
            cbCategories.DataSource = CategoriesBusinessLayer.LoadCategoriesList();
            cbCategories.DisplayMember = "Type";
            cbCategories.ValueMember = "ID";
        }

        private void btnSelectImage_Click(object sender, EventArgs e)
        {
            var openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp;*.jfif";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;

            pictureBox1.ImageLocation = openFileDialog1.FileName;

            btnRemoveImage.Visible = true;
        }

        private void btnRemoveImage_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = Resources.Question_32;
            pictureBox1.ImageLocation = null;

            btnRemoveImage.Visible = false;
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = (Control)sender;
            
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
                return;
            }

            errorProvider1.SetError(Temp, null);

            if (Temp.Name == "txtProductID")
            {
                if (_Product1.ProductID != null && _Product1.ProductID.ToLower() == txtProductID.Text.Trim().ToLower())
                    return;

                if (PBL.ExistProductID(Temp.Text.Trim()))
                {
                    e.Cancel = true;
                    errorProvider1.SetError(Temp, "Reserved!");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are not valid!, put the mouse over the red icon(s) to see the error",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string ProductID = txtProductID.Text.Trim();
            int CategoryID = Convert.ToInt32(cbCategories.SelectedValue);
            string CategoryDescription = txtDescription.Text.Trim();
            int Quantity = Convert.ToInt32(nQuantity.Value);
            decimal Price = nPrice.Value;
            string PathImage = pictureBox1.ImageLocation;

            lblTitle.Text = "Edit Product";

            _Product1.ProductID = ProductID;
            _Product1.CategoryID = CategoryID;
            _Product1.ProductLabel = CategoryDescription;
            _Product1.Quantity = Quantity;
            _Product1.Price = Price;

            _Product1.PathImage = _HandleImage();

            MessageBox.Show(_Product1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.",
                "", MessageBoxButtons.OK, MessageBoxIcon.Information);

            _ProductId = _Product1.ProductID;

            ProductsScreen.GetForm.RefreshData();
        }

        private byte[] _HandleImage()
        {
            if (pictureBox1.ImageLocation == null) return null;

            var ms = new MemoryStream();
            pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);
            return ms.ToArray();
        }
    }
}