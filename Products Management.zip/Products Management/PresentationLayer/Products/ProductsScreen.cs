﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;


namespace PresentationLayer.Products
{
    public partial class ProductsScreen : Form
    {
        private static ProductsScreen fr;

        private static void Fr_Closed(object sender, FormClosedEventArgs e)
        {
            fr = null;
        }

        public static ProductsScreen GetForm
        {
            get
            {
                if (fr != null) return fr;

                fr = new ProductsScreen();
                fr.FormClosed += Fr_Closed;

                return fr;
            }
        }

        public ProductsScreen()
        {
            InitializeComponent();
            if (fr == null)
                fr = this;
        }

        private DataTable _DataTable;

        private string _ProductID;
        private ProductsBusinessLayer _Product1;

        private void ProductsScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        public void RefreshData()
        {
            _DataTable = ProductsBusinessLayer.GetAllProducts();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            btnDeleteProduct.Enabled = btnUpdateProduct.Enabled = btnProductImage.Enabled = btnPrintProduct.Enabled =
                btnPrintProducts.Enabled = btnSaveAsPDF.Enabled = comboBox1.Enabled = textBox1.Enabled = true;

            comboBox1.SelectedIndex = 0;

            LoadData();
            textBox1.Text = "";

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Product ID", typeof(int));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("Category", typeof(string));
            _DataTable.Columns.Add("Quantity", typeof(int));
            _DataTable.Columns.Add("Price", typeof(decimal));
            _DataTable.Columns.Add("Selected", typeof(int));

            GridViewProductsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewProductsList.Rows.Count > 0)
                GridViewProductsList.Rows.RemoveAt(0);

            btnDeleteProduct.Enabled = btnUpdateProduct.Enabled = btnProductImage.Enabled = btnPrintProduct.Enabled =
                btnPrintProducts.Enabled = btnSaveAsPDF.Enabled = comboBox1.Enabled = textBox1.Enabled = false;

            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewProductsList.Columns[0].Width = 31;
            GridViewProductsList.Columns[1].Width = 51;
            GridViewProductsList.Columns[2].Width = 51;
            GridViewProductsList.Columns[3].Width = 51;
            GridViewProductsList.Columns[4].Width = 79;
            GridViewProductsList.Columns[5].Width = 99;
        }

        private void LoadData(string Type = "Product ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                DataFilter = Text == "" ? null : $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewProductsList.DataSource = _DataView1;

            btnDeleteProduct.Enabled = btnUpdateProduct.Enabled =
                btnProductImage.Enabled = GridViewProductsList.Rows.Count != 0;

            lblRecords.Text = Convert.ToString(GridViewProductsList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            var fr = new AddEditProduct();
            fr.ShowDialog();

            // RefreshData();
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            UpdateProductInfo(Convert.ToString(GridViewProductsList.CurrentRow.Cells[0].Value));

            var fr = new AddEditProduct(_ProductID);
            fr.ShowDialog();

            //  RefreshData();
        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            UpdateProductInfo(Convert.ToString(GridViewProductsList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to delete [" + _ProductID + "]", "Confirm Deletion",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_Product1.Delete())
            {
                MessageBox.Show("Product Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Product, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnProductImage_Click(object sender, EventArgs e)
        {
            UpdateProductInfo(Convert.ToString(GridViewProductsList.CurrentRow.Cells[0].Value));

            var fr = new ProductImageScreen(_ProductID);
            fr.ShowDialog();
        }

        private void btnPrintProduct_Click(object sender, EventArgs e)
        {
        }

        private void btnPrintProducts_Click(object sender, EventArgs e)
        {
        }

        private void btnSaveAsPDF_Click(object sender, EventArgs e)
        {
        }

        private void UpdateProductInfo(string ID)
        {
            _ProductID = ID;
            _Product1 = ProductsBusinessLayer.FindProduct(_ProductID);
        }
    }
}