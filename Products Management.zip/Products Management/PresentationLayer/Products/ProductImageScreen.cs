﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Products
{
    public partial class ProductImageScreen : Form
    {
        private ProductsBusinessLayer product;

        public ProductImageScreen(string ProductID)
        {
            InitializeComponent();
            product = ProductsBusinessLayer.FindProduct(ProductID);
        }

        private void ProductImageScreen_Load(object sender, EventArgs e)
        {
            if (product.PathImage == null) return;

            var ms = new MemoryStream(product.PathImage);
            pictureBox1.Image = Image.FromStream(ms);
        }
    }
}