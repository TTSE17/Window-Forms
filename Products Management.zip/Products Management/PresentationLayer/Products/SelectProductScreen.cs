﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Orders;

namespace PresentationLayer.Products
{
    public partial class SelectProductScreen : Form
    {
        public SelectProductScreen()
        {
            InitializeComponent();
        }

        public delegate void DataBackEventHandler(string ProductID);

        public event DataBackEventHandler DataBack;

        private DataTable _DataTable;

        private string _ProductID = null;

        private void SelectProductScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
            GridViewProductsList.ClearSelection();
        }

        private void RefreshData()
        {
            _DataTable = ProductsBusinessLayer.GetAllProducts();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            groupBox1.Enabled = textBox1.Enabled = btnSelect.Enabled = true;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Product ID", typeof(int));
            _DataTable.Columns.Add("Description", typeof(string));
            _DataTable.Columns.Add("Category", typeof(string));
            _DataTable.Columns.Add("Quantity", typeof(int));
            _DataTable.Columns.Add("Price", typeof(decimal));
            _DataTable.Columns.Add("Selected", typeof(int));
            GridViewProductsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewProductsList.Rows.Count > 0)
                GridViewProductsList.Rows.RemoveAt(0);
        }

        private void _SetWidthColumns()
        {
            GridViewProductsList.Columns[0].Width = 51;
            GridViewProductsList.Columns[1].Width = 51;
            GridViewProductsList.Columns[2].Width = 51;
            GridViewProductsList.Columns[3].Width = 51;
            GridViewProductsList.Columns[4].Width = 79;
            GridViewProductsList.Columns[5].Width = 99;
        }

        private void LoadData(string Type = "Product ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                DataFilter = Text == "" ? null : $"[{Type}] LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "Unacceptable Key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewProductsList.DataSource = _DataView1;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = rbProductID.Checked ? "Product ID" : "Description";
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
            GridViewProductsList.ClearSelection();
        }

        private void rbProductID_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Product ID :";
        }

        private void rbProductLabel_CheckedChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            lblSearch.Text = "Product Label :";
        }

        private void GridViewProductsList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)
            {
                _ProductID = null;
                return;
            }

            _ProductID = Convert.ToString(GridViewProductsList.CurrentRow.Cells[0].Value);
        }

        private void GridViewProductsList_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            GridViewProductsList.ClearSelection();
            _ProductID = null;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (_ProductID == null)
            {
                MessageBox.Show("Select A Product!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if ((Application.OpenForms["AddEditOrderScreen"] as AddEditOrderScreen).IsExistInList(_ProductID))
            {
                MessageBox.Show("Already Exist In List !", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (Convert.ToInt32(GridViewProductsList.CurrentRow.Cells[3].Value) == 0)
            {
                MessageBox.Show("This Product Empty!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DataBack?.Invoke(_ProductID);
            Close();
        }
    }
}