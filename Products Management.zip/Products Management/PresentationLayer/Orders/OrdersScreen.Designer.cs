﻿using System.ComponentModel;

namespace PresentationLayer.Orders
{
    partial class OrdersScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.GridViewOrdersList = new System.Windows.Forms.DataGridView();
            this.lblRecords = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnPrintProducts = new System.Windows.Forms.Button();
            this.btnSaveAsPDF = new System.Windows.Forms.Button();
            this.btnDisplayOrder = new System.Windows.Forms.Button();
            this.btnUpdateOrder = new System.Windows.Forms.Button();
            this.btnDeleteOrder = new System.Windows.Forms.Button();
            this.btnProductImage = new System.Windows.Forms.Button();
            this.btnAddOrder = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewOrdersList)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkRed;
            this.panel2.Location = new System.Drawing.Point(251, 42);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(407, 2);
            this.panel2.TabIndex = 125;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.GridViewOrdersList);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox1.Location = new System.Drawing.Point(16, 68);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1043, 351);
            this.groupBox1.TabIndex = 124;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Orders List ";
            // 
            // GridViewOrdersList
            // 
            this.GridViewOrdersList.AllowUserToAddRows = false;
            this.GridViewOrdersList.AllowUserToDeleteRows = false;
            this.GridViewOrdersList.AllowUserToResizeColumns = false;
            this.GridViewOrdersList.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.GridViewOrdersList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.GridViewOrdersList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewOrdersList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.GridViewOrdersList.BackgroundColor = System.Drawing.Color.White;
            this.GridViewOrdersList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridViewOrdersList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewOrdersList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridViewOrdersList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewOrdersList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.GridViewOrdersList.GridColor = System.Drawing.Color.Crimson;
            this.GridViewOrdersList.Location = new System.Drawing.Point(4, 42);
            this.GridViewOrdersList.Margin = new System.Windows.Forms.Padding(0);
            this.GridViewOrdersList.Name = "GridViewOrdersList";
            this.GridViewOrdersList.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewOrdersList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.GridViewOrdersList.RowHeadersVisible = false;
            this.GridViewOrdersList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.GridViewOrdersList.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.GridViewOrdersList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridViewOrdersList.Size = new System.Drawing.Size(1035, 295);
            this.GridViewOrdersList.TabIndex = 110;
            // 
            // lblRecords
            // 
            this.lblRecords.AutoSize = true;
            this.lblRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecords.Location = new System.Drawing.Point(1029, 18);
            this.lblRecords.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(26, 29);
            this.lblRecords.TabIndex = 123;
            this.lblRecords.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(860, 18);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(161, 29);
            this.label1.TabIndex = 122;
            this.label1.Text = "Total Orders :";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] { "Order ID", "Customer Name", "UserName" });
            this.comboBox1.Location = new System.Drawing.Point(16, 15);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(207, 32);
            this.comboBox1.TabIndex = 120;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(251, 17);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(407, 25);
            this.textBox1.TabIndex = 121;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnPrintProducts);
            this.groupBox2.Controls.Add(this.btnSaveAsPDF);
            this.groupBox2.Controls.Add(this.btnDisplayOrder);
            this.groupBox2.Controls.Add(this.btnUpdateOrder);
            this.groupBox2.Controls.Add(this.btnDeleteOrder);
            this.groupBox2.Controls.Add(this.btnProductImage);
            this.groupBox2.Controls.Add(this.btnAddOrder);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox2.Location = new System.Drawing.Point(12, 426);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(1043, 185);
            this.groupBox2.TabIndex = 119;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "The Operations ";
            // 
            // btnPrintProducts
            // 
            this.btnPrintProducts.AutoSize = true;
            this.btnPrintProducts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrintProducts.Enabled = false;
            this.btnPrintProducts.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintProducts.ForeColor = System.Drawing.Color.Black;
            this.btnPrintProducts.Location = new System.Drawing.Point(440, 111);
            this.btnPrintProducts.Margin = new System.Windows.Forms.Padding(4);
            this.btnPrintProducts.Name = "btnPrintProducts";
            this.btnPrintProducts.Size = new System.Drawing.Size(199, 42);
            this.btnPrintProducts.TabIndex = 130;
            this.btnPrintProducts.Text = "Print Products";
            this.btnPrintProducts.UseVisualStyleBackColor = true;
            // 
            // btnSaveAsPDF
            // 
            this.btnSaveAsPDF.AutoSize = true;
            this.btnSaveAsPDF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveAsPDF.Enabled = false;
            this.btnSaveAsPDF.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSaveAsPDF.ForeColor = System.Drawing.Color.Black;
            this.btnSaveAsPDF.Location = new System.Drawing.Point(690, 111);
            this.btnSaveAsPDF.Margin = new System.Windows.Forms.Padding(4);
            this.btnSaveAsPDF.Name = "btnSaveAsPDF";
            this.btnSaveAsPDF.Size = new System.Drawing.Size(191, 42);
            this.btnSaveAsPDF.TabIndex = 129;
            this.btnSaveAsPDF.Text = "Save As PDF";
            this.btnSaveAsPDF.UseVisualStyleBackColor = true;
            // 
            // btnDisplayOrder
            // 
            this.btnDisplayOrder.AutoSize = true;
            this.btnDisplayOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDisplayOrder.Enabled = false;
            this.btnDisplayOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDisplayOrder.ForeColor = System.Drawing.Color.Black;
            this.btnDisplayOrder.Location = new System.Drawing.Point(192, 111);
            this.btnDisplayOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnDisplayOrder.Name = "btnDisplayOrder";
            this.btnDisplayOrder.Size = new System.Drawing.Size(175, 42);
            this.btnDisplayOrder.TabIndex = 127;
            this.btnDisplayOrder.Text = "Display Order";
            this.btnDisplayOrder.UseVisualStyleBackColor = true;
            this.btnDisplayOrder.Click += new System.EventHandler(this.btnDisplayOrder_Click);
            // 
            // btnUpdateOrder
            // 
            this.btnUpdateOrder.AutoSize = true;
            this.btnUpdateOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateOrder.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateOrder.Location = new System.Drawing.Point(306, 51);
            this.btnUpdateOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnUpdateOrder.Name = "btnUpdateOrder";
            this.btnUpdateOrder.Size = new System.Drawing.Size(199, 42);
            this.btnUpdateOrder.TabIndex = 126;
            this.btnUpdateOrder.Text = "Update Order";
            this.btnUpdateOrder.UseVisualStyleBackColor = true;
            this.btnUpdateOrder.Click += new System.EventHandler(this.btnUpdateOrder_Click);
            // 
            // btnDeleteOrder
            // 
            this.btnDeleteOrder.AutoSize = true;
            this.btnDeleteOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDeleteOrder.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteOrder.Location = new System.Drawing.Point(565, 51);
            this.btnDeleteOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnDeleteOrder.Name = "btnDeleteOrder";
            this.btnDeleteOrder.Size = new System.Drawing.Size(191, 42);
            this.btnDeleteOrder.TabIndex = 125;
            this.btnDeleteOrder.Text = "Delete Order";
            this.btnDeleteOrder.UseVisualStyleBackColor = true;
            this.btnDeleteOrder.Click += new System.EventHandler(this.btnDeleteOrder_Click);
            // 
            // btnProductImage
            // 
            this.btnProductImage.AutoSize = true;
            this.btnProductImage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnProductImage.Enabled = false;
            this.btnProductImage.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnProductImage.ForeColor = System.Drawing.Color.Black;
            this.btnProductImage.Location = new System.Drawing.Point(802, 51);
            this.btnProductImage.Margin = new System.Windows.Forms.Padding(4);
            this.btnProductImage.Name = "btnProductImage";
            this.btnProductImage.Size = new System.Drawing.Size(212, 42);
            this.btnProductImage.TabIndex = 124;
            this.btnProductImage.Text = "Product\'s Image";
            this.btnProductImage.UseVisualStyleBackColor = true;
            // 
            // btnAddOrder
            // 
            this.btnAddOrder.AutoSize = true;
            this.btnAddOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddOrder.ForeColor = System.Drawing.Color.Black;
            this.btnAddOrder.Location = new System.Drawing.Point(88, 51);
            this.btnAddOrder.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddOrder.Name = "btnAddOrder";
            this.btnAddOrder.Size = new System.Drawing.Size(164, 42);
            this.btnAddOrder.TabIndex = 121;
            this.btnAddOrder.Text = "Add Order";
            this.btnAddOrder.UseVisualStyleBackColor = true;
            this.btnAddOrder.Click += new System.EventHandler(this.btnAddOrder_Click);
            // 
            // OrdersScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 624);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblRecords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "OrdersScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Orders Screen";
            this.Load += new System.EventHandler(this.OrdersScreen_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridViewOrdersList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPrintProducts;
        private System.Windows.Forms.Button btnSaveAsPDF;
        private System.Windows.Forms.Button btnDisplayOrder;
        private System.Windows.Forms.Button btnUpdateOrder;
        private System.Windows.Forms.Button btnDeleteOrder;
        private System.Windows.Forms.Button btnProductImage;
        private System.Windows.Forms.Button btnAddOrder;

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView GridViewOrdersList;
        private System.Windows.Forms.Label lblRecords;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;

        #endregion
    }
}