﻿using System.ComponentModel;
using System.Drawing;

namespace PresentationLayer.Orders
{
    partial class AddEditOrderScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectCustomer = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblUserName = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnDeleteAll = new System.Windows.Forms.Button();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTotal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnNewOrder = new System.Windows.Forms.Button();
            this.btnPrintOrder = new System.Windows.Forms.Button();
            this.btnSaveOrder = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnAddToList = new System.Windows.Forms.Label();
            this.lblMaxQuantity = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.GridViewProductsList = new System.Windows.Forms.DataGridView();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTotalAmount = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nDiscount = new System.Windows.Forms.NumericUpDown();
            this.lblProductID = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblSelectProduct = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.nQuantity = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lblCategory = new System.Windows.Forms.Label();
            this.lblProductPrice = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewProductsList)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nDiscount)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblEmail);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lblLastName);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.lblFirstName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblCustomerID);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSelectCustomer);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Black;
            this.groupBox1.Location = new System.Drawing.Point(551, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(363, 258);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Info";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoEllipsis = true;
            this.lblEmail.ForeColor = System.Drawing.Color.Crimson;
            this.lblEmail.Location = new System.Drawing.Point(138, 227);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(224, 21);
            this.lblEmail.TabIndex = 141;
            this.lblEmail.Text = "N/A";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(67, 227);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 25);
            this.label8.TabIndex = 140;
            this.label8.Text = "Email :";
            // 
            // lblPhone
            // 
            this.lblPhone.AutoEllipsis = true;
            this.lblPhone.ForeColor = System.Drawing.Color.Crimson;
            this.lblPhone.Location = new System.Drawing.Point(138, 191);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(222, 21);
            this.lblPhone.TabIndex = 139;
            this.lblPhone.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 25);
            this.label4.TabIndex = 138;
            this.label4.Text = "Phone :";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoEllipsis = true;
            this.lblLastName.BackColor = System.Drawing.SystemColors.Control;
            this.lblLastName.ForeColor = System.Drawing.Color.Crimson;
            this.lblLastName.Location = new System.Drawing.Point(138, 153);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(222, 21);
            this.lblLastName.TabIndex = 137;
            this.lblLastName.Text = "N/A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 25);
            this.label6.TabIndex = 136;
            this.label6.Text = "LastName :";
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoEllipsis = true;
            this.lblFirstName.ForeColor = System.Drawing.Color.Crimson;
            this.lblFirstName.Location = new System.Drawing.Point(138, 117);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(222, 21);
            this.lblFirstName.TabIndex = 135;
            this.lblFirstName.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 25);
            this.label3.TabIndex = 134;
            this.label3.Text = "FirstName :";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.ForeColor = System.Drawing.Color.Crimson;
            this.lblCustomerID.Location = new System.Drawing.Point(135, 81);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(46, 25);
            this.lblCustomerID.TabIndex = 133;
            this.lblCustomerID.Text = "N/A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 25);
            this.label1.TabIndex = 132;
            this.label1.Text = "Customer ID :";
            // 
            // btnSelectCustomer
            // 
            this.btnSelectCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnSelectCustomer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelectCustomer.FlatAppearance.BorderSize = 0;
            this.btnSelectCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelectCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectCustomer.ForeColor = System.Drawing.Color.White;
            this.btnSelectCustomer.Location = new System.Drawing.Point(99, 35);
            this.btnSelectCustomer.Name = "btnSelectCustomer";
            this.btnSelectCustomer.Size = new System.Drawing.Size(195, 35);
            this.btnSelectCustomer.TabIndex = 131;
            this.btnSelectCustomer.Text = "Select Customer";
            this.btnSelectCustomer.UseVisualStyleBackColor = false;
            this.btnSelectCustomer.Click += new System.EventHandler(this.btnSelectCustomer_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtDescription);
            this.groupBox2.Controls.Add(this.lblUserName);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lblOrderDate);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.lblOrderID);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(352, 258);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Order Info";
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(127, 78);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(200, 66);
            this.txtDescription.TabIndex = 150;
            // 
            // lblUserName
            // 
            this.lblUserName.AutoEllipsis = true;
            this.lblUserName.ForeColor = System.Drawing.Color.Crimson;
            this.lblUserName.Location = new System.Drawing.Point(127, 215);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(200, 21);
            this.lblUserName.TabIndex = 149;
            this.lblUserName.Text = "N/A";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 214);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 25);
            this.label9.TabIndex = 148;
            this.label9.Text = "UserName :";
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.AutoEllipsis = true;
            this.lblOrderDate.BackColor = System.Drawing.SystemColors.Control;
            this.lblOrderDate.ForeColor = System.Drawing.Color.Crimson;
            this.lblOrderDate.Location = new System.Drawing.Point(123, 168);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(200, 21);
            this.lblOrderDate.TabIndex = 147;
            this.lblOrderDate.Text = "N/A";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 168);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(119, 25);
            this.label11.TabIndex = 146;
            this.label11.Text = "Order Date :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 78);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(120, 25);
            this.label13.TabIndex = 144;
            this.label13.Text = "Description :";
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.ForeColor = System.Drawing.Color.Crimson;
            this.lblOrderID.Location = new System.Drawing.Point(127, 39);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(46, 25);
            this.lblOrderID.TabIndex = 143;
            this.lblOrderID.Text = "N/A";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(29, 39);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 25);
            this.label15.TabIndex = 142;
            this.label15.Text = "Order ID :";
            // 
            // btnDeleteAll
            // 
            this.btnDeleteAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(73)))), ((int)(((byte)(245)))));
            this.btnDeleteAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteAll.FlatAppearance.BorderSize = 0;
            this.btnDeleteAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteAll.ForeColor = System.Drawing.Color.White;
            this.btnDeleteAll.Location = new System.Drawing.Point(779, 681);
            this.btnDeleteAll.Name = "btnDeleteAll";
            this.btnDeleteAll.Size = new System.Drawing.Size(129, 33);
            this.btnDeleteAll.TabIndex = 132;
            this.btnDeleteAll.Text = "Delete All";
            this.btnDeleteAll.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnDeleteAll.UseVisualStyleBackColor = false;
            this.btnDeleteAll.Click += new System.EventHandler(this.btnDeleteAll_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            this.toolStripMenuItem1.Text = "toolStripMenuItem1";
            // 
            // lblTotal
            // 
            this.lblTotal.AutoEllipsis = true;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.Crimson;
            this.lblTotal.Location = new System.Drawing.Point(96, 681);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(533, 29);
            this.lblTotal.TabIndex = 151;
            this.lblTotal.Text = "0";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 681);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 26);
            this.label5.TabIndex = 150;
            this.label5.Text = "Total :";
            // 
            // btnNewOrder
            // 
            this.btnNewOrder.AutoSize = true;
            this.btnNewOrder.BackColor = System.Drawing.SystemColors.Control;
            this.btnNewOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewOrder.ForeColor = System.Drawing.Color.Black;
            this.btnNewOrder.Location = new System.Drawing.Point(391, 60);
            this.btnNewOrder.Name = "btnNewOrder";
            this.btnNewOrder.Size = new System.Drawing.Size(135, 35);
            this.btnNewOrder.TabIndex = 131;
            this.btnNewOrder.Text = "New Order";
            this.btnNewOrder.UseVisualStyleBackColor = false;
            this.btnNewOrder.Click += new System.EventHandler(this.btnNewOrder_Click);
            // 
            // btnPrintOrder
            // 
            this.btnPrintOrder.AutoSize = true;
            this.btnPrintOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrintOrder.Enabled = false;
            this.btnPrintOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrintOrder.ForeColor = System.Drawing.Color.Black;
            this.btnPrintOrder.Location = new System.Drawing.Point(391, 175);
            this.btnPrintOrder.Name = "btnPrintOrder";
            this.btnPrintOrder.Size = new System.Drawing.Size(135, 35);
            this.btnPrintOrder.TabIndex = 126;
            this.btnPrintOrder.Text = "Print Order";
            this.btnPrintOrder.UseVisualStyleBackColor = true;
            // 
            // btnSaveOrder
            // 
            this.btnSaveOrder.AutoSize = true;
            this.btnSaveOrder.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveOrder.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSaveOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaveOrder.ForeColor = System.Drawing.Color.Black;
            this.btnSaveOrder.Location = new System.Drawing.Point(391, 119);
            this.btnSaveOrder.Name = "btnSaveOrder";
            this.btnSaveOrder.Size = new System.Drawing.Size(135, 35);
            this.btnSaveOrder.TabIndex = 121;
            this.btnSaveOrder.Text = "Save Order";
            this.btnSaveOrder.UseVisualStyleBackColor = true;
            this.btnSaveOrder.Click += new System.EventHandler(this.btnSaveOrder_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnAddToList);
            this.groupBox4.Controls.Add(this.lblMaxQuantity);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.GridViewProductsList);
            this.groupBox4.Controls.Add(this.lblTotalAmount);
            this.groupBox4.Controls.Add(this.label32);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label31);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Controls.Add(this.lblProductID);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.lblSelectProduct);
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.lblCategory);
            this.groupBox4.Controls.Add(this.lblProductPrice);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 287);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(902, 379);
            this.groupBox4.TabIndex = 153;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Selected Products";
            // 
            // btnAddToList
            // 
            this.btnAddToList.BackColor = System.Drawing.SystemColors.Control;
            this.btnAddToList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.btnAddToList.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddToList.Enabled = false;
            this.btnAddToList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddToList.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddToList.Location = new System.Drawing.Point(795, 67);
            this.btnAddToList.Name = "btnAddToList";
            this.btnAddToList.Size = new System.Drawing.Size(103, 29);
            this.btnAddToList.TabIndex = 231;
            this.btnAddToList.Text = "Click";
            this.btnAddToList.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddToList.Click += new System.EventHandler(this.btnAddToList_Click);
            // 
            // lblMaxQuantity
            // 
            this.lblMaxQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaxQuantity.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblMaxQuantity.Location = new System.Drawing.Point(244, 112);
            this.lblMaxQuantity.Name = "lblMaxQuantity";
            this.lblMaxQuantity.Size = new System.Drawing.Size(446, 23);
            this.lblMaxQuantity.TabIndex = 217;
            this.lblMaxQuantity.Text = "Note : This Product Has 4 Item in Stock";
            this.lblMaxQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMaxQuantity.Visible = false;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(795, 44);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(103, 24);
            this.label19.TabIndex = 230;
            this.label19.Text = "Add To List";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // GridViewProductsList
            // 
            this.GridViewProductsList.AllowUserToAddRows = false;
            this.GridViewProductsList.AllowUserToDeleteRows = false;
            this.GridViewProductsList.AllowUserToResizeColumns = false;
            this.GridViewProductsList.AllowUserToResizeRows = false;
            this.GridViewProductsList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewProductsList.BackgroundColor = System.Drawing.SystemColors.Window;
            this.GridViewProductsList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewProductsList.ContextMenuStrip = this.contextMenuStrip1;
            this.GridViewProductsList.Font = new System.Drawing.Font("Arial", 9F);
            this.GridViewProductsList.Location = new System.Drawing.Point(10, 150);
            this.GridViewProductsList.MultiSelect = false;
            this.GridViewProductsList.Name = "GridViewProductsList";
            this.GridViewProductsList.ReadOnly = true;
            this.GridViewProductsList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridViewProductsList.ShowCellToolTips = false;
            this.GridViewProductsList.Size = new System.Drawing.Size(886, 223);
            this.GridViewProductsList.TabIndex = 216;
            this.GridViewProductsList.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.editToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.editToolStripMenuItem, this.toolStripSeparator1, this.deleteToolStripMenuItem });
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(123, 58);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(119, 6);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(122, 24);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // lblTotalAmount
            // 
            this.lblTotalAmount.BackColor = System.Drawing.SystemColors.Window;
            this.lblTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalAmount.Location = new System.Drawing.Point(690, 67);
            this.lblTotalAmount.Name = "lblTotalAmount";
            this.lblTotalAmount.Size = new System.Drawing.Size(108, 29);
            this.lblTotalAmount.TabIndex = 229;
            this.lblTotalAmount.Text = "N/A";
            this.lblTotalAmount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(7, 44);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(91, 24);
            this.label32.TabIndex = 216;
            this.label32.Text = "Select";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(690, 44);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(108, 24);
            this.label22.TabIndex = 228;
            this.label22.Text = "Total Amount";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(97, 44);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(109, 24);
            this.label31.TabIndex = 217;
            this.label31.Text = "Product ID";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.nDiscount);
            this.panel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel3.Location = new System.Drawing.Point(588, 67);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(105, 29);
            this.panel3.TabIndex = 227;
            // 
            // nDiscount
            // 
            this.nDiscount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nDiscount.DecimalPlaces = 1;
            this.nDiscount.Enabled = false;
            this.nDiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nDiscount.Location = new System.Drawing.Point(0, 2);
            this.nDiscount.Maximum = new decimal(new int[] { 999, 0, 0, 65536 });
            this.nDiscount.Name = "nDiscount";
            this.nDiscount.Size = new System.Drawing.Size(101, 28);
            this.nDiscount.TabIndex = 0;
            this.nDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nDiscount.ValueChanged += new System.EventHandler(this.NumericUpDown_ValueChanged);
            // 
            // lblProductID
            // 
            this.lblProductID.BackColor = System.Drawing.SystemColors.Window;
            this.lblProductID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductID.Location = new System.Drawing.Point(97, 67);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(109, 29);
            this.lblProductID.TabIndex = 218;
            this.lblProductID.Text = "N/A";
            this.lblProductID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(588, 44);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(106, 24);
            this.label23.TabIndex = 226;
            this.label23.Text = "Discount %";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSelectProduct
            // 
            this.lblSelectProduct.BackColor = System.Drawing.SystemColors.Control;
            this.lblSelectProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSelectProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblSelectProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectProduct.Location = new System.Drawing.Point(7, 67);
            this.lblSelectProduct.Name = "lblSelectProduct";
            this.lblSelectProduct.Size = new System.Drawing.Size(91, 29);
            this.lblSelectProduct.TabIndex = 219;
            this.lblSelectProduct.Text = "Click";
            this.lblSelectProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSelectProduct.Click += new System.EventHandler(this.lblSelectProduct_Click);
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.nQuantity);
            this.panel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.Location = new System.Drawing.Point(483, 67);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(106, 29);
            this.panel4.TabIndex = 225;
            // 
            // nQuantity
            // 
            this.nQuantity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.nQuantity.Enabled = false;
            this.nQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nQuantity.Location = new System.Drawing.Point(0, 2);
            this.nQuantity.Margin = new System.Windows.Forms.Padding(3, 3, 6, 3);
            this.nQuantity.Maximum = new decimal(new int[] { 10, 0, 0, 0 });
            this.nQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.nQuantity.Name = "nQuantity";
            this.nQuantity.Size = new System.Drawing.Size(101, 28);
            this.nQuantity.TabIndex = 0;
            this.nQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
            this.nQuantity.ValueChanged += new System.EventHandler(this.NumericUpDown_ValueChanged);
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(205, 44);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(140, 24);
            this.label28.TabIndex = 220;
            this.label28.Text = "Category";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(483, 44);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(106, 24);
            this.label24.TabIndex = 224;
            this.label24.Text = "Quantity ";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCategory
            // 
            this.lblCategory.BackColor = System.Drawing.SystemColors.Window;
            this.lblCategory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategory.Location = new System.Drawing.Point(205, 67);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(140, 29);
            this.lblCategory.TabIndex = 221;
            this.lblCategory.Text = "N/A";
            this.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblProductPrice
            // 
            this.lblProductPrice.BackColor = System.Drawing.SystemColors.Window;
            this.lblProductPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductPrice.Location = new System.Drawing.Point(343, 67);
            this.lblProductPrice.Name = "lblProductPrice";
            this.lblProductPrice.Size = new System.Drawing.Size(141, 29);
            this.lblProductPrice.TabIndex = 223;
            this.lblProductPrice.Text = "N/A";
            this.lblProductPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(343, 44);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(141, 24);
            this.label26.TabIndex = 222;
            this.label26.Text = "Product Price";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AddEditOrderScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(931, 735);
            this.Controls.Add(this.btnPrintOrder);
            this.Controls.Add(this.btnNewOrder);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnSaveOrder);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnDeleteAll);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddEditOrderScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Orders Screen";
            this.Load += new System.EventHandler(this.OrdersScreen_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridViewProductsList)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nDiscount)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nQuantity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label btnAddToList;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblTotalAmount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.NumericUpDown nDiscount;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.NumericUpDown nQuantity;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lblProductPrice;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label lblSelectProduct;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;

        private System.Windows.Forms.Label lblMaxQuantity;

        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;

        private System.Windows.Forms.DataGridView GridViewProductsList;

        private System.Windows.Forms.GroupBox groupBox4;

        private System.Windows.Forms.Button btnNewOrder;
        private System.Windows.Forms.Button btnPrintOrder;
        private System.Windows.Forms.Button btnSaveOrder;

        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Label label5;

        private System.Windows.Forms.Button btnDeleteAll;


        private System.Windows.Forms.TextBox txtDescription;

        private System.Windows.Forms.Label lblUserName;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.Label label15;

        private System.Windows.Forms.GroupBox groupBox2;

        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label label8;

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSelectCustomer;

        #endregion
    }
}