﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Orders
{
    public partial class OrdersScreen : Form
    {
        public OrdersScreen(int? CustomerID = null)
        {
            InitializeComponent();
            _CustomerID = CustomerID;
        }

        private DataTable _DataTable;

        private int? _CustomerID;

        private void OrdersScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        public void RefreshData()
        {
            _DataTable = OrdersBusinessLayer.GetAllOrders(_CustomerID);

            btnUpdateOrder.Enabled = btnDeleteOrder.Enabled = btnDisplayOrder.Enabled = true;

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();

                btnUpdateOrder.Enabled = btnDeleteOrder.Enabled = btnDisplayOrder.Enabled = false;

                return;
            }

            comboBox1.Enabled = textBox1.Enabled = !_CustomerID.HasValue;

            comboBox1.SelectedIndex = 0;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Order ID", typeof(int));
            _DataTable.Columns.Add("Customer Name", typeof(string));
            _DataTable.Columns.Add("UserName", typeof(string));
            _DataTable.Columns.Add("Total", typeof(decimal));
            _DataTable.Columns.Add("OrderDate", typeof(DateTime));
            _DataTable.Columns.Add("Products", typeof(int));
            //     _DataTable.Columns.Add("Description", typeof(string));

            GridViewOrdersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewOrdersList.Rows.Count > 0)
                GridViewOrdersList.Rows.RemoveAt(0);

            comboBox1.Enabled = textBox1.Enabled = false;

            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewOrdersList.Columns[0].Width = 111;
            GridViewOrdersList.Columns[1].Width = 151;
            GridViewOrdersList.Columns[2].Width = 111;
            GridViewOrdersList.Columns[3].Width = 111;
            GridViewOrdersList.Columns[4].Width = 151;
            GridViewOrdersList.Columns[4].Width = 111;
            // GridViewOrdersList.Columns[5].Width = 111;
        }

        private void LoadData(string Type = "Order ID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "Order ID")
                    DataFilter = $"[{Type}] = '{Text}'";
                else
                    DataFilter = $"[{Type}] LIKE '{Text}%'";

                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                textBox1.Text = Text.Substring(0, Text.Length - 1);

                _DataView1.RowFilter = null;
            }

            GridViewOrdersList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewOrdersList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox1.Focus();
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            var fr = new AddEditOrderScreen();
            fr.ShowDialog();
        }

        private void btnUpdateOrder_Click(object sender, EventArgs e)
        {
            var fr = new AddEditOrderScreen(Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value));
            fr.ShowDialog();
        }

        private void btnDeleteOrder_Click(object sender, EventArgs e)
        {
            int ID = Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value);

            if (MessageBox.Show("Are you sure you want to delete [" + ID +
                                "] \n\nNote : All products belonging to this Order will be deleted!",
                    "Confirm Deletion", MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (OrdersBusinessLayer.Delete(ID))
            {
                MessageBox.Show("Order Deleted Successfully.", "Done",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Order, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDisplayOrder_Click(object sender, EventArgs e)
        {
            var fr = new OrderDetailScreen(Convert.ToInt32(GridViewOrdersList.CurrentRow.Cells[0].Value));
            fr.ShowDialog();
        }
    }
}