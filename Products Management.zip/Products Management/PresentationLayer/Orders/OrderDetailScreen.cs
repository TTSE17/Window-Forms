﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Orders
{
    public partial class OrderDetailScreen : Form
    {
        private int _OrderID;
        private readonly DataTable DT = new DataTable();
        
        public OrderDetailScreen(int orderId)
        {
            InitializeComponent();

            _OrderID = orderId;
        }

        private void OrderDetailScreen_Load(object sender, EventArgs e)
        {
            _SetColumns();
            
            LoadData();
        }

        private void _SetColumns()
        {
            DT.Columns.Add("Product ID", typeof(string));
            DT.Columns.Add("Product Name", typeof(string));
            DT.Columns.Add("Price", typeof(decimal));
            DT.Columns.Add("Quantity", typeof(int));
            DT.Columns.Add("MaxQuantity", typeof(int));
            DT.Columns.Add("Discount", typeof(decimal));
            DT.Columns.Add("Total Amount", typeof(decimal));

            GridViewProductsList.DataSource = DT;

            _SetWidthColumns();
        }

        private void _SetWidthColumns()
        {
            GridViewProductsList.RowHeadersVisible = false;
            GridViewProductsList.Columns[0].Width = 96;
            GridViewProductsList.Columns[1].Width = 111;
            GridViewProductsList.Columns[2].Width = 96;
            GridViewProductsList.Columns[3].Width = 77;
            // GridViewProductsList.Columns[4].Width = 0;
            GridViewProductsList.Columns[4].Visible = false;
            GridViewProductsList.Columns[5].Width = 96;
            // GridViewProductsList.Columns[6].Width = 111;

            // GridViewProductsList.ColumnHeadersVisible = false;
        }

        private void LoadData()
        {
            var _Order1 = OrdersBusinessLayer.FindOrder(_OrderID);
            lblOrderID.Text = Convert.ToString(_OrderID);
            _LoadCustomerInfo(_Order1.CustomerID.Value);
            lblTotal.Text = _Order1.Total.ToString("0.00");
            lblOrderDate.Text = DateTime.Now.ToString("yyyy/MM/dd");
            lblDescription.Text = _Order1.Description;

            _LoadOrderDetails();
        }

        private void _LoadCustomerInfo(int _CustomerID)
        {
            var _Customer1 = CustomersBusinessLayer.FindCustomer(_CustomerID);

            lblCustomerID.Text = Convert.ToString(_CustomerID);
            lblFullName.Text = _Customer1.FirstName + " " + _Customer1.LastName;
            lblPhone.Text = _Customer1.Phone;
            lblEmail.Text = _Customer1.Email;
        }

        private void _LoadOrderDetails()
        {
            DataTable OrderDetailsList = OrdersDetailsDetailsBusinessLayer.GetAllOrderDetails(_OrderID);
            ProductsBusinessLayer Product;
            foreach (DataRow Row in OrderDetailsList.Rows)
            {
                Product = ProductsBusinessLayer.FindProduct(Convert.ToString(Row[0]));

                DT.Rows.Add(Row[0], Product.CategoryInfo.CategoryDescription, Row[3],
                    Row[2], Product.Quantity + Convert.ToInt32(Row[2]), Row[4], Row[5]);

                // (DT.Rows.Add()_ProductID, lblCategory.Text, lblProductPrice.Text,
                //     nQuantity.Value, nQuantity.Maximum, nDiscount.Value, lblTotalAmount.Text);
            }
        }
    }
}