﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Customers;
using PresentationLayer.Products;

namespace PresentationLayer.Orders
{
    public partial class AddEditOrderScreen : Form
    {
        private enum enMood
        {
            Add,
            Edit
        }

        public AddEditOrderScreen(int? OrderID = null)
        {
            InitializeComponent();

            _OrderID = OrderID;
        }

        private CustomersBusinessLayer _Customer1;
        private int _CustomerID = -1;

        private ProductsBusinessLayer _Product1;
        private string _ProductID;

        private enMood _Mood = enMood.Add;

        private readonly DataTable DT = new DataTable();

        private int? _OrderID;
        private OrdersBusinessLayer _Order1;

        private void OrdersScreen_Load(object sender, EventArgs e) /////////
        {
            _SetColumns();
             lblUserName.Text = clsGlobal.CurrentUser.UserName;
           // lblUserName.Text = "User1";

            if (_OrderID.HasValue)
            {
                LoadData();
            }
            else
            {
                _ClearOrder();
            }
        }

        private void LoadData()
        {
            _Order1 = OrdersBusinessLayer.FindOrder(_OrderID);
            lblOrderID.Text = Convert.ToString(_OrderID);
            _LoadCustomerInfo(_Order1.CustomerID.Value);
            lblTotal.Text = _Order1.Total.ToString("0.00");
            lblOrderDate.Text = DateTime.Now.ToString("yyyy/MM/dd");
            txtDescription.Text = _Order1.Description;

            _LoadOrderDetails();
        }

        private void _LoadOrderDetails()
        {
            DataTable OrderDetailsList = OrdersDetailsDetailsBusinessLayer.GetAllOrderDetails(_OrderID);
            ProductsBusinessLayer Product;
            foreach (DataRow Row in OrderDetailsList.Rows)
            {
                Product = ProductsBusinessLayer.FindProduct(Convert.ToString(Row[0]));
                
                DT.Rows.Add(Row[0], Product.CategoryInfo.CategoryDescription, Row[3],
                    Row[2], Product.Quantity + Convert.ToInt32(Row[2]), Row[4], Row[5]);
                
                // (DT.Rows.Add()_ProductID, lblCategory.Text, lblProductPrice.Text,
                //     nQuantity.Value, nQuantity.Maximum, nDiscount.Value, lblTotalAmount.Text);
            }
        }

        private void _ClearOrder()
        {
            _OrderID = null;
            _Order1 = null;

            lblOrderID.Text = "N/A";
            lblOrderDate.Text = DateTime.Now.ToString("yyyy/MM/dd");
            txtDescription.Clear();

            _ClearCustomerInfo();

            _ClearSelectedProduct();

            DT.Rows.Clear();

            _CalculateTotal();
        }

        private void _ClearCustomerInfo()
        {
            _Customer1 = null;
            _CustomerID = -1;

            lblCustomerID.Text = lblFirstName.Text = lblLastName.Text = lblPhone.Text = lblEmail.Text = "N/A";
        }

        private void _ClearSelectedProduct()
        {
            lblProductID.Text = lblCategory.Text = lblProductPrice.Text = lblTotalAmount.Text = "N/A";
            nQuantity.Enabled = nDiscount.Enabled = btnAddToList.Enabled = false;
            nQuantity.Value = 1;
            nDiscount.Value = 0;
        }

        private void _SetColumns()
        {
            DT.Columns.Add("Product ID", typeof(string));
            DT.Columns.Add("Product Name", typeof(string));
            DT.Columns.Add("Price", typeof(decimal));
            DT.Columns.Add("Quantity", typeof(int));
            DT.Columns.Add("MaxQuantity", typeof(int));
            DT.Columns.Add("Discount", typeof(decimal));
            DT.Columns.Add("Total Amount", typeof(decimal));

            GridViewProductsList.DataSource = DT;

            _SetWidthColumns();
        }

        private void _SetWidthColumns()
        {
            GridViewProductsList.RowHeadersVisible = false;
            GridViewProductsList.Columns[0].Width = 96;
            GridViewProductsList.Columns[1].Width = 96;
            GridViewProductsList.Columns[2].Width = 96;
            GridViewProductsList.Columns[3].Width = 96;
            // GridViewProductsList.Columns[4].Width = 0;
            GridViewProductsList.Columns[4].Visible = false;
            GridViewProductsList.Columns[5].Width = 96;
            // GridViewProductsList.Columns[6].Width = 111;

            // GridViewProductsList.ColumnHeadersVisible = false;
        }

        private void btnNewOrder_Click(object sender, EventArgs e)
        {
            _ClearOrder();
        }

        private void btnSelectCustomer_Click(object sender, EventArgs e)
        {
            var fr = new SelectCustomerScreen();
            fr.DataBack += _LoadCustomerInfo;
            fr.ShowDialog();
        }

        private void _LoadCustomerInfo(int ID)
        {
            _CustomerID = ID;
            _Customer1 = CustomersBusinessLayer.FindCustomer(_CustomerID);

            lblCustomerID.Text = Convert.ToString(_CustomerID);
            lblFirstName.Text = _Customer1.FirstName;
            lblLastName.Text = _Customer1.LastName;
            lblPhone.Text = _Customer1.Phone;
            lblEmail.Text = _Customer1.Email;
        }

        private void lblSelectProduct_Click(object sender, EventArgs e)
        {
            var fr = new SelectProductScreen();

            fr.DataBack += _GetProductID;

            fr.ShowDialog();
        }

        private void _GetProductID(string ID)
        {
            _ProductID = ID;
            _Product1 = ProductsBusinessLayer.FindProduct(_ProductID);

            lblProductID.Text = _ProductID;
            lblCategory.Text = _Product1.CategoryInfo.CategoryDescription;
            lblProductPrice.Text = lblTotalAmount.Text = _Product1.Price.ToString("0.00");

            nQuantity.Enabled = nDiscount.Enabled = btnAddToList.Enabled = true;
            nQuantity.Value = 1;
            nQuantity.Maximum = Convert.ToDecimal(_Product1.Quantity);
            nDiscount.Value = 0;
            nQuantity.Focus();

            lblMaxQuantity.Visible = true;
            lblMaxQuantity.Text = $"Note : This Product Has Only {nQuantity.Maximum} item(s) In Stock";
        }

        public bool IsExistInList(string productID)
        {
            foreach (DataRow Row in DT.Rows)
            {
                if (productID == Convert.ToString(Row[0])) return true;
            }

            return false;
        }

        private void NumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            decimal BeforeDiscount = 0;

            try
            {
                BeforeDiscount = Convert.ToDecimal(lblProductPrice.Text.Trim()) * nQuantity.Value;
            }
            catch (Exception)
            {
                // ignored
            }

            var AfterDiscount = BeforeDiscount - BeforeDiscount * (nDiscount.Value / 100);

            lblTotalAmount.Text = AfterDiscount.ToString("0.00");
        }

        private void btnAddToList_Click(object sender, EventArgs e)
        {
            if (_ProductID == null)
            {
                MessageBox.Show("Select A Product!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (_Mood == enMood.Edit)
            {
                _UpdateRow();
            }

            _AddRowToList();

            _CalculateTotal();

            _ClearSelectedProduct();

            lblSelectProduct.Focus();

            _Mood = enMood.Add;
            lblMaxQuantity.Visible = false;
            _ProductID = null;
        }

        private void _UpdateRow()
        {
            foreach (DataRow Row in DT.Rows)
            {
                if (Convert.ToString(Row[0]) != _ProductID) continue;

                Row.Delete();
                return;
            }
        }

        private void _AddRowToList()
        {
            DT.Rows.Add(_ProductID, lblCategory.Text, lblProductPrice.Text,
                nQuantity.Value, nQuantity.Maximum, nDiscount.Value, lblTotalAmount.Text);
        }

        private void _CalculateTotal()
        {
            decimal Total = 0;
            foreach (DataRow Row in DT.Rows)
            {
                Total += Convert.ToDecimal(Row[6]);
            }

            lblTotal.Text = Total.ToString("0.00");
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var row = GridViewProductsList.CurrentRow;

            if (row == null) return;

            _ProductID = Convert.ToString(row.Cells[0].Value);

            lblProductID.Text = _ProductID;
            lblCategory.Text = Convert.ToString(row.Cells[1].Value);
            lblProductPrice.Text = Convert.ToString(row.Cells[2].Value);
            nQuantity.Maximum = Convert.ToDecimal(row.Cells[4].Value);
            nQuantity.Value = Convert.ToDecimal(row.Cells[3].Value);
            nDiscount.Value = Convert.ToDecimal(row.Cells[5].Value);
            lblTotalAmount.Text = Convert.ToString(row.Cells[6].Value);

            _Mood = enMood.Edit;
            nQuantity.Enabled = nDiscount.Enabled = btnAddToList.Enabled = true;

            lblMaxQuantity.Visible = true;
            lblMaxQuantity.Text = $"Note : This Product Has Only {nQuantity.Maximum} item(s) In Stock";
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GridViewProductsList.CurrentRow == null)
            {
                MessageBox.Show("Select Row!", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var ID = Convert.ToString(GridViewProductsList.CurrentRow.Cells[0].Value);

            if (MessageBox.Show("Are you sure you want to delete [" + ID + "]", "Confirm Deletion",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) !=
                DialogResult.OK)
                return;

            if (ID == lblProductID.Text)
                _ClearSelectedProduct();

            GridViewProductsList.Rows.RemoveAt(GridViewProductsList.CurrentRow.Index);

            _CalculateTotal();

            MessageBox.Show("Product Deleted Successfully.", "Deleted",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDeleteAll_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete All Product", "Confirm Deletion",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) !=
                DialogResult.OK)
                return;

            DT.Rows.Clear();

            _CalculateTotal();

            _ClearSelectedProduct();

            MessageBox.Show("Products Deleted Successfully.", "Deleted", MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void btnSaveOrder_Click(object sender, EventArgs e)
        {
            if (_CustomerID == -1)
            {
                MessageBox.Show("Select A Customer!",
                    "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (GridViewProductsList.Rows.Count == 0)
            {
                MessageBox.Show("Select At Lest One Product!",
                    "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (_OrderID.HasValue)
            {
                //  MessageBox.Show("Has Value");
                OrdersDetailsDetailsBusinessLayer.DeleteOrderDetailsByOrderID(_OrderID);
            }
            else
            {
                _Order1 = new OrdersBusinessLayer();
            }

            try
            {
                _Order1.CustomerID = _CustomerID;
                // _Order1.OrderData = DateTime.Now;
                _Order1.Description = txtDescription.Text.Trim();
                _Order1.UserName = lblUserName.Text.Trim();
                _Order1.Total = Convert.ToDecimal(lblTotal.Text.Trim());
            }

            catch (Exception exception)
            {
                // ignored
                MessageBox.Show("" + exception);
            }

            MessageBox.Show(_Order1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.",
                "", MessageBoxButtons.OK, MessageBoxIcon.Information);

            _OrderID = _Order1.OrderID;
            lblOrderID.Text = Convert.ToString(_OrderID);

            _SaveOrderDetails(_OrderID);

            btnPrintOrder.Enabled = true;

            (Application.OpenForms["OrdersScreen"] as OrdersScreen)?.RefreshData();
        }

        private void _SaveOrderDetails(int? OrderID)
        {
            var OrderDetails1 = new OrdersDetailsDetailsBusinessLayer();

            foreach (DataRow Row in DT.Rows)
            {
                OrderDetails1.ProductID = Convert.ToString(Row[0]);
                OrderDetails1.OrderID = OrderID;
                OrderDetails1.Price = Convert.ToDecimal(Row[2]);
                OrderDetails1.Quantity = Convert.ToInt32(Row[3]);
                OrderDetails1.Discount = Convert.ToDecimal(Row[5]);
                OrderDetails1.TotalAmount = Convert.ToDecimal(Row[6]);

                OrderDetails1.AddNewOrderDetails();
            }
        }
    }
}