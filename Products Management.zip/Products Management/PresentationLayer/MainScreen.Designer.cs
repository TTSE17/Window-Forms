﻿using System.ComponentModel;

namespace PresentationLayer
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restoreDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productsManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.categoriesManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customersManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.addNewSaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.usersManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblUserName = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.fileToolStripMenuItem, this.productsToolStripMenuItem, this.customersToolStripMenuItem, this.usersToolStripMenuItem });
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1827, 49);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.loginToolStripMenuItem, this.backupToolStripMenuItem, this.restoreDataToolStripMenuItem, this.logoutToolStripMenuItem });
            this.fileToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Padding = new System.Windows.Forms.Padding(11, 11, 4, 0);
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(65, 45);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // loginToolStripMenuItem
            // 
            this.loginToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            this.loginToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.loginToolStripMenuItem.Size = new System.Drawing.Size(191, 37);
            this.loginToolStripMenuItem.Text = "Login";
            this.loginToolStripMenuItem.Click += new System.EventHandler(this.loginToolStripMenuItem_Click);
            // 
            // backupToolStripMenuItem
            // 
            this.backupToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.backupToolStripMenuItem.Name = "backupToolStripMenuItem";
            this.backupToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.backupToolStripMenuItem.Size = new System.Drawing.Size(191, 37);
            this.backupToolStripMenuItem.Text = "Backup ";
            this.backupToolStripMenuItem.Click += new System.EventHandler(this.backupToolStripMenuItem_Click);
            // 
            // restoreDataToolStripMenuItem
            // 
            this.restoreDataToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.restoreDataToolStripMenuItem.Name = "restoreDataToolStripMenuItem";
            this.restoreDataToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.restoreDataToolStripMenuItem.Size = new System.Drawing.Size(191, 37);
            this.restoreDataToolStripMenuItem.Text = "Restore Data";
            this.restoreDataToolStripMenuItem.Click += new System.EventHandler(this.restoreDataToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 1, 0, 8);
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(191, 37);
            this.logoutToolStripMenuItem.Text = "Logout ";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // productsToolStripMenuItem
            // 
            this.productsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.productsManagementToolStripMenuItem, this.addNewProductToolStripMenuItem, this.toolStripSeparator1, this.categoriesManagementToolStripMenuItem });
            this.productsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.productsToolStripMenuItem.Name = "productsToolStripMenuItem";
            this.productsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(11, 11, 4, 0);
            this.productsToolStripMenuItem.Size = new System.Drawing.Size(116, 45);
            this.productsToolStripMenuItem.Text = "Products";
            // 
            // productsManagementToolStripMenuItem
            // 
            this.productsManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.productsManagementToolStripMenuItem.Name = "productsManagementToolStripMenuItem";
            this.productsManagementToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.productsManagementToolStripMenuItem.Size = new System.Drawing.Size(292, 37);
            this.productsManagementToolStripMenuItem.Text = "Products Management";
            this.productsManagementToolStripMenuItem.Click += new System.EventHandler(this.productsManagementToolStripMenuItem_Click);
            // 
            // addNewProductToolStripMenuItem
            // 
            this.addNewProductToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.addNewProductToolStripMenuItem.Name = "addNewProductToolStripMenuItem";
            this.addNewProductToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 11, 0, 1);
            this.addNewProductToolStripMenuItem.Size = new System.Drawing.Size(292, 40);
            this.addNewProductToolStripMenuItem.Text = "Add New Product";
            this.addNewProductToolStripMenuItem.Click += new System.EventHandler(this.addNewProductToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(289, 6);
            // 
            // categoriesManagementToolStripMenuItem
            // 
            this.categoriesManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.categoriesManagementToolStripMenuItem.Name = "categoriesManagementToolStripMenuItem";
            this.categoriesManagementToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.categoriesManagementToolStripMenuItem.Size = new System.Drawing.Size(292, 37);
            this.categoriesManagementToolStripMenuItem.Text = "Categories Management";
            this.categoriesManagementToolStripMenuItem.Click += new System.EventHandler(this.categoriesManagementToolStripMenuItem_Click);
            // 
            // customersToolStripMenuItem
            // 
            this.customersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.customersManagementToolStripMenuItem, this.addNewCustomerToolStripMenuItem, this.toolStripSeparator2, this.addNewSaleToolStripMenuItem, this.salesManagementToolStripMenuItem });
            this.customersToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.customersToolStripMenuItem.Name = "customersToolStripMenuItem";
            this.customersToolStripMenuItem.Padding = new System.Windows.Forms.Padding(11, 11, 4, 0);
            this.customersToolStripMenuItem.Size = new System.Drawing.Size(135, 45);
            this.customersToolStripMenuItem.Text = "Customers";
            // 
            // customersManagementToolStripMenuItem
            // 
            this.customersManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.customersManagementToolStripMenuItem.Name = "customersManagementToolStripMenuItem";
            this.customersManagementToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.customersManagementToolStripMenuItem.Size = new System.Drawing.Size(291, 37);
            this.customersManagementToolStripMenuItem.Text = "Customers Management";
            this.customersManagementToolStripMenuItem.Click += new System.EventHandler(this.customersManagementToolStripMenuItem_Click);
            // 
            // addNewCustomerToolStripMenuItem
            // 
            this.addNewCustomerToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.addNewCustomerToolStripMenuItem.Name = "addNewCustomerToolStripMenuItem";
            this.addNewCustomerToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.addNewCustomerToolStripMenuItem.Size = new System.Drawing.Size(291, 37);
            this.addNewCustomerToolStripMenuItem.Text = "Add New Customer";
            this.addNewCustomerToolStripMenuItem.Click += new System.EventHandler(this.addNewCustomerToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(288, 6);
            // 
            // addNewSaleToolStripMenuItem
            // 
            this.addNewSaleToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.addNewSaleToolStripMenuItem.Name = "addNewSaleToolStripMenuItem";
            this.addNewSaleToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.addNewSaleToolStripMenuItem.Size = new System.Drawing.Size(291, 37);
            this.addNewSaleToolStripMenuItem.Text = "Add New Sale";
            this.addNewSaleToolStripMenuItem.Click += new System.EventHandler(this.addNewToolStripMenuItem_Click);
            // 
            // salesManagementToolStripMenuItem
            // 
            this.salesManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.salesManagementToolStripMenuItem.Name = "salesManagementToolStripMenuItem";
            this.salesManagementToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.salesManagementToolStripMenuItem.Size = new System.Drawing.Size(291, 37);
            this.salesManagementToolStripMenuItem.Text = "Sales Management";
            this.salesManagementToolStripMenuItem.Click += new System.EventHandler(this.salesManagementToolStripMenuItem_Click);
            // 
            // usersToolStripMenuItem
            // 
            this.usersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] { this.usersManagementToolStripMenuItem, this.addNewUserToolStripMenuItem });
            this.usersToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.usersToolStripMenuItem.Name = "usersToolStripMenuItem";
            this.usersToolStripMenuItem.Padding = new System.Windows.Forms.Padding(11, 11, 4, 0);
            this.usersToolStripMenuItem.Size = new System.Drawing.Size(85, 45);
            this.usersToolStripMenuItem.Text = "Users";
            // 
            // usersManagementToolStripMenuItem
            // 
            this.usersManagementToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.usersManagementToolStripMenuItem.Name = "usersManagementToolStripMenuItem";
            this.usersManagementToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.usersManagementToolStripMenuItem.Size = new System.Drawing.Size(248, 37);
            this.usersManagementToolStripMenuItem.Text = "Users Management";
            this.usersManagementToolStripMenuItem.Click += new System.EventHandler(this.usersManagementToolStripMenuItem_Click);
            // 
            // addNewUserToolStripMenuItem
            // 
            this.addNewUserToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.addNewUserToolStripMenuItem.Name = "addNewUserToolStripMenuItem";
            this.addNewUserToolStripMenuItem.Padding = new System.Windows.Forms.Padding(0, 8, 0, 1);
            this.addNewUserToolStripMenuItem.Size = new System.Drawing.Size(248, 37);
            this.addNewUserToolStripMenuItem.Text = "Add New User";
            // 
            // lblUserName
            // 
            this.lblUserName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserName.ForeColor = System.Drawing.Color.Crimson;
            this.lblUserName.Location = new System.Drawing.Point(1657, 11);
            this.lblUserName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(133, 28);
            this.lblUserName.TabIndex = 3;
            this.lblUserName.Text = "N/A";
            this.lblUserName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1827, 554);
            this.Controls.Add(this.lblUserName);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Screen";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblUserName;

        private System.Windows.Forms.ToolStripMenuItem salesManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem usersManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewUserToolStripMenuItem;

        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem addNewSaleToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem customersManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewCustomerToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem customersToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem categoriesManagementToolStripMenuItem;

        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;

        private System.Windows.Forms.ToolStripMenuItem productsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productsManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewProductToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreDataToolStripMenuItem;

        private System.Windows.Forms.MenuStrip menuStrip1;

        #endregion
    }
}