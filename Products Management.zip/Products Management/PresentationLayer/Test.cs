﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PresentationLayer
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();
        }

        private void Test_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Visible = comboBox1.SelectedIndex == 1;
            textBox1.Visible = !comboBox2.Visible;

            textBox1.Text = "";
            comboBox2.SelectedIndex = -1;
        }
    }
}