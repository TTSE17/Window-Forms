﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Users
{
    public partial class UsersScreen : Form
    {
        public UsersScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private string _UserID;
        private UsersBusinessLayer _User1;

        private void UsersScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
            textBox1.Focus();
        }

        public void RefreshData()
        {
            _DataTable = UsersBusinessLayer.GetAllUsers();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            btnUpdateUser.Enabled = btnDeleteUser.Enabled = textBox1.Enabled = true;

            textBox1.Text = "";
            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("User Name", typeof(string));
            _DataTable.Columns.Add("Password", typeof(string));
            _DataTable.Columns.Add("Admin", typeof(bool));

            GridViewUsersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewUsersList.Rows.Count > 0)
                GridViewUsersList.Rows.RemoveAt(0);

            btnUpdateUser.Enabled = btnDeleteUser.Enabled = textBox1.Enabled = false;

            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewUsersList.Columns[0].Width = 181;
            GridViewUsersList.Columns[1].Width = 180;
            GridViewUsersList.Columns[2].Width = 162;
            GridViewUsersList.Columns[3].Width = 162;
        }

        private void LoadData(string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                DataFilter = Text == "" ? null : $"UserName LIKE '{Text}%'";

                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                textBox1.Text = Text.Substring(0, Text.Length - 1);

                _DataView1.RowFilter = null;
            }

            GridViewUsersList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewUsersList.Rows.Count);

            // MessageBox.Show(
            //     GridViewUsersList.Columns[0].Width + "_" + GridViewUsersList.Columns[1].Width + "_" + GridViewUsersList
            //         .Columns[2].Width);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Text = textBox1.Text.Trim();

            LoadData(Text);
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            var fr = new AddEditUserScreen();
            fr.ShowDialog();
        }

        private void btnUpdateUser_Click(object sender, EventArgs e)
        {
            var fr = new AddEditUserScreen(Convert.ToString(GridViewUsersList.CurrentRow.Cells[0].Value));
            fr.ShowDialog();
        }

        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            var UserID = (Convert.ToString(GridViewUsersList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to delete [" + UserID + "]", "Confirm Deletion",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (UsersBusinessLayer.Delete(UserID))
            {
                MessageBox.Show("User Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete User, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}