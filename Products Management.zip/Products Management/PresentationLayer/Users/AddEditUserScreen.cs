﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using BusinessLayer;
using PresentationLayer.Properties;

namespace PresentationLayer.Users
{
    public partial class AddEditUserScreen : Form
    {
        private string _UserName;
        private UsersBusinessLayer _User1;

        public AddEditUserScreen(string userName = null)
        {
            InitializeComponent();
            _UserName = userName;

            AutoValidate = AutoValidate.EnableAllowFocusChange;
        }

        private void AddEditUserScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_UserName == null)
            {
                txtUserName.Focus();
                lblTitle.Text = "Add New User";
                Text = "Add New User";
                _User1 = new UsersBusinessLayer();
            }

            else
            {
                _User1 = UsersBusinessLayer.FindUser(_UserName);

                if (_User1 == null) return;

                txtUserName.Text = Convert.ToString(_UserName);
                txtPassword.Text = Convert.ToString(clsGlobal.DecryptText(_User1.Password));
                txtConfirmPassword.Text = txtPassword.Text;
                chAdmin.Checked = _User1.Type;

                lblTitle.Text = "Update User";
                Text = "Update User";

                txtUserName.Enabled = false;
            }
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = (TextBox)sender;

            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
                return;
            }

            errorProvider1.SetError(Temp, null);

            if (Temp.Name == "txtUserName")
            {
                if (_User1.UserName != null) return;

                if (UsersBusinessLayer.ExistUserName(Temp.Text.Trim()))
                {
                    e.Cancel = true;

                    errorProvider1.SetError(Temp, "User Name Already Used !");
                }
                else
                {
                    errorProvider1.SetError(Temp, null);
                }
            }
            
            else if (Temp.Name == "txtPassword" || Temp.Name == "txtConfirmPassword")
            {
                errorProvider1.SetError(txtConfirmPassword,
                    txtPassword.Text != txtConfirmPassword.Text
                        ? txtConfirmPassword.Text == ""
                            ? "This field is required!"
                            : "Must Be The Same Password!"
                        : null);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren() || errorProvider1.GetError(txtConfirmPassword) != "")
            {
                MessageBox.Show("Some fields are Invalid!, Hover over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var userName = txtUserName.Text.Trim();
            var password = txtPassword.Text.Trim();
            var Type = chAdmin.Checked;

            _User1.UserName = userName;
            _User1.Password = clsGlobal.EncryptText(password);
            _User1.Type = Type;

            MessageBox.Show(_User1.Save() ? "Data Saved Successfully." : "Error: Data Was not Saved.");

            txtUserName.Text = _User1.UserName;

            _UserName = _User1.UserName;

            lblTitle.Text = "Update User";

            (Application.OpenForms["UsersScreen"] as UsersScreen)?.RefreshData();

            txtUserName.Enabled = false;
        }
    }
}