﻿using System;
using BusinessLayer;

namespace PresentationLayer
{
    public static class clsGlobal
    {
        public static UsersBusinessLayer CurrentUser = null;

        public static string EncryptText(string Text, int EncryptionKey = 2)
        {
            var CharArray = Text.ToCharArray();
            var len = CharArray.Length;
            for (var i = 0; i < len; i++)
            {
                CharArray[i] = Convert.ToChar(CharArray[i] + EncryptionKey);
            }

            return new string(CharArray);
        }

        public static string DecryptText(string Text, int EncryptionKey = 2)
        {
            var CharArray = Text.ToCharArray();
            var len = CharArray.Length;
            for (var i = 0; i < len; i++)
            {
                CharArray[i] = Convert.ToChar(CharArray[i] - EncryptionKey);
            }

            return new string(CharArray);
        }

        public static bool AllNumber(string Number)
        {
            var len = Number.Length;

            for (var i = 0; i < len; i++)
                if (!(char.IsNumber(Number[i])))
                    return false;

            return true;
        }

        public static bool AllLetter(string Name)
        {
            var len = Name.Length;

            for (var i = 0; i < len; i++)
                if (!(char.IsLetter(Name[i])))
                    return false;

            return true;
        }
    }
}