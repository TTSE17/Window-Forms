﻿using System;
using System.Windows.Forms;
using PresentationLayer.Categories;
using PresentationLayer.Customers;
using PresentationLayer.Orders;
using PresentationLayer.Products;
using PresentationLayer.Users;

namespace PresentationLayer
{
    public partial class MainScreen : Form
    {
        public MainScreen()
        {
            InitializeComponent();
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {
            _EnableItems(false);
        }

        private void _EnableItems(bool Status)
        {
            ToolStripMenuItem[] ItemsList =
            {
                backupToolStripMenuItem, restoreDataToolStripMenuItem, logoutToolStripMenuItem,
                productsToolStripMenuItem, customersToolStripMenuItem, usersToolStripMenuItem
            };

            foreach (var Item in ItemsList)
            {
                Item.Enabled = Status;
            }
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new LoginScreen();

            fr.ShowDialog();

            if (clsGlobal.CurrentUser == null) return;

            _EnableItems(true);

            addNewUserToolStripMenuItem.Enabled = usersManagementToolStripMenuItem.Enabled = clsGlobal.CurrentUser.Type;

            loginToolStripMenuItem.Enabled = false;

            lblUserName.Text = clsGlobal.CurrentUser.UserName;
        }

        private void backupToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new BackupScreen();
            fr.ShowDialog();
        }

        private void restoreDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new RestoreScreen();
            fr.ShowDialog();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clsGlobal.CurrentUser = null;

            _EnableItems(false);
            loginToolStripMenuItem.Enabled = true;
            lblUserName.Text = "N/A";
        }

        private void productsManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new ProductsScreen();
            fr.ShowDialog();
        }

        private void addNewProductToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddEditProduct();
            fr.ShowDialog();
        }

        private void categoriesManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new CategoriesScreen();
            fr.ShowDialog();
        }

        private void customersManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new CustomersScreen();
            fr.ShowDialog();
        }

        private void addNewCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddEditCustomerScreen();
            fr.ShowDialog();
        }

        private void addNewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddEditOrderScreen();
            fr.ShowDialog();
        }

        private void salesManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new OrdersScreen();
            fr.ShowDialog();
        }

        private void usersManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddEditUserScreen();
            fr.ShowDialog();
        }
    }
}