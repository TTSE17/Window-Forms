﻿using System.ComponentModel;

namespace PresentationLayer.Categories
{
    partial class CategoriesScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.GridViewCategoriesList = new System.Windows.Forms.DataGridView();
            this.lblRecords = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnNewProduct = new System.Windows.Forms.Button();
            this.btnPrintCategories = new System.Windows.Forms.Button();
            this.btnSaveAsPDF = new System.Windows.Forms.Button();
            this.btnPrintCategory = new System.Windows.Forms.Button();
            this.btnUpdateCategory = new System.Windows.Forms.Button();
            this.btnDeleteCategory = new System.Windows.Forms.Button();
            this.btnCategoryProducts = new System.Windows.Forms.Button();
            this.btnAddCategory = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnTheLast = new System.Windows.Forms.Button();
            this.btnTheFirst = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.lblCounter = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lblCategoryID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewCategoriesList)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkRed;
            this.panel2.Location = new System.Drawing.Point(15, 37);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(305, 2);
            this.panel2.TabIndex = 125;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.GridViewCategoriesList);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox1.Location = new System.Drawing.Point(12, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(338, 304);
            this.groupBox1.TabIndex = 124;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Categories List ";
            // 
            // GridViewCategoriesList
            // 
            this.GridViewCategoriesList.AllowUserToAddRows = false;
            this.GridViewCategoriesList.AllowUserToDeleteRows = false;
            this.GridViewCategoriesList.AllowUserToResizeColumns = false;
            this.GridViewCategoriesList.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.GridViewCategoriesList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.GridViewCategoriesList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewCategoriesList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.GridViewCategoriesList.BackgroundColor = System.Drawing.Color.White;
            this.GridViewCategoriesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridViewCategoriesList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewCategoriesList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridViewCategoriesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewCategoriesList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.GridViewCategoriesList.GridColor = System.Drawing.Color.Crimson;
            this.GridViewCategoriesList.Location = new System.Drawing.Point(3, 34);
            this.GridViewCategoriesList.Margin = new System.Windows.Forms.Padding(0);
            this.GridViewCategoriesList.MultiSelect = false;
            this.GridViewCategoriesList.Name = "GridViewCategoriesList";
            this.GridViewCategoriesList.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewCategoriesList.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.GridViewCategoriesList.RowHeadersVisible = false;
            this.GridViewCategoriesList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.GridViewCategoriesList.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.GridViewCategoriesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridViewCategoriesList.Size = new System.Drawing.Size(331, 258);
            this.GridViewCategoriesList.TabIndex = 110;
            this.GridViewCategoriesList.SelectionChanged += new System.EventHandler(this.GridViewCategoriesList_SelectionChanged);
            // 
            // lblRecords
            // 
            this.lblRecords.AutoSize = true;
            this.lblRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecords.Location = new System.Drawing.Point(688, 14);
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(20, 22);
            this.lblRecords.TabIndex = 123;
            this.lblRecords.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(545, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 22);
            this.label1.TabIndex = 122;
            this.label1.Text = "Total Products :";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(15, 14);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(305, 20);
            this.textBox1.TabIndex = 121;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnNewProduct);
            this.groupBox2.Controls.Add(this.btnPrintCategories);
            this.groupBox2.Controls.Add(this.btnSaveAsPDF);
            this.groupBox2.Controls.Add(this.btnPrintCategory);
            this.groupBox2.Controls.Add(this.btnUpdateCategory);
            this.groupBox2.Controls.Add(this.btnDeleteCategory);
            this.groupBox2.Controls.Add(this.btnCategoryProducts);
            this.groupBox2.Controls.Add(this.btnAddCategory);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox2.Location = new System.Drawing.Point(12, 381);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(696, 139);
            this.groupBox2.TabIndex = 126;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "The Operations ";
            // 
            // btnNewProduct
            // 
            this.btnNewProduct.AutoSize = true;
            this.btnNewProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNewProduct.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNewProduct.ForeColor = System.Drawing.Color.Black;
            this.btnNewProduct.Location = new System.Drawing.Point(36, 36);
            this.btnNewProduct.Name = "btnNewProduct";
            this.btnNewProduct.Size = new System.Drawing.Size(128, 34);
            this.btnNewProduct.TabIndex = 131;
            this.btnNewProduct.Text = "New Category";
            this.btnNewProduct.UseVisualStyleBackColor = true;
            this.btnNewProduct.Click += new System.EventHandler(this.btnNewProduct_Click);
            // 
            // btnPrintCategories
            // 
            this.btnPrintCategories.AutoSize = true;
            this.btnPrintCategories.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrintCategories.Enabled = false;
            this.btnPrintCategories.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintCategories.ForeColor = System.Drawing.Color.Black;
            this.btnPrintCategories.Location = new System.Drawing.Point(345, 88);
            this.btnPrintCategories.Name = "btnPrintCategories";
            this.btnPrintCategories.Size = new System.Drawing.Size(149, 34);
            this.btnPrintCategories.TabIndex = 130;
            this.btnPrintCategories.Text = "Print Categories";
            this.btnPrintCategories.UseVisualStyleBackColor = true;
            // 
            // btnSaveAsPDF
            // 
            this.btnSaveAsPDF.AutoSize = true;
            this.btnSaveAsPDF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaveAsPDF.Enabled = false;
            this.btnSaveAsPDF.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnSaveAsPDF.ForeColor = System.Drawing.Color.Black;
            this.btnSaveAsPDF.Location = new System.Drawing.Point(536, 88);
            this.btnSaveAsPDF.Name = "btnSaveAsPDF";
            this.btnSaveAsPDF.Size = new System.Drawing.Size(143, 34);
            this.btnSaveAsPDF.TabIndex = 129;
            this.btnSaveAsPDF.Text = "Save As PDF";
            this.btnSaveAsPDF.UseVisualStyleBackColor = true;
            // 
            // btnPrintCategory
            // 
            this.btnPrintCategory.AutoSize = true;
            this.btnPrintCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrintCategory.Enabled = false;
            this.btnPrintCategory.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnPrintCategory.ForeColor = System.Drawing.Color.Black;
            this.btnPrintCategory.Location = new System.Drawing.Point(197, 88);
            this.btnPrintCategory.Name = "btnPrintCategory";
            this.btnPrintCategory.Size = new System.Drawing.Size(128, 34);
            this.btnPrintCategory.TabIndex = 127;
            this.btnPrintCategory.Text = "Print Category";
            this.btnPrintCategory.UseVisualStyleBackColor = true;
            // 
            // btnUpdateCategory
            // 
            this.btnUpdateCategory.AutoSize = true;
            this.btnUpdateCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdateCategory.Enabled = false;
            this.btnUpdateCategory.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnUpdateCategory.ForeColor = System.Drawing.Color.Black;
            this.btnUpdateCategory.Location = new System.Drawing.Point(342, 36);
            this.btnUpdateCategory.Name = "btnUpdateCategory";
            this.btnUpdateCategory.Size = new System.Drawing.Size(149, 34);
            this.btnUpdateCategory.TabIndex = 126;
            this.btnUpdateCategory.Text = "Update Category";
            this.btnUpdateCategory.UseVisualStyleBackColor = true;
            this.btnUpdateCategory.Click += new System.EventHandler(this.btnUpdateCategory_Click);
            // 
            // btnDeleteCategory
            // 
            this.btnDeleteCategory.AutoSize = true;
            this.btnDeleteCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDeleteCategory.Enabled = false;
            this.btnDeleteCategory.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnDeleteCategory.ForeColor = System.Drawing.Color.Black;
            this.btnDeleteCategory.Location = new System.Drawing.Point(536, 36);
            this.btnDeleteCategory.Name = "btnDeleteCategory";
            this.btnDeleteCategory.Size = new System.Drawing.Size(143, 34);
            this.btnDeleteCategory.TabIndex = 125;
            this.btnDeleteCategory.Text = "Delete Category";
            this.btnDeleteCategory.UseVisualStyleBackColor = true;
            this.btnDeleteCategory.Click += new System.EventHandler(this.btnDeleteCategory_Click);
            // 
            // btnCategoryProducts
            // 
            this.btnCategoryProducts.AutoSize = true;
            this.btnCategoryProducts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCategoryProducts.Enabled = false;
            this.btnCategoryProducts.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCategoryProducts.ForeColor = System.Drawing.Color.Black;
            this.btnCategoryProducts.Location = new System.Drawing.Point(25, 88);
            this.btnCategoryProducts.Name = "btnCategoryProducts";
            this.btnCategoryProducts.Size = new System.Drawing.Size(157, 34);
            this.btnCategoryProducts.TabIndex = 124;
            this.btnCategoryProducts.Text = "Category\'s Products";
            this.btnCategoryProducts.UseVisualStyleBackColor = true;
            // 
            // btnAddCategory
            // 
            this.btnAddCategory.AutoSize = true;
            this.btnAddCategory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCategory.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnAddCategory.ForeColor = System.Drawing.Color.Black;
            this.btnAddCategory.Location = new System.Drawing.Point(202, 36);
            this.btnAddCategory.Name = "btnAddCategory";
            this.btnAddCategory.Size = new System.Drawing.Size(123, 34);
            this.btnAddCategory.TabIndex = 121;
            this.btnAddCategory.Text = "Add Category";
            this.btnAddCategory.UseVisualStyleBackColor = true;
            this.btnAddCategory.Click += new System.EventHandler(this.btnAddCategory_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnTheLast);
            this.groupBox3.Controls.Add(this.btnTheFirst);
            this.groupBox3.Controls.Add(this.txtDescription);
            this.groupBox3.Controls.Add(this.lblCounter);
            this.groupBox3.Controls.Add(this.btnNext);
            this.groupBox3.Controls.Add(this.btnPrevious);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.lblCategoryID);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox3.Location = new System.Drawing.Point(383, 55);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(325, 304);
            this.groupBox3.TabIndex = 127;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Category";
            // 
            // btnTheLast
            // 
            this.btnTheLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTheLast.Image = global::PresentationLayer.Properties.Resources.next;
            this.btnTheLast.Location = new System.Drawing.Point(268, 268);
            this.btnTheLast.Name = "btnTheLast";
            this.btnTheLast.Size = new System.Drawing.Size(51, 23);
            this.btnTheLast.TabIndex = 0;
            this.btnTheLast.Click += new System.EventHandler(this.btnTheLast_Click);
            // 
            // btnTheFirst
            // 
            this.btnTheFirst.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTheFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTheFirst.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnTheFirst.Image = global::PresentationLayer.Properties.Resources.previous;
            this.btnTheFirst.Location = new System.Drawing.Point(21, 269);
            this.btnTheFirst.Name = "btnTheFirst";
            this.btnTheFirst.Size = new System.Drawing.Size(51, 23);
            this.btnTheFirst.TabIndex = 10;
            this.btnTheFirst.UseVisualStyleBackColor = true;
            this.btnTheFirst.Click += new System.EventHandler(this.btnTheFirst_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(21, 127);
            this.txtDescription.Multiline = true;
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(298, 127);
            this.txtDescription.TabIndex = 9;
            // 
            // lblCounter
            // 
            this.lblCounter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCounter.ForeColor = System.Drawing.Color.Black;
            this.lblCounter.Location = new System.Drawing.Point(135, 269);
            this.lblCounter.Name = "lblCounter";
            this.lblCounter.Size = new System.Drawing.Size(70, 23);
            this.lblCounter.TabIndex = 8;
            this.lblCounter.Text = "99/99";
            this.lblCounter.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNext
            // 
            this.btnNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnNext.Image = global::PresentationLayer.Properties.Resources.play;
            this.btnNext.Location = new System.Drawing.Point(211, 269);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(51, 23);
            this.btnNext.TabIndex = 6;
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrevious.ForeColor = System.Drawing.Color.MediumBlue;
            this.btnPrevious.Image = global::PresentationLayer.Properties.Resources.play_2;
            this.btnPrevious.Location = new System.Drawing.Point(78, 269);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(51, 23);
            this.btnPrevious.TabIndex = 5;
            this.btnPrevious.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(21, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Description :";
            // 
            // lblCategoryID
            // 
            this.lblCategoryID.AutoSize = true;
            this.lblCategoryID.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCategoryID.ForeColor = System.Drawing.Color.Black;
            this.lblCategoryID.Location = new System.Drawing.Point(137, 34);
            this.lblCategoryID.Name = "lblCategoryID";
            this.lblCategoryID.Size = new System.Drawing.Size(40, 22);
            this.lblCategoryID.TabIndex = 1;
            this.lblCategoryID.Text = "N/A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(16, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Category ID :";
            // 
            // CategoriesScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(723, 543);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblRecords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CategoriesScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Categories Management";
            this.Load += new System.EventHandler(this.CategoriesScreen_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridViewCategoriesList)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Button btnNewProduct;

        private System.Windows.Forms.Button btnTheFirst;
        private System.Windows.Forms.Button btnTheLast;

        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Label lblCounter;
        

        private System.Windows.Forms.Label lblCategoryID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDescription;

        private System.Windows.Forms.Label label2;

        private System.Windows.Forms.GroupBox groupBox3;

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnPrintCategories;
        private System.Windows.Forms.Button btnSaveAsPDF;
        private System.Windows.Forms.Button btnPrintCategory;
        private System.Windows.Forms.Button btnUpdateCategory;
        private System.Windows.Forms.Button btnDeleteCategory;
        private System.Windows.Forms.Button btnCategoryProducts;
        private System.Windows.Forms.Button btnAddCategory;

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView GridViewCategoriesList;
        private System.Windows.Forms.Label lblRecords;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;

        #endregion
    }
}