﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer.Categories
{
    public partial class CategoriesScreen : Form
    {
        public CategoriesScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _CategoryID;
        private CategoriesBusinessLayer _Category1;

        private void CategoriesScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = CategoriesBusinessLayer.LoadCategoriesList();

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            btnDeleteCategory.Enabled = btnUpdateCategory.Enabled = btnCategoryProducts.Enabled =
                btnPrintCategory.Enabled = btnPrintCategories.Enabled = btnSaveAsPDF.Enabled = textBox1.Enabled = true;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("Category ID", typeof(int));
            _DataTable.Columns.Add("Description", typeof(string));
            GridViewCategoriesList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewCategoriesList.Rows.Count > 0)
                GridViewCategoriesList.Rows.RemoveAt(0);

            btnDeleteCategory.Enabled = btnUpdateCategory.Enabled = btnCategoryProducts.Enabled =
                btnPrintCategory.Enabled = btnPrintCategories.Enabled = btnSaveAsPDF.Enabled = textBox1.Enabled = false;

            lblRecords.Text = "0";
        }

        private void _SetWidthColumns()
        {
            GridViewCategoriesList.Columns[0].Width = 11;
            GridViewCategoriesList.Columns[1].Width = 211;
        }

        private void LoadData(string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            string DataFilter;

            try
            {
                DataFilter = Text == "" ? null : $" Type LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This Field accepts numbers only", "unacceptable key",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewCategoriesList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewCategoriesList.Rows.Count);

            // GridViewCategoriesList.Columns[0].Visible = false;

            _CheckCurrentRow();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Text = textBox1.Text.Trim();

            LoadData(Text);
        }

        private void GridViewCategoriesList_SelectionChanged(object sender, EventArgs e)
        {
            if (GridViewCategoriesList.CurrentRow == null || !GridViewCategoriesList.CurrentRow.Selected) return;
            _CheckCurrentRow();

            // MessageBox.Show(new StackFrame(1, true).GetMethod().Name);
        }

        private void _CheckCurrentRow()
        {
            btnAddCategory.Enabled = false;
            btnNewProduct.Enabled = true;

            if (GridViewCategoriesList.Rows.Count == 0)
            {
                _Clear(false);

                lblCounter.Text = "0/0";
                lblCategoryID.Text = txtDescription.Text = "";
                
                return;
            }

            _Clear(true);

            var Index = GridViewCategoriesList.CurrentRow.Index;

            _LoadCategoryInfo();

            lblCounter.Text = (Index + 1) + "/" + GridViewCategoriesList.Rows.Count;

            btnTheFirst.Enabled = btnPrevious.Enabled = btnNext.Enabled = btnTheLast.Enabled = true;

            if (Index == 0)
            {
                btnTheFirst.Enabled = btnPrevious.Enabled = false;
            }

            if (Index == GridViewCategoriesList.Rows.Count - 1)
            {
                btnTheLast.Enabled = btnNext.Enabled = false;
            }
        }

        private void _ChangeCurrentRow(int NewIndex)
        {
            GridViewCategoriesList.CurrentCell = GridViewCategoriesList.Rows[NewIndex].Cells[0];

            _CheckCurrentRow();
        }

        private void _Clear(bool status)
        {
            btnTheFirst.Enabled = btnPrevious.Enabled = btnNext.Enabled = btnTheLast.Enabled =
                btnDeleteCategory.Enabled = btnUpdateCategory.Enabled = btnCategoryProducts.Enabled =
                    btnPrintCategory.Enabled = btnPrintCategories.Enabled = btnSaveAsPDF.Enabled = status;
        }

        private void _LoadCategoryInfo()
        {
            var CurrentRow = GridViewCategoriesList.CurrentRow;

            lblCategoryID.Text = Convert.ToString(CurrentRow.Cells[0].Value);
            txtDescription.Text = Convert.ToString(CurrentRow.Cells[1].Value);
        }

        private void btnTheLast_Click(object sender, EventArgs e)
        {
            var NewIndex = GridViewCategoriesList.Rows.Count - 1;
            _ChangeCurrentRow(NewIndex);
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            var NewIndex = GridViewCategoriesList.CurrentRow.Index + 1;
            _ChangeCurrentRow(NewIndex);
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            var NewIndex = GridViewCategoriesList.CurrentRow.Index - 1;
            _ChangeCurrentRow(NewIndex);
        }

        private void btnTheFirst_Click(object sender, EventArgs e)
        {
            _ChangeCurrentRow(0);
        }

        private void btnNewProduct_Click(object sender, EventArgs e)
        {
            _Clear(false);

            lblCategoryID.Text = lblCounter.Text = "N/A";
            txtDescription.Text = "";
            txtDescription.Focus();

            GridViewCategoriesList.CurrentRow.Selected = false;

            btnAddCategory.Enabled = true;
            btnNewProduct.Enabled = false;
        }

        private void btnAddCategory_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDescription.Text.Trim()))
            {
                MessageBox.Show("The Field Is Empty!");
                return;
            }

            var ID = CategoriesBusinessLayer.AddCategory(txtDescription.Text.Trim());

            MessageBox.Show($"Added Successfully,ID : {ID}", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
            RefreshData();
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            UpdateCategoryInfo(Convert.ToInt32(GridViewCategoriesList.CurrentRow.Cells[0].Value));

            if (string.IsNullOrWhiteSpace(txtDescription.Text.Trim()))
            {
                MessageBox.Show("The Field Is Empty!");
                return;
            }

            MessageBox.Show(
                CategoriesBusinessLayer.UpdateCategory(_CategoryID, txtDescription.Text.Trim())
                    ? "Data Saved Successfully."
                    : "Error: Data Is not Saved Successfully; Cannot insert duplicate Value in 'Categories",
                "", MessageBoxButtons.OK, MessageBoxIcon.Information);

            RefreshData();
        }

        private void btnDeleteCategory_Click(object sender, EventArgs e)
        {
            UpdateCategoryInfo(Convert.ToInt32(GridViewCategoriesList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show(
                    "Are you sure you want to delete [" + _CategoryID +
                    "] \n\nNote : All products belonging to this category will be deleted!", "Confirm Deletion",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (CategoriesBusinessLayer.DeleteCategory(_CategoryID))
            {
                MessageBox.Show("Category Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Category, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateCategoryInfo(int ID)
        {
            _CategoryID = ID;
            _Category1 = CategoriesBusinessLayer.FindCategory(_CategoryID);
        }
    }
}