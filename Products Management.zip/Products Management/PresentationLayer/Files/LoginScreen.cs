﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private static bool _ValidateInputs(string UserName, string Password)
        {
            return string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var UserName = txtUserName.Text.Trim();
            var Password = txtPassword.Text.Trim();

            if (_ValidateInputs(UserName, Password))
            {
                MessageBox.Show("Enter Username, Password !");
                return;
            }

            if (UsersBusinessLayer.IsFound(UserName, clsGlobal.EncryptText(Password)))
            {
                var User1 = UsersBusinessLayer.FindUser(UserName);

                clsGlobal.CurrentUser = User1;

                Close();
            }

            else
            {
                txtUserName.Focus();

                MessageBox.Show("Invalid Username/Password.", "Wrong Credintials",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}