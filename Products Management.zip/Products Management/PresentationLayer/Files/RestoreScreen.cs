﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer
{
    public partial class RestoreScreen : Form
    {
        public RestoreScreen()
        {
            InitializeComponent();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Database Files|*.bak;";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                lblPath.Text = openFileDialog1.FileName;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var path = lblPath.Text.Trim();

            // Cursor = new Cursor(Cursor.Handle);

//            BackupBusinessLayer.RestoreData(path);

            Cursor = default;

            MessageBox.Show("Backup Saved Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}