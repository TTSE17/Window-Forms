﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace PresentationLayer
{
    public partial class BackupScreen : Form
    {
        public BackupScreen()
        {
            InitializeComponent();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                lblPath.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var path = lblPath.Text.Trim() + "\\ProductsManagement_DB" +
                       DateTime.Now.ToString("yyyy_MM_dd hh_mm_ss") + ".bak";

            // Cursor = new Cursor(Cursor.Handle);
            
            BackupBusinessLayer.StoreBackUp(path);
            
            Cursor = default;

            MessageBox.Show("Backup Saved Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}