﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class CustomersDataAccessLayer
    {
        public static DataTable GetAllCustomers()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
                {
                    string Query = @"Select 'Customer ID' = Customers.CustomerID , FirstName,
						                    LastName,Phone ,
						                    'Orders'=(Select Count(1) From Orders Where Customers.CustomerID=Orders.CustomerID)
                                            ,Email From Customers;";

                    using (SqlCommand command = new SqlCommand(Query, connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                dt.Load(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return dt;
        }

        public static bool GetCustomerByCustomerID(int? CustomerID, ref string firstName, ref string lastName,
            ref string phone, ref string email, ref byte[] pathImage)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * From Customers Where CustomerID=@CustomerID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@CustomerID", CustomerID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    firstName = Convert.ToString(reader[1]);
                    lastName = Convert.ToString(reader[2]);
                    phone = Convert.ToString(reader[3]);
                    email = Convert.ToString(reader[4]);
                    pathImage = reader[5] != DBNull.Value ? (byte[])reader[5] : null;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewCustomer(string firstName, string lastName,
            string phone, string email, byte[] pathImage)
        {
            int Id = -1;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Customers
                             VALUES (@firstName,@lastName,@phone,@email,@pathImage);
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@email", email);


            if (pathImage != null)
                command.Parameters.AddWithValue("@pathImage", pathImage);
            else
            {
                var imageParameter = new SqlParameter("@pathImage", SqlDbType.Image)
                {
                    Value = DBNull.Value
                };
                command.Parameters.Add(imageParameter);
            }

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                Id = -1;
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateCustomer(int? CustomerID, string firstName, string lastName,
            string phone, string email, byte[] pathImage)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Customers
                            set firstName=@firstName,lastName=@lastName,phone=@phone,
                                email=@email,pathImage=@pathImage
                            where CustomerID = @CustomerID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@CustomerID", CustomerID);
            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@email", email);

            if (pathImage != null)
                command.Parameters.AddWithValue("@pathImage", pathImage);
            else
            {
                // command.Parameters.AddWithValue("@pathImage", DBNull.Value);

                var imageParameter = new SqlParameter("@pathImage", SqlDbType.Image)
                {
                    Value = DBNull.Value
                };
                command.Parameters.Add(imageParameter);
            }


            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteCustomer(int? CustomerID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @" Delete From Customers Where CustomerID =@CustomerID ;";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@CustomerID", CustomerID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool ExistCustomerID(string CustomerID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Select Found='1' From Customers
                             Where CustomerID = @CustomerID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@CustomerID", CustomerID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = reader.HasRows;
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isFound = false;
            }

            finally
            {
                connection.Close();
            }

            return isFound;
        }
    }
}