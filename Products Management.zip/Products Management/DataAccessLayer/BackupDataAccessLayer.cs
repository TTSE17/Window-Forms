﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class BackupDataAccessLayer
    {
        public static bool StoreBackUp(string path)
        {
            bool isAdded;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = $@"Backup Database ProductsManagement To Disk ='{path}'";

            SqlCommand command = new SqlCommand(query, connection);

            // command.Parameters.AddWithValue("@path", path);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                isAdded = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                isAdded = false;
            }
            finally
            {
                connection.Close();
            }

            return isAdded;
        }

        public static bool RestoreData(string path)
        {
            bool isAdded;

            // string ConnectionString = "Server=.;Database=ProductsManagement;Integrated Security=True";
            string ConnectionString = "Server=.;Database=ProductsManagement;User Id=sa;Password=sa123456;";

            SqlConnection connection = new SqlConnection(ConnectionString);

            string query = $@"USE [master]
                             Restore Database ProductsManagement2 From Disk ='{path}'";

            SqlCommand command = new SqlCommand(query, connection);

            // command.Parameters.AddWithValue("@path", path);
            try

            {
                connection.Open();
                command.ExecuteNonQuery();
                isAdded = true;
            }
            catch
                (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                isAdded = false;
            }
            finally
            {
                connection.Close();
            }

            return isAdded;
        }
    }
}