﻿using System;
using System.Data;
using System.Data.SqlClient;


namespace DataAccessLayer
{
    public class clsDataAccessSettings
    {
        public const string ConnectionString = "Server=.;Database=ProductsManagement;User Id= ;Password= ;";

        // public static readonly SqlConnection ConnectionString =
        //     new SqlConnection("Server=.;Database=ProductsManagement;User Id= ;Password= ;");
        //
        //
        // public void Open()
        // {
        //     if (connection.State != ConnectionState.Open)
        //     {
        //         connection.Open();
        //     }
        // }
        //
        // public void Close()
        // {
        //     if (connection.State == ConnectionState.Open)
        //     {
        //         connection.Close();
        //     }
        // }
    }
}