﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class ProductsDataAccessLayer
    {
        public static DataTable GetAllProducts()
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString))
                {
                    string Query = @"Select 'Product ID' = ProductID , Description = ProductLabel ,
                                      Category =(Select CategoryDescription From Categories Where Categories.CategoryID=Products.CategoryID),
		                              Quantity , Price ,
                                      Selected = (Select Count(1) From OrdersDetails Where OrdersDetails.ProductID=Products.ProductID)
                                    From Products;";

                    using (SqlCommand command = new SqlCommand(Query, connection))
                    {
                        connection.Open();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                dt.Load(reader);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }

            return dt;
        }

        public static bool GetProductByProductID(string productID, ref string productLabel, ref int quantity,
            ref decimal price, ref byte[] pathImage, ref int categoryID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * From Products Where productID=@productID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@productID", productID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    productLabel = Convert.ToString(reader[1]);
                    quantity = Convert.ToInt32(reader[2]);
                    price = Convert.ToDecimal(reader[3]);
                    pathImage = reader[4] != DBNull.Value ? (byte[])reader[4] : null;
                    categoryID = Convert.ToInt32(reader[5]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool AddNewProduct(string ProductID, string productLabel, int quantity,
            decimal price, byte[] pathImage, int categoryID)
        {
            bool isAdded;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Products
                             VALUES (@ProductID,@productLabel,@quantity,@price,@pathImage,@categoryID);";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@ProductID", ProductID);
            command.Parameters.AddWithValue("@productLabel", productLabel);
            command.Parameters.AddWithValue("@quantity", quantity);
            command.Parameters.AddWithValue("@price", price);
            if (pathImage != null)
                command.Parameters.AddWithValue("@pathImage", pathImage);
            else
            {
                // command.Parameters.AddWithValue("@pathImage", DBNull.Value);

                var imageParameter = new SqlParameter("@pathImage", SqlDbType.Image)
                {
                    Value = DBNull.Value
                };
                command.Parameters.Add(imageParameter);
            }

            command.Parameters.AddWithValue("@categoryID", categoryID);
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                isAdded = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                isAdded = false;
            }
            finally
            {
                connection.Close();
            }

            return isAdded;
        }

        public static bool UpdateProduct(string ProductID, string productLabel, int quantity,
            decimal price, byte[] pathImage, int categoryID)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Products
                            set productLabel=@productLabel,quantity=@quantity,price=@price,
                                pathImage=@pathImage,categoryID=@categoryID
                            where ProductID = @ProductID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@ProductID", ProductID);
            command.Parameters.AddWithValue("@productLabel", productLabel);
            command.Parameters.AddWithValue("@quantity", quantity);
            command.Parameters.AddWithValue("@price", price);

            if (pathImage != null)
                command.Parameters.AddWithValue("@pathImage", pathImage);
            else
            {
                // command.Parameters.AddWithValue("@pathImage", DBNull.Value);

                var imageParameter = new SqlParameter("@pathImage", SqlDbType.Image)
                {
                    Value = DBNull.Value
                };
                command.Parameters.Add(imageParameter);
            }

            command.Parameters.AddWithValue("@categoryID", categoryID);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteProduct(string ProductID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @" Delete From Products Where ProductID =@ProductID ;";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ProductID", ProductID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool ExistProductID(string ProductID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Select Found='1' From Products
                             Where ProductID = @ProductID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@ProductID", ProductID);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = reader.HasRows;
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isFound = false;
            }

            finally
            {
                connection.Close();
            }

            return isFound;
        }
    }
}