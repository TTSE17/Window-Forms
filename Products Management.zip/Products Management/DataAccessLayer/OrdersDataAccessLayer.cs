﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class OrdersDataAccessLayer
    {
        public static DataTable GetAllOrders(int? CustomerID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select 'Order ID'=OrderID , 'Customer Name'=FirstName+' '+LastName,
                               UserName,Total , OrderData ,
                               'Products'=(Select Count(1) From OrdersDetails Where Orders.OrderID=OrdersDetails.OrderID)
                              From Orders
                              Inner Join Customers on Customers.CustomerID =Orders.CustomerID
                               where Orders.CustomerID  = isnull(@CustomerID,Orders.CustomerID)";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@CustomerID", CustomerID.HasValue ? CustomerID : DBNull.Value);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static int AddNewOrder(int? customerID, decimal total, DateTime orderData,
            string description, string userName)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Orders
                             VALUES (@customerID,@total,GETDATE(),@description,@userName);
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@customerID", customerID);
            command.Parameters.AddWithValue("@total", total);
            // command.Parameters.AddWithValue("@orderData", orderData);
            command.Parameters.AddWithValue("@description", description);
            command.Parameters.AddWithValue("@userName", userName);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateOrder(int? OrderID, int? customerID, decimal total, DateTime orderData,
            string description, string userName)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Orders
                            set customerID=@customerID,total=@Total,orderData=GETDATE(),
                                description=@description,userName=@userName
                            where OrderID = @OrderID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@OrderID", OrderID);
            command.Parameters.AddWithValue("@customerID", customerID);
            command.Parameters.AddWithValue("@Total", total);
            // command.Parameters.AddWithValue("@orderData", orderData);
            command.Parameters.AddWithValue("@description", description);
            command.Parameters.AddWithValue("@userName", userName);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool GetOrderByID(int? orderID, ref int customerID, ref decimal total, ref DateTime orderDate,
            ref string description, ref string userName)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * From Orders Where orderID=@orderID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@orderID", orderID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    customerID = Convert.ToInt32(reader[1]);
                    total = Convert.ToDecimal(reader[2]);
                    orderDate = Convert.ToDateTime(reader[3]);
                    description = Convert.ToString(reader[4]);
                    userName = Convert.ToString(reader[5]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool DeleteOrder(int OrderID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @" Delete From Orders Where OrderID =@OrderID ;";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@OrderID", OrderID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }


        public static bool GetOrderByDescription(ref int OrderID, string OrderDescription)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Orders Where OrderDescription=@OrderDescription";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@OrderDescription", OrderDescription);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = true;
                    OrderID = Convert.ToInt32(reader[1]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}