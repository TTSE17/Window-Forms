﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class OrdersDetailsDataAccessLayer
    {
        public static DataTable GetAllOrderDetails(int? OrderID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * From OrdersDetails Where OrderID=@orderId";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@orderId", OrderID);
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool AddNewOrderDetails(string productId, int? orderId, int quantity, decimal price,
            decimal discount, decimal totalAmount)
        {
            var isAdded = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO OrdersDetails
                             VALUES (@productId,@orderId,@quantity,@price,@discount,@totalAmount);

                             Update Products Set quantity= quantity - @quantity
                              Where ProductID=@productID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@productId", productId);
            command.Parameters.AddWithValue("@orderId", orderId);
            command.Parameters.AddWithValue("@quantity", quantity);
            command.Parameters.AddWithValue("@price", price);
            command.Parameters.AddWithValue("@discount", discount);
            command.Parameters.AddWithValue("@totalAmount", totalAmount);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();
                isAdded = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                isAdded = false;
            }
            finally
            {
                connection.Close();
            }

            return isAdded;
        }

        public static bool DeleteOrderDetailsByOrderID(int? OrderID)
        {
            bool isDeleted;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Update Products
                                Set Products.quantity = Products.quantity + (OrdersDetails.Quantity) From Products
		                         Inner Join OrdersDetails ON OrdersDetails.ProductID = Products.ProductID
	                                 Where OrderID=@OrderID ;
                                                    
                             Delete From OrdersDetails Where OrderID =@OrderID ;";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@OrderID", OrderID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}