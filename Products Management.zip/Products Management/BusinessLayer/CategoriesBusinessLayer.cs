﻿using System.Data;
using CDA = DataAccessLayer.CategoriesDataAccessLayer;

namespace BusinessLayer
{
    public class CategoriesBusinessLayer
    {
        public int CategoryID { get; set; }
        public string CategoryDescription { get; set; }

        public CategoriesBusinessLayer()
        {
            CategoryID = -1;
        }

        private CategoriesBusinessLayer(int categoryId, string categoryDescription)
        {
            CategoryID = categoryId;
            CategoryDescription = categoryDescription;
        }

        public static CategoriesBusinessLayer FindCategory(int categoryID)
        {
            var categoryDescription = "";

            if (CDA.GetCategoryByID(categoryID, ref categoryDescription))
                return new CategoriesBusinessLayer(categoryID, categoryDescription);
            return null;
        }

        public static int AddCategory(string categoryDescription)
        {
            return CDA.AddNewCategory(categoryDescription);
        }

        public static bool UpdateCategory(int categoryID, string categoryDescription)
        {
            return CDA.UpdateCategory(categoryID, categoryDescription);
        }

        public static bool DeleteCategory(int categoryID)
        {
            return CDA.DeleteCategory(categoryID);
        }

        public static CategoriesBusinessLayer FindCategory(string categoryDescription)
        {
            var categoryID = -1;

            if (CDA.GetCategoryByDescription(ref categoryID, categoryDescription))
                return new CategoriesBusinessLayer(categoryID, categoryDescription);
            return null;
        }

        public static DataTable LoadCategoriesList()
        {
            return CDA.LoadCategoriesList();
        }

        public static DataTable FindCategoryByName(string CategoryName)
        {
            return CDA.FindCategoryByName(CategoryName);
        }
    }
}