﻿using System.Data;
using PDA = DataAccessLayer.ProductsDataAccessLayer;


namespace BusinessLayer
{
    public class ProductsBusinessLayer
    {
        public string ProductID { get; set; }
        public string ProductLabel { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public byte[] PathImage { get; set; }
        public int CategoryID { get; set; }

        public CategoriesBusinessLayer CategoryInfo;

        public enum enMood
        {
            New = 0,
            Update = 1
        }

        public enMood Mood;

        public ProductsBusinessLayer()
        {
            ProductID = null;
            PathImage = null;
            CategoryID = -1;
            Mood = enMood.New;
        }

        private ProductsBusinessLayer(string productId, string productLabel, int quantity,
            decimal price, byte[] pathImage, int categoryId)
        {
            ProductID = productId;
            ProductLabel = productLabel;
            Quantity = quantity;
            Price = price;
            PathImage = pathImage;
            CategoryID = categoryId;
            CategoryInfo = CategoriesBusinessLayer.FindCategory(categoryId);
            Mood = enMood.Update;
        }

        public static DataTable GetAllProducts()
        {
            return PDA.GetAllProducts();
        }

        public static ProductsBusinessLayer FindProduct(string productID)
        {
            var productLabel = "";
            byte[] pathImage = default;
            int quantity = -1, categoryID = -1;
            decimal price = 0;

            if (PDA.GetProductByProductID(productID, ref productLabel, ref quantity,
                    ref price, ref pathImage, ref categoryID))
                return new ProductsBusinessLayer(productID, productLabel, quantity, price, pathImage, categoryID);

            return null;
        }

        private bool _AddNewProduct()
        {
            Mood = enMood.Update;
            return PDA.AddNewProduct(ProductID, ProductLabel, Quantity, Price, PathImage, CategoryID);
        }

        private bool _UpdateProduct()
        {
            return PDA.UpdateProduct(ProductID, ProductLabel, Quantity, Price, PathImage, CategoryID);
        }

        public bool Save()
        {
            return Mood == enMood.New ? _AddNewProduct() : _UpdateProduct();
        }

        public bool Delete()
        {
            return PDA.DeleteProduct(ProductID);
        }

        public static bool ExistProductID(string productID)
        {
            return PDA.ExistProductID(productID);
        }
    }
}