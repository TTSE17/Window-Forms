﻿using System;
using System.Data;
using ODA = DataAccessLayer.OrdersDataAccessLayer;

namespace BusinessLayer
{
    public class OrdersBusinessLayer
    {
        public int? OrderID { get; set; }

        public int? CustomerID { get; set; }

        public decimal Total { get; set; }
        public DateTime OrderData { get; set; }

        public CustomersBusinessLayer CustomerInfo;
        public string Description { get; set; }
        public string UserName { get; set; }

        public UsersBusinessLayer UserInfo;

        public OrdersBusinessLayer()
        {
            OrderID = CustomerID = null;
            CustomerInfo = null;
            UserInfo = null;
            UserName = null;
        }

        private OrdersBusinessLayer(int? orderId, int? customerID, decimal total, DateTime orderData,
            string description, string userName)
        {
            OrderID = orderId;
            CustomerID = customerID;
            CustomerInfo = CustomersBusinessLayer.FindCustomer(CustomerID);
            Total = total;
            OrderData = orderData;
            Description = description;
            UserName = userName;
            UserInfo = UsersBusinessLayer.FindUser(UserName);
        }

        public static DataTable GetAllOrders(int? customerID)
        {
            return ODA.GetAllOrders(customerID);
        }

        public static OrdersBusinessLayer FindOrder(int? orderID)
        {
            var customerID = -1;
            decimal total = 0;
            DateTime orderDate = default;
            string description = "", userName = "";

            if (ODA.GetOrderByID(orderID, ref customerID, ref total, ref orderDate,
                    ref description, ref userName))
                return new OrdersBusinessLayer(orderID, customerID, total, orderDate, description, userName);

            return null;
        }

        private int _AddNewOrder()
        {
            return ODA.AddNewOrder(CustomerID, Total, OrderData, Description, UserName);
        }

        private bool _UpdateOrder()
        {
            return ODA.UpdateOrder(OrderID, CustomerID, Total, OrderData, Description, UserName);
        }

        public bool Save()
        {
            if (OrderID.HasValue) return _UpdateOrder();

            OrderID = _AddNewOrder();
            return true;
        }

        public static bool Delete(int orderID)
        {
            return OrdersDetailsDetailsBusinessLayer.DeleteOrderDetailsByOrderID(orderID)
                ? ODA.DeleteOrder(orderID)
                : false;
        }
    }
}