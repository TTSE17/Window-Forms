﻿using DataAccessLayer;

namespace BusinessLayer
{
    public class BackupBusinessLayer
    {
        public static bool StoreBackUp(string Path)
        {
            return BackupDataAccessLayer.StoreBackUp(Path);
        }
        
        public static bool RestoreData(string Path)
        {
            return BackupDataAccessLayer.RestoreData(Path);
        }
        
    }
}