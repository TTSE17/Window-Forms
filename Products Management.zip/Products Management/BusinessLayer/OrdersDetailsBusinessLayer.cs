﻿using System;
using System.Data;
using ODDA = DataAccessLayer.OrdersDetailsDataAccessLayer;

namespace BusinessLayer
{
    public class OrdersDetailsDetailsBusinessLayer
    {
        public string ProductID { get; set; }
        public ProductsBusinessLayer ProductInfo;
        public int? OrderID { get; set; }
        public OrdersBusinessLayer OrderInfo;
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal Discount { get; set; }
        public decimal TotalAmount { get; set; }

        public OrdersDetailsDetailsBusinessLayer()
        {
            OrderID = null;
            ProductID = null;
            ProductInfo = null;
            OrderInfo = null;
        }

        private OrdersDetailsDetailsBusinessLayer(string productId, int? orderId, int quantity, decimal price,
            decimal discount, decimal totalAmount)
        {
            ProductID = productId;
            ProductInfo = ProductsBusinessLayer.FindProduct(ProductID);
            OrderID = orderId;
            OrderInfo = OrdersBusinessLayer.FindOrder(orderId);
            Quantity = quantity;
            Price = price;
            Discount = discount;
            TotalAmount = totalAmount;
        }

        public static DataTable GetAllOrderDetails(int? orderID)
        {
            return ODDA.GetAllOrderDetails(orderID);
        }

        public bool AddNewOrderDetails()
        {
            return ODDA.AddNewOrderDetails(ProductID, OrderID, Quantity, Price, Discount, TotalAmount);
        }

        public static bool DeleteOrderDetailsByOrderID(int? orderID)
        {
            return ODDA.DeleteOrderDetailsByOrderID(orderID);
        }
    }
}