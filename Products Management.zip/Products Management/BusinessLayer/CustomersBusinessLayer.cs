﻿using System;
using System.Data;
using CDA = DataAccessLayer.CustomersDataAccessLayer;

namespace BusinessLayer
{
    public class CustomersBusinessLayer
    {
        public Nullable<int> CustomerID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }

        public byte[] PathImage { get; set; }

        public CustomersBusinessLayer()
        {
            CustomerID = null;
            PathImage = null;
        }

        private CustomersBusinessLayer(int? CustomerId, string firstName, string lastName,
            string phone, string email, byte[] pathImage)
        {
            CustomerID = CustomerId;
            FirstName = firstName;
            LastName = lastName;
            Phone = phone;
            Email = email;
            PathImage = pathImage;
        }

        public static DataTable GetAllCustomers()
        {
            return CDA.GetAllCustomers();
        }

        public static CustomersBusinessLayer FindCustomer(int? CustomerID)
        {
            string firstName = "", lastName = "", phone = "", email = "";
            byte[] pathImage = default;

            if (CDA.GetCustomerByCustomerID(CustomerID, ref firstName, ref lastName,
                    ref phone, ref email, ref pathImage))
                return new CustomersBusinessLayer(CustomerID, firstName, lastName, phone, email, pathImage);

            return null;
        }

        private int _AddNewCustomer()
        {
            return CDA.AddNewCustomer(FirstName, LastName, Phone, Email, PathImage);
        }

        private bool _UCDAteCustomer()
        {
            return CDA.UpdateCustomer(CustomerID, FirstName, LastName, Phone, Email, PathImage);
        }

        public bool Save()
        {
            if (CustomerID.HasValue) return _UCDAteCustomer();

            CustomerID = _AddNewCustomer();
            return true;
        }

        public static bool Delete(int customerID)
        {
            return CDA.DeleteCustomer(customerID);
        }

        // public static bool ExistCustomerID(int CustomerID)
        // {
        //     return CDA.ExistCustomerID(CustomerID);
        // }
    }
}