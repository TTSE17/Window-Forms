﻿using System.Data;
// using DataAccessLayer;
using UDA = DataAccessLayer.UsersDataAccessLayer;

namespace BusinessLayer
{
    public class UsersBusinessLayer
    {
        public string UserName { get; set; }
        public string Password { get; set; }

        public bool Type { get; set; }

        public enum enMood
        {
            New = 0,
            Update = 1
        }

        public enMood Mood;

        public UsersBusinessLayer()
        {
            UserName = null;
            Mood = enMood.New;
        }

        private UsersBusinessLayer(string userName, string password, bool type)
        {
            UserName = userName;
            Password = password;
            Type = type;

            Mood = enMood.Update;
        }

        public static DataTable GetAllUsers()
        {
            return UDA.GetAllUsers();
        }

        public static bool IsFound(string UserName, string Password)
        {
            return UDA.IsFound(UserName, Password);
        }

        public static UsersBusinessLayer FindUser(string userName)
        {
            var password = "";
            var type = false;

            if (UDA.GetUserByUserName(userName, ref password, ref type))
                return new UsersBusinessLayer(userName, password, type);

            return null;
        }

        private bool _AddNewUser()
        {
            Mood = enMood.Update;
            return UDA.AddNewUser(UserName, Password, Type);
        }

        private bool _UpdateUser()
        {
            return UDA.UpdateUser(UserName, Password, Type);
        }

        public bool Save()
        {
            return Mood == enMood.New ? _AddNewUser() : _UpdateUser();
        }

        public static bool Delete(string userName)
        {
            return UDA.DeleteUser(userName);
        }

        public static bool ExistUserName(string userName)
        {
            return UDA.ExistUserName(userName);
        }
    }
}