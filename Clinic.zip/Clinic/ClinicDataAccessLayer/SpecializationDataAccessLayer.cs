﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public class SpecializationDataAccessLayer
    {
        public static DataTable GetAllSpecializations()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            DataTable dt = new DataTable();

            string Query = @"select * from Specializations";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindSpecialization(int ID, ref string SpecializationName)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Specializations Where ID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    SpecializationName = (string)reader[1];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool FindSpecialization(ref int ID, string SpecializationName)
        {
            bool isFoound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Specializations Where Specialization=@SpecializationName";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@SpecializationName", SpecializationName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFoound = true;
                    ID = (int)reader[0];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFoound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFoound;
        }
    }
}