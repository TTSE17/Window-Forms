﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public static class AppointmentsDataAccessLayer
    {
        public static DataTable GetAllAppointments(string Text = "", string Status = "")
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from (
                                    select 
                                    AppointmentID,  
                                    'Patient Name'=
                                    (select (Persons.FirstName +' '+Persons.MiddleName+' '+ Persons.LastName)from Persons Where Patients.PersonId=Persons.PersonID ),
                                    'Doctor Name'=
                                    (select (Persons.FirstName +' '+Persons.MiddleName+' '+ Persons.LastName)from Persons Where Doctors.PersonId=Persons.PersonID),
                                    Appointments.AppointmentDate , Appointments.AppointmentTime  ,
                                    'Service'= (select ServiceName from Services where MedicalRecords.ServiceID = Services.ServiceID),
	                                'Medicine' = (select MedicineName from Medicine where MedicalRecords.MedicineID = Medicine.MedicineID),
	                                Appointments.RegistrationDate , Appointments.Status
                                    from Appointments 
                                    Inner join Doctors on Appointments.DoctorId=Doctors.DoctorID
                                    Inner Join Patients on Appointments.PatientID = Patients.PatientID
                                    Left Join MedicalRecords on Appointments.MedicalRecordID = MedicalRecords.MedicalRecordID
                                )T where (T.[Patient Name] like @Text +'%' OR T.[Doctor Name] like @Text+'%')and(Status like @Status+'%')";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@Text", Text);
            command.Parameters.AddWithValue("@Status", Status);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable GetAllAppointmentsToday(string TodayDate)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from Appointments where AppointmentDate=@TodayDate";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@TodayDate", TodayDate);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool IsFoundAppointmentTimeInAppointmentDate(string AppointmentTime, string AppointmentDate)
        {
            bool IsFound = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select found = 1 from Appointments 
                             where AppointmentDate  = @AppointmentDate  COLLATE SQL_Latin1_General_CP1_CS_AS
                             and   AppointmentTime  = @AppointmentTime  COLLATE SQL_Latin1_General_CP1_CS_AS";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@AppointmentTime", AppointmentTime);
            command.Parameters.AddWithValue("@AppointmentDate", AppointmentDate);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                IsFound = reader.HasRows;

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                IsFound = false;
            }
            finally
            {
                connection.Close();
            }

            return IsFound;
        }

        public static bool FindAppointment(int ID, ref int patientID, ref int doctorID, ref DateTime appointmentDate,
            ref string appointmentTime, ref int medicalRecordID, ref DateTime registrationDate, ref string status)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Appointments Where AppointmentID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    patientID = (int)reader[1];
                    doctorID = (int)reader[2];
                    appointmentDate = (DateTime)reader[3];
                    appointmentTime = (string)reader[4];
                    medicalRecordID = (reader[5] == DBNull.Value) ? -1 : (int)reader[5];
                    registrationDate = (DateTime)reader[6];
                    status = (string)reader[7];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewAppointment(int patientID, int doctorID, DateTime appointmentDate,
            string appointmentTime, DateTime registrationDate, string status)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Appointments
                             VALUES (@patientID,@doctorID,@appointmentDate,@appointmentTime,@medicalRecordID,@registrationDate,@status)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@patientID", patientID);
            command.Parameters.AddWithValue("doctorID", doctorID);
            command.Parameters.AddWithValue("appointmentDate", appointmentDate);
            command.Parameters.AddWithValue("appointmentTime", appointmentTime);
            command.Parameters.AddWithValue("medicalRecordID", System.DBNull.Value);
            command.Parameters.AddWithValue("registrationDate", registrationDate);
            command.Parameters.AddWithValue("status", status);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateAppointment(int AppointmentID, int patientID, int doctorID, DateTime appointmentDate,
            string appointmentTime, int medicalRecordID, DateTime registrationDate, string status)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Appointments
                            set patientID = @patientID,doctorID =@doctorID,appointmentDate=@appointmentDate,
                                appointmentTime=@appointmentTime,medicalRecordID=@medicalRecordID,
                                registrationDate=@registrationDate,status=@status
                            where AppointmentID = @AppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);
            command.Parameters.AddWithValue("@patientID", patientID);
            command.Parameters.AddWithValue("@doctorID", doctorID);
            command.Parameters.AddWithValue("@appointmentDate", appointmentDate);
            command.Parameters.AddWithValue("@appointmentTime", appointmentTime);

            if (medicalRecordID != -1)
                command.Parameters.AddWithValue("@medicalRecordID", medicalRecordID);
            else
                command.Parameters.AddWithValue("@medicalRecordID", System.DBNull.Value);

            command.Parameters.AddWithValue("@registrationDate", registrationDate);
            command.Parameters.AddWithValue("@status", status);


            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static void UpdateAppointmentsMissed(string TodayDate)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Appointments
                             set Status='Missed'
                             where AppointmentDate <@TodayDate and Status='Unconfirmed'";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TodayDate", TodayDate);

            try
            {
                connection.Open();
                command.ExecuteNonQuery();


                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : " + ex);
            }

            finally
            {
                connection.Close();
            }
        }

        public static bool DeleteAppointment(int AppointmentID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete  from Appointments Where AppointmentID=@AppointmentID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@AppointmentID", AppointmentID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}