﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public class PatientsDataAccessLayer
    {
        public static DataTable GetAllPatients(string Text = "")
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from (
                                select PatientId,'Full Name'=(FirstName+' '+MiddleName+' '+LastName),Registration_Date , Email , Phone , Address ,DateOfBirth , 
                                Gender , ImagePath=IsNull(ImagePath,'NULL') , Country = (select CountryName from  Countries where Country_id =CountryID) from Persons 
                                Inner Join Patients on Persons.PersonID = Patients.PersonId
                                ) T where T.[Full Name] like @Text+'%'";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@Text", Text);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindPatient(int ID, ref DateTime RegistrationDate, ref int PersonID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Patients Where PatientID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    RegistrationDate = (DateTime)reader[1];
                    PersonID = (int)reader[2];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewPatient(DateTime RegistrationDate, int PersonID)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Patients
                             VALUES (@RegistrationDate,@PersonID)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("RegistrationDate", RegistrationDate);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool DeletePatient(int PatientID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete  from Patients Where PatientID=@PatientID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PatientID", PatientID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}