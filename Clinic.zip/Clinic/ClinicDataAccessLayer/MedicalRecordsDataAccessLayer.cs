﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public class MedicalRecordsDataAccessLayer
    {
        public static DataTable GetAllMedicalRecords(string Text = "")
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from MedicalRecords Where MedicalRecordID  like @Text+'%'";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@Text", Text);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindMedicalRecord(int ID, ref int serviceID, ref int MedicineID, ref string Diagnosis)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from MedicalRecords Where MedicalRecordId=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    serviceID = (int)reader[1];
                    MedicineID = (int)reader[2];
                    Diagnosis = (string)reader[3];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewMedicalRecord(int serviceID, int MedicineID, string Diagnosis)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO MedicalRecords
                             VALUES (@serviceID,@MedicineID,@Diagnosis)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@serviceID", serviceID);
            command.Parameters.AddWithValue("@MedicineID", MedicineID);
            command.Parameters.AddWithValue("@Diagnosis", Diagnosis);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateMedicalRecord(int MedicalRecordId, int serviceID, int MedicineID, string Diagnosis)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update MedicalRecords
                            set serviceID = @serviceID,MedicineID =@MedicineID,Diagnosis=@Diagnosis
                            where MedicalRecordId = @MedicalRecordId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicalRecordId", MedicalRecordId);
            command.Parameters.AddWithValue("@serviceID", serviceID);
            command.Parameters.AddWithValue("@MedicineID", MedicineID);
            command.Parameters.AddWithValue("@Diagnosis", Diagnosis);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteMedicalRecord(int MedicalRecordID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete  from MedicalRecords Where MedicalRecordID=@MedicalRecordID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@MedicalRecordID", MedicalRecordID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}