﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Net.Mime;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public class DashboardDataAccessLayer
    {
        public static DataTable GetNumberEveryThing()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select  
                                (Select count(1) From Appointments),
                                (Select count(1) From Patients),
                                (Select count(1) From Doctors),
                                (Select count(1) From Services),
                                (Select count(1) From Medicine),
	                            (select count(1) From Appointments Where AppointmentDate=(SELECT FORMAT (GetDate(), 'yyyy/MM/dd'))),
	                            (select count(1) From Appointments Where Status ='Confirmed'),
	                            (select count(1) From Appointments Where Status ='Unconfirmed'),
	                            (select count(1) From Appointments Where Status ='Cancelled'),
	                            (select count(1) From Appointments Where Status ='Missed')";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }
    }
}