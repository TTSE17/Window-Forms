﻿namespace DataAccessLayer
{
    public class clsDataAccessSettings
    {
        public static string ConnectionString = "Server=.;Database=Clinic;User Id=;Password=;";
    }
}