﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public class MedicineDataAccessLayer
    {
        public static DataTable GetAllMedicine(string Text = "")
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from Medicine Where MedicineName  like @Text+'%'";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@Text", Text);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindMedicine(int ID, ref string MedicineName, ref int Dose, ref int Times, ref int Days)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Medicine Where MedicineID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    MedicineName = (string)reader[1];
                    Dose = (int)reader[2];
                    Times = (int)reader[3];
                    Days = (int)reader[4];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewMedicine(string MedicineName, int Dose, int Times, int Days)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Medicine
                             VALUES (@MedicineName,@Dose,@Times,@Days)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicineName", MedicineName);
            command.Parameters.AddWithValue("@Dose", Dose);
            command.Parameters.AddWithValue("@Times", Times);
            command.Parameters.AddWithValue("@Days", Days);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateMedicine(int MedicineId, string MedicineName, int Dose, int Times, int Days)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Medicine
                            set MedicineName = @MedicineName,Dose =@Dose,Times=@Times,Days=@Days 
                            where MedicineId = @MedicineId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@MedicineName", MedicineName);
            command.Parameters.AddWithValue("@Dose", Dose);
            command.Parameters.AddWithValue("@Times", Times);
            command.Parameters.AddWithValue("@Days", Days);
            command.Parameters.AddWithValue("@MedicineId", MedicineId);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteMedicine(int MedicineID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete  from Medicine Where MedicineID=@MedicineID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@MedicineID", MedicineID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}