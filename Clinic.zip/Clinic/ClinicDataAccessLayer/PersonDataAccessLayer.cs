﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using DataAccessLayer;

namespace ClassLibrary1
{
    public class PersonDataAccessLayer
    {
        public static int AddNewPerson(string firstName, string middleName, string lastName, string email,
            string phone, string address, DateTime birthDate, string gender, string ImagePath, int countryId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Persons
                             VALUES (@firstName, @middleName,@lastName,@email,@phone,@address,@birthDate,@gender,@imagePath,@countryId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@middleName", middleName);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@gender", gender);
            if (ImagePath != "NULL")
                command.Parameters.AddWithValue("@ImagePath", ImagePath);
            else
                command.Parameters.AddWithValue("@ImagePath", DBNull.Value);
            command.Parameters.AddWithValue("@countryId", countryId);
            command.Parameters.AddWithValue("@birthDate", birthDate);


            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdatePerson(int personId, string firstName, string middleName, string lastName,
            string email, string phone, string address, DateTime birthDate, string gender, string imagePath,
            int countryId)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Persons  
                            set firstName = @firstName,middleName =@middleName,lastName=@lastName,gender=@gender ,phone=@phone,
                                address=@address,  imagePath = @imagePath, email= @email , country_Id=@countryId,Dateofbirth=@birthDate
                            where PersonId = @PersonId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonId", personId);
            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@middleName", middleName);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@imagePath", imagePath);
            command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@birthDate", birthDate);
            command.Parameters.AddWithValue("@countryId", countryId);


            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool FindPerson(int personId, ref string firstName, ref string middleName, ref string lastName,
            ref string email, ref string phone, ref string address, ref DateTime birthDate, ref string gender,
            ref string imagePath, ref int countryId)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Persons Where personId=@personId";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@personId", personId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = true;
                    firstName = (string)reader[1];
                    middleName = (string)reader[2];
                    lastName = (string)reader[3];
                    email = (string)reader[4];
                    phone = (string)reader[5];
                    address = (string)reader[6];
                    birthDate = (DateTime)reader[7];
                    gender = (string)reader[8];
                    imagePath = (reader[9] == DBNull.Value) ? "NULL" : (string)reader[9];
                    countryId = (int)reader[10];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool DeletePerson(int PersonID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete from Persons Where PersonID=@PersonID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}