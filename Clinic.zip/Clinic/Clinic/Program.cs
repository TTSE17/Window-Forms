﻿
using System;
using System.Windows.Forms;
using Clinic.DashBoard;
using Clinic.Doctors;
using Clinic.Medicine;
using Clinic.Patients;
using Clinic.Services;
using Clinic.TodaySession;
using Clinic.Users;

namespace Clinic
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LoginScreen());
        }
    }
}