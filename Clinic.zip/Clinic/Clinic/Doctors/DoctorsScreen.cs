﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Doctors
{
    public partial class DoctorsScreen : Form
    {
        public DoctorsScreen()
        {
            InitializeComponent();
        }

        private void DoctorsScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            GridViewDoctorsList.DataSource = DoctorsBusinessLayer.GetAllDoctors(Text);
            lbl_Totall_Doctors.Text = Convert.ToString(GridViewDoctorsList.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnAddNewDoctor_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditDoctor();
            fr.ShowDialog();
            LoadData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var DoctorID = Convert.ToInt32(GridViewDoctorsList.CurrentRow.Cells[0].Value);
            Form fr = new AddEditDoctor(DoctorID);
            fr.ShowDialog();
            LoadData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Delete Doctor",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var DoctorID = Convert.ToInt32(GridViewDoctorsList.CurrentRow.Cells[0].Value);

            if (DoctorsBusinessLayer.DeleteDoctor(DoctorID))
            {
                MessageBox.Show("Deleled Successfully");
                LoadData();
            }
            else
            {
                MessageBox.Show("You Can't Delete This Record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}