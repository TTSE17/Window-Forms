﻿using System;
using System.Data;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Doctors
{
    public partial class AddEditDoctor : Form
    {
        private int _DoctorID = -1;

        private DoctorsBusinessLayer Doctor1;

        private PersonBusinessLayer Person1;

        public AddEditDoctor(int Id = -1)
        {
            InitializeComponent();
            _DoctorID = Id;
        }

        private void AddEditDoctor_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadCountries();
            LoadSpecialization();

            if (_DoctorID == -1)
            {
                Doctor1 = new DoctorsBusinessLayer();
                Person1 = new PersonBusinessLayer();
                lblMode.Text = "Add New Doctor";
                lblDoctorID.Text = "-";
            }

            else
            {
                Doctor1 = DoctorsBusinessLayer.FindDoctor(_DoctorID);
                Person1 = PersonBusinessLayer.FindPerson(Doctor1.PersonID);

                lblMode.Text = "Edit Employee";
                lblDoctorID.Text = Convert.ToString(Doctor1.DoctorID);

                txtFirstname.Text = Person1.FirstName;
                txtMiddleName.Text = Person1.MiddleName;
                txtLastname.Text = Person1.LastName;
                txtEmail.Text = Person1.Email;
                txtPhone.Text = Person1.Phone;
                txtAddress.Text = Person1.Address;
                DateTimePicker.Value = Person1.BirthDate;

                if (Person1.ImagePath != "NULL" || string.IsNullOrEmpty(Person1.ImagePath))
                {
                    Doctor_pictureBox.Load(Person1.ImagePath);
                }

                cmbGender.SelectedIndex = cmbGender.FindString(Person1.Gender);

                cbCountries1.SelectedIndex =
                    cbCountries1.FindString(CountryBusinessLayer.FindCountry(Person1.CountryID).CountryName);

                cbSpecialization.SelectedIndex =
                    cbSpecialization.FindString(SpecializationBusinessLayer.FindSpecialization(Doctor1.SpecializationId)
                        .Specialization);
            }
        }

        private void LoadCountries()
        {
            DataTable dt = CountryBusinessLayer.GetAllCountries();

            foreach (DataRow Row in dt.Rows)
            {
                cbCountries1.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private void LoadSpecialization()
        {
            DataTable dt = SpecializationBusinessLayer.GetAllSpecializations();
            foreach (DataRow Row in dt.Rows)
            {
                cbSpecialization.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var FirstName = txtFirstname.Text.Trim();
            var Specialization = Convert.ToString(cbSpecialization.SelectedItem);
            var MiddleName = txtMiddleName.Text.Trim();
            var LastName = txtLastname.Text.Trim();
            var Email = txtEmail.Text.Trim();
            var Phone = txtPhone.Text.Trim();
            var Address = txtAddress.Text.Trim();
            var ImagePath = Doctor_pictureBox.ImageLocation;
            var Gender = Convert.ToString(cmbGender.SelectedItem);
            var BirthDate = DateTimePicker.Value;
            var CountryName = Convert.ToString(cbCountries1.SelectedItem);

            if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(MiddleName) ||
                string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Phone) || string.IsNullOrEmpty(Address) ||
                string.IsNullOrEmpty(Gender) || string.IsNullOrEmpty(CountryName) ||
                string.IsNullOrEmpty(Specialization))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            lblMode.Text = "Edit Doctor";

            Person1.FirstName = FirstName;
            Person1.MiddleName = MiddleName;
            Person1.LastName = LastName;
            Person1.Email = Email;
            Person1.Phone = Phone;
            Person1.Address = Address;
            Person1.ImagePath = ImagePath ?? "NULL";
            Person1.Gender = Gender;
            Person1.BirthDate = BirthDate;
            Person1.CountryID = CountryBusinessLayer.FindCountry(CountryName).CountryID;


            var isUpdatedPerson = Person1.Save();

            Doctor1.PersonID = Person1.PersonId;
            Doctor1.SpecializationId = SpecializationBusinessLayer.FindSpecialization(Specialization).SpecializationID;

            MessageBox.Show((Doctor1.Save() && isUpdatedPerson)
                ? "Data Saved Successfully."
                : "Error: Data Is not Saved Successfully.");

            lblDoctorID.Text = Convert.ToString(Doctor1.DoctorID);
            _DoctorID = Doctor1.DoctorID;
        }

        private void btn_UploadPhoto_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Process the selected file
                string selectedFilePath = openFileDialog1.FileName;
                //MessageBox.Show("Selected Image is:" + selectedFilePath);

                Doctor_pictureBox.Load(selectedFilePath);
                // ...
            }
        }

        private void linkLabel_RemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Doctor_pictureBox.ImageLocation = null;
        }
    }
}