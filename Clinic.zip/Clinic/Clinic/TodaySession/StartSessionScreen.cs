﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.TodaySession
{
    public partial class StartSessionScreen : Form
    {
        private int _AppointmentID;
        private PersonBusinessLayer _Person1;
        private PatientsBusinessLayer _Patient1;
        private AppointmentsBusinessLayer _Appointment1;

        private int _MedicalRecordID;
        private MedicalRecordsBusinessLayer _MedicalRecord1;

        public StartSessionScreen(int AppointmentID, int MedicalRecordId = -1)
        {
            InitializeComponent();
            _AppointmentID = AppointmentID;
            _MedicalRecordID = MedicalRecordId;
        }

        private void StartSessionScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            txtAppointmentID.Text = Convert.ToString(_AppointmentID);

            _Appointment1 = AppointmentsBusinessLayer.FindAppointment(_AppointmentID);

            _Patient1 = PatientsBusinessLayer.FindPatient(_Appointment1.PatientID);

            _Person1 = PersonBusinessLayer.FindPerson(_Patient1.PersonID);

            txtName.Text = _Person1.FirstName + " " + _Person1.MiddleName + " " + _Person1.LastName;
            txtGender.Text = _Person1.Gender;
            txtAge.Text = Convert.ToString((DateTime.Now - _Person1.BirthDate).Days / 365);

            if (_MedicalRecordID == -1)
            {
                _MedicalRecord1 = new MedicalRecordsBusinessLayer();
                this.Text = "Start Session Scrren";
            }
            else
            {
                _MedicalRecord1 = MedicalRecordsBusinessLayer.FindMedicalRecord(_MedicalRecordID);

                this.Text = "Edit Session Screen";

                lblMedicalID.Text = Convert.ToString(_MedicalRecord1.MedicalRecordID);
                lblServiceID.Text = Convert.ToString(_MedicalRecord1.ServiceID);
                lblMedicineID.Text = Convert.ToString(_MedicalRecord1.MedicineID);
                lblDiagnosis.Text = _MedicalRecord1.Diagnosis;
            }
        }

        private void btnSelectService_Click(object sender, EventArgs e)
        {
            var fr = new SelectPatientDoctor("S");
            fr.DataBack += DataBackServiceID; // Subscribe to the event
            fr.ShowDialog();
        }

        private void DataBackServiceID(int ID)
        {
            lblServiceID.Text = Convert.ToString(ID);
        }

        private void btnSelectMedicine_Click(object sender, EventArgs e)
        {
            var fr = new SelectPatientDoctor("M");
            fr.DataBack += DataBackMedicineID; // Subscribe to the event
            fr.ShowDialog();
        }

        private void DataBackMedicineID(int ID)
        {
            lblMedicineID.Text = Convert.ToString(ID);
        }

        private void txtDiagnosis_TextChanged(object sender, EventArgs e)
        {
            lblDiagnosis.Text = txtDiagnosis.Text.Trim();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var ServiceID = lblServiceID.Text;
            var MedicineID = lblMedicineID.Text;
            var Diagnosis = lblDiagnosis.Text;

            if (ServiceID == "??" || MedicineID == "??")
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            _MedicalRecord1.ServiceID = Convert.ToInt32(ServiceID);
            _MedicalRecord1.MedicineID = Convert.ToInt32(MedicineID);
            _MedicalRecord1.Diagnosis = Diagnosis == "" ? "NULL" : Diagnosis;

            _MedicalRecord1.Save();

            _Appointment1.Status = "Confirmed";
            _Appointment1.MedicalRecordID = _MedicalRecord1.MedicalRecordID;

            MessageBox.Show(
                _Appointment1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblMedicalID.Text = Convert.ToString(_MedicalRecord1.MedicalRecordID);

            this.Text = "Edit Session Screen";

            _MedicalRecordID = _MedicalRecord1.MedicalRecordID;
        }
    }
}