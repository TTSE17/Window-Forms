﻿using System.ComponentModel;

namespace Clinic.TodaySession
{
    partial class StartSessionScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtGender = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblDiagnosis = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMedicineID = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.lblMedicalID = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblServiceID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnSelectMedicine = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSelectService = new System.Windows.Forms.Button();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.txtAppointmentID = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtDiagnosis = new System.Windows.Forms.RichTextBox();
            this.groupBox_firstname = new System.Windows.Forms.GroupBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox_firstname.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox10);
            this.panel1.Controls.Add(this.groupBox8);
            this.panel1.Controls.Add(this.groupBox_firstname);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(781, 408);
            this.panel1.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.txtGender);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox3.Location = new System.Drawing.Point(489, 19);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox3.Size = new System.Drawing.Size(125, 47);
            this.groupBox3.TabIndex = 176;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Gender";
            // 
            // txtGender
            // 
            this.txtGender.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtGender.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtGender.ForeColor = System.Drawing.Color.Black;
            this.txtGender.Location = new System.Drawing.Point(3, 20);
            this.txtGender.Margin = new System.Windows.Forms.Padding(0);
            this.txtGender.Multiline = true;
            this.txtGender.Name = "txtGender";
            this.txtGender.ReadOnly = true;
            this.txtGender.Size = new System.Drawing.Size(117, 20);
            this.txtGender.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtAge);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox1.Location = new System.Drawing.Point(643, 19);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(125, 47);
            this.groupBox1.TabIndex = 182;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Age";
            // 
            // txtAge
            // 
            this.txtAge.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtAge.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtAge.ForeColor = System.Drawing.Color.Black;
            this.txtAge.Location = new System.Drawing.Point(3, 20);
            this.txtAge.Margin = new System.Windows.Forms.Padding(0);
            this.txtAge.Multiline = true;
            this.txtAge.Name = "txtAge";
            this.txtAge.ReadOnly = true;
            this.txtAge.Size = new System.Drawing.Size(117, 20);
            this.txtAge.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.lblDiagnosis);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.lblMedicineID);
            this.panel3.Controls.Add(this.label);
            this.panel3.Controls.Add(this.lblMedicalID);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.lblServiceID);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(489, 98);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(279, 201);
            this.panel3.TabIndex = 181;
            // 
            // lblDiagnosis
            // 
            this.lblDiagnosis.AutoEllipsis = true;
            this.lblDiagnosis.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblDiagnosis.ForeColor = System.Drawing.Color.DimGray;
            this.lblDiagnosis.Location = new System.Drawing.Point(17, 156);
            this.lblDiagnosis.Name = "lblDiagnosis";
            this.lblDiagnosis.Size = new System.Drawing.Size(287, 25);
            this.lblDiagnosis.TabIndex = 148;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(17, 120);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 25);
            this.label1.TabIndex = 147;
            this.label1.Text = "Diagnosis :";
            // 
            // lblMedicineID
            // 
            this.lblMedicineID.AutoSize = true;
            this.lblMedicineID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblMedicineID.ForeColor = System.Drawing.Color.DimGray;
            this.lblMedicineID.Location = new System.Drawing.Point(127, 82);
            this.lblMedicineID.Name = "lblMedicineID";
            this.lblMedicineID.Size = new System.Drawing.Size(28, 25);
            this.lblMedicineID.TabIndex = 146;
            this.lblMedicineID.Text = "??";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label.ForeColor = System.Drawing.Color.DimGray;
            this.label.Location = new System.Drawing.Point(17, 82);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(115, 25);
            this.label.TabIndex = 145;
            this.label.Text = "Medicine ID :";
            // 
            // lblMedicalID
            // 
            this.lblMedicalID.AutoSize = true;
            this.lblMedicalID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblMedicalID.ForeColor = System.Drawing.Color.DimGray;
            this.lblMedicalID.Location = new System.Drawing.Point(122, 14);
            this.lblMedicalID.Name = "lblMedicalID";
            this.lblMedicalID.Size = new System.Drawing.Size(28, 25);
            this.lblMedicalID.TabIndex = 144;
            this.lblMedicalID.Text = "??";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(17, 14);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(105, 25);
            this.label7.TabIndex = 143;
            this.label7.Text = "Medical ID :";
            // 
            // lblServiceID
            // 
            this.lblServiceID.AutoSize = true;
            this.lblServiceID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblServiceID.ForeColor = System.Drawing.Color.DimGray;
            this.lblServiceID.Location = new System.Drawing.Point(122, 48);
            this.lblServiceID.Name = "lblServiceID";
            this.lblServiceID.Size = new System.Drawing.Size(28, 25);
            this.lblServiceID.TabIndex = 138;
            this.lblServiceID.Text = "??";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(17, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 25);
            this.label2.TabIndex = 137;
            this.label2.Text = "Service ID :";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(158)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(311, 332);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(151, 46);
            this.btnSave.TabIndex = 180;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.btnSelectMedicine);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox4.Location = new System.Drawing.Point(259, 98);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox4.Size = new System.Drawing.Size(210, 65);
            this.groupBox4.TabIndex = 179;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Medicine";
            // 
            // btnSelectMedicine
            // 
            this.btnSelectMedicine.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectMedicine.Location = new System.Drawing.Point(3, 23);
            this.btnSelectMedicine.Name = "btnSelectMedicine";
            this.btnSelectMedicine.Size = new System.Drawing.Size(200, 32);
            this.btnSelectMedicine.TabIndex = 105;
            this.btnSelectMedicine.Text = "Select Medicine";
            this.btnSelectMedicine.UseVisualStyleBackColor = true;
            this.btnSelectMedicine.Click += new System.EventHandler(this.btnSelectMedicine_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnSelectService);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox2.Location = new System.Drawing.Point(19, 98);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(210, 65);
            this.groupBox2.TabIndex = 178;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Service";
            // 
            // btnSelectService
            // 
            this.btnSelectService.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectService.Location = new System.Drawing.Point(3, 23);
            this.btnSelectService.Name = "btnSelectService";
            this.btnSelectService.Size = new System.Drawing.Size(200, 32);
            this.btnSelectService.TabIndex = 105;
            this.btnSelectService.Text = "Select Service";
            this.btnSelectService.UseVisualStyleBackColor = true;
            this.btnSelectService.Click += new System.EventHandler(this.btnSelectService_Click);
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.Transparent;
            this.groupBox10.Controls.Add(this.txtAppointmentID);
            this.groupBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox10.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox10.Location = new System.Drawing.Point(19, 19);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox10.Size = new System.Drawing.Size(125, 47);
            this.groupBox10.TabIndex = 175;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Appointment ID";
            // 
            // txtAppointmentID
            // 
            this.txtAppointmentID.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtAppointmentID.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAppointmentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtAppointmentID.ForeColor = System.Drawing.Color.Black;
            this.txtAppointmentID.Location = new System.Drawing.Point(3, 20);
            this.txtAppointmentID.Margin = new System.Windows.Forms.Padding(0);
            this.txtAppointmentID.Multiline = true;
            this.txtAppointmentID.Name = "txtAppointmentID";
            this.txtAppointmentID.ReadOnly = true;
            this.txtAppointmentID.Size = new System.Drawing.Size(117, 20);
            this.txtAppointmentID.TabIndex = 0;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.txtDiagnosis);
            this.groupBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox8.Location = new System.Drawing.Point(19, 196);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox8.Size = new System.Drawing.Size(450, 103);
            this.groupBox8.TabIndex = 168;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Diagnosis:";
            // 
            // txtDiagnosis
            // 
            this.txtDiagnosis.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDiagnosis.ForeColor = System.Drawing.Color.DimGray;
            this.txtDiagnosis.Location = new System.Drawing.Point(3, 23);
            this.txtDiagnosis.Name = "txtDiagnosis";
            this.txtDiagnosis.Size = new System.Drawing.Size(440, 70);
            this.txtDiagnosis.TabIndex = 0;
            this.txtDiagnosis.Text = "";
            this.txtDiagnosis.TextChanged += new System.EventHandler(this.txtDiagnosis_TextChanged);
            // 
            // groupBox_firstname
            // 
            this.groupBox_firstname.BackColor = System.Drawing.Color.Transparent;
            this.groupBox_firstname.Controls.Add(this.txtName);
            this.groupBox_firstname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox_firstname.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox_firstname.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox_firstname.Location = new System.Drawing.Point(169, 19);
            this.groupBox_firstname.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox_firstname.Name = "groupBox_firstname";
            this.groupBox_firstname.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox_firstname.Size = new System.Drawing.Size(300, 47);
            this.groupBox_firstname.TabIndex = 165;
            this.groupBox_firstname.TabStop = false;
            this.groupBox_firstname.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtName.ForeColor = System.Drawing.Color.Black;
            this.txtName.Location = new System.Drawing.Point(3, 20);
            this.txtName.Margin = new System.Windows.Forms.Padding(0);
            this.txtName.Multiline = true;
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(290, 20);
            this.txtName.TabIndex = 0;
            // 
            // StartSessionScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(781, 408);
            this.Controls.Add(this.panel1);
            this.Name = "StartSessionScreen";
            this.Text = "StartSessionScreen";
            this.Load += new System.EventHandler(this.StartSessionScreen_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox_firstname.ResumeLayout(false);
            this.groupBox_firstname.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDiagnosis;

        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtGender;

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lblMedicineID;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label lblMedicalID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblServiceID;
        private System.Windows.Forms.Label label2;

        private System.Windows.Forms.Button btnSave;

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnSelectMedicine;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnSelectService;

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtAge;

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.TextBox txtAppointmentID;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RichTextBox txtDiagnosis;
        private System.Windows.Forms.GroupBox groupBox_firstname;
        private System.Windows.Forms.TextBox txtName;

        #endregion
    }
}