﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.TodaySession
{
    public partial class TodaySessionsScreen : Form
    {
        public TodaySessionsScreen()
        {
            InitializeComponent();
        }

        private void TodaySessionsScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        public void LoadData()
        {
            lblDateToday.Text = DateTime.Now.ToString("yyyy-MM-dd , hh:mm tt");

            DataTable dt = AppointmentsBusinessLayer.GetAllAppointmentsToday();

            MainContainer.Controls.Clear();

            foreach (DataRow Row in dt.Rows)
            {
                CreateSession(Row);
            }
        }

        private void CreateSession(DataRow Record)
        {
            var Status = Convert.ToString(Record[7]).Trim();


            var Item = new TheSession();

            Item.lblAppointmentID.Text = Convert.ToString(Record[0]);
            Item.lblAppointmentTime.Text = Convert.ToString(Record[4]);
            Item.lblStatus.Text = Status;

            if (Status == "Confirmed")
            {
                Item.btnStartSession.Enabled = Item.btnCancel.Enabled = false;
                Item.btnEditSession.Enabled = true;
                Item.BackColor = Color.LimeGreen;
            }
            else if (Status == "Cancelled" || Status=="Missed")
            {
                Item.btnCancel.Enabled = Item.btnStartSession.Enabled = Item.btnEditSession.Enabled = false;
                Item.BackColor = Color.Crimson;
            }


            MainContainer.Controls.Add(Item);
        }
    }
}