﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.TodaySession
{
    public partial class TheSession : UserControl
    {
        public TheSession()
        {
            InitializeComponent();
        }

        private void btnStartSession_Click(object sender, EventArgs e)
        {
            var AppoinmentID = Convert.ToInt32(lblAppointmentID.Text);

            StartSessionScreen fr = new StartSessionScreen(AppoinmentID);
            fr.ShowDialog();


            (Application.OpenForms["TodaySessionsScreen"] as TodaySessionsScreen)?.LoadData();
        }

        private void btnEditSession_Click(object sender, EventArgs e)
        {
            var AppoinmentID = Convert.ToInt32(lblAppointmentID.Text);
            var Appointment1 = AppointmentsBusinessLayer.FindAppointment(AppoinmentID);
            StartSessionScreen fr = new StartSessionScreen(AppoinmentID, Appointment1.MedicalRecordID);
            fr.ShowDialog();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Cancel Session",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var AppoinmentID = Convert.ToInt32(lblAppointmentID.Text);
            var Appointment1 = AppointmentsBusinessLayer.FindAppointment(AppoinmentID);
            Appointment1.Status = "Cancelled";

            MessageBox.Show((Appointment1.Save()) ? "Done !" : "Not Saved");

            (Application.OpenForms["TodaySessionsScreen"] as TodaySessionsScreen)?.LoadData();
        }
    }
}