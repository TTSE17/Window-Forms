﻿using System.ComponentModel;

namespace Clinic.Users
{
    partial class AddEditUserScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lblRegistrationDate = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.User_Permissions = new System.Windows.Forms.ListBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbPatientScreen = new System.Windows.Forms.CheckBox();
            this.cbTodaySessionScreen = new System.Windows.Forms.CheckBox();
            this.cbServicesScreen = new System.Windows.Forms.CheckBox();
            this.cbMedicineScreen = new System.Windows.Forms.CheckBox();
            this.cbDoctorsScreen = new System.Windows.Forms.CheckBox();
            this.cbAppointmentsScreen = new System.Windows.Forms.CheckBox();
            this.checkBoxAdmin = new System.Windows.Forms.CheckBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblMode = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.lblRegistrationDate);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.User_Permissions);
            this.panel1.Controls.Add(this.groupBox11);
            this.panel1.Controls.Add(this.groupBox8);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblUserID);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(521, 516);
            this.panel1.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(284, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 20);
            this.label3.TabIndex = 131;
            this.label3.Text = "Registration Date :";
            // 
            // lblRegistrationDate
            // 
            this.lblRegistrationDate.AutoSize = true;
            this.lblRegistrationDate.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.lblRegistrationDate.ForeColor = System.Drawing.Color.DimGray;
            this.lblRegistrationDate.Location = new System.Drawing.Point(420, 57);
            this.lblRegistrationDate.Name = "lblRegistrationDate";
            this.lblRegistrationDate.Size = new System.Drawing.Size(23, 20);
            this.lblRegistrationDate.TabIndex = 130;
            this.lblRegistrationDate.Text = "??";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtUserName);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox1.Location = new System.Drawing.Point(24, 94);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox1.Size = new System.Drawing.Size(210, 51);
            this.groupBox1.TabIndex = 129;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "User Name";
            // 
            // txtUserName
            // 
            this.txtUserName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtUserName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtUserName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtUserName.ForeColor = System.Drawing.Color.Black;
            this.txtUserName.Location = new System.Drawing.Point(5, 23);
            this.txtUserName.Margin = new System.Windows.Forms.Padding(0);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(200, 16);
            this.txtUserName.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(284, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 20);
            this.label2.TabIndex = 128;
            this.label2.Text = "Selected Permissions:";
            // 
            // User_Permissions
            // 
            this.User_Permissions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.User_Permissions.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.User_Permissions.ForeColor = System.Drawing.Color.DarkRed;
            this.User_Permissions.FormattingEnabled = true;
            this.User_Permissions.ItemHeight = 20;
            this.User_Permissions.Location = new System.Drawing.Point(284, 182);
            this.User_Permissions.Name = "User_Permissions";
            this.User_Permissions.Size = new System.Drawing.Size(210, 202);
            this.User_Permissions.TabIndex = 127;
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Transparent;
            this.groupBox11.Controls.Add(this.panel3);
            this.groupBox11.Controls.Add(this.checkBoxAdmin);
            this.groupBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox11.Location = new System.Drawing.Point(24, 153);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox11.Size = new System.Drawing.Size(210, 269);
            this.groupBox11.TabIndex = 109;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Edit User Permissions:";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.cbPatientScreen);
            this.panel3.Controls.Add(this.cbTodaySessionScreen);
            this.panel3.Controls.Add(this.cbServicesScreen);
            this.panel3.Controls.Add(this.cbMedicineScreen);
            this.panel3.Controls.Add(this.cbDoctorsScreen);
            this.panel3.Controls.Add(this.cbAppointmentsScreen);
            this.panel3.Location = new System.Drawing.Point(5, 47);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(205, 219);
            this.panel3.TabIndex = 1;
            // 
            // cbPatientScreen
            // 
            this.cbPatientScreen.AutoSize = true;
            this.cbPatientScreen.BackColor = System.Drawing.Color.Transparent;
            this.cbPatientScreen.Location = new System.Drawing.Point(18, 77);
            this.cbPatientScreen.Name = "cbPatientScreen";
            this.cbPatientScreen.Size = new System.Drawing.Size(127, 24);
            this.cbPatientScreen.TabIndex = 9;
            this.cbPatientScreen.Tag = "4";
            this.cbPatientScreen.Text = "Patients Screen";
            this.cbPatientScreen.UseVisualStyleBackColor = false;
            this.cbPatientScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbTodaySessionScreen
            // 
            this.cbTodaySessionScreen.AutoSize = true;
            this.cbTodaySessionScreen.Location = new System.Drawing.Point(18, 8);
            this.cbTodaySessionScreen.Name = "cbTodaySessionScreen";
            this.cbTodaySessionScreen.Size = new System.Drawing.Size(175, 24);
            this.cbTodaySessionScreen.TabIndex = 8;
            this.cbTodaySessionScreen.Tag = "1";
            this.cbTodaySessionScreen.Text = "Today Sessions Screen";
            this.cbTodaySessionScreen.UseVisualStyleBackColor = true;
            this.cbTodaySessionScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbServicesScreen
            // 
            this.cbServicesScreen.AutoSize = true;
            this.cbServicesScreen.Location = new System.Drawing.Point(18, 150);
            this.cbServicesScreen.Name = "cbServicesScreen";
            this.cbServicesScreen.Size = new System.Drawing.Size(129, 24);
            this.cbServicesScreen.TabIndex = 7;
            this.cbServicesScreen.Tag = "16";
            this.cbServicesScreen.Text = "Services Screen";
            this.cbServicesScreen.UseVisualStyleBackColor = true;
            this.cbServicesScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbMedicineScreen
            // 
            this.cbMedicineScreen.AutoSize = true;
            this.cbMedicineScreen.Location = new System.Drawing.Point(18, 187);
            this.cbMedicineScreen.Name = "cbMedicineScreen";
            this.cbMedicineScreen.Size = new System.Drawing.Size(137, 24);
            this.cbMedicineScreen.TabIndex = 6;
            this.cbMedicineScreen.Tag = "32";
            this.cbMedicineScreen.Text = "Medicine Screen";
            this.cbMedicineScreen.UseVisualStyleBackColor = true;
            this.cbMedicineScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbDoctorsScreen
            // 
            this.cbDoctorsScreen.AutoSize = true;
            this.cbDoctorsScreen.Location = new System.Drawing.Point(18, 113);
            this.cbDoctorsScreen.Name = "cbDoctorsScreen";
            this.cbDoctorsScreen.Size = new System.Drawing.Size(128, 24);
            this.cbDoctorsScreen.TabIndex = 4;
            this.cbDoctorsScreen.Tag = "8";
            this.cbDoctorsScreen.Text = "Doctors Screen";
            this.cbDoctorsScreen.UseVisualStyleBackColor = true;
            this.cbDoctorsScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // cbAppointmentsScreen
            // 
            this.cbAppointmentsScreen.AutoSize = true;
            this.cbAppointmentsScreen.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAppointmentsScreen.Location = new System.Drawing.Point(18, 43);
            this.cbAppointmentsScreen.Name = "cbAppointmentsScreen";
            this.cbAppointmentsScreen.Size = new System.Drawing.Size(170, 24);
            this.cbAppointmentsScreen.TabIndex = 0;
            this.cbAppointmentsScreen.Tag = "2";
            this.cbAppointmentsScreen.Text = "Appointments Screen";
            this.cbAppointmentsScreen.UseVisualStyleBackColor = true;
            this.cbAppointmentsScreen.CheckedChanged += new System.EventHandler(this.CheckBox_CheckedChanged);
            // 
            // checkBoxAdmin
            // 
            this.checkBoxAdmin.AutoSize = true;
            this.checkBoxAdmin.Location = new System.Drawing.Point(5, 25);
            this.checkBoxAdmin.Name = "checkBoxAdmin";
            this.checkBoxAdmin.Size = new System.Drawing.Size(86, 24);
            this.checkBoxAdmin.TabIndex = 0;
            this.checkBoxAdmin.Tag = "-1";
            this.checkBoxAdmin.Text = "Is Admin";
            this.checkBoxAdmin.UseVisualStyleBackColor = true;
            this.checkBoxAdmin.CheckedChanged += new System.EventHandler(this.checkBoxAdmin_CheckedChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.txtPassword);
            this.groupBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox8.Location = new System.Drawing.Point(284, 94);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox8.Size = new System.Drawing.Size(210, 51);
            this.groupBox8.TabIndex = 126;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Password";
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.txtPassword.ForeColor = System.Drawing.Color.Black;
            this.txtPassword.Location = new System.Drawing.Point(5, 23);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(0);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(200, 16);
            this.txtPassword.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(158)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(208, 449);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(99, 34);
            this.btnSave.TabIndex = 124;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(24, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 25);
            this.label1.TabIndex = 120;
            this.label1.Text = "ID:";
            // 
            // lblUserID
            // 
            this.lblUserID.AutoSize = true;
            this.lblUserID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblUserID.ForeColor = System.Drawing.Color.DimGray;
            this.lblUserID.Location = new System.Drawing.Point(61, 52);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(28, 25);
            this.lblUserID.TabIndex = 119;
            this.lblUserID.Text = "??";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Controls.Add(this.lblMode);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(521, 38);
            this.panel2.TabIndex = 100;
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblMode.ForeColor = System.Drawing.Color.DimGray;
            this.lblMode.Location = new System.Drawing.Point(202, 6);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(105, 28);
            this.lblMode.TabIndex = 71;
            this.lblMode.Text = "Add New ";
            // 
            // AddEditUserScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 516);
            this.Controls.Add(this.panel1);
            this.Name = "AddEditUserScreen";
            this.Text = "AddEditUserScreen";
            this.Load += new System.EventHandler(this.AddEditUserScreen_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.CheckBox cbAppointmentsScreen;
        private System.Windows.Forms.CheckBox cbTodaySessionScreen;
        private System.Windows.Forms.CheckBox cbPatientScreen;
        private System.Windows.Forms.CheckBox cbDoctorsScreen;
        private System.Windows.Forms.CheckBox cbMedicineScreen;
        private System.Windows.Forms.CheckBox cbServicesScreen;

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblRegistrationDate;

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox User_Permissions;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.CheckBox checkBoxAdmin;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.TextBox txtUserName;

        #endregion
    }
}