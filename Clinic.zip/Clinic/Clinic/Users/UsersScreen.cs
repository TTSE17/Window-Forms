﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Users
{
    public partial class UsersScreen : Form
    {
        public UsersScreen()
        {
            InitializeComponent();
        }

        private void UsersScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            GridViewUsersList.DataSource = UsersBusinessLayer.GetAllUsers(Text);
            lbl_Totall_Users.Text = Convert.ToString(GridViewUsersList.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnAddNewUser_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditUserScreen();
            fr.ShowDialog();
            LoadData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var UserID = Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value);
            Form fr = new AddEditUserScreen(UserID);
            fr.ShowDialog();
            LoadData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Delete User" ,
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var UserID = Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value);

            UsersBusinessLayer.DeleteUser(UserID);
            LoadData();
        }
    }
}