﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Users
{
    public partial class AddEditUserScreen : Form
    {
        private bool _Checked = false;
        private int _UserID = -1;
        private UsersBusinessLayer _User1;

        public AddEditUserScreen(int ID = -1)
        {
            InitializeComponent();
            _UserID = ID;
        }

        private void AddEditUserScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_UserID == -1)
            {
                _User1 = new UsersBusinessLayer();
                lblMode.Text = "Add New User";
                lblUserID.Text = lblRegistrationDate.Text = "-";
            }

            else
            {
                _User1 = UsersBusinessLayer.FindUser(_UserID);

                lblMode.Text = "Edit User";
                lblUserID.Text = Convert.ToString(_User1.UserID);
                lblRegistrationDate.Text = _User1.RegistrationDate.ToShortDateString();

                txtUserName.Text = _User1.UserName;
                txtPassword.Text = Convert.ToString(_User1.Password);
                SetPermission(_User1.Permission);
                
                txtPassword.Enabled = txtPassword.Enabled = false;

            }
        }

        private void SetPermission(int Permission)
        {
            CheckBox[] ArrayBoxes =
            {
                cbTodaySessionScreen, cbAppointmentsScreen, cbPatientScreen,
                cbDoctorsScreen, cbServicesScreen, cbMedicineScreen
            };

            foreach (var Box in ArrayBoxes)
            {
                if ((Permission & Convert.ToInt32(Box.Tag)) == Convert.ToInt32(Box.Tag))
                    Box.Checked = true;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var UserName = txtUserName.Text.Trim();
            var Password = txtPassword.Text.Trim();
            var Permission = GetPermission();

            if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            if (UsersBusinessLayer.IsExists(UserName) && _UserID==-1)
            {
                MessageBox.Show("Username Already Exists");
                return;
            }
            
            lblMode.Text = "Edit User";

            _User1.UserName = UserName;
            _User1.Password = Password;
            _User1.Permission = Permission;

            if (_UserID == -1)
            {
                _User1.RegistrationDate = DateTime.Now;
                lblRegistrationDate.Text = _User1.RegistrationDate.ToShortDateString();
                txtPassword.Enabled = txtPassword.Enabled = false;
            }

            MessageBox.Show(_User1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblUserID.Text = Convert.ToString(_User1.UserID);

            _UserID = _User1.UserID;
        }

        private int GetPermission()
        {
            if (checkBoxAdmin.Checked)
                return -1;

            var Permission = 0;

            CheckBox[] ArrayBoxes =
            {
                cbAppointmentsScreen, cbTodaySessionScreen, cbPatientScreen,
                cbDoctorsScreen, cbMedicineScreen, cbServicesScreen
            };

            foreach (var Box in ArrayBoxes)
            {
                if (Box.Checked)
                    Permission += Convert.ToInt32(Box.Tag);
            }

            return Permission;
        }

        private void checkBoxAdmin_CheckedChanged(object sender, EventArgs e)
        {
            if (_Checked) return;

            cbAppointmentsScreen.Checked = cbDoctorsScreen.Checked = cbMedicineScreen.Checked =
                cbPatientScreen.Checked = cbServicesScreen.Checked =
                    cbTodaySessionScreen.Checked = checkBoxAdmin.Checked;
        }

        private void CheckedBoxAdmin()
        {
            _Checked = true;
            checkBoxAdmin.Checked = (cbAppointmentsScreen.Checked && cbDoctorsScreen.Checked &&
                                     cbMedicineScreen.Checked && cbPatientScreen.Checked &&
                                     cbServicesScreen.Checked && cbTodaySessionScreen.Checked);
            _Checked = false;
        }

        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            PushAllCheckedItemInList();
            var checkBox = (CheckBox)sender;

            if (checkBox.Checked)
                CheckedBoxAdmin();

            else
            {
                _Checked = true;
                checkBoxAdmin.Checked = false;
                _Checked = false;
            }
        }

        private void PushAllCheckedItemInList()
        {
            User_Permissions.Items.Clear();

            CheckBox[] ArrayBoxes =
            {
                cbTodaySessionScreen, cbAppointmentsScreen, cbPatientScreen,
                cbDoctorsScreen, cbServicesScreen, cbMedicineScreen
            };

            foreach (var Box in ArrayBoxes)
            {
                if (Box.Checked)
                    User_Permissions.Items.Add(Box.Text);
            }
        }
    }
}