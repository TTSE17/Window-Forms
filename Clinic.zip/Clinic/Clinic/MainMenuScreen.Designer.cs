﻿using System.ComponentModel;

namespace Clinic
{
    partial class MainMenuScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogout = new System.Windows.Forms.Button();
            this.MainPanel = new System.Windows.Forms.Panel();
            this.Top_panel = new System.Windows.Forms.Panel();
            this.btnAppointments = new System.Windows.Forms.Button();
            this.btnTodaySessions = new System.Windows.Forms.Button();
            this.btnServices = new System.Windows.Forms.Button();
            this.btnMedicine = new System.Windows.Forms.Button();
            this.btnDoctors = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.btnPatients = new System.Windows.Forms.Button();
            this.Top_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Transparent;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatAppearance.MouseDownBackColor = System.Drawing.Color.WhiteSmoke;
            this.btnLogout.FlatAppearance.MouseOverBackColor = System.Drawing.Color.WhiteSmoke;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnLogout.ForeColor = System.Drawing.Color.DimGray;
            this.btnLogout.Image = global::Clinic.Properties.Resources.icons8_Logout_20px;
            this.btnLogout.Location = new System.Drawing.Point(1331, 0);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(0);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(123, 82);
            this.btnLogout.TabIndex = 16;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // MainPanel
            // 
            this.MainPanel.BackColor = System.Drawing.Color.White;
            this.MainPanel.Location = new System.Drawing.Point(0, 96);
            this.MainPanel.Margin = new System.Windows.Forms.Padding(0);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(1463, 618);
            this.MainPanel.TabIndex = 19;
            // 
            // Top_panel
            // 
            this.Top_panel.BackColor = System.Drawing.Color.White;
            this.Top_panel.Controls.Add(this.btnAppointments);
            this.Top_panel.Controls.Add(this.btnLogout);
            this.Top_panel.Controls.Add(this.btnTodaySessions);
            this.Top_panel.Controls.Add(this.btnServices);
            this.Top_panel.Controls.Add(this.btnMedicine);
            this.Top_panel.Controls.Add(this.btnDoctors);
            this.Top_panel.Controls.Add(this.btnDashboard);
            this.Top_panel.Controls.Add(this.btnPatients);
            this.Top_panel.Dock = System.Windows.Forms.DockStyle.Top;
            this.Top_panel.Location = new System.Drawing.Point(0, 0);
            this.Top_panel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Top_panel.Name = "Top_panel";
            this.Top_panel.Size = new System.Drawing.Size(1465, 86);
            this.Top_panel.TabIndex = 5;
            // 
            // btnAppointments
            // 
            this.btnAppointments.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnAppointments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAppointments.FlatAppearance.BorderSize = 0;
            this.btnAppointments.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppointments.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnAppointments.ForeColor = System.Drawing.Color.DimGray;
            this.btnAppointments.Image = global::Clinic.Properties.Resources.AppointmentsBlack_schedule_30px_11;
            this.btnAppointments.Location = new System.Drawing.Point(404, 0);
            this.btnAppointments.Margin = new System.Windows.Forms.Padding(0);
            this.btnAppointments.Name = "btnAppointments";
            this.btnAppointments.Size = new System.Drawing.Size(185, 82);
            this.btnAppointments.TabIndex = 22;
            this.btnAppointments.Tag = "2";
            this.btnAppointments.Text = "Appointments";
            this.btnAppointments.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnAppointments.UseVisualStyleBackColor = false;
            this.btnAppointments.Click += new System.EventHandler(this.btnAppointments_Click);
            // 
            // btnTodaySessions
            // 
            this.btnTodaySessions.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnTodaySessions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTodaySessions.FlatAppearance.BorderSize = 0;
            this.btnTodaySessions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnTodaySessions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTodaySessions.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnTodaySessions.ForeColor = System.Drawing.Color.DimGray;
            this.btnTodaySessions.Image = global::Clinic.Properties.Resources.checkup2_30px;
            this.btnTodaySessions.Location = new System.Drawing.Point(219, 0);
            this.btnTodaySessions.Margin = new System.Windows.Forms.Padding(0);
            this.btnTodaySessions.Name = "btnTodaySessions";
            this.btnTodaySessions.Size = new System.Drawing.Size(185, 82);
            this.btnTodaySessions.TabIndex = 24;
            this.btnTodaySessions.Tag = "1";
            this.btnTodaySessions.Text = "Today Sessions";
            this.btnTodaySessions.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTodaySessions.UseVisualStyleBackColor = false;
            this.btnTodaySessions.Click += new System.EventHandler(this.btnTodaySessions_Click);
            // 
            // btnServices
            // 
            this.btnServices.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnServices.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnServices.FlatAppearance.BorderSize = 0;
            this.btnServices.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnServices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnServices.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnServices.ForeColor = System.Drawing.Color.DimGray;
            this.btnServices.Image = global::Clinic.Properties.Resources.settingsBlack_30px_1;
            this.btnServices.Location = new System.Drawing.Point(1145, 0);
            this.btnServices.Margin = new System.Windows.Forms.Padding(0);
            this.btnServices.Name = "btnServices";
            this.btnServices.Size = new System.Drawing.Size(185, 82);
            this.btnServices.TabIndex = 21;
            this.btnServices.Tag = "32";
            this.btnServices.Text = "Services";
            this.btnServices.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnServices.UseVisualStyleBackColor = false;
            this.btnServices.Click += new System.EventHandler(this.btnServices_Click);
            // 
            // btnMedicine
            // 
            this.btnMedicine.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnMedicine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMedicine.FlatAppearance.BorderSize = 0;
            this.btnMedicine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnMedicine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedicine.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnMedicine.ForeColor = System.Drawing.Color.DimGray;
            this.btnMedicine.Image = global::Clinic.Properties.Resources.pill_30px;
            this.btnMedicine.Location = new System.Drawing.Point(960, 0);
            this.btnMedicine.Margin = new System.Windows.Forms.Padding(0);
            this.btnMedicine.Name = "btnMedicine";
            this.btnMedicine.Size = new System.Drawing.Size(185, 82);
            this.btnMedicine.TabIndex = 25;
            this.btnMedicine.Tag = "16";
            this.btnMedicine.Text = "Medicine";
            this.btnMedicine.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMedicine.UseVisualStyleBackColor = false;
            this.btnMedicine.Click += new System.EventHandler(this.btnMedicine_Click);
            // 
            // btnDoctors
            // 
            this.btnDoctors.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnDoctors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDoctors.FlatAppearance.BorderSize = 0;
            this.btnDoctors.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnDoctors.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDoctors.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnDoctors.ForeColor = System.Drawing.Color.DimGray;
            this.btnDoctors.Image = global::Clinic.Properties.Resources.businessman1_30px_1;
            this.btnDoctors.Location = new System.Drawing.Point(775, 0);
            this.btnDoctors.Margin = new System.Windows.Forms.Padding(0);
            this.btnDoctors.Name = "btnDoctors";
            this.btnDoctors.Size = new System.Drawing.Size(185, 82);
            this.btnDoctors.TabIndex = 23;
            this.btnDoctors.Tag = "8";
            this.btnDoctors.Text = "Doctors";
            this.btnDoctors.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDoctors.UseVisualStyleBackColor = false;
            this.btnDoctors.Click += new System.EventHandler(this.btnDoctors_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.LightGray;
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnDashboard.ForeColor = System.Drawing.Color.DimGray;
            this.btnDashboard.Image = global::Clinic.Properties.Resources.combo_chart_black_30px_2;
            this.btnDashboard.Location = new System.Drawing.Point(0, 0);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(0);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(219, 82);
            this.btnDashboard.TabIndex = 20;
            this.btnDashboard.Text = "Dashboard";
            this.btnDashboard.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // btnPatients
            // 
            this.btnPatients.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnPatients.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPatients.FlatAppearance.BorderSize = 0;
            this.btnPatients.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightCyan;
            this.btnPatients.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPatients.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.btnPatients.ForeColor = System.Drawing.Color.DimGray;
            this.btnPatients.Image = global::Clinic.Properties.Resources.icons8_staff_30px_1;
            this.btnPatients.Location = new System.Drawing.Point(589, 0);
            this.btnPatients.Margin = new System.Windows.Forms.Padding(0);
            this.btnPatients.Name = "btnPatients";
            this.btnPatients.Size = new System.Drawing.Size(185, 82);
            this.btnPatients.TabIndex = 19;
            this.btnPatients.Tag = "4";
            this.btnPatients.Text = "Patients";
            this.btnPatients.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPatients.UseVisualStyleBackColor = false;
            this.btnPatients.Click += new System.EventHandler(this.btnPatients_Click);
            // 
            // MainMenuScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1465, 714);
            this.Controls.Add(this.Top_panel);
            this.Controls.Add(this.MainPanel);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainMenuScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Main Menu Screen";
            this.Load += new System.EventHandler(this.MainMenuScreen_Load);
            this.Top_panel.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel Top_panel;

        private System.Windows.Forms.Panel MainPanel;

        private System.Windows.Forms.Button btnAppointments;
        private System.Windows.Forms.Button btnTodaySessions;
        private System.Windows.Forms.Button btnServices;
        private System.Windows.Forms.Button btnMedicine;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnDoctors;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Button btnPatients;

        #endregion
    }
}