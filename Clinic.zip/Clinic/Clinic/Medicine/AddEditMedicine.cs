﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Medicine
{
    public partial class AddEditMedicine : Form
    {
        private int _MedicineId = -1;

        private MedicineBusinessLayer _Medicine1;

        public AddEditMedicine(int ID = -1)
        {
            InitializeComponent();

            _MedicineId = ID;
        }

        private void AddEditMedicine_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_MedicineId == -1)
            {
                _Medicine1 = new MedicineBusinessLayer();
                lblMode.Text = "Add New Medicine";
            }

            else
            {
                _Medicine1 = MedicineBusinessLayer.FindMedicine(_MedicineId);

                lblMode.Text = "Edit Medicine";
                lblMedicine_id.Text = Convert.ToString(_Medicine1.MedicineId);

                txtMedicine_Name.Text = _Medicine1.MedicineName;
                txtDose.Text = Convert.ToString(_Medicine1.Dose);
                txtHowmanyTimes.Text = Convert.ToString(_Medicine1.Times);
                txtHowManyDays.Text = Convert.ToString(_Medicine1.Days);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var medicineName = txtMedicine_Name.Text.Trim();
            var does = txtDose.Text.Trim();
            var times = txtHowmanyTimes.Text.Trim();
            var days = txtHowManyDays.Text.Trim();

            if (string.IsNullOrEmpty(medicineName) || string.IsNullOrEmpty(does) || string.IsNullOrEmpty(times) ||
                string.IsNullOrEmpty(days))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            lblMode.Text = "Edit Medicine";

            _Medicine1.MedicineName = medicineName;
            _Medicine1.Dose = Convert.ToInt32(does);
            _Medicine1.Times = Convert.ToInt32(times);
            _Medicine1.Days = Convert.ToInt32(days);

            MessageBox.Show(_Medicine1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblMedicine_id.Text = Convert.ToString(_Medicine1.MedicineId);

            _MedicineId = _Medicine1.MedicineId;
        }
    }
}