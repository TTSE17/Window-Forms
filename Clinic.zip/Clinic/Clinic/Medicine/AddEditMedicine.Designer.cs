﻿using System.ComponentModel;

namespace Clinic.Medicine
{
    partial class AddEditMedicine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblMode = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtHowManyDays = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblMedicine_id = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.txtMedicine_Name = new System.Windows.Forms.TextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.txtHowmanyTimes = new System.Windows.Forms.TextBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.txtDose = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblMedicine_id);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.groupBox18);
            this.panel1.Controls.Add(this.groupBox22);
            this.panel1.Controls.Add(this.groupBox23);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(319, 450);
            this.panel1.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Controls.Add(this.lblMode);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(319, 38);
            this.panel2.TabIndex = 75;
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblMode.ForeColor = System.Drawing.Color.DimGray;
            this.lblMode.Location = new System.Drawing.Point(109, 3);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(105, 28);
            this.lblMode.TabIndex = 71;
            this.lblMode.Text = "Add New ";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.txtHowManyDays);
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox5.Location = new System.Drawing.Point(60, 289);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox5.Size = new System.Drawing.Size(210, 51);
            this.groupBox5.TabIndex = 78;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "How Many Days";
            // 
            // txtHowManyDays
            // 
            this.txtHowManyDays.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtHowManyDays.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHowManyDays.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtHowManyDays.ForeColor = System.Drawing.Color.DimGray;
            this.txtHowManyDays.Location = new System.Drawing.Point(4, 25);
            this.txtHowManyDays.Margin = new System.Windows.Forms.Padding(0);
            this.txtHowManyDays.Name = "txtHowManyDays";
            this.txtHowManyDays.Size = new System.Drawing.Size(200, 17);
            this.txtHowManyDays.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(59, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 25);
            this.label1.TabIndex = 73;
            this.label1.Text = "ID :";
            // 
            // lblMedicine_id
            // 
            this.lblMedicine_id.AutoSize = true;
            this.lblMedicine_id.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblMedicine_id.ForeColor = System.Drawing.Color.DimGray;
            this.lblMedicine_id.Location = new System.Drawing.Point(102, 57);
            this.lblMedicine_id.Name = "lblMedicine_id";
            this.lblMedicine_id.Size = new System.Drawing.Size(28, 25);
            this.lblMedicine_id.TabIndex = 72;
            this.lblMedicine_id.Text = "??";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Tai Le", 11.55F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.DimGray;
            this.btnSave.Location = new System.Drawing.Point(109, 375);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(102, 34);
            this.btnSave.TabIndex = 59;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.BackColor = System.Drawing.Color.Transparent;
            this.groupBox18.Controls.Add(this.txtMedicine_Name);
            this.groupBox18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox18.Location = new System.Drawing.Point(60, 99);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox18.Size = new System.Drawing.Size(210, 51);
            this.groupBox18.TabIndex = 72;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Medicine Name";
            // 
            // txtMedicine_Name
            // 
            this.txtMedicine_Name.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtMedicine_Name.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtMedicine_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtMedicine_Name.ForeColor = System.Drawing.Color.DimGray;
            this.txtMedicine_Name.Location = new System.Drawing.Point(5, 25);
            this.txtMedicine_Name.Margin = new System.Windows.Forms.Padding(0);
            this.txtMedicine_Name.Name = "txtMedicine_Name";
            this.txtMedicine_Name.Size = new System.Drawing.Size(200, 17);
            this.txtMedicine_Name.TabIndex = 0;
            // 
            // groupBox22
            // 
            this.groupBox22.BackColor = System.Drawing.Color.Transparent;
            this.groupBox22.Controls.Add(this.txtHowmanyTimes);
            this.groupBox22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox22.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox22.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox22.Location = new System.Drawing.Point(60, 223);
            this.groupBox22.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox22.Size = new System.Drawing.Size(210, 51);
            this.groupBox22.TabIndex = 74;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "How Many Times";
            // 
            // txtHowmanyTimes
            // 
            this.txtHowmanyTimes.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtHowmanyTimes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtHowmanyTimes.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtHowmanyTimes.ForeColor = System.Drawing.Color.DimGray;
            this.txtHowmanyTimes.Location = new System.Drawing.Point(5, 25);
            this.txtHowmanyTimes.Margin = new System.Windows.Forms.Padding(0);
            this.txtHowmanyTimes.Name = "txtHowmanyTimes";
            this.txtHowmanyTimes.Size = new System.Drawing.Size(200, 17);
            this.txtHowmanyTimes.TabIndex = 0;
            // 
            // groupBox23
            // 
            this.groupBox23.BackColor = System.Drawing.Color.Transparent;
            this.groupBox23.Controls.Add(this.txtDose);
            this.groupBox23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox23.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox23.Location = new System.Drawing.Point(59, 159);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox23.Size = new System.Drawing.Size(210, 51);
            this.groupBox23.TabIndex = 73;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Dose";
            // 
            // txtDose
            // 
            this.txtDose.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDose.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDose.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtDose.ForeColor = System.Drawing.Color.DimGray;
            this.txtDose.Location = new System.Drawing.Point(5, 25);
            this.txtDose.Margin = new System.Windows.Forms.Padding(0);
            this.txtDose.Name = "txtDose";
            this.txtDose.Size = new System.Drawing.Size(200, 17);
            this.txtDose.TabIndex = 0;
            // 
            // AddEditMedicine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 450);
            this.Controls.Add(this.panel1);
            this.Name = "AddEditMedicine";
            this.Text = "AddEditMedicine";
            this.Load += new System.EventHandler(this.AddEditMedicine_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtHowManyDays;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMedicine_id;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox txtMedicine_Name;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox txtHowmanyTimes;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox txtDose;

        #endregion
    }
}