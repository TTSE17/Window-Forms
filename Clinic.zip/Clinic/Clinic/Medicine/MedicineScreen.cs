﻿using System;
using System.Data;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Medicine
{
    public partial class MedicineScreen : Form
    {
        public MedicineScreen()
        {
            InitializeComponent();
        }

        private void MedicineScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            GridViewMedicineList.DataSource = MedicineBusinessLayer.GetAllMedicine(Text);
            lbl_Totall_Medicine.Text = Convert.ToString(GridViewMedicineList.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnAddNewMedicine_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditMedicine();
            fr.ShowDialog();
            LoadData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var MedicineID = Convert.ToInt32(GridViewMedicineList.CurrentRow.Cells[0].Value);
            Form fr = new AddEditMedicine(MedicineID);
            fr.ShowDialog();
            LoadData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Delete Medicine",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var MedicineID = Convert.ToInt32(GridViewMedicineList.CurrentRow.Cells[0].Value);

            if (MedicineBusinessLayer.DeleteMedicine(MedicineID))
            {
                MessageBox.Show("Deleted Successfully", "Done");
                LoadData();
            }
            else
            {
                MessageBox.Show("You Can't Delete This Record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}