﻿using System.Windows.Forms;

namespace Clinic
{
    public class OpenForm
    {
        public static Form activeForm = null;
        public static string LastForm = "";
        public static Panel MainPanel = null;

        public static void OpenChildFormInPanel(ref Form childForm)
        {
            if (LastForm == childForm.Text)
            {
                MessageBox.Show("Return");
                return;
            }
            activeForm?.Close();

            activeForm = childForm;
            LastForm = childForm.Text;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            MainPanel.Controls.Add(childForm);
            MainPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
    }
}