﻿using System;
using System.Windows.Forms;
using Clinic.Users;
using ClinicBusinessLayer;

namespace Clinic
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            var UserName = txtUsername.Text.Trim();
            var Password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password))
                MessageBox.Show("Enter Username, Password !");

            else if (UsersBusinessLayer.IsFound(UserName, Password))
            {
                var user1 = UsersBusinessLayer.FindUser(UserName);

                Hide();

                MessageBox.Show("Welcome :)");

                var fr = new MainMenuScreen(user1.Permission);
                fr.ShowDialog();

                Show();
            }

            else
            {
                MessageBox.Show("Incorrect Username, Password");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            UsersScreen fr = new UsersScreen();
            fr.ShowDialog();
        }
    }
}