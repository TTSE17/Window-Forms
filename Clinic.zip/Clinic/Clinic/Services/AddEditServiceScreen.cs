﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Services
{
    public partial class AddEditServiceScreen : Form
    {
        private int _ServiceID = -1;
        private ServicesBusinessLayer _Service1;

        public AddEditServiceScreen(int ID = -1)
        {
            InitializeComponent();
            _ServiceID = ID;
        }

        private void AddEditServiceScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_ServiceID == -1)
            {
                _Service1 = new ServicesBusinessLayer();
                lblMode.Text = "Add New Service";
            }

            else
            {
                _Service1 = ServicesBusinessLayer.FindService(_ServiceID);

                lblMode.Text = "Edit Service";
                lblService_id.Text = Convert.ToString(_Service1.ServiceId);

                txtServiceName.Text = _Service1.ServiceName;
                txtServicePrice.Text = Convert.ToString(_Service1.ServicePrice);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var ServiceName = txtServiceName.Text.Trim();
            var ServicePrice = txtServicePrice.Text.Trim();

            if (string.IsNullOrEmpty(ServiceName) || string.IsNullOrEmpty(ServicePrice))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            lblMode.Text = "Edit Service";

            _Service1.ServiceName = ServiceName;
            _Service1.ServicePrice = Convert.ToDecimal(ServicePrice);


            MessageBox.Show(_Service1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblService_id.Text = Convert.ToString(_Service1.ServiceId);

            _ServiceID = _Service1.ServiceId;
        }
    }
}