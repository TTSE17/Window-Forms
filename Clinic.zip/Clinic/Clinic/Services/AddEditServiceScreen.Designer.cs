﻿using System.ComponentModel;

namespace Clinic.Services
{
    partial class AddEditServiceScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblMode = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblService_id = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.txtServiceName = new System.Windows.Forms.TextBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.txtServicePrice = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel2.Controls.Add(this.lblMode);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(319, 38);
            this.panel2.TabIndex = 85;
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.lblMode.ForeColor = System.Drawing.Color.DimGray;
            this.lblMode.Location = new System.Drawing.Point(109, 3);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(105, 28);
            this.lblMode.TabIndex = 71;
            this.lblMode.Text = "Add New ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(59, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 25);
            this.label1.TabIndex = 83;
            this.label1.Text = "ID :";
            // 
            // lblService_id
            // 
            this.lblService_id.AutoSize = true;
            this.lblService_id.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblService_id.ForeColor = System.Drawing.Color.DimGray;
            this.lblService_id.Location = new System.Drawing.Point(102, 78);
            this.lblService_id.Name = "lblService_id";
            this.lblService_id.Size = new System.Drawing.Size(28, 25);
            this.lblService_id.TabIndex = 80;
            this.lblService_id.Text = "??";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.Gainsboro;
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Tai Le", 11.55F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.DimGray;
            this.btnSave.Location = new System.Drawing.Point(102, 338);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(112, 34);
            this.btnSave.TabIndex = 79;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.BackColor = System.Drawing.Color.Transparent;
            this.groupBox18.Controls.Add(this.txtServiceName);
            this.groupBox18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox18.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox18.Location = new System.Drawing.Point(59, 132);
            this.groupBox18.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox18.Size = new System.Drawing.Size(210, 51);
            this.groupBox18.TabIndex = 81;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Service Name";
            // 
            // txtServiceName
            // 
            this.txtServiceName.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtServiceName.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtServiceName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtServiceName.ForeColor = System.Drawing.Color.DimGray;
            this.txtServiceName.Location = new System.Drawing.Point(5, 25);
            this.txtServiceName.Margin = new System.Windows.Forms.Padding(0);
            this.txtServiceName.Name = "txtServiceName";
            this.txtServiceName.Size = new System.Drawing.Size(200, 17);
            this.txtServiceName.TabIndex = 0;
            // 
            // groupBox23
            // 
            this.groupBox23.BackColor = System.Drawing.Color.Transparent;
            this.groupBox23.Controls.Add(this.txtServicePrice);
            this.groupBox23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox23.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox23.Location = new System.Drawing.Point(59, 225);
            this.groupBox23.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox23.Size = new System.Drawing.Size(210, 51);
            this.groupBox23.TabIndex = 82;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Service  Price";
            // 
            // txtServicePrice
            // 
            this.txtServicePrice.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtServicePrice.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtServicePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.txtServicePrice.ForeColor = System.Drawing.Color.DimGray;
            this.txtServicePrice.Location = new System.Drawing.Point(5, 25);
            this.txtServicePrice.Margin = new System.Windows.Forms.Padding(0);
            this.txtServicePrice.Name = "txtServicePrice";
            this.txtServicePrice.Size = new System.Drawing.Size(200, 17);
            this.txtServicePrice.TabIndex = 0;
            // 
            // AddEditServiceScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 421);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblService_id);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.groupBox18);
            this.Controls.Add(this.groupBox23);
            this.Name = "AddEditServiceScreen";
            this.Text = "AddEditServiceScreen";
            this.Load += new System.EventHandler(this.AddEditServiceScreen_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblService_id;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox txtServiceName;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox txtServicePrice;

        #endregion
    }
}