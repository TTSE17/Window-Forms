﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Services
{
    public partial class ServicesScreen : Form
    {
        public ServicesScreen()
        {
            InitializeComponent();
        }

        private void ServicesScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            GridViewServicesList.DataSource = ServicesBusinessLayer.GetAllServices(Text);
            lbl_Totall_Services.Text = Convert.ToString(GridViewServicesList.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnAddNewService_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditServiceScreen();
            fr.ShowDialog();
            LoadData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ServiceID = Convert.ToInt32(GridViewServicesList.CurrentRow.Cells[0].Value);
            Form fr = new AddEditServiceScreen(ServiceID);
            fr.ShowDialog();
            LoadData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Delete Service",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var ServiceID = Convert.ToInt32(GridViewServicesList.CurrentRow.Cells[0].Value);

            if (ServicesBusinessLayer.DeleteService(ServiceID))
            {
                MessageBox.Show("Deleted Successfully");
                LoadData();
            }
            else
            {
                MessageBox.Show("You Can't Delete This Record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}