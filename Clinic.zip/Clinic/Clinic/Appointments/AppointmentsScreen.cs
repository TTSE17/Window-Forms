﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic
{
    public partial class AppointmentsScreen : Form
    {
        public AppointmentsScreen()
        {
            InitializeComponent();
        }

        private void AppointmentsScreen_Load(object sender, EventArgs e)
        {
            AppointmentsBusinessLayer.UpdateAppointmentsMissed();
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            GridViewAppointmentList.DataSource = AppointmentsBusinessLayer.GetAllAppointments(Text);
            lbl_Totall_Appointments.Text = Convert.ToString(GridViewAppointmentList.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnAddNewAppointment_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditAppointmentScreen();
            fr.ShowDialog();
            LoadData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Check if Missed Or Cancelled Or Confirmed

            var Status = Convert.ToString(GridViewAppointmentList.CurrentRow.Cells[8].Value).Trim();
            
            if(Status!="Unconfirmed")
            {
                MessageBox.Show("You Can't ,The Record " + Status);
                return;
            }            
            var AppointmentID = Convert.ToInt32(GridViewAppointmentList.CurrentRow.Cells[0].Value);
            Form fr = new AddEditAppointmentScreen(AppointmentID);
            fr.ShowDialog();
            LoadData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Delete Appointment",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var AppointmentID = Convert.ToInt32(GridViewAppointmentList.CurrentRow.Cells[0].Value);

            AppointmentsBusinessLayer.DeleteAppointment(AppointmentID);
            LoadData();
        }
    }
}