﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic
{
    public partial class AddEditAppointmentScreen : Form
    {
        private int _AppointmentID = -1;

        private AppointmentsBusinessLayer _Appointment1;

        public AddEditAppointmentScreen(int ID = -1)
        {
            InitializeComponent();

            _AppointmentID = ID;
        }

        private void AddEditAppointmentScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LimitAppointmentDate();
            CheckAvailableAppointmentTime(DateTimePicker.Value.ToString("yyyy-M-d"));

            if (_AppointmentID == -1)
            {
                _Appointment1 = new AppointmentsBusinessLayer();
                lblMode.Text = "Add New Appoitment";
                lblAppointmentID.Text = lblRegistrationDate.Text = "-";
            }

            else
            {
                _Appointment1 = AppointmentsBusinessLayer.FindAppointment(_AppointmentID);

                lblMode.Text = "Edit Appointment";
                lblAppointmentID.Text = Convert.ToString(_Appointment1.AppointmentID);
                lblPatientID.Text = Convert.ToString(_Appointment1.PatientID);
                lblDoctorID.Text = Convert.ToString(_Appointment1.DoctorID);
                lblAppointmentDate.Text = Convert.ToString(_Appointment1.AppointmentDate);
                lblAppointmentTime.Text = _Appointment1.AppointmentTime;
                lblRegistrationDate.Text = _Appointment1.RegistrationDate.ToShortDateString();

                DateTimePicker.Value = _Appointment1.AppointmentDate;
            }
        }

        private void LimitAppointmentDate()
        {
            DateTimePicker.MinDate = DateTime.Now;
        }

        private void CheckAvailableAppointmentTime(string Date)
        {
            var IsFound = false;

            Button[] ArrayAppointmentsTimes =
                { btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn10, btn11, btn12 };
            // MessageBox.Show(Date);

            foreach (var button in ArrayAppointmentsTimes)
            {
                IsFound = AppointmentsBusinessLayer.IsFoundAppointmentTimeInAppointmentDate(button.Text, Date);

                button.Enabled = !IsFound;

                button.BackColor = IsFound ? Color.DarkGray : Color.RoyalBlue;
            }
        }

        private void btnSelectPatient_Click(object sender, EventArgs e)
        {
            var fr = new SelectPatientDoctor("P");
            fr.DataBack += DataBackPatientID; // Subscribe to the event
            fr.ShowDialog();
        }

        private void DataBackPatientID(int ID)
        {
            lblPatientID.Text = Convert.ToString(ID);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var fr = new SelectPatientDoctor("D");
            fr.DataBack += DataBackDoctorID; // Subscribe to the event
            fr.ShowDialog();
        }

        private void DataBackDoctorID(int ID)
        {
            lblDoctorID.Text = Convert.ToString(ID);
        }

        private void DateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            var Date = DateTimePicker.Value.ToString("yyyy-M-d");
            lblAppointmentDate.Text = Date;
            CheckAvailableAppointmentTime(Date);
        }

        private void AppointmentTime_Click(object sender, EventArgs e)
        {
            var AppointmentTime = ((Button)sender).Text;
            lblAppointmentTime.Text = AppointmentTime;
        }

        private void btnReserve_Click(object sender, EventArgs e)
        {
            var PatientID = lblPatientID.Text;
            var DoctorID = lblDoctorID.Text;
            var AppointmentDate = lblAppointmentDate.Text;
            var AppointmentTime = lblAppointmentTime.Text;
            var Status = lblStatus.Text.Trim();

            if (PatientID == "??" || DoctorID == "??" || AppointmentDate == "??" || AppointmentTime == "??")
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            lblMode.Text = "Edit Appointment";

            _Appointment1.PatientID = Convert.ToInt32(PatientID);
            _Appointment1.DoctorID = Convert.ToInt32(DoctorID);
            _Appointment1.AppointmentDate = Convert.ToDateTime(AppointmentDate);
            _Appointment1.AppointmentTime = AppointmentTime;
            _Appointment1.Status = Status;

            if (_AppointmentID == -1)
            {
                _Appointment1.RegistrationDate = DateTime.Now;
                lblRegistrationDate.Text = _Appointment1.RegistrationDate.ToShortDateString();
            }

            MessageBox.Show(
                _Appointment1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblAppointmentID.Text = Convert.ToString(_Appointment1.AppointmentID);

            _AppointmentID = _Appointment1.AppointmentID;
        }
    }
}