﻿using System;
using System.Windows.Forms;

namespace Clinic
{
    public partial class SelectPatientDoctor : Form
    {
        public delegate void DataBackEventHandler(int ID);

        public event DataBackEventHandler DataBack;

        public SelectPatientDoctor(string Selection)
        {
            InitializeComponent();
            SearchPatientDoctor.Selection = Selection;
        }


        private void SelectPatientDoctor_FormClosing(object sender, FormClosingEventArgs e)
        {
            DataBack?.Invoke(SearchPatientDoctor.ID);
            // MessageBox.Show(SearchPatientDoctor.ID + "");
        }
    }
}