﻿using System;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic
{
    public partial class SearchPatientDoctor : UserControl
    {
        public static string Selection = "";

        public static int ID = -1;


        public SearchPatientDoctor()
        {
            InitializeComponent();
        }

        private void SearchPatientDoctor_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            switch (Selection)
            {
                case "P":
                    GridViewList.DataSource = PatientsBusinessLayer.GetAllPatients(Text);
                    break;
                case "D":
                    GridViewList.DataSource = DoctorsBusinessLayer.GetAllDoctors(Text);
                    break;
                case "S":
                    GridViewList.DataSource = ServicesBusinessLayer.GetAllServices(Text);
                    break;
                case "M":
                    GridViewList.DataSource = MedicineBusinessLayer.GetAllMedicine(Text);
                    break;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
             ID = Convert.ToInt32(GridViewList.CurrentRow.Cells[0].Value);

            ((Form)this.TopLevelControl).Close();
        }
    }
}