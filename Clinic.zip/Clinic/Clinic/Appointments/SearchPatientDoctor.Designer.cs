﻿using System.ComponentModel;

namespace Clinic
{
    partial class SearchPatientDoctor
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnAppointmentsListSearch = new System.Windows.Forms.Button();
            this.GridViewList = new System.Windows.Forms.DataGridView();
            this.btnSelect = new System.Windows.Forms.Button();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewList)).BeginInit();
            this.SuspendLayout();
            // 
            // panel8
            // 
            this.panel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.txtSearch);
            this.panel8.Controls.Add(this.btnAppointmentsListSearch);
            this.panel8.Location = new System.Drawing.Point(191, 12);
            this.panel8.Margin = new System.Windows.Forms.Padding(0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(381, 33);
            this.panel8.TabIndex = 4;
            // 
            // txtSearch
            // 
            this.txtSearch.BackColor = System.Drawing.Color.White;
            this.txtSearch.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSearch.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtSearch.ForeColor = System.Drawing.Color.DimGray;
            this.txtSearch.Location = new System.Drawing.Point(44, 7);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(0);
            this.txtSearch.Multiline = true;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(326, 20);
            this.txtSearch.TabIndex = 0;
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // btnAppointmentsListSearch
            // 
            this.btnAppointmentsListSearch.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAppointmentsListSearch.FlatAppearance.BorderSize = 0;
            this.btnAppointmentsListSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAppointmentsListSearch.Image = global::Clinic.Properties.Resources.search_White_20px_11;
            this.btnAppointmentsListSearch.Location = new System.Drawing.Point(0, 0);
            this.btnAppointmentsListSearch.Margin = new System.Windows.Forms.Padding(0);
            this.btnAppointmentsListSearch.Name = "btnAppointmentsListSearch";
            this.btnAppointmentsListSearch.Size = new System.Drawing.Size(36, 33);
            this.btnAppointmentsListSearch.TabIndex = 9;
            this.btnAppointmentsListSearch.UseVisualStyleBackColor = false;
            // 
            // GridViewList
            // 
            this.GridViewList.AllowUserToAddRows = false;
            this.GridViewList.AllowUserToDeleteRows = false;
            this.GridViewList.AllowUserToResizeColumns = false;
            this.GridViewList.AllowUserToResizeRows = false;
            this.GridViewList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewList.BackgroundColor = System.Drawing.Color.White;
            this.GridViewList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridViewList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridViewList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.GridViewList.Location = new System.Drawing.Point(0, 61);
            this.GridViewList.Margin = new System.Windows.Forms.Padding(0);
            this.GridViewList.Name = "GridViewList";
            this.GridViewList.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridViewList.RowHeadersVisible = false;
            this.GridViewList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.GridViewList.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.GridViewList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridViewList.Size = new System.Drawing.Size(795, 343);
            this.GridViewList.TabIndex = 7;
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSelect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSelect.FlatAppearance.BorderSize = 0;
            this.btnSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSelect.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelect.ForeColor = System.Drawing.Color.White;
            this.btnSelect.Location = new System.Drawing.Point(318, 435);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(159, 46);
            this.btnSelect.TabIndex = 81;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // SearchPatientDoctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.GridViewList);
            this.Controls.Add(this.panel8);
            this.Name = "SearchPatientDoctor";
            this.Size = new System.Drawing.Size(795, 507);
            this.Load += new System.EventHandler(this.SearchPatientDoctor_Load);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewList)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button btnSelect;

        private System.Windows.Forms.DataGridView GridViewList;

        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnAppointmentsListSearch;

        #endregion
    }
}