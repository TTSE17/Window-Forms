﻿using System.ComponentModel;

namespace Clinic
{
    partial class AddEditAppointmentScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lblRegistrationDate = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblPatientID = new System.Windows.Forms.Label();
            this.label = new System.Windows.Forms.Label();
            this.lblDoctorID = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblAppointmentTime = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lblAppointmentDate = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAppointmentID = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnSelectDoctor = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSelectPatient = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtn_unconfirmed = new System.Windows.Forms.RadioButton();
            this.rdbtn_confirmed = new System.Windows.Forms.RadioButton();
            this.rdbtn_Missed = new System.Windows.Forms.RadioButton();
            this.rdbtn_Cancelled = new System.Windows.Forms.RadioButton();
            this.btnReserve = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblMode = new System.Windows.Forms.Label();
            this.btnappCancel = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.btnReserve);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(888, 444);
            this.panel1.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.lblRegistrationDate);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.lblStatus);
            this.panel3.Controls.Add(this.lblPatientID);
            this.panel3.Controls.Add(this.label);
            this.panel3.Controls.Add(this.lblDoctorID);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.lblAppointmentTime);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.lblAppointmentDate);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.lblAppointmentID);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(540, 73);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(336, 252);
            this.panel3.TabIndex = 106;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label1.ForeColor = System.Drawing.Color.DimGray;
            this.label1.Location = new System.Drawing.Point(18, 186);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(157, 25);
            this.label1.TabIndex = 150;
            this.label1.Text = "Registration Date :";
            // 
            // lblRegistrationDate
            // 
            this.lblRegistrationDate.AutoSize = true;
            this.lblRegistrationDate.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblRegistrationDate.ForeColor = System.Drawing.Color.DimGray;
            this.lblRegistrationDate.Location = new System.Drawing.Point(181, 186);
            this.lblRegistrationDate.Name = "lblRegistrationDate";
            this.lblRegistrationDate.Size = new System.Drawing.Size(28, 25);
            this.lblRegistrationDate.TabIndex = 149;
            this.lblRegistrationDate.Text = "??";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(17, 219);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 25);
            this.label6.TabIndex = 148;
            this.label6.Text = "Status :";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblStatus.ForeColor = System.Drawing.Color.DimGray;
            this.lblStatus.Location = new System.Drawing.Point(92, 219);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(120, 25);
            this.lblStatus.TabIndex = 147;
            this.lblStatus.Text = "Unconfirmed ";
            // 
            // lblPatientID
            // 
            this.lblPatientID.AutoSize = true;
            this.lblPatientID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblPatientID.ForeColor = System.Drawing.Color.DimGray;
            this.lblPatientID.Location = new System.Drawing.Point(122, 45);
            this.lblPatientID.Name = "lblPatientID";
            this.lblPatientID.Size = new System.Drawing.Size(28, 25);
            this.lblPatientID.TabIndex = 146;
            this.lblPatientID.Text = "??";
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label.ForeColor = System.Drawing.Color.DimGray;
            this.label.Location = new System.Drawing.Point(17, 45);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(103, 25);
            this.label.TabIndex = 145;
            this.label.Text = "Patientt ID :";
            // 
            // lblDoctorID
            // 
            this.lblDoctorID.AutoSize = true;
            this.lblDoctorID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblDoctorID.ForeColor = System.Drawing.Color.DimGray;
            this.lblDoctorID.Location = new System.Drawing.Point(122, 80);
            this.lblDoctorID.Name = "lblDoctorID";
            this.lblDoctorID.Size = new System.Drawing.Size(28, 25);
            this.lblDoctorID.TabIndex = 144;
            this.lblDoctorID.Text = "??";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(17, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(99, 25);
            this.label7.TabIndex = 143;
            this.label7.Text = "Doctor ID :";
            // 
            // lblAppointmentTime
            // 
            this.lblAppointmentTime.AutoSize = true;
            this.lblAppointmentTime.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblAppointmentTime.ForeColor = System.Drawing.Color.DimGray;
            this.lblAppointmentTime.Location = new System.Drawing.Point(193, 115);
            this.lblAppointmentTime.Name = "lblAppointmentTime";
            this.lblAppointmentTime.Size = new System.Drawing.Size(28, 25);
            this.lblAppointmentTime.TabIndex = 142;
            this.lblAppointmentTime.Text = "??";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(17, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(169, 25);
            this.label5.TabIndex = 141;
            this.label5.Text = "Appointment Date :";
            // 
            // lblAppointmentDate
            // 
            this.lblAppointmentDate.AutoSize = true;
            this.lblAppointmentDate.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblAppointmentDate.ForeColor = System.Drawing.Color.DimGray;
            this.lblAppointmentDate.Location = new System.Drawing.Point(192, 151);
            this.lblAppointmentDate.Name = "lblAppointmentDate";
            this.lblAppointmentDate.Size = new System.Drawing.Size(28, 25);
            this.lblAppointmentDate.TabIndex = 140;
            this.lblAppointmentDate.Text = "??";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(17, 115);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 25);
            this.label3.TabIndex = 139;
            this.label3.Text = "Appointment Time :";
            // 
            // lblAppointmentID
            // 
            this.lblAppointmentID.AutoSize = true;
            this.lblAppointmentID.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.lblAppointmentID.ForeColor = System.Drawing.Color.DimGray;
            this.lblAppointmentID.Location = new System.Drawing.Point(173, 10);
            this.lblAppointmentID.Name = "lblAppointmentID";
            this.lblAppointmentID.Size = new System.Drawing.Size(28, 25);
            this.lblAppointmentID.TabIndex = 138;
            this.lblAppointmentID.Text = "??";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(17, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 25);
            this.label2.TabIndex = 137;
            this.label2.Text = "Appointment ID :";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.btnSelectDoctor);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox4.Location = new System.Drawing.Point(22, 156);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox4.Size = new System.Drawing.Size(210, 65);
            this.groupBox4.TabIndex = 105;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Doctor";
            // 
            // btnSelectDoctor
            // 
            this.btnSelectDoctor.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectDoctor.Location = new System.Drawing.Point(3, 23);
            this.btnSelectDoctor.Name = "btnSelectDoctor";
            this.btnSelectDoctor.Size = new System.Drawing.Size(200, 32);
            this.btnSelectDoctor.TabIndex = 105;
            this.btnSelectDoctor.Text = "Select Doctor";
            this.btnSelectDoctor.UseVisualStyleBackColor = true;
            this.btnSelectDoctor.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.btnSelectPatient);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.DimGray;
            this.groupBox2.Location = new System.Drawing.Point(22, 73);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(0);
            this.groupBox2.Size = new System.Drawing.Size(210, 65);
            this.groupBox2.TabIndex = 77;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Patient";
            // 
            // btnSelectPatient
            // 
            this.btnSelectPatient.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSelectPatient.Location = new System.Drawing.Point(3, 23);
            this.btnSelectPatient.Name = "btnSelectPatient";
            this.btnSelectPatient.Size = new System.Drawing.Size(200, 32);
            this.btnSelectPatient.TabIndex = 105;
            this.btnSelectPatient.Text = "Select Patient";
            this.btnSelectPatient.UseVisualStyleBackColor = true;
            this.btnSelectPatient.Click += new System.EventHandler(this.btnSelectPatient_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.DateTimePicker);
            this.groupBox3.Controls.Add(this.pictureBox3);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.btn1);
            this.groupBox3.Controls.Add(this.btn7);
            this.groupBox3.Controls.Add(this.btn6);
            this.groupBox3.Controls.Add(this.btn8);
            this.groupBox3.Controls.Add(this.btn2);
            this.groupBox3.Controls.Add(this.btn9);
            this.groupBox3.Controls.Add(this.btn5);
            this.groupBox3.Controls.Add(this.btn10);
            this.groupBox3.Controls.Add(this.btn3);
            this.groupBox3.Controls.Add(this.btn11);
            this.groupBox3.Controls.Add(this.btn4);
            this.groupBox3.Controls.Add(this.btn12);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.groupBox3.Location = new System.Drawing.Point(273, 73);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(261, 252);
            this.groupBox3.TabIndex = 99;
            this.groupBox3.TabStop = false;
            // 
            // DateTimePicker
            // 
            this.DateTimePicker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DateTimePicker.CustomFormat = "dddd  -  dd  /  MM  /  yyyy ";
            this.DateTimePicker.Font = new System.Drawing.Font("Segoe UI", 9.55F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.DateTimePicker.Location = new System.Drawing.Point(6, 221);
            this.DateTimePicker.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.DateTimePicker.Name = "DateTimePicker";
            this.DateTimePicker.Size = new System.Drawing.Size(237, 24);
            this.DateTimePicker.TabIndex = 25;
            this.DateTimePicker.ValueChanged += new System.EventHandler(this.DateTimePicker_ValueChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.DarkGray;
            this.pictureBox3.Location = new System.Drawing.Point(115, 21);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(15, 15);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 119;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.RoyalBlue;
            this.pictureBox2.Location = new System.Drawing.Point(6, 21);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(15, 15);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 116;
            this.pictureBox2.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label12.Location = new System.Drawing.Point(136, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 17);
            this.label12.TabIndex = 118;
            this.label12.Text = "Not Available";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.Location = new System.Drawing.Point(27, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 17);
            this.label11.TabIndex = 117;
            this.label11.Text = "Available";
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn1.Enabled = false;
            this.btn1.FlatAppearance.BorderSize = 0;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn1.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn1.ForeColor = System.Drawing.Color.White;
            this.btn1.Location = new System.Drawing.Point(6, 51);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 34);
            this.btn1.TabIndex = 88;
            this.btn1.Text = "11:00";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn7.FlatAppearance.BorderSize = 0;
            this.btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn7.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn7.ForeColor = System.Drawing.Color.White;
            this.btn7.Location = new System.Drawing.Point(6, 135);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(75, 34);
            this.btn7.TabIndex = 82;
            this.btn7.Text = "05:00";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn6.FlatAppearance.BorderSize = 0;
            this.btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn6.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn6.ForeColor = System.Drawing.Color.White;
            this.btn6.Location = new System.Drawing.Point(168, 93);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(75, 34);
            this.btn6.TabIndex = 102;
            this.btn6.Text = "04:00";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn8.FlatAppearance.BorderSize = 0;
            this.btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn8.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn8.ForeColor = System.Drawing.Color.White;
            this.btn8.Location = new System.Drawing.Point(87, 135);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(75, 34);
            this.btn8.TabIndex = 83;
            this.btn8.Text = "06:00";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn2.FlatAppearance.BorderSize = 0;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn2.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn2.ForeColor = System.Drawing.Color.White;
            this.btn2.Location = new System.Drawing.Point(87, 51);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 34);
            this.btn2.TabIndex = 89;
            this.btn2.Text = "12:00";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn9.FlatAppearance.BorderSize = 0;
            this.btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn9.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn9.ForeColor = System.Drawing.Color.White;
            this.btn9.Location = new System.Drawing.Point(168, 135);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(75, 34);
            this.btn9.TabIndex = 84;
            this.btn9.Text = "07:00";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn5.FlatAppearance.BorderSize = 0;
            this.btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn5.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn5.ForeColor = System.Drawing.Color.White;
            this.btn5.Location = new System.Drawing.Point(87, 93);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(75, 34);
            this.btn5.TabIndex = 101;
            this.btn5.Text = "03:00";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn10.FlatAppearance.BorderSize = 0;
            this.btn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn10.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn10.ForeColor = System.Drawing.Color.White;
            this.btn10.Location = new System.Drawing.Point(6, 177);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(75, 34);
            this.btn10.TabIndex = 85;
            this.btn10.Text = "08:00";
            this.btn10.UseVisualStyleBackColor = false;
            this.btn10.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn3.FlatAppearance.BorderSize = 0;
            this.btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn3.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn3.ForeColor = System.Drawing.Color.White;
            this.btn3.Location = new System.Drawing.Point(168, 51);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(75, 34);
            this.btn3.TabIndex = 99;
            this.btn3.Text = "01:00";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn11.FlatAppearance.BorderSize = 0;
            this.btn11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn11.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn11.ForeColor = System.Drawing.Color.White;
            this.btn11.Location = new System.Drawing.Point(87, 177);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(75, 34);
            this.btn11.TabIndex = 86;
            this.btn11.Text = "09:00";
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn4.FlatAppearance.BorderSize = 0;
            this.btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn4.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn4.ForeColor = System.Drawing.Color.White;
            this.btn4.Location = new System.Drawing.Point(6, 93);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 34);
            this.btn4.TabIndex = 100;
            this.btn4.Text = "02:00";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn12.FlatAppearance.BorderSize = 0;
            this.btn12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn12.Font = new System.Drawing.Font("Tahoma", 10F);
            this.btn12.ForeColor = System.Drawing.Color.White;
            this.btn12.Location = new System.Drawing.Point(168, 177);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(75, 34);
            this.btn12.TabIndex = 87;
            this.btn12.Text = "10:00";
            this.btn12.UseVisualStyleBackColor = false;
            this.btn12.Click += new System.EventHandler(this.AppointmentTime_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtn_unconfirmed);
            this.groupBox1.Controls.Add(this.rdbtn_confirmed);
            this.groupBox1.Controls.Add(this.rdbtn_Missed);
            this.groupBox1.Controls.Add(this.rdbtn_Cancelled);
            this.groupBox1.Enabled = false;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.groupBox1.Location = new System.Drawing.Point(22, 241);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(210, 84);
            this.groupBox1.TabIndex = 98;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Status:";
            // 
            // rdbtn_unconfirmed
            // 
            this.rdbtn_unconfirmed.AutoSize = true;
            this.rdbtn_unconfirmed.Checked = true;
            this.rdbtn_unconfirmed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rdbtn_unconfirmed.Location = new System.Drawing.Point(13, 25);
            this.rdbtn_unconfirmed.Name = "rdbtn_unconfirmed";
            this.rdbtn_unconfirmed.Size = new System.Drawing.Size(96, 19);
            this.rdbtn_unconfirmed.TabIndex = 93;
            this.rdbtn_unconfirmed.TabStop = true;
            this.rdbtn_unconfirmed.Tag = "unconfirmed";
            this.rdbtn_unconfirmed.Text = "Unconfirmed";
            this.rdbtn_unconfirmed.UseVisualStyleBackColor = true;
            // 
            // rdbtn_confirmed
            // 
            this.rdbtn_confirmed.AutoSize = true;
            this.rdbtn_confirmed.Enabled = false;
            this.rdbtn_confirmed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rdbtn_confirmed.Location = new System.Drawing.Point(123, 25);
            this.rdbtn_confirmed.Name = "rdbtn_confirmed";
            this.rdbtn_confirmed.Size = new System.Drawing.Size(82, 19);
            this.rdbtn_confirmed.TabIndex = 94;
            this.rdbtn_confirmed.Tag = "confirmed";
            this.rdbtn_confirmed.Text = "Confirmed";
            this.rdbtn_confirmed.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Missed
            // 
            this.rdbtn_Missed.AutoSize = true;
            this.rdbtn_Missed.Enabled = false;
            this.rdbtn_Missed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rdbtn_Missed.Location = new System.Drawing.Point(123, 58);
            this.rdbtn_Missed.Name = "rdbtn_Missed";
            this.rdbtn_Missed.Size = new System.Drawing.Size(65, 19);
            this.rdbtn_Missed.TabIndex = 96;
            this.rdbtn_Missed.Tag = "missed";
            this.rdbtn_Missed.Text = "Missed";
            this.rdbtn_Missed.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Cancelled
            // 
            this.rdbtn_Cancelled.AutoSize = true;
            this.rdbtn_Cancelled.Enabled = false;
            this.rdbtn_Cancelled.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.rdbtn_Cancelled.Location = new System.Drawing.Point(13, 58);
            this.rdbtn_Cancelled.Name = "rdbtn_Cancelled";
            this.rdbtn_Cancelled.Size = new System.Drawing.Size(80, 19);
            this.rdbtn_Cancelled.TabIndex = 95;
            this.rdbtn_Cancelled.Tag = "cancelled";
            this.rdbtn_Cancelled.Text = "Cancelled";
            this.rdbtn_Cancelled.UseVisualStyleBackColor = true;
            // 
            // btnReserve
            // 
            this.btnReserve.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(158)))));
            this.btnReserve.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReserve.FlatAppearance.BorderSize = 0;
            this.btnReserve.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReserve.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReserve.ForeColor = System.Drawing.Color.White;
            this.btnReserve.Location = new System.Drawing.Point(328, 371);
            this.btnReserve.Name = "btnReserve";
            this.btnReserve.Size = new System.Drawing.Size(151, 46);
            this.btnReserve.TabIndex = 80;
            this.btnReserve.Text = "Reserve";
            this.btnReserve.UseVisualStyleBackColor = false;
            this.btnReserve.Click += new System.EventHandler(this.btnReserve_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.lblMode);
            this.panel2.Controls.Add(this.btnappCancel);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(888, 55);
            this.panel2.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Clinic.Properties.Resources.tooth_50px_1;
            this.pictureBox1.Location = new System.Drawing.Point(273, 8);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 84;
            this.pictureBox1.TabStop = false;
            // 
            // lblMode
            // 
            this.lblMode.AutoSize = true;
            this.lblMode.BackColor = System.Drawing.Color.Transparent;
            this.lblMode.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.lblMode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(143)))), ((int)(((byte)(158)))));
            this.lblMode.Location = new System.Drawing.Point(328, 15);
            this.lblMode.Name = "lblMode";
            this.lblMode.Size = new System.Drawing.Size(206, 29);
            this.lblMode.TabIndex = 13;
            this.lblMode.Text = "Make Reservation";
            // 
            // btnappCancel
            // 
            this.btnappCancel.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btnappCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnappCancel.FlatAppearance.BorderSize = 0;
            this.btnappCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnappCancel.ForeColor = System.Drawing.Color.Tomato;
            this.btnappCancel.Location = new System.Drawing.Point(1169, -1);
            this.btnappCancel.Name = "btnappCancel";
            this.btnappCancel.Size = new System.Drawing.Size(34, 27);
            this.btnappCancel.TabIndex = 81;
            this.btnappCancel.Text = "x";
            this.btnappCancel.UseVisualStyleBackColor = false;
            // 
            // AddEditAppointmentScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 444);
            this.Controls.Add(this.panel1);
            this.Name = "AddEditAppointmentScreen";
            this.Text = "Add/Edit AppointmentScreen";
            this.Load += new System.EventHandler(this.AddEditAppointmentScreen_Load);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblRegistrationDate;

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblStatus;

        private System.Windows.Forms.Label lblAppointmentID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAppointmentTime;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblDoctorID;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPatientID;
        private System.Windows.Forms.Label label;

        private System.Windows.Forms.Label lblAppointmentDate;

        private System.Windows.Forms.Panel panel3;

        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnSelectDoctor;

        private System.Windows.Forms.GroupBox groupBox2;

        private System.Windows.Forms.Button btnSelectPatient;

        private System.Windows.Forms.DateTimePicker DateTimePicker;

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtn_unconfirmed;
        private System.Windows.Forms.RadioButton rdbtn_confirmed;
        private System.Windows.Forms.RadioButton rdbtn_Missed;
        private System.Windows.Forms.RadioButton rdbtn_Cancelled;
        private System.Windows.Forms.Button btnReserve;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblMode;
        private System.Windows.Forms.Button btnappCancel;

        #endregion
    }
}