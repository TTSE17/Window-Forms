﻿using System.ComponentModel;

namespace Clinic
{
    partial class SelectPatientDoctor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.searchPatientDoctor1 = new Clinic.SearchPatientDoctor();
            this.SuspendLayout();
            // 
            // searchPatientDoctor1
            // 
            this.searchPatientDoctor1.BackColor = System.Drawing.SystemColors.Control;
            this.searchPatientDoctor1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.searchPatientDoctor1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.searchPatientDoctor1.Location = new System.Drawing.Point(0, 0);
            this.searchPatientDoctor1.Name = "searchPatientDoctor1";
            this.searchPatientDoctor1.Size = new System.Drawing.Size(801, 498);
            this.searchPatientDoctor1.TabIndex = 0;
            // 
            // SelectPatientDoctor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 498);
            this.Controls.Add(this.searchPatientDoctor1);
            this.Name = "SelectPatientDoctor";
            this.Text = "SelectPatientDoctor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SelectPatientDoctor_FormClosing);
            this.ResumeLayout(false);
        }

        private Clinic.SearchPatientDoctor searchPatientDoctor1;

        #endregion
    }
}