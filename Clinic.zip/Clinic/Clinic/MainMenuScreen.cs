﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Clinic.DashBoard;
using Clinic.Doctors;
using Clinic.Medicine;
using Clinic.Patients;
using Clinic.Services;
using Clinic.TodaySession;

namespace Clinic
{
    public partial class MainMenuScreen : Form
    {
        private Form fr = null;
        private Button LastButton = null;
        private int _Permissions = -1;

        public MainMenuScreen(int Permissions)
        {
            InitializeComponent();

            OpenForm.MainPanel = MainPanel;
            OpenForm.LastForm = "";
            OpenForm.activeForm = null;

            _Permissions = Permissions;
        }

        private void MainMenuScreen_Load(object sender, EventArgs e)
        {
            btnDashboard.PerformClick();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnDashboard);

            fr = new DashBoardScreen(_Permissions);
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Home";
        }

        private void btnTodaySessions_Click(object sender, EventArgs e)
        {
            if (!HasPermission(Convert.ToInt32(((Button)sender).Tag)))
            {
                MessageBox.Show("You Haven't Permission");
                return;
            }

            ChangeActiveButton(btnTodaySessions);

            fr = new TodaySessionsScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Today Sessions";
        }

        private void btnAppointments_Click(object sender, EventArgs e)
        {
            if (!HasPermission(Convert.ToInt32(((Button)sender).Tag)))
            {
                MessageBox.Show("You Haven't Permission");
                return;
            }

            ChangeActiveButton(btnAppointments);

            fr = new AppointmentsScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Appointments";
        }

        private void btnPatients_Click(object sender, EventArgs e)
        {
            if (!HasPermission(Convert.ToInt32(((Button)sender).Tag)))
            {
                MessageBox.Show("You Haven't Permission");
                return;
            }

            ChangeActiveButton(btnPatients);

            fr = new PatientsScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Patients";
        }

        private void btnDoctors_Click(object sender, EventArgs e)
        {
            if (!HasPermission(Convert.ToInt32(((Button)sender).Tag)))
            {
                MessageBox.Show("You Haven't Permission");
                return;
            }

            ChangeActiveButton(btnDoctors);

            fr = new DoctorsScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Doctors";
        }

        private void btnMedicine_Click(object sender, EventArgs e)
        {
            if (!HasPermission(Convert.ToInt32(((Button)sender).Tag)))
            {
                MessageBox.Show("You Haven't Permission");
                return;
            }

            ChangeActiveButton(btnMedicine);

            fr = new MedicineScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Medicine";
        }

        private void btnServices_Click(object sender, EventArgs e)
        {
            if (!HasPermission(Convert.ToInt32(((Button)sender).Tag)))
            {
                MessageBox.Show("You Haven't Permission");
                return;
            }

            ChangeActiveButton(btnServices);

            fr = new ServicesScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
            Text = "Services";
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void ChangeActiveButton(Button ActiveButton)
        {
            if (LastButton != null)
                LastButton.BackColor = Color.WhiteSmoke;

            ActiveButton.BackColor = Color.LightGray;
            LastButton = ActiveButton;
        }

        private bool HasPermission(int SectionPermission)
        {
            return ((SectionPermission & _Permissions) == SectionPermission) || _Permissions == -1;
        }
    }
}