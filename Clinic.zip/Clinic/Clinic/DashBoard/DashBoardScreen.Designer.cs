﻿using System.ComponentModel;

namespace Clinic.DashBoard
{
    partial class DashBoardScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblDateToday = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.MainContainer = new System.Windows.Forms.FlowLayoutPanel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnAll = new System.Windows.Forms.Button();
            this.lblMissed = new System.Windows.Forms.Label();
            this.lbl_Cnacelled = new System.Windows.Forms.Label();
            this.lbl_Confirmed = new System.Windows.Forms.Label();
            this.lbl_unconfirmed = new System.Windows.Forms.Label();
            this.btn_unconfirmed = new System.Windows.Forms.Button();
            this.btn_confirmed = new System.Windows.Forms.Button();
            this.btn_Cancelled = new System.Windows.Forms.Button();
            this.btn_Missed = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_Total_Doctors = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_Total_Medicine = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbl_Today_Sessions = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.lbl_Total_Services = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.flowLayoutPanelRight = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lbl_Total_Appointments = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_Total_Patients = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.flowLayoutPanelRight.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.panel7);
            this.panel8.Controls.Add(this.MainContainer);
            this.panel8.Controls.Add(this.panel10);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(916, 462);
            this.panel8.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightCyan;
            this.panel7.Controls.Add(this.lblDateToday);
            this.panel7.Controls.Add(this.lblTime);
            this.panel7.Location = new System.Drawing.Point(3, 381);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel7.Name = "panel7";
            this.panel7.Padding = new System.Windows.Forms.Padding(1);
            this.panel7.Size = new System.Drawing.Size(184, 78);
            this.panel7.TabIndex = 58;
            // 
            // lblDateToday
            // 
            this.lblDateToday.AutoSize = true;
            this.lblDateToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateToday.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDateToday.Location = new System.Drawing.Point(40, 15);
            this.lblDateToday.Name = "lblDateToday";
            this.lblDateToday.Size = new System.Drawing.Size(120, 25);
            this.lblDateToday.TabIndex = 36;
            this.lblDateToday.Text = "2022/12/31";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblTime.Location = new System.Drawing.Point(46, 50);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(66, 25);
            this.lblTime.TabIndex = 37;
            this.lblTime.Text = "12:00";
            // 
            // MainContainer
            // 
            this.MainContainer.AutoScroll = true;
            this.MainContainer.Location = new System.Drawing.Point(193, 13);
            this.MainContainer.Name = "MainContainer";
            this.MainContainer.Size = new System.Drawing.Size(720, 446);
            this.MainContainer.TabIndex = 30;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.LimeGreen;
            this.panel10.Controls.Add(this.lblTotal);
            this.panel10.Controls.Add(this.btnAll);
            this.panel10.Controls.Add(this.lblMissed);
            this.panel10.Controls.Add(this.lbl_Cnacelled);
            this.panel10.Controls.Add(this.lbl_Confirmed);
            this.panel10.Controls.Add(this.lbl_unconfirmed);
            this.panel10.Controls.Add(this.btn_unconfirmed);
            this.panel10.Controls.Add(this.btn_confirmed);
            this.panel10.Controls.Add(this.btn_Cancelled);
            this.panel10.Controls.Add(this.btn_Missed);
            this.panel10.Location = new System.Drawing.Point(3, 13);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(184, 240);
            this.panel10.TabIndex = 1;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Tahoma", 13F);
            this.lblTotal.ForeColor = System.Drawing.Color.White;
            this.lblTotal.Location = new System.Drawing.Point(158, 9);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(20, 22);
            this.lblTotal.TabIndex = 34;
            this.lblTotal.Text = "0";
            // 
            // btnAll
            // 
            this.btnAll.AutoSize = true;
            this.btnAll.BackColor = System.Drawing.Color.LimeGreen;
            this.btnAll.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAll.FlatAppearance.BorderSize = 0;
            this.btnAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAll.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btnAll.ForeColor = System.Drawing.Color.White;
            this.btnAll.Location = new System.Drawing.Point(6, 2);
            this.btnAll.Margin = new System.Windows.Forms.Padding(0);
            this.btnAll.Name = "btnAll";
            this.btnAll.Size = new System.Drawing.Size(42, 35);
            this.btnAll.TabIndex = 35;
            this.btnAll.Text = "All";
            this.btnAll.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAll.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btnAll.UseVisualStyleBackColor = false;
            this.btnAll.Click += new System.EventHandler(this.Button_Click);
            // 
            // lblMissed
            // 
            this.lblMissed.AutoSize = true;
            this.lblMissed.BackColor = System.Drawing.Color.Transparent;
            this.lblMissed.Font = new System.Drawing.Font("Tahoma", 13F);
            this.lblMissed.ForeColor = System.Drawing.Color.Transparent;
            this.lblMissed.Location = new System.Drawing.Point(158, 179);
            this.lblMissed.Name = "lblMissed";
            this.lblMissed.Size = new System.Drawing.Size(20, 22);
            this.lblMissed.TabIndex = 27;
            this.lblMissed.Text = "0";
            // 
            // lbl_Cnacelled
            // 
            this.lbl_Cnacelled.AutoSize = true;
            this.lbl_Cnacelled.Font = new System.Drawing.Font("Tahoma", 13F);
            this.lbl_Cnacelled.ForeColor = System.Drawing.Color.White;
            this.lbl_Cnacelled.Location = new System.Drawing.Point(158, 138);
            this.lbl_Cnacelled.Name = "lbl_Cnacelled";
            this.lbl_Cnacelled.Size = new System.Drawing.Size(20, 22);
            this.lbl_Cnacelled.TabIndex = 26;
            this.lbl_Cnacelled.Text = "0";
            // 
            // lbl_Confirmed
            // 
            this.lbl_Confirmed.AutoSize = true;
            this.lbl_Confirmed.Font = new System.Drawing.Font("Tahoma", 13F);
            this.lbl_Confirmed.ForeColor = System.Drawing.Color.White;
            this.lbl_Confirmed.Location = new System.Drawing.Point(158, 94);
            this.lbl_Confirmed.Name = "lbl_Confirmed";
            this.lbl_Confirmed.Size = new System.Drawing.Size(20, 22);
            this.lbl_Confirmed.TabIndex = 25;
            this.lbl_Confirmed.Text = "0";
            // 
            // lbl_unconfirmed
            // 
            this.lbl_unconfirmed.AutoSize = true;
            this.lbl_unconfirmed.Font = new System.Drawing.Font("Tahoma", 13F);
            this.lbl_unconfirmed.ForeColor = System.Drawing.Color.White;
            this.lbl_unconfirmed.Location = new System.Drawing.Point(158, 51);
            this.lbl_unconfirmed.Name = "lbl_unconfirmed";
            this.lbl_unconfirmed.Size = new System.Drawing.Size(20, 22);
            this.lbl_unconfirmed.TabIndex = 24;
            this.lbl_unconfirmed.Text = "0";
            // 
            // btn_unconfirmed
            // 
            this.btn_unconfirmed.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_unconfirmed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_unconfirmed.FlatAppearance.BorderSize = 0;
            this.btn_unconfirmed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_unconfirmed.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btn_unconfirmed.ForeColor = System.Drawing.Color.White;
            this.btn_unconfirmed.Location = new System.Drawing.Point(6, 45);
            this.btn_unconfirmed.Margin = new System.Windows.Forms.Padding(0);
            this.btn_unconfirmed.Name = "btn_unconfirmed";
            this.btn_unconfirmed.Size = new System.Drawing.Size(123, 32);
            this.btn_unconfirmed.TabIndex = 30;
            this.btn_unconfirmed.Tag = "Unconfirmed";
            this.btn_unconfirmed.Text = "Unconfirmed";
            this.btn_unconfirmed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_unconfirmed.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_unconfirmed.UseVisualStyleBackColor = false;
            this.btn_unconfirmed.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn_confirmed
            // 
            this.btn_confirmed.AutoSize = true;
            this.btn_confirmed.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_confirmed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_confirmed.FlatAppearance.BorderSize = 0;
            this.btn_confirmed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_confirmed.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btn_confirmed.ForeColor = System.Drawing.Color.White;
            this.btn_confirmed.Location = new System.Drawing.Point(6, 87);
            this.btn_confirmed.Margin = new System.Windows.Forms.Padding(0);
            this.btn_confirmed.Name = "btn_confirmed";
            this.btn_confirmed.Size = new System.Drawing.Size(106, 35);
            this.btn_confirmed.TabIndex = 31;
            this.btn_confirmed.Tag = "Confirmed";
            this.btn_confirmed.Text = "Confirmed";
            this.btn_confirmed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_confirmed.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_confirmed.UseVisualStyleBackColor = false;
            this.btn_confirmed.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn_Cancelled
            // 
            this.btn_Cancelled.AutoSize = true;
            this.btn_Cancelled.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_Cancelled.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Cancelled.FlatAppearance.BorderSize = 0;
            this.btn_Cancelled.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cancelled.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btn_Cancelled.ForeColor = System.Drawing.Color.White;
            this.btn_Cancelled.Location = new System.Drawing.Point(6, 131);
            this.btn_Cancelled.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Cancelled.Name = "btn_Cancelled";
            this.btn_Cancelled.Size = new System.Drawing.Size(97, 35);
            this.btn_Cancelled.TabIndex = 32;
            this.btn_Cancelled.Tag = "Cancelled";
            this.btn_Cancelled.Text = "Cancelled";
            this.btn_Cancelled.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Cancelled.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Cancelled.UseVisualStyleBackColor = false;
            this.btn_Cancelled.Click += new System.EventHandler(this.Button_Click);
            // 
            // btn_Missed
            // 
            this.btn_Missed.AutoSize = true;
            this.btn_Missed.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_Missed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Missed.FlatAppearance.BorderSize = 0;
            this.btn_Missed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Missed.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.btn_Missed.ForeColor = System.Drawing.Color.White;
            this.btn_Missed.Location = new System.Drawing.Point(6, 172);
            this.btn_Missed.Margin = new System.Windows.Forms.Padding(0);
            this.btn_Missed.Name = "btn_Missed";
            this.btn_Missed.Size = new System.Drawing.Size(78, 35);
            this.btn_Missed.TabIndex = 33;
            this.btn_Missed.Tag = "Missed";
            this.btn_Missed.Text = "Missed";
            this.btn_Missed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_Missed.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.btn_Missed.UseVisualStyleBackColor = false;
            this.btn_Missed.Click += new System.EventHandler(this.Button_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightCyan;
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.lbl_Total_Doctors);
            this.panel2.Location = new System.Drawing.Point(13, 150);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.panel2.Size = new System.Drawing.Size(131, 53);
            this.panel2.TabIndex = 53;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox4.Image = global::Clinic.Properties.Resources._3467830;
            this.pictureBox4.Location = new System.Drawing.Point(85, 6);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(35, 29);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(13, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 17);
            this.label7.TabIndex = 5;
            this.label7.Text = "Doctors";
            // 
            // lbl_Total_Doctors
            // 
            this.lbl_Total_Doctors.AutoSize = true;
            this.lbl_Total_Doctors.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total_Doctors.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Total_Doctors.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lbl_Total_Doctors.Location = new System.Drawing.Point(13, 12);
            this.lbl_Total_Doctors.Name = "lbl_Total_Doctors";
            this.lbl_Total_Doctors.Size = new System.Drawing.Size(18, 20);
            this.lbl_Total_Doctors.TabIndex = 4;
            this.lbl_Total_Doctors.Text = "0";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightCyan;
            this.panel3.Controls.Add(this.lbl_Total_Medicine);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(13, 282);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(1);
            this.panel3.Size = new System.Drawing.Size(131, 53);
            this.panel3.TabIndex = 54;
            // 
            // lbl_Total_Medicine
            // 
            this.lbl_Total_Medicine.AutoSize = true;
            this.lbl_Total_Medicine.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total_Medicine.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Total_Medicine.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lbl_Total_Medicine.Location = new System.Drawing.Point(13, 8);
            this.lbl_Total_Medicine.Name = "lbl_Total_Medicine";
            this.lbl_Total_Medicine.Size = new System.Drawing.Size(18, 20);
            this.lbl_Total_Medicine.TabIndex = 12;
            this.lbl_Total_Medicine.Text = "0";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox2.Image = global::Clinic.Properties.Resources.hand_with_a_pill_30px_1;
            this.pictureBox2.Location = new System.Drawing.Point(85, 1);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 36);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 14;
            this.pictureBox2.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(7, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Medicine";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.LightCyan;
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Controls.Add(this.lbl_Today_Sessions);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Location = new System.Drawing.Point(13, 348);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel4.Name = "panel4";
            this.panel4.Padding = new System.Windows.Forms.Padding(10);
            this.panel4.Size = new System.Drawing.Size(131, 53);
            this.panel4.TabIndex = 55;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox3.Image = global::Clinic.Properties.Resources.icons8_new_ticket_26px;
            this.pictureBox3.Location = new System.Drawing.Point(85, 1);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(35, 29);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 18;
            this.pictureBox3.TabStop = false;
            // 
            // lbl_Today_Sessions
            // 
            this.lbl_Today_Sessions.AutoSize = true;
            this.lbl_Today_Sessions.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Today_Sessions.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Today_Sessions.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lbl_Today_Sessions.Location = new System.Drawing.Point(13, 10);
            this.lbl_Today_Sessions.Name = "lbl_Today_Sessions";
            this.lbl_Today_Sessions.Size = new System.Drawing.Size(18, 20);
            this.lbl_Today_Sessions.TabIndex = 16;
            this.lbl_Today_Sessions.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(5, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(114, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Today Sessions";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.LightCyan;
            this.panel5.Controls.Add(this.lbl_Total_Services);
            this.panel5.Controls.Add(this.pictureBox5);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Location = new System.Drawing.Point(13, 216);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(1);
            this.panel5.Size = new System.Drawing.Size(131, 53);
            this.panel5.TabIndex = 57;
            // 
            // lbl_Total_Services
            // 
            this.lbl_Total_Services.AutoSize = true;
            this.lbl_Total_Services.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total_Services.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Total_Services.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lbl_Total_Services.Location = new System.Drawing.Point(13, 8);
            this.lbl_Total_Services.Name = "lbl_Total_Services";
            this.lbl_Total_Services.Size = new System.Drawing.Size(18, 20);
            this.lbl_Total_Services.TabIndex = 12;
            this.lbl_Total_Services.Text = "0";
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox5.Image = global::Clinic.Properties.Resources.services_30px;
            this.pictureBox5.Location = new System.Drawing.Point(85, 1);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(35, 36);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 14;
            this.pictureBox5.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.DimGray;
            this.label4.Location = new System.Drawing.Point(7, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Services ";
            // 
            // flowLayoutPanelRight
            // 
            this.flowLayoutPanelRight.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanelRight.Controls.Add(this.panel6);
            this.flowLayoutPanelRight.Controls.Add(this.panel1);
            this.flowLayoutPanelRight.Controls.Add(this.panel2);
            this.flowLayoutPanelRight.Controls.Add(this.panel5);
            this.flowLayoutPanelRight.Controls.Add(this.panel3);
            this.flowLayoutPanelRight.Controls.Add(this.panel4);
            this.flowLayoutPanelRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.flowLayoutPanelRight.Location = new System.Drawing.Point(924, 0);
            this.flowLayoutPanelRight.Margin = new System.Windows.Forms.Padding(5);
            this.flowLayoutPanelRight.Name = "flowLayoutPanelRight";
            this.flowLayoutPanelRight.Padding = new System.Windows.Forms.Padding(10);
            this.flowLayoutPanelRight.Size = new System.Drawing.Size(157, 462);
            this.flowLayoutPanelRight.TabIndex = 3;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightCyan;
            this.panel6.Controls.Add(this.lbl_Total_Appointments);
            this.panel6.Controls.Add(this.label6);
            this.panel6.Controls.Add(this.pictureBox6);
            this.panel6.Location = new System.Drawing.Point(13, 13);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.panel6.Size = new System.Drawing.Size(139, 58);
            this.panel6.TabIndex = 53;
            // 
            // lbl_Total_Appointments
            // 
            this.lbl_Total_Appointments.AutoSize = true;
            this.lbl_Total_Appointments.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total_Appointments.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Total_Appointments.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lbl_Total_Appointments.Location = new System.Drawing.Point(13, 10);
            this.lbl_Total_Appointments.Name = "lbl_Total_Appointments";
            this.lbl_Total_Appointments.Size = new System.Drawing.Size(18, 20);
            this.lbl_Total_Appointments.TabIndex = 11;
            this.lbl_Total_Appointments.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(14, 35);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(106, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Appointments";
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox6.Image = global::Clinic.Properties.Resources.AppointmentsBlack_schedule_30px_1;
            this.pictureBox6.Location = new System.Drawing.Point(85, 6);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(35, 29);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 13;
            this.pictureBox6.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightCyan;
            this.panel1.Controls.Add(this.lbl_Total_Patients);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(13, 84);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.panel1.Size = new System.Drawing.Size(131, 53);
            this.panel1.TabIndex = 54;
            // 
            // lbl_Total_Patients
            // 
            this.lbl_Total_Patients.AutoSize = true;
            this.lbl_Total_Patients.BackColor = System.Drawing.Color.Transparent;
            this.lbl_Total_Patients.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lbl_Total_Patients.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lbl_Total_Patients.Location = new System.Drawing.Point(13, 10);
            this.lbl_Total_Patients.Name = "lbl_Total_Patients";
            this.lbl_Total_Patients.Size = new System.Drawing.Size(18, 20);
            this.lbl_Total_Patients.TabIndex = 11;
            this.lbl_Total_Patients.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(13, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Patients";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.LightCyan;
            this.pictureBox1.Image = global::Clinic.Properties.Resources.wheelchair_26px;
            this.pictureBox1.Location = new System.Drawing.Point(85, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(35, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // DashBoardScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1081, 462);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.flowLayoutPanelRight);
            this.Name = "DashBoardScreen";
            this.Text = "DashBoardScreen";
            this.Load += new System.EventHandler(this.DashBoardScreen_Load);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.flowLayoutPanelRight.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panel7;

        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label lbl_Total_Appointments;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox6;

        private System.Windows.Forms.Timer timer1;

        private System.Windows.Forms.Label lblDateToday;
        private System.Windows.Forms.Label lblTime;

        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnAll;

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label lbl_Total_Services;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label4;

        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.FlowLayoutPanel MainContainer;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lblMissed;
        private System.Windows.Forms.Label lbl_Cnacelled;
        private System.Windows.Forms.Label lbl_Confirmed;
        private System.Windows.Forms.Label lbl_unconfirmed;
        private System.Windows.Forms.Button btn_unconfirmed;
        private System.Windows.Forms.Button btn_confirmed;
        private System.Windows.Forms.Button btn_Cancelled;
        private System.Windows.Forms.Button btn_Missed;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanelRight;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_Total_Patients;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_Total_Doctors;

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbl_Total_Medicine;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lbl_Today_Sessions;
        private System.Windows.Forms.Label label8;

        #endregion
    }
}