﻿using System.Windows.Forms;

namespace Clinic.DashBoard
{
    public partial class TheSession2 : UserControl
    {
        public TheSession2()
        {
            InitializeComponent();
        }
    }
}