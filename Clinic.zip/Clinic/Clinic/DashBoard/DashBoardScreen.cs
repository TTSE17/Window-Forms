﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.DashBoard
{
    public partial class DashBoardScreen : Form
    {
        private readonly int _Permission = -1;

        public DashBoardScreen(int Permissions)
        {
            InitializeComponent();

            _Permission = Permissions;
        }

        private void DashBoardScreen_Load(object sender, EventArgs e)
        {
            lblDateToday.Text = DateTime.Now.ToString("yyyy-MM-dd");
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");

            LoadData("");
            NumberEveryThing();
        }

        private void NumberEveryThing()
        {
            var DT = DashboardBusinessLayer.GetNumberEveryThing();
            lbl_Total_Appointments.Text = Convert.ToString(DT.Rows[0][0]);
            lblTotal.Text = lbl_Total_Appointments.Text;
            lbl_Total_Patients.Text = Convert.ToString(DT.Rows[0][1]);
            lbl_Total_Doctors.Text = Convert.ToString(DT.Rows[0][2]);
            lbl_Total_Services.Text = Convert.ToString(DT.Rows[0][3]);
            lbl_Total_Medicine.Text = Convert.ToString(DT.Rows[0][4]);
            lbl_Today_Sessions.Text = Convert.ToString(DT.Rows[0][5]);
            lbl_Confirmed.Text = Convert.ToString(DT.Rows[0][6]);
            lbl_unconfirmed.Text = Convert.ToString(DT.Rows[0][7]);
            lbl_Cnacelled.Text = Convert.ToString(DT.Rows[0][8]);
            lblMissed.Text = Convert.ToString(DT.Rows[0][9]);
        }

        private void LoadData(string Status = "")
        {
            DataTable dt = AppointmentsBusinessLayer.GetAllAppointments("", Status);

            MainContainer.Controls.Clear();

            foreach (DataRow Row in dt.Rows)
            {
                CreateSession(Row);
            }
        }

        private void CreateSession(DataRow Record)
        {
            var Status = Convert.ToString(Record[8]).Trim();


            var Item = new TheSession2();

            Item.lblPatientName.Text = Convert.ToString(Record[1]);
            Item.lblDoctorName.Text = Convert.ToString(Record[2]);
            Item.lblDate.Text = Convert.ToDateTime((Record[3])).ToString("yyyy-MM-dd");
            Item.lblTime.Text = Convert.ToString(Record[4]);

            if (Status == "Confirmed")
                Item.BackColor = Color.FromArgb(125, 238, 115);

            else if (Status == "Cancelled" || Status == "Missed")
                Item.BackColor = Color.FromArgb(255, 188, 185);

            MainContainer.Controls.Add(Item);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDateToday.Text = DateTime.Now.ToString("yyyy-MM-dd");
            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
        }

        private void Button_Click(object sender, EventArgs e)
        {
            var btn = (Button)sender;
            LoadData(Convert.ToString(btn.Tag));
        }

  
    }
}