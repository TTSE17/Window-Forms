﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Patients
{
    public partial class AddEditPatientScreen : Form
    {
        private int _PatientID = -1;

        private PatientsBusinessLayer Patient1;

        private PersonBusinessLayer Person1;

        public AddEditPatientScreen(int Id = -1)
        {
            InitializeComponent();

            _PatientID = Id;
        }

        private void AddEditPatientScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadCountries();

            if (_PatientID == -1)
            {
                Patient1 = new PatientsBusinessLayer();
                Person1 = new PersonBusinessLayer();
                lblMode.Text = "Add New Patient";
                lblPatientID.Text = lblRegistrationDate.Text = "-";
            }

            else
            {
                Patient1 = PatientsBusinessLayer.FindPatient(_PatientID);
                Person1 = PersonBusinessLayer.FindPerson(Patient1.PersonID);

                lblMode.Text = "Edit Employee";
                lblPatientID.Text = Convert.ToString(Patient1.PatientID);
                lblRegistrationDate.Text = Patient1.RegistrationDate.ToShortDateString();

                txtFirstname.Text = Person1.FirstName;
                txtMiddleName.Text = Person1.MiddleName;
                txtLastname.Text = Person1.LastName;
                txtEmail.Text = Person1.Email;
                txtPhone.Text = Person1.Phone;
                txtAddress.Text = Person1.Address;
                DateTimePicker.Value = Person1.BirthDate;

                if (Person1.ImagePath != "NULL" || string.IsNullOrEmpty(Person1.ImagePath))
                {
                    Patient_pictureBox.Load(Person1.ImagePath);
                }

                cmbGender.SelectedIndex = cmbGender.FindString(Person1.Gender);
                cbCountries1.SelectedIndex =
                    cbCountries1.FindString(CountryBusinessLayer.FindCountry(Person1.CountryID).CountryName);
            }
        }

        private void LoadCountries()
        {
            DataTable dt = CountryBusinessLayer.GetAllCountries();

            foreach (DataRow Row in dt.Rows)
            {
                cbCountries1.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var FirstName = txtFirstname.Text.Trim();
            var MiddleName = txtMiddleName.Text.Trim();
            var LastName = txtLastname.Text.Trim();
            var Email = txtEmail.Text.Trim();
            var Phone = txtPhone.Text.Trim();
            var Address = txtAddress.Text.Trim();
            var ImagePath = Patient_pictureBox.ImageLocation;
            var Gender = Convert.ToString(cmbGender.SelectedItem);
            var BirthDate = DateTimePicker.Value;
            var CountryName = Convert.ToString(cbCountries1.SelectedItem);


            if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(MiddleName) ||
                string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Phone) || string.IsNullOrEmpty(Address) ||
                string.IsNullOrEmpty(Gender))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            lblMode.Text = "Edit Patient";

            Person1.FirstName = FirstName;
            Person1.MiddleName = MiddleName;
            Person1.LastName = LastName;
            Person1.Email = Email;
            Person1.Phone = Phone;
            Person1.Address = Address;
            Person1.ImagePath = ImagePath ?? "NULL";
            Person1.Gender = Gender;
            Person1.BirthDate = BirthDate;
            Person1.CountryID = (string.IsNullOrEmpty(CountryName))
                ? 0
                : CountryBusinessLayer.FindCountry(CountryName).CountryID;


            Person1.Save();

            Patient1.PersonID = Person1.PersonId;
            if(_PatientID==-1)
                Patient1.RegistrationDate = DateTime.Now;


            MessageBox.Show(Patient1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblPatientID.Text = Convert.ToString(Patient1.PatientID);
            lblRegistrationDate.Text = Patient1.RegistrationDate.ToShortDateString();
            
            _PatientID = Patient1.PatientID;
        }

        private void btn_UploadPhoto_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                // Process the selected file
                string selectedFilePath = openFileDialog1.FileName;
                //MessageBox.Show("Selected Image is:" + selectedFilePath);

                Patient_pictureBox.Load(selectedFilePath);
                // ...
            }
        }

        private void linkLabel_RemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Patient_pictureBox.ImageLocation = null;
        }
    }
}