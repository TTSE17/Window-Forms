﻿using System;
using System.Data;
using System.Windows.Forms;
using ClinicBusinessLayer;

namespace Clinic.Patients
{
    public partial class PatientsScreen : Form
    {
        public PatientsScreen()
        {
            InitializeComponent();
        }

        private void PatientsScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData(string Text = "")
        {
            GridViewPatientsList.DataSource = PatientsBusinessLayer.GetAllPatients(Text);
            lbl_Totall_Patients.Text = Convert.ToString(GridViewPatientsList.Rows.Count);
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadData(txtSearch.Text.Trim());
        }

        private void btnAddNewAppointment_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditPatientScreen();
            fr.ShowDialog();
            LoadData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var PatientID = Convert.ToInt32(GridViewPatientsList.CurrentRow.Cells[0].Value);
            Form fr = new AddEditPatientScreen(PatientID);
            fr.ShowDialog();
            LoadData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var check = MessageBox.Show("Are You Sure?", "Delete Patient",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

            if (check != DialogResult.Yes) return;

            var PatientID = Convert.ToInt32(GridViewPatientsList.CurrentRow.Cells[0].Value);

            if (PatientsBusinessLayer.DeletePatient(PatientID))
            {
                MessageBox.Show("Deleted Successfully");
                LoadData();
            }
            else
            {
                MessageBox.Show("You Can't Delete This Record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}