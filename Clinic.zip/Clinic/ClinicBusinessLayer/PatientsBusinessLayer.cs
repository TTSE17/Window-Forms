﻿using System;
using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class PatientsBusinessLayer
    {
        public int PatientID { get; set; }
        public int PersonID { get; set; }
        public DateTime RegistrationDate { get; set; }

        public PatientsBusinessLayer()
        {
            PatientID = -1;
        }

        private PatientsBusinessLayer(int patientId, DateTime registrationDate, int personId)
        {
            PatientID = patientId;
            PersonID = personId;
            RegistrationDate = registrationDate;
        }

        public static DataTable GetAllPatients(string Text = "")
        {
            return PatientsDataAccessLayer.GetAllPatients(Text);
        }

        public static PatientsBusinessLayer FindPatient(int ID)
        {
            var personID = -1;
            var registrationDate = DateTime.Now;

            return PatientsDataAccessLayer.FindPatient(ID,ref registrationDate, ref personID)
                ? new PatientsBusinessLayer(ID,registrationDate, personID)
                : null;
        }

        private int _AddNewPatient()
        {
            return PatientsDataAccessLayer.AddNewPatient(RegistrationDate,PersonID);
        }

        public bool Save()
        {
            if (this.PatientID != -1) return true;

            PatientID = _AddNewPatient();
            return true;
        }

        public static bool DeletePatient(int ID)
        {
            var PersonID = FindPatient(ID).PersonID;

            return (PatientsDataAccessLayer.DeletePatient(ID) && PersonBusinessLayer.DeletePerson(PersonID));
        }
    }
}