﻿using System;
using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class UsersBusinessLayer
    {
        public int UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int Permission { get; set; }

        public UsersBusinessLayer()
        {
            UserID = -1;
        }

        private UsersBusinessLayer(int userId, string userName, string password,
            DateTime registrationDate, int permission)
        {
            UserID = userId;
            UserName = userName;
            Password = password;
            RegistrationDate = registrationDate;
            Permission = permission;
        }

        public static DataTable GetAllUsers(string Text = "")
        {
            return UsersDataAccessLayer.GetAllUsers(Text);
        }

        public static bool IsFound(string UserName, string Password)
        {
            return UsersDataAccessLayer.IsFound(UserName, Password);
        }

        public static UsersBusinessLayer FindUser(int ID)
        {
            var UserName = "";
            var Password = "";
            var RegistrationDate = DateTime.Now;
            var Permission = -1;

            return UsersDataAccessLayer.FindUser(ID, ref UserName, ref Password, ref RegistrationDate, ref Permission)
                ? new UsersBusinessLayer(ID, UserName, Password, RegistrationDate, Permission)
                : null;
        }
        
        public static UsersBusinessLayer FindUser(string Username)
        {
            var UserID = -1;
            var Password = "";
            var RegistrationDate = DateTime.Now;
            var Permission = -1;

            return UsersDataAccessLayer.FindUser(ref UserID , Username, ref Password, ref RegistrationDate, ref Permission)
                ? new UsersBusinessLayer(UserID, Username, Password, RegistrationDate, Permission)
                : null;
        }


        public static bool IsExists(string Username)
        {
            return UsersDataAccessLayer.IsExists(Username);
        }
        
        private int _AddNewUser()
        {
            return UsersDataAccessLayer.AddNewUser(UserName, Password,RegistrationDate,Permission);
        }

        private bool _UpdateUser()
        {
            return UsersDataAccessLayer.UpdateUser(UserID, UserName, Password, RegistrationDate, Permission);
        }

        public bool Save()
        {
            if (this.UserID != -1) return _UpdateUser();

            UserID = _AddNewUser();
            return true;
        }

        public static bool DeleteUser(int ID)
        {
            return (UsersDataAccessLayer.DeleteUser(ID));
        }
    }
}