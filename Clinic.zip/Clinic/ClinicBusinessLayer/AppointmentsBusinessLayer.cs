﻿using System;
using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class AppointmentsBusinessLayer
    {
        public int AppointmentID { get; set; }

        public int PatientID { get; set; }

        public int DoctorID { get; set; }

        public DateTime AppointmentDate { get; set; }

        public string AppointmentTime { get; set; }

        public int MedicalRecordID { get; set; }

        public DateTime RegistrationDate { get; set; }

        public string Status { get; set; }

        public AppointmentsBusinessLayer()
        {
            AppointmentID = -1;
            MedicalRecordID = -1;
        }

        private AppointmentsBusinessLayer(int appointmentId, int patientId, int doctorId, DateTime appointmentDate,
            string appointmentTime, int medicalRecordId, DateTime registrationDate, string status)
        {
            AppointmentID = appointmentId;
            PatientID = patientId;
            DoctorID = doctorId;
            AppointmentDate = appointmentDate;
            AppointmentTime = appointmentTime;
            MedicalRecordID = medicalRecordId;
            RegistrationDate = registrationDate;
            Status = status;
        }

        public static DataTable GetAllAppointments(string Text, string Status = "")
        {
            return AppointmentsDataAccessLayer.GetAllAppointments(Text, Status);
        }

        public static DataTable GetAllAppointmentsToday()
        {
            var DT = DateTime.Now.ToString("yyyy-MM-dd");
            return AppointmentsDataAccessLayer.GetAllAppointmentsToday(DT);
        }

        public static void UpdateAppointmentsMissed()
        {
            AppointmentsDataAccessLayer.UpdateAppointmentsMissed(DateTime.Now.ToString("yyyy-MM-dd"));
        }

        public static bool IsFoundAppointmentTimeInAppointmentDate(string AppointmentTime, string AppointmentDate)
        {
            return AppointmentsDataAccessLayer.IsFoundAppointmentTimeInAppointmentDate(AppointmentTime,
                AppointmentDate);
        }

        public static AppointmentsBusinessLayer FindAppointment(int ID)
        {
            var patientID = -1;
            var doctorID = -1;
            var appointmentDate = DateTime.Now;
            var appointmentTime = "";
            var medicalRecordID = -1;
            var registrationDate = DateTime.Now;
            var status = "";

            return AppointmentsDataAccessLayer.FindAppointment(ID, ref patientID, ref doctorID, ref appointmentDate,
                ref appointmentTime, ref medicalRecordID, ref registrationDate, ref status)
                ? new AppointmentsBusinessLayer(ID, patientID, doctorID,
                    appointmentDate, appointmentTime, medicalRecordID, registrationDate, status)
                : null;
        }

        private int _AddNewAppointment()
        {
            return AppointmentsDataAccessLayer.AddNewAppointment(PatientID, DoctorID, AppointmentDate,
                AppointmentTime, RegistrationDate, Status);
        }

        private bool _UpdateAppointment()
        {
            return AppointmentsDataAccessLayer.UpdateAppointment(AppointmentID, PatientID, DoctorID, AppointmentDate,
                AppointmentTime, MedicalRecordID, RegistrationDate, Status);
        }

        public bool Save()
        {
            if (this.AppointmentID != -1) return _UpdateAppointment(); //Update

            AppointmentID = _AddNewAppointment();
            return true;
        }

        public static bool DeleteAppointment(int ID)
        {
            return AppointmentsDataAccessLayer.DeleteAppointment(ID);
        }
    }
}