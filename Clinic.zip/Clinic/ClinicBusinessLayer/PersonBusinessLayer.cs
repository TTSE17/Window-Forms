﻿using System;
using System.Windows.Forms;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class PersonBusinessLayer
    {
        public int PersonId { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string Gender { get; set; }
        public string ImagePath { get; set; }
        public int CountryID { get; set; }
        public DateTime BirthDate { get; set; }

        public PersonBusinessLayer()
        {
            PersonId = -1;
        }

        private PersonBusinessLayer(int personId, string firstName, string middleName, string lastName, string email,
            string phone, string address, DateTime birthDate, string gender, string imagePath, int countryId)
        {
            PersonId = personId;
            FirstName = firstName;
            MiddleName = middleName;
            LastName = lastName;
            Email = email;
            Phone = phone;
            ImagePath = imagePath;
            Address = address;
            Gender = gender;
            CountryID = countryId;
            BirthDate = birthDate;
        }

        private int _AddNewPerson()
        {
            return PersonDataAccessLayer.AddNewPerson(FirstName, MiddleName, LastName, Email,
                Phone, Address, BirthDate, Gender, ImagePath, CountryID);
        }

        private bool _UpdatePerson()
        {
            return PersonDataAccessLayer.UpdatePerson(PersonId, FirstName, MiddleName, LastName, Email,
                Phone, Address, BirthDate, Gender, ImagePath, CountryID);
        }

        public static PersonBusinessLayer FindPerson(int PersonId)
        {
            string FirstName = "",
                MiddleName = "",
                LastName = "",
                Phone = "",
                Email = "",
                Address = "",
                ImagePath = "",
                Gender = "";
            var CountryId = -1;
            DateTime BirthDate = DateTime.Now;

            if (PersonDataAccessLayer.FindPerson(PersonId, ref FirstName, ref MiddleName, ref LastName, ref Email,
                    ref Phone, ref Address, ref BirthDate, ref Gender, ref ImagePath, ref CountryId))

                return new PersonBusinessLayer(PersonId, FirstName, MiddleName, LastName, Email,
                    Phone, Address, BirthDate, Gender, ImagePath, CountryId);

            return null;
        }

        public bool Save()
        {
            if (this.PersonId != -1) return _UpdatePerson();
            
            PersonId = _AddNewPerson();
            return true;

        }

        public static bool DeletePerson(int ID)
        {
            return PersonDataAccessLayer.DeletePerson(ID);
        }
    }
}