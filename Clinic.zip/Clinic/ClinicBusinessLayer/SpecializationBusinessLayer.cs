﻿using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class SpecializationBusinessLayer
    {
        public int SpecializationID { get; set; }
        
        public string Specialization { get; set; }

        private SpecializationBusinessLayer(int SpecializationId, string specialization)
        {
            SpecializationID = SpecializationId;
            Specialization= specialization;
        }

        public static DataTable GetAllSpecializations()
        {
            return SpecializationDataAccessLayer.GetAllSpecializations();
        }

        public static SpecializationBusinessLayer FindSpecialization(int ID)
        {
            var SpecializationName = "";
            return SpecializationDataAccessLayer.FindSpecialization(ID, ref SpecializationName)
                ? new SpecializationBusinessLayer(ID, SpecializationName)
                : null;
        }

        public static SpecializationBusinessLayer FindSpecialization(string SpecializationName)
        {
            var SpecializationId = -1;
            return SpecializationDataAccessLayer.FindSpecialization(ref SpecializationId, SpecializationName)
                ? new SpecializationBusinessLayer(SpecializationId, SpecializationName)
                : null;
        }
    }
}