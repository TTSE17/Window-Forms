﻿using System;
using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class MedicalRecordsBusinessLayer
    {
        public int MedicalRecordID { get; set; }
        public int ServiceID { get; set; }
        public int MedicineID { get; set; }
        public string Diagnosis { get; set; }

        public MedicalRecordsBusinessLayer()
        {
            MedicalRecordID = -1;
        }

        private MedicalRecordsBusinessLayer(int medicalRecordId, int serviceID, int medicineId, string diagnosis)
        {
            MedicalRecordID = medicalRecordId;
            ServiceID = serviceID;
            MedicineID = medicineId;
            Diagnosis = diagnosis;
        }
        
        public static DataTable GetAllMedicalRecords(string Text = "")
        {
            return MedicalRecordsDataAccessLayer.GetAllMedicalRecords(Text);
        }

        public static MedicalRecordsBusinessLayer FindMedicalRecord(int ID)
        {
            var ServiceID = -1;
            var MedicineID= -1;
            var Diagnosis = "";

            return MedicalRecordsDataAccessLayer.FindMedicalRecord(ID, ref ServiceID, ref MedicineID,ref Diagnosis)
                ? new MedicalRecordsBusinessLayer(ID, ServiceID, MedicineID,Diagnosis)
                : null;
        }

        private int _AddNewMedicalRecord()
        {
            return MedicalRecordsDataAccessLayer.AddNewMedicalRecord(ServiceID,MedicineID,Diagnosis);
        }

        private bool _UpdateMedicalRecord()
        {
            return MedicalRecordsDataAccessLayer.UpdateMedicalRecord(MedicalRecordID, ServiceID, MedicineID,Diagnosis);
        }

        public bool Save()
        {
            if (this.MedicalRecordID != -1) return _UpdateMedicalRecord();

            MedicalRecordID = _AddNewMedicalRecord();
            return true;
        }

        public static bool DeleteMedicalRecord(int ID)
        {
            return (MedicalRecordsDataAccessLayer.DeleteMedicalRecord(ID));
        }
    }
}