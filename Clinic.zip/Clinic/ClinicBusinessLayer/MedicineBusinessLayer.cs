﻿using System.Data;
using System.Windows.Forms;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class MedicineBusinessLayer
    {
        public int MedicineId { get; set; }
        public string MedicineName { get; set; }
        public int Dose { get; set; }
        public int Times { get; set; }
        public int Days { get; set; }

        public MedicineBusinessLayer()
        {
            MedicineId = -1;
        }

        private MedicineBusinessLayer(int medicineId, string medicineName, int dose, int times, int days)
        {
            MedicineId = medicineId;
            MedicineName = medicineName;
            Dose = dose;
            Times = times;
            Days = days;
        }

        public static DataTable GetAllMedicine(string Text)
        {
            return MedicineDataAccessLayer.GetAllMedicine(Text);
        }

        public static MedicineBusinessLayer FindMedicine(int ID)
        {
            var medicineName = "";
            var dose = -1;
            var times = -1;
            var days = -1;

            return MedicineDataAccessLayer.FindMedicine(ID, ref medicineName, ref dose, ref times, ref days)
                ? new MedicineBusinessLayer(ID, medicineName, dose, times, days)
                : null;
        }

        private int _AddNewMedicine()
        {
            return MedicineDataAccessLayer.AddNewMedicine(MedicineName, Dose,Times,Days);
        }

        private bool _UpdateMedicine()
        {
            return MedicineDataAccessLayer.UpdateMedicine(MedicineId, MedicineName, Dose, Times, Days);
        }

        public bool Save()
        {
            if (this.MedicineId != -1) return _UpdateMedicine();

            MedicineId = _AddNewMedicine();
            return true;
        }

        public static bool DeleteMedicine(int ID)
        {
            return (MedicineDataAccessLayer.DeleteMedicine(ID));
        }
    }
}