﻿using System;
using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class ServicesBusinessLayer
    {
        public int ServiceId { get; set; }
        public string ServiceName { get; set; }
        public decimal ServicePrice { get; set; }

        public ServicesBusinessLayer()
        {
            ServiceId = -1;
        }

        private ServicesBusinessLayer(int serviceId, string serviceName, decimal servicePrice)
        {
            ServiceId = serviceId;
            ServiceName = serviceName;
            ServicePrice = servicePrice;
        }

        public static DataTable GetAllServices(string Text = "")
        {
            return ServicesDataAccessLayer.GetAllServices(Text);
        }

        public static ServicesBusinessLayer FindService(int ID)
        {
            var ServiceName = "";
            var ServicePrice = Convert.ToDecimal(-1);

            return ServicesDataAccessLayer.FindService(ID, ref ServiceName, ref ServicePrice)
                ? new ServicesBusinessLayer(ID, ServiceName, ServicePrice)
                : null;
        }

        private int _AddNewService()
        {
            return ServicesDataAccessLayer.AddNewService(ServiceName,ServicePrice);
        }

        private bool _UpdateService()
        {
            return ServicesDataAccessLayer.UpdateService(ServiceId, ServiceName, ServicePrice);
        }

        public bool Save()
        {
            if (this.ServiceId != -1) return _UpdateService();

            ServiceId = _AddNewService();
            return true;
        }

        public static bool DeleteService(int ID)
        {
            return (ServicesDataAccessLayer.DeleteService(ID));
        }
    }
}