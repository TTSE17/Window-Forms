﻿using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class DashboardBusinessLayer
    {
        public static DataTable GetNumberEveryThing()
        {
            return DashboardDataAccessLayer.GetNumberEveryThing();
        }
    }
}