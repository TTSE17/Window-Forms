﻿using System.Data;
using ClassLibrary1;

namespace ClinicBusinessLayer
{
    public class DoctorsBusinessLayer
    {
        public int DoctorID { get; set; }

        public int SpecializationId { get; set; }
        public int PersonID { get; set; }


        public DoctorsBusinessLayer()
        {
            DoctorID = -1;
        }

        private DoctorsBusinessLayer(int doctorID, int specializationID, int personId)
        {
            DoctorID = doctorID;
            SpecializationId = specializationID;
            PersonID = personId;
        }

        public static DataTable GetAllDoctors(string Text = "")
        {
            return DoctorDataAccessLayer.GetAllDoctors(Text);
        }

        public static DoctorsBusinessLayer FindDoctor(int ID)
        {
            var personID = -1;
            var specializationId = -1;

            return DoctorDataAccessLayer.FindDoctor(ID, ref specializationId, ref personID)
                ? new DoctorsBusinessLayer(ID, specializationId, personID)
                : null;
        }

        private int _AddNewDoctor()
        {
            return DoctorDataAccessLayer.AddNewDoctor(SpecializationId, PersonID);
        }

        private bool _UpdateDoctor()
        {
            return DoctorDataAccessLayer.UpdateDoctor(DoctorID, SpecializationId);
        }

        public bool Save()
        {
            if (this.DoctorID != -1) return _UpdateDoctor();

            DoctorID = _AddNewDoctor();
            return true;
        }

        public static bool DeleteDoctor(int ID)
        {
            var PersonID = FindDoctor(ID).PersonID;

            return (DoctorDataAccessLayer.DeleteDoctor(ID) && PersonBusinessLayer.DeletePerson(PersonID));
        }
    }
}