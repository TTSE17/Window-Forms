﻿using System;
using System.Data;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.Students
{
    public partial class ctrlStudentCourses : UserControl
    {
        public ctrlStudentCourses()
        {
            InitializeComponent();
        }

        private DataTable DT;

        public void LoadStudentCourses(int StudentID)
        {
            LoadData(StudentID);
        }

        private void LoadData(int StudentID)
        {
            DT = StudentsBusinessLayer.GetAllStudentCourses(StudentID);
            if (DT.Columns.Count > 0)
                GridViewStudentCoursesList.DataSource = DT;
            else
                _SetDefaultColumns();

            lblRecords.Text = Convert.ToString(DT.Rows.Count);
        }

        private void _SetDefaultColumns()
        {
            DT.Columns.Add("Course");
            DT.Columns.Add("Teacher");
            DT.Columns.Add("Enrollment Date");
            DT.Columns.Add("Status");

            GridViewStudentCoursesList.DataSource = DT;

            // _SetWidthColumns();

            if (GridViewStudentCoursesList.Rows.Count > 0)
                GridViewStudentCoursesList.Rows.RemoveAt(0);
        }

        private void _SetWidthColumns()
        {
            GridViewStudentCoursesList.Columns[0].Width = 71;
            GridViewStudentCoursesList.Columns[1].Width = 71;
            GridViewStudentCoursesList.Columns[2].Width = 79;
            GridViewStudentCoursesList.Columns[3].Width = 59;
        }
    }
}