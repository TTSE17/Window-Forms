﻿using System;
using System.IO;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Properties;

namespace InstitutionPresentationLayer.Students
{
    public partial class ctrlStudentInfo : UserControl
    {
        public ctrlStudentInfo()
        {
            InitializeComponent();
        }

        private int _StudentID;
        private StudentsBusinessLayer _Student1;

        public void LoadStudentInfo(int StudentID)
        {
            _StudentID = StudentID;
            LoadData();
        }

        private void LoadData()
        {
            _Student1 = StudentsBusinessLayer.FindStudent(_StudentID);

            if (_Student1 == null) return;

            lblStudentID.Text = Convert.ToString(_Student1.StudentID);
            lblName.Text = _Student1.Name;
            lblGender.Text = (_Student1.Gender == 1) ? "Male" : "Female";
            lblEmail.Text = _Student1.Email;
            lblPayments.Text = Convert.ToString(_Student1.Payments);
            lblDateOfBirth.Text = _Student1.DateOfBirth.ToString("dd/MM/yyyy");
            lblAddress.Text = _Student1.Address;

            if (_Student1.ImagePath != "" && File.Exists(_Student1.ImagePath))
                pbPerson.ImageLocation = _Student1.ImagePath;

            else
                pbPerson.Image = (_Student1.Gender == 1) ? Resources.student : Resources.student_little_girl;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new AddEditStudentScreen(_StudentID);
            fr.ShowDialog();

            LoadStudentInfo(_StudentID);
        }
    }
}