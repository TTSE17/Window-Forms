﻿using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Properties;

namespace InstitutionPresentationLayer.Students
{
    public partial class AddEditStudentScreen : Form
    {
        private int _StudentID;
        private StudentsBusinessLayer _Student1;

        public AddEditStudentScreen(int studentId = -1)
        {
            InitializeComponent();
            _StudentID = studentId;
        }

        private void AddEditStudentScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            pbPerson.ImageLocation = null;

            DateTimePicker.MaxDate = DateTime.Now.AddYears(-18);
            DateTimePicker.MinDate = DateTime.Now.AddYears(-100);

            if (_StudentID == -1)
            {
                _Student1 = new StudentsBusinessLayer();
                lblTitleForm.Text = "Add New Students";
                lblStudentID.Text = "N/A";
                lilRemoveImage.Visible = false;
            }

            else
            {
                _Student1 = StudentsBusinessLayer.FindStudent(_StudentID);

                if (_Student1 == null) return;

                lblTitleForm.Text = "Update Students";

                lblStudentID.Text = Convert.ToString(_StudentID);
                txtName.Text = _Student1.Name;
                if (_Student1.Gender == 1)
                    rbMale.Checked = true;
                else
                    rbFemale.Checked = true;
                txtEmail.Text = _Student1.Email;
                DateTimePicker.Value = _Student1.DateOfBirth;
                txtAddress.Text = _Student1.Address;

                if (_Student1.ImagePath != "" && File.Exists(_Student1.ImagePath))
                {
                    pbPerson.ImageLocation = _Student1.ImagePath;
                    lilRemoveImage.Visible = true;
                }
                else
                {
                    pbPerson.Image = (rbMale.Checked) ? Resources.student : Resources.student_little_girl;
                    lilRemoveImage.Visible = false;
                }
            }
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            var Item = (RadioButton)sender;

            if (pbPerson.ImageLocation != null) return;

            pbPerson.Image = (rbMale.Checked) ? Resources.student : Resources.student_little_girl;
        }

        private void lilSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;

            var selectedFilePath = openFileDialog1.FileName;

            pbPerson.ImageLocation = selectedFilePath;

            lilRemoveImage.Visible = true;
        }

        private void lilRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pbPerson.ImageLocation = null;
            pbPerson.Image = (rbMale.Checked) ? Resources.student : Resources.student_little_girl;

            lilRemoveImage.Visible = false;
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = ((TextBox)sender);
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
            }
            else
            {
                errorProvider1.SetError(Temp, null);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are not valid!, put the mouse over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var Name = txtName.Text.Trim();
            var Gender = Convert.ToInt16((rbMale.Checked) ? 1 : 0);
            var Email = txtEmail.Text.Trim();
            var BirthDate = DateTimePicker.Value;
            var Address = txtAddress.Text.Trim();
            var ImagePath = pbPerson.ImageLocation;

            // if (StudentsBusinessLayer.ExistStudent(Name))
            // {
            //     MessageBox.Show("There is a Student with that name , Enter Another",
            //         "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //     return;
            // }


            lblTitleForm.Text = "Update Students";

            _Student1.Name = Name;
            _Student1.Gender = Gender;
            _Student1.Email = Email;
            _Student1.DateOfBirth = BirthDate;
            _Student1.Address = Address;

            _HandleImage();

            _Student1.ImagePath = pbPerson.ImageLocation ?? "";

            MessageBox.Show(_Student1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblStudentID.Text = Convert.ToString(_Student1.StudentID);

            _StudentID = _Student1.StudentID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void _HandleImage()
        {
            if (_Student1.ImagePath == pbPerson.ImageLocation) return;

            if (_Student1.ImagePath != "")
            {
                try
                {
                    File.Delete(_Student1.ImagePath);
                }
                catch (IOException ee)
                {
                    // MessageBox.Show(ee + "");
                }
            }

            if (pbPerson.ImageLocation != null)
            {
                var SourceImageFile = pbPerson.ImageLocation;

                var CurrentPath =
                    Directory.GetCurrentDirectory()+"\\Images\\"+
                    Guid.NewGuid() + Path.GetExtension(SourceImageFile);

                File.Copy(SourceImageFile, CurrentPath, true);

                pbPerson.ImageLocation = CurrentPath;
            }
        }
    }
}