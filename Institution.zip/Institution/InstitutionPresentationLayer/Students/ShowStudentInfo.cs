﻿using System.Windows.Forms;

namespace InstitutionPresentationLayer.Students
{
    public partial class ShowStudentInfo : Form
    {
        public ShowStudentInfo(int StudentID)
        {
            InitializeComponent();
            
            ctrlStudentInfo1.LoadStudentInfo(StudentID);
            
        }
    }
}