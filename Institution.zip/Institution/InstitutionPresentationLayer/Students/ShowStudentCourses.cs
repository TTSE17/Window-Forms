﻿using System.Windows.Forms;

namespace InstitutionPresentationLayer.Students
{
    public partial class ShowStudentCourses : Form
    {
        public ShowStudentCourses(int StudentID)
        {
            InitializeComponent();
            ctrlStudentCourses1.LoadStudentCourses(StudentID);
            ctrlStudentInfo1.LoadStudentInfo(StudentID);
        }
    }
}