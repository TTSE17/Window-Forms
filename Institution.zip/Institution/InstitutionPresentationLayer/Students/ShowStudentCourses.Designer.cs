﻿using System.ComponentModel;

namespace InstitutionPresentationLayer.Students
{
    partial class ShowStudentCourses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlStudentCourses1 = new InstitutionPresentationLayer.Students.ctrlStudentCourses();
            this.ctrlStudentInfo1 = new InstitutionPresentationLayer.Students.ctrlStudentInfo();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ctrlStudentCourses1
            // 
            this.ctrlStudentCourses1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlStudentCourses1.Location = new System.Drawing.Point(12, 381);
            this.ctrlStudentCourses1.Name = "ctrlStudentCourses1";
            this.ctrlStudentCourses1.Size = new System.Drawing.Size(597, 229);
            this.ctrlStudentCourses1.TabIndex = 0;
            // 
            // ctrlStudentInfo1
            // 
            this.ctrlStudentInfo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlStudentInfo1.Location = new System.Drawing.Point(12, 77);
            this.ctrlStudentInfo1.Name = "ctrlStudentInfo1";
            this.ctrlStudentInfo1.Size = new System.Drawing.Size(595, 287);
            this.ctrlStudentInfo1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(188, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(245, 35);
            this.label1.TabIndex = 2;
            this.label1.Text = "Student Courses";
            // 
            // ShowStudentCourses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 614);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ctrlStudentInfo1);
            this.Controls.Add(this.ctrlStudentCourses1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ShowStudentCourses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "   Show Student Courses";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label label1;

        private InstitutionPresentationLayer.Students.ctrlStudentCourses ctrlStudentCourses1;
        private InstitutionPresentationLayer.Students.ctrlStudentInfo ctrlStudentInfo1;

        #endregion
    }
}