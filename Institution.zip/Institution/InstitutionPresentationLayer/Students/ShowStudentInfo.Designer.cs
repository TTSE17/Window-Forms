﻿using System.ComponentModel;

namespace InstitutionPresentationLayer.Students
{
    partial class ShowStudentInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlStudentInfo1 = new InstitutionPresentationLayer.Students.ctrlStudentInfo();
            this.lblTitleForm = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ctrlStudentInfo1
            // 
            this.ctrlStudentInfo1.Location = new System.Drawing.Point(16, 67);
            this.ctrlStudentInfo1.Name = "ctrlStudentInfo1";
            this.ctrlStudentInfo1.Size = new System.Drawing.Size(573, 291);
            this.ctrlStudentInfo1.TabIndex = 0;
            // 
            // lblTitleForm
            // 
            this.lblTitleForm.AutoSize = true;
            this.lblTitleForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleForm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitleForm.Location = new System.Drawing.Point(171, 18);
            this.lblTitleForm.Name = "lblTitleForm";
            this.lblTitleForm.Size = new System.Drawing.Size(273, 36);
            this.lblTitleForm.TabIndex = 13;
            this.lblTitleForm.Text = "Student information";
            // 
            // ShowStudentInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 370);
            this.Controls.Add(this.lblTitleForm);
            this.Controls.Add(this.ctrlStudentInfo1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ShowStudentInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "  Show Student Information";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitleForm;

        private InstitutionPresentationLayer.Students.ctrlStudentInfo ctrlStudentInfo1;

        #endregion
    }
}