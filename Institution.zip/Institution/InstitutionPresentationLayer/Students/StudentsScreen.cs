﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.Students
{
    public partial class StudentsScreen : Form
    {
        public StudentsScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _StudentID;
        private StudentsBusinessLayer _Student1;

        private void StudentsScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void StudentsScreen_Shown(object sender, EventArgs e)
        {
            RefreshData();
        }
        private void RefreshData()
        {
            _DataTable = StudentsBusinessLayer.GetAllStudents();

            comboBox1.Enabled = textBox1.Enabled = true;

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            comboBox1.SelectedIndex = 0;
            cbGender.SelectedIndex = 0;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("StudentID", typeof(int));
            _DataTable.Columns.Add("Name", typeof(string));
            _DataTable.Columns.Add("Gender", typeof(byte));
            _DataTable.Columns.Add("Email", typeof(string));
            _DataTable.Columns.Add("Payments", typeof(double));
            _DataTable.Columns.Add("Courses", typeof(int));
            _DataTable.Columns.Add("DateOfBirth", typeof(DateTime));
            _DataTable.Columns.Add("Address", typeof(string));
            _DataTable.Columns.Add("ImagePath", typeof(string));

            GridViewStudentsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewStudentsList.Rows.Count > 0)
                GridViewStudentsList.Rows.RemoveAt(0);

            comboBox1.Enabled = cbGender.Enabled = textBox1.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewStudentsList.Columns[0].Width = 51;
            GridViewStudentsList.Columns[1].Width = 99;
            GridViewStudentsList.Columns[2].Width = 59;
            GridViewStudentsList.Columns[3].Width = 91;
            GridViewStudentsList.Columns[4].Width = 71;
            GridViewStudentsList.Columns[5].Width = 71;
            GridViewStudentsList.Columns[6].Width = 99;
            GridViewStudentsList.Columns[7].Width = 99;
            GridViewStudentsList.Columns[8].Width = 111;
        }

        private void LoadData(string Type = "StudentID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            var DataFilter = "";

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "StudentID" || Type == "Gender")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewStudentsList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewStudentsList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsActiveChoice = comboBox1.SelectedIndex == 2;

            textBox1.Visible = !IsActiveChoice;
            cbGender.Visible = IsActiveChoice;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbGender.SelectedItem);

            var GenderValue = Selection == "All" ? "" : Selection;

            LoadData("Gender", GenderValue);
        }

        private void btnNewStudent_Click(object sender, EventArgs e)
        {
            var fr = new AddEditStudentScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = GridViewStudentsList.Rows.Count <= 0;
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewStudentsList.CurrentRow.Cells[0].Value));

            var fr = new ShowStudentInfo(_StudentID);
            fr.ShowDialog();

            RefreshData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewStudentsList.CurrentRow.Cells[0].Value));

            var fr = new AddEditStudentScreen(_StudentID);
            fr.ShowDialog();

            RefreshData();
        }

        private void showCoursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewStudentsList.CurrentRow.Cells[0].Value));

            var fr = new ShowStudentCourses(_StudentID);
            fr.ShowDialog();
            
            RefreshData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewStudentsList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to delete [" + _StudentID + "]", "Confirm Delete",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_Student1.Delete())
            {
                MessageBox.Show("Student Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Student, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateStudentInfo(int ID)
        {
            _StudentID = ID;
            _Student1 = StudentsBusinessLayer.FindStudent(_StudentID);
        }

    }
}