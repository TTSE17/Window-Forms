﻿using System.ComponentModel;

namespace InstitutionPresentationLayer
{
    partial class MainScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dashBoardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teachersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enrollmentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.coursesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblDateTime = new System.Windows.Forms.Label();
            this.MainContainer = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dashBoardToolStripMenuItem
            // 
            this.dashBoardToolStripMenuItem.AutoSize = false;
            this.dashBoardToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.dashBoardToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.dashBoardToolStripMenuItem.Image = global::InstitutionPresentationLayer.Properties.Resources.stock_market;
            this.dashBoardToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.dashBoardToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.dashBoardToolStripMenuItem.Name = "dashBoardToolStripMenuItem";
            this.dashBoardToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.dashBoardToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.dashBoardToolStripMenuItem.Text = "Dashboard";
            this.dashBoardToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.dashBoardToolStripMenuItem.Click += new System.EventHandler(this.dashBoardToolStripMenuItem_Click);
            this.dashBoardToolStripMenuItem.MouseEnter += new System.EventHandler(this.ToolStripMenuItem_MouseHover);
            this.dashBoardToolStripMenuItem.MouseLeave += new System.EventHandler(this.ToolStripMenuItem_MouseLeave);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlText;
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.dashBoardToolStripMenuItem, this.studentsToolStripMenuItem, this.teachersToolStripMenuItem, this.enrollmentsToolStripMenuItem, this.coursesToolStripMenuItem });
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(195, 572);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.AutoSize = false;
            this.studentsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.studentsToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.studentsToolStripMenuItem.Image = global::InstitutionPresentationLayer.Properties.Resources.Drivers_64;
            this.studentsToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.studentsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.studentsToolStripMenuItem.Margin = new System.Windows.Forms.Padding(0, 11, 0, 0);
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.studentsToolStripMenuItem.Text = "Students";
            this.studentsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.studentsToolStripMenuItem.Click += new System.EventHandler(this.studentsToolStripMenuItem_Click);
            this.studentsToolStripMenuItem.MouseEnter += new System.EventHandler(this.ToolStripMenuItem_MouseHover);
            this.studentsToolStripMenuItem.MouseLeave += new System.EventHandler(this.ToolStripMenuItem_MouseLeave);
            // 
            // teachersToolStripMenuItem
            // 
            this.teachersToolStripMenuItem.AutoSize = false;
            this.teachersToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.teachersToolStripMenuItem.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.teachersToolStripMenuItem.Image = global::InstitutionPresentationLayer.Properties.Resources.People_64;
            this.teachersToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.teachersToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.teachersToolStripMenuItem.Margin = new System.Windows.Forms.Padding(0, 11, 0, 0);
            this.teachersToolStripMenuItem.Name = "teachersToolStripMenuItem";
            this.teachersToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.teachersToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.teachersToolStripMenuItem.Text = "Teachers";
            this.teachersToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.teachersToolStripMenuItem.Click += new System.EventHandler(this.teachersToolStripMenuItem_Click);
            this.teachersToolStripMenuItem.MouseEnter += new System.EventHandler(this.ToolStripMenuItem_MouseHover);
            this.teachersToolStripMenuItem.MouseLeave += new System.EventHandler(this.ToolStripMenuItem_MouseLeave);
            // 
            // enrollmentsToolStripMenuItem
            // 
            this.enrollmentsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.enrollmentsToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.enrollmentsToolStripMenuItem.Image = global::InstitutionPresentationLayer.Properties.Resources.Application_Types_64;
            this.enrollmentsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.enrollmentsToolStripMenuItem.Margin = new System.Windows.Forms.Padding(0, 11, 0, 0);
            this.enrollmentsToolStripMenuItem.Name = "enrollmentsToolStripMenuItem";
            this.enrollmentsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.enrollmentsToolStripMenuItem.Size = new System.Drawing.Size(189, 81);
            this.enrollmentsToolStripMenuItem.Text = "Enrollments";
            this.enrollmentsToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.enrollmentsToolStripMenuItem.Click += new System.EventHandler(this.enrollmentsToolStripMenuItem_Click);
            this.enrollmentsToolStripMenuItem.MouseEnter += new System.EventHandler(this.ToolStripMenuItem_MouseHover);
            this.enrollmentsToolStripMenuItem.MouseLeave += new System.EventHandler(this.ToolStripMenuItem_MouseLeave);
            // 
            // coursesToolStripMenuItem
            // 
            this.coursesToolStripMenuItem.AutoSize = false;
            this.coursesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.coursesToolStripMenuItem.ForeColor = System.Drawing.Color.White;
            this.coursesToolStripMenuItem.Image = global::InstitutionPresentationLayer.Properties.Resources.Manage_Applications_64;
            this.coursesToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.coursesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.coursesToolStripMenuItem.Margin = new System.Windows.Forms.Padding(0, 11, 0, 0);
            this.coursesToolStripMenuItem.Name = "coursesToolStripMenuItem";
            this.coursesToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4, 13, 4, 0);
            this.coursesToolStripMenuItem.Size = new System.Drawing.Size(189, 89);
            this.coursesToolStripMenuItem.Text = "Courses";
            this.coursesToolStripMenuItem.Click += new System.EventHandler(this.coursesToolStripMenuItem_Click);
            this.coursesToolStripMenuItem.MouseEnter += new System.EventHandler(this.ToolStripMenuItem_MouseHover);
            this.coursesToolStripMenuItem.MouseLeave += new System.EventHandler(this.ToolStripMenuItem_MouseLeave);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblDateTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 17F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTime.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lblDateTime.Location = new System.Drawing.Point(12, 499);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(0, 29);
            this.lblDateTime.TabIndex = 1;
            // 
            // MainContainer
            // 
            this.MainContainer.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.MainContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainContainer.Location = new System.Drawing.Point(195, 0);
            this.MainContainer.Name = "MainContainer";
            this.MainContainer.Size = new System.Drawing.Size(976, 572);
            this.MainContainer.TabIndex = 2;
            // 
            // MainScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 572);
            this.Controls.Add(this.MainContainer);
            this.Controls.Add(this.lblDateTime);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "   Main Screen";
            this.Load += new System.EventHandler(this.MainScreen_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ToolStripMenuItem coursesToolStripMenuItem;

        private System.Windows.Forms.Panel MainContainer;

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblDateTime;

        private System.Windows.Forms.ToolStripMenuItem enrollmentsToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem teachersToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem dashBoardToolStripMenuItem;

        private System.Windows.Forms.MenuStrip menuStrip1;

        #endregion
    }
}