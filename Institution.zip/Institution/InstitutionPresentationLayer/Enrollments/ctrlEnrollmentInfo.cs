﻿using System;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Students;

namespace InstitutionPresentationLayer.Enrollments
{
    public partial class ctrlEnrollmentInfo : UserControl
    {
        public ctrlEnrollmentInfo()
        {
            InitializeComponent();
        }


        public void LoadInfo(int ID)
        {
            LoadData(ID);
        }

        private void LoadData(int EnrollmentID)
        {
            var _Enrollment1 = EnrollmentsBusinessLayer.FindEnrollment(EnrollmentID);
            if (_Enrollment1 == null) return;

            lblEnrollmentID.Text = Convert.ToString(EnrollmentID);
            lblCourse.Text = _Enrollment1.CourseInfo.Subject;
            lblStatus.Text = _Enrollment1.Status ? "Enrolled" : "Canceled";
            lblEnrollmentDate.Text = _Enrollment1.EnrollmentDate.ToShortDateString();
            ctrlStudentInfo1.LoadStudentInfo(_Enrollment1.StudentID);
            ctrlTeacherInfo1.LoadTeacherInfo(_Enrollment1.TeacherID);
        }
    }
}