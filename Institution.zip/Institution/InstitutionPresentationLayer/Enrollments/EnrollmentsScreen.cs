﻿using System;
using System.ComponentModel;
using System.Data;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Students;
using InstitutionPresentationLayer.Teachers;

namespace InstitutionPresentationLayer.Enrollments
{
    public partial class EnrollmentsScreen : Form
    {
        public EnrollmentsScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private int _EnrollmentID;
        private EnrollmentsBusinessLayer _Enrollment1;


        private void EnrollmentsScreen_Activated(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void EnrollmentsScreen_Shown(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void EnrollmentsScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }


        private void RefreshData()
        {
            _DataTable = EnrollmentsBusinessLayer.GetAllEnrollments();

            comboBox1.Enabled = textBox1.Enabled = true;

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            comboBox1.SelectedIndex = 0;
            cbStatus.SelectedIndex = 0;

            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("EnrollmentID", typeof(int));
            _DataTable.Columns.Add("StudentName", typeof(string));
            _DataTable.Columns.Add("Course", typeof(byte));
            _DataTable.Columns.Add("TeacherName", typeof(string));
            _DataTable.Columns.Add("Enrollment Date", typeof(DateTime));
            _DataTable.Columns.Add("Status", typeof(double));

            GridViewEnrollmentsList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewEnrollmentsList.Rows.Count > 0)
                GridViewEnrollmentsList.Rows.RemoveAt(0);

            comboBox1.Enabled = cbStatus.Enabled = textBox1.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewEnrollmentsList.Columns[0].Width = 51;
            GridViewEnrollmentsList.Columns[1].Width = 51;
            GridViewEnrollmentsList.Columns[2].Width = 51;
            GridViewEnrollmentsList.Columns[3].Width = 51;
            GridViewEnrollmentsList.Columns[4].Width = 51;
            GridViewEnrollmentsList.Columns[5].Width = 71;
        }

        private void LoadData(string Type = "EnrollmentID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            var DataFilter = "";
            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "EnrollmentID" || Type == "Status")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewEnrollmentsList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewEnrollmentsList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsStatusChoice = comboBox1.SelectedIndex == 4;

            textBox1.Visible = !IsStatusChoice;
            cbStatus.Visible = IsStatusChoice;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbStatus.SelectedItem);

            var GenderValue = Selection == "All" ? "" : Selection;

            LoadData("Status", GenderValue);
        }

        private void btnNewEnrollment_Click(object sender, EventArgs e)
        {
            var fr = new AddEditEnrollmentScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            e.Cancel = GridViewEnrollmentsList.Rows.Count <= 0;

            editToolStripMenuItem.Enabled = canceleToolStripMenuItem.Enabled = _Enrollment1.Status;
            deleteToolStripMenuItem.Enabled = !_Enrollment1.Status;
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            var fr = new ShowEnrollmentInfo(_EnrollmentID);
            fr.ShowDialog();

            RefreshData();
        }

        private void showStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            var fr = new ShowStudentInfo(_Enrollment1.StudentID);
            fr.ShowDialog();

            RefreshData();
        }

        private void showTeacherInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            var fr = new ShowTeacherInfo(_Enrollment1.TeacherID);
            fr.ShowDialog();

            RefreshData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            var fr = new AddEditEnrollmentScreen(_Enrollment1.EnrollmentID);
            fr.ShowDialog();

            RefreshData();
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to Cancel [" + _EnrollmentID + "]", "Confirm Cancel",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_Enrollment1.Cancel())
            {
                MessageBox.Show("Enrollment Canceled Successfully.", "Canceld",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not Cancel Enrollment, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateStudentInfo(Convert.ToInt32(GridViewEnrollmentsList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to Delete [" + _EnrollmentID + "]", "Confirm Delete",
                    MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_Enrollment1.Delete())
            {
                MessageBox.Show("Enrollment Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not Deleted Enrollment, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateStudentInfo(int ID)
        {
            _EnrollmentID = ID;
            _Enrollment1 = EnrollmentsBusinessLayer.FindEnrollment(ID);
        }
    }
}