﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Properties;

namespace InstitutionPresentationLayer.Enrollments
{
    public partial class AddEditEnrollmentScreen : Form
    {
        private int _EnrollmentID;
        private EnrollmentsBusinessLayer _Enrollment1;

        public AddEditEnrollmentScreen(int EnrollmentID = -1)
        {
            InitializeComponent();
            _EnrollmentID = EnrollmentID;
        }

        private void AddEditEnrollmentScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadCourses();
            LoadStudentsNames();

            if (_EnrollmentID == -1)
            {
                _Enrollment1 = new EnrollmentsBusinessLayer();
                lblTitleForm.Text = "Add New Enrollments";
                lblEnrollmentID.Text = "N/A";
                lblEnrollmentDate.Text = DateTime.Now.ToShortDateString();
                // cbCourses.SelectedIndex = 0;
                cbTeachers.Enabled = false;
            }

            else
            {
                cbStudents.Enabled = false;
                cbTeachers.Enabled = true;

                _Enrollment1 = EnrollmentsBusinessLayer.FindEnrollment(_EnrollmentID);

                if (_Enrollment1 == null) return;

                lblTitleForm.Text = "Update Enrollments";

                lblEnrollmentID.Text = Convert.ToString(_EnrollmentID);
                cbStudents.SelectedIndex = cbStudents.FindString(_Enrollment1.StudentInfo.Name);
                cbCourses.SelectedIndex = cbCourses.FindString(_Enrollment1.CourseInfo.Subject);
                cbTeachers.SelectedIndex = cbTeachers.FindString(_Enrollment1.TeacherInfo.Name);
                lblEnrollmentDate.Text = _Enrollment1.EnrollmentDate.ToShortDateString();
                lblSessions.Text = Convert.ToString(_Enrollment1.CourseInfo.Sessions);
                lblCost.Text = Convert.ToString(_Enrollment1.CourseInfo.Cost);
            }
        }

        private void LoadCourses()
        {
            var dt = CoursesBusinessLayer.GetAllCourses();

            foreach (DataRow Row in dt.Rows)
            {
                cbCourses.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private void LoadStudentsNames()
        {
            var dt = StudentsBusinessLayer.GetAllStudentsNames();

            foreach (DataRow Row in dt.Rows)
            {
                cbStudents.Items.Add(Convert.ToString(Row[0]));
            }
        }

        private void LoadTeachersNames(int courseID)
        {
            cbTeachers.Items.Clear();
            cbTeachers.SelectedIndex = -1;

            var dt = TeachersBusinessLayer.GetAllTeachersNamesBySpeciality(courseID);

            if (dt.Rows.Count > 0)
                foreach (DataRow Row in dt.Rows)
                    cbTeachers.Items.Add(Convert.ToString(Row[0]));

            else
                MessageBox.Show("There aren't teacher");
        }

        private void comboBox_Validating(object sender, CancelEventArgs e)
        {
            var Temp = (ComboBox)sender;
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This Field Is Required!");
            }
            else
            {
                errorProvider1.SetError(Temp, null);
            }
        }

        private void btnEnroll_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are not valide!, put the mouse over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            var StudentID = StudentsBusinessLayer.FindStudent(cbStudents.Text).StudentID;
            var CourseID = CoursesBusinessLayer.FindCourse(cbCourses.Text).CourseId;
            var TeahcerID = TeachersBusinessLayer.FindTeacher(cbTeachers.Text).TeacherID;

            if (EnrollmentsBusinessLayer.HasEnrollment(StudentID, CourseID, TeahcerID))
            {
                MessageBox.Show("You Already Have Enrolled in This Course with this Teacher !",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            cbStudents.Enabled = false;

            lblTitleForm.Text = "Update Enrollment";

            _Enrollment1.StudentID = StudentID;
            _Enrollment1.CourseID = CourseID;
            _Enrollment1.TeacherID = TeahcerID;
            _Enrollment1.EnrollmentDate = DateTime.Now;
            _Enrollment1.Status = true;

            MessageBox.Show(_Enrollment1.Save()
                ? "Data Saved Successfully."
                : "Error: Data Is not Saved Successfully.");

            lblEnrollmentID.Text = Convert.ToString(_Enrollment1.EnrollmentID);

            _EnrollmentID = _Enrollment1.EnrollmentID;
        }

        private void cbCourses_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbTeachers.Enabled = true;

            var value = Convert.ToString(cbCourses.SelectedItem);
            var course = CoursesBusinessLayer.FindCourse(value);

            LoadTeachersNames(course.CourseId);

            lblCost.Text = Convert.ToString(course.Cost);
        }
    }
}