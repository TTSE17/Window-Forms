﻿using System.ComponentModel;

namespace InstitutionPresentationLayer.Enrollments
{
    partial class EnrollmentsScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cbStatus = new System.Windows.Forms.ComboBox();
            this.lblRecords = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pbPeopleImage = new System.Windows.Forms.PictureBox();
            this.btnNewEnrollment = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.showDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showStudentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showTeacherInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.canceleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.GridViewEnrollmentsList = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pbPeopleImage)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridViewEnrollmentsList)).BeginInit();
            this.SuspendLayout();
            // 
            // cbStatus
            // 
            this.cbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbStatus.FormattingEnabled = true;
            this.cbStatus.Items.AddRange(new object[] { "All", "Enrolled", "Canceled" });
            this.cbStatus.Location = new System.Drawing.Point(202, 247);
            this.cbStatus.Name = "cbStatus";
            this.cbStatus.Size = new System.Drawing.Size(101, 26);
            this.cbStatus.TabIndex = 117;
            this.cbStatus.SelectedIndexChanged += new System.EventHandler(this.cbStatus_SelectedIndexChanged);
            // 
            // lblRecords
            // 
            this.lblRecords.AutoSize = true;
            this.lblRecords.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecords.Location = new System.Drawing.Point(117, 537);
            this.lblRecords.Name = "lblRecords";
            this.lblRecords.Size = new System.Drawing.Size(27, 20);
            this.lblRecords.TabIndex = 116;
            this.lblRecords.Text = "99";
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitle.Location = new System.Drawing.Point(308, 185);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(328, 37);
            this.lblTitle.TabIndex = 119;
            this.lblTitle.Text = "Manage Enrollments";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 537);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 20);
            this.label1.TabIndex = 115;
            this.label1.Text = " # Records :";
            // 
            // pbPeopleImage
            // 
            this.pbPeopleImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbPeopleImage.Image = global::InstitutionPresentationLayer.Properties.Resources.registration;
            this.pbPeopleImage.InitialImage = null;
            this.pbPeopleImage.Location = new System.Drawing.Point(360, 14);
            this.pbPeopleImage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pbPeopleImage.Name = "pbPeopleImage";
            this.pbPeopleImage.Size = new System.Drawing.Size(231, 166);
            this.pbPeopleImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbPeopleImage.TabIndex = 118;
            this.pbPeopleImage.TabStop = false;
            // 
            // btnNewEnrollment
            // 
            this.btnNewEnrollment.BackgroundImage = global::InstitutionPresentationLayer.Properties.Resources.appointment;
            this.btnNewEnrollment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnNewEnrollment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewEnrollment.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNewEnrollment.Location = new System.Drawing.Point(889, 220);
            this.btnNewEnrollment.Name = "btnNewEnrollment";
            this.btnNewEnrollment.Size = new System.Drawing.Size(64, 54);
            this.btnNewEnrollment.TabIndex = 114;
            this.btnNewEnrollment.UseVisualStyleBackColor = true;
            this.btnNewEnrollment.Click += new System.EventHandler(this.btnNewEnrollment_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { this.showDetailsToolStripMenuItem, this.showStudentToolStripMenuItem, this.showTeacherInfoToolStripMenuItem, this.editToolStripMenuItem, this.canceleToolStripMenuItem, this.deleteToolStripMenuItem });
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(172, 136);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // showDetailsToolStripMenuItem
            // 
            this.showDetailsToolStripMenuItem.Name = "showDetailsToolStripMenuItem";
            this.showDetailsToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.showDetailsToolStripMenuItem.Text = "Show Details";
            this.showDetailsToolStripMenuItem.Click += new System.EventHandler(this.showDetailsToolStripMenuItem_Click);
            // 
            // showStudentToolStripMenuItem
            // 
            this.showStudentToolStripMenuItem.Name = "showStudentToolStripMenuItem";
            this.showStudentToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.showStudentToolStripMenuItem.Text = "Show Student Info";
            this.showStudentToolStripMenuItem.Click += new System.EventHandler(this.showStudentToolStripMenuItem_Click);
            // 
            // showTeacherInfoToolStripMenuItem
            // 
            this.showTeacherInfoToolStripMenuItem.Name = "showTeacherInfoToolStripMenuItem";
            this.showTeacherInfoToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.showTeacherInfoToolStripMenuItem.Text = "Show Teacher Info";
            this.showTeacherInfoToolStripMenuItem.Click += new System.EventHandler(this.showTeacherInfoToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // canceleToolStripMenuItem
            // 
            this.canceleToolStripMenuItem.Name = "canceleToolStripMenuItem";
            this.canceleToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.canceleToolStripMenuItem.Text = "Cancele";
            this.canceleToolStripMenuItem.Click += new System.EventHandler(this.cancelToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] { "EnrollmentID", "StudentName", "Course", "TeacherName", "Status" });
            this.comboBox1.Location = new System.Drawing.Point(26, 247);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(156, 26);
            this.comboBox1.TabIndex = 112;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(202, 247);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(317, 27);
            this.textBox1.TabIndex = 113;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // GridViewEnrollmentsList
            // 
            this.GridViewEnrollmentsList.AllowUserToAddRows = false;
            this.GridViewEnrollmentsList.AllowUserToDeleteRows = false;
            this.GridViewEnrollmentsList.AllowUserToResizeColumns = false;
            this.GridViewEnrollmentsList.AllowUserToResizeRows = false;
            this.GridViewEnrollmentsList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.GridViewEnrollmentsList.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.GridViewEnrollmentsList.BackgroundColor = System.Drawing.Color.White;
            this.GridViewEnrollmentsList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridViewEnrollmentsList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewEnrollmentsList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.GridViewEnrollmentsList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridViewEnrollmentsList.ContextMenuStrip = this.contextMenuStrip1;
            this.GridViewEnrollmentsList.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.GridViewEnrollmentsList.Location = new System.Drawing.Point(24, 286);
            this.GridViewEnrollmentsList.Margin = new System.Windows.Forms.Padding(0);
            this.GridViewEnrollmentsList.Name = "GridViewEnrollmentsList";
            this.GridViewEnrollmentsList.ReadOnly = true;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GridViewEnrollmentsList.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.GridViewEnrollmentsList.RowHeadersVisible = false;
            this.GridViewEnrollmentsList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            this.GridViewEnrollmentsList.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.GridViewEnrollmentsList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GridViewEnrollmentsList.Size = new System.Drawing.Size(933, 236);
            this.GridViewEnrollmentsList.TabIndex = 111;
            // 
            // EnrollmentsScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 577);
            this.Controls.Add(this.cbStatus);
            this.Controls.Add(this.lblRecords);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbPeopleImage);
            this.Controls.Add(this.btnNewEnrollment);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.GridViewEnrollmentsList);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "EnrollmentsScreen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "   Enrollments Screen";
            this.Load += new System.EventHandler(this.EnrollmentsScreen_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbPeopleImage)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GridViewEnrollmentsList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ToolStripMenuItem canceleToolStripMenuItem;

        private System.Windows.Forms.ToolStripMenuItem showStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showTeacherInfoToolStripMenuItem;

        private System.Windows.Forms.ComboBox cbStatus;
        private System.Windows.Forms.Label lblRecords;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbPeopleImage;
        private System.Windows.Forms.Button btnNewEnrollment;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem showDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView GridViewEnrollmentsList;

        #endregion
    }
}