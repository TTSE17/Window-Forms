﻿using System.ComponentModel;

namespace InstitutionPresentationLayer.Enrollments
{
    partial class ctrlEnrollmentInfo
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEnrollmentDate = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblCourse = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblEnrollmentID = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ctrlTeacherInfo1 = new InstitutionPresentationLayer.Teachers.ctrlTeacherInfo();
            this.ctrlStudentInfo1 = new InstitutionPresentationLayer.Students.ctrlStudentInfo();
            this.SuspendLayout();
            // 
            // lblEnrollmentDate
            // 
            this.lblEnrollmentDate.AutoEllipsis = true;
            this.lblEnrollmentDate.AutoSize = true;
            this.lblEnrollmentDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnrollmentDate.Location = new System.Drawing.Point(1040, 0);
            this.lblEnrollmentDate.Name = "lblEnrollmentDate";
            this.lblEnrollmentDate.Size = new System.Drawing.Size(46, 25);
            this.lblEnrollmentDate.TabIndex = 92;
            this.lblEnrollmentDate.Text = "N/A";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(864, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 25);
            this.label3.TabIndex = 91;
            this.label3.Text = "Enrollment Date :";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoEllipsis = true;
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.Location = new System.Drawing.Point(660, 0);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(46, 25);
            this.lblStatus.TabIndex = 90;
            this.lblStatus.Text = "N/A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(302, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 25);
            this.label4.TabIndex = 89;
            this.label4.Text = "Course :";
            // 
            // lblCourse
            // 
            this.lblCourse.AutoEllipsis = true;
            this.lblCourse.AutoSize = true;
            this.lblCourse.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCourse.Location = new System.Drawing.Point(395, 0);
            this.lblCourse.Name = "lblCourse";
            this.lblCourse.Size = new System.Drawing.Size(46, 25);
            this.lblCourse.TabIndex = 88;
            this.lblCourse.Text = "N/A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(575, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 25);
            this.label2.TabIndex = 87;
            this.label2.Text = "Status :";
            // 
            // lblEnrollmentID
            // 
            this.lblEnrollmentID.AutoEllipsis = true;
            this.lblEnrollmentID.AutoSize = true;
            this.lblEnrollmentID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnrollmentID.Location = new System.Drawing.Point(165, 0);
            this.lblEnrollmentID.Name = "lblEnrollmentID";
            this.lblEnrollmentID.Size = new System.Drawing.Size(46, 25);
            this.lblEnrollmentID.TabIndex = 86;
            this.lblEnrollmentID.Text = "N/A";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 25);
            this.label5.TabIndex = 85;
            this.label5.Text = "Enrollment ID :";
            // 
            // ctrlTeacherInfo1
            // 
            this.ctrlTeacherInfo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlTeacherInfo1.Location = new System.Drawing.Point(604, 46);
            this.ctrlTeacherInfo1.Name = "ctrlTeacherInfo1";
            this.ctrlTeacherInfo1.Size = new System.Drawing.Size(609, 294);
            this.ctrlTeacherInfo1.TabIndex = 84;
            // 
            // ctrlStudentInfo1
            // 
            this.ctrlStudentInfo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlStudentInfo1.Location = new System.Drawing.Point(3, 46);
            this.ctrlStudentInfo1.Name = "ctrlStudentInfo1";
            this.ctrlStudentInfo1.Size = new System.Drawing.Size(595, 294);
            this.ctrlStudentInfo1.TabIndex = 83;
            // 
            // ctrlEnrollmentInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblEnrollmentDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblCourse);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblEnrollmentID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ctrlTeacherInfo1);
            this.Controls.Add(this.ctrlStudentInfo1);
            this.Name = "ctrlEnrollmentInfo";
            this.Size = new System.Drawing.Size(1217, 343);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblEnrollmentDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblCourse;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblEnrollmentID;
        private System.Windows.Forms.Label label5;
        private InstitutionPresentationLayer.Teachers.ctrlTeacherInfo ctrlTeacherInfo1;
        private InstitutionPresentationLayer.Students.ctrlStudentInfo ctrlStudentInfo1;

        #endregion
    }
}