﻿using System.ComponentModel;

namespace InstitutionPresentationLayer.Enrollments
{
    partial class ShowEnrollmentInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ctrlEnrollmentInfo1 = new InstitutionPresentationLayer.Enrollments.ctrlEnrollmentInfo();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 23F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(439, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(323, 35);
            this.label1.TabIndex = 94;
            this.label1.Text = "Enrollment Information";
            // 
            // ctrlEnrollmentInfo1
            // 
            this.ctrlEnrollmentInfo1.Location = new System.Drawing.Point(12, 95);
            this.ctrlEnrollmentInfo1.Name = "ctrlEnrollmentInfo1";
            this.ctrlEnrollmentInfo1.Size = new System.Drawing.Size(1217, 343);
            this.ctrlEnrollmentInfo1.TabIndex = 95;
            // 
            // ShowEnrollmentInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1237, 450);
            this.Controls.Add(this.ctrlEnrollmentInfo1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "ShowEnrollmentInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "   Show Enrollment Information";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private InstitutionPresentationLayer.Enrollments.ctrlEnrollmentInfo ctrlEnrollmentInfo1;

        private System.Windows.Forms.Label label1;

        #endregion
    }
}