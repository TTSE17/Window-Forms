﻿using System.Windows.Forms;

namespace InstitutionPresentationLayer.Enrollments
{
    public partial class ShowEnrollmentInfo : Form
    {
        public ShowEnrollmentInfo(int ID)
        {
            InitializeComponent();
            ctrlEnrollmentInfo1.LoadInfo(ID);
        }
    }
}