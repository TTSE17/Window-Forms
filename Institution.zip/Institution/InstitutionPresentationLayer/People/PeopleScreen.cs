﻿using System;
using System.Data;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.People
{
    public partial class PeopleScreen : Form
    {
        public PeopleScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private void PeopleScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = PeopleBusinessLayer.GetAllPeople();

            comboBox1.SelectedIndex = cbGender.SelectedIndex = 0;

            comboBox1.Enabled = textBox1.Enabled = true;

            if (GridViewPeopleList.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }
            
            _SetWidthColumns();


            LoadData();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("PersonID", typeof(int));
            _DataTable.Columns.Add("Name", typeof(string));
            _DataTable.Columns.Add("Gender", typeof(byte));
            _DataTable.Columns.Add("Email", typeof(string));
            _DataTable.Columns.Add("DateOfBirth", typeof(DateTime));
            _DataTable.Columns.Add("Address", typeof(string));
            _DataTable.Columns.Add("ImagePath", typeof(string));

            _SetWidthColumns();

            comboBox1.Enabled = textBox1.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewPeopleList.Columns[0].Width = 51;
            GridViewPeopleList.Columns[1].Width = 99;
            GridViewPeopleList.Columns[2].Width = 59;
            GridViewPeopleList.Columns[3].Width = 91;
            GridViewPeopleList.Columns[4].Width = 79;
            GridViewPeopleList.Columns[5].Width = 99;
            GridViewPeopleList.Columns[6].Width = 111;
        }

        private void LoadData(string Type = "PersonID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;

            var DataFilter = "";

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "PersonID" || Type == "Gender")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewPeopleList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewPeopleList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsActiveChoice = comboBox1.SelectedIndex == 2;

            textBox1.Visible = !IsActiveChoice;
            cbGender.Visible = IsActiveChoice;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbGender.SelectedItem);

            var IsActiveValue = Selection == "All" ? "" : Selection;

            LoadData("Gender", IsActiveValue);
        }

        private void btnNewPerson_Click(object sender, EventArgs e)
        {
            
        }
    }
}