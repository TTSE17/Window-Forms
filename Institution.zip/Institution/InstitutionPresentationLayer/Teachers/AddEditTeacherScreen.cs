﻿using System;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Properties;

namespace InstitutionPresentationLayer.Teachers
{
    public partial class AddEditTeacherScreen : Form
    {
        private int _TeacherID;
        private TeachersBusinessLayer _Teacher1;

        public AddEditTeacherScreen(int teacherId = -1)
        {
            InitializeComponent();
            _TeacherID = teacherId;
        }

        private void AddEditTeacherScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadCourses();

            pbPerson.ImageLocation = null;

            DateTimePicker.MaxDate = DateTime.Now.AddYears(-21);
            DateTimePicker.MinDate = DateTime.Now.AddYears(-100);

            if (_TeacherID == -1)
            {
                _Teacher1 = new TeachersBusinessLayer();
                lblTitleForm.Text = "Add New Teachers";
                lblTeacherID.Text = "N/A";
                lilRemoveImage.Visible = false;
                cbCourses.SelectedIndex = 0;
            }

            else
            {
                _Teacher1 = TeachersBusinessLayer.FindTeacher(_TeacherID);

                if (_Teacher1 == null) return;

                lblTitleForm.Text = "Update Teachers";

                lblTeacherID.Text = Convert.ToString(_TeacherID);
                txtName.Text = _Teacher1.Name;
                cbCourses.SelectedIndex = cbCourses.FindString(_Teacher1.CourseInfo.Subject);
                if (_Teacher1.Gender == 1)
                    rbMale.Checked = true;
                else
                    rbFemale.Checked = true;
                txtEmail.Text = _Teacher1.Email;
                DateTimePicker.Value = _Teacher1.DateOfBirth;
                txtAddress.Text = _Teacher1.Address;

                if (_Teacher1.ImagePath != "" && File.Exists(_Teacher1.ImagePath))
                {
                    pbPerson.ImageLocation = _Teacher1.ImagePath;
                    lilRemoveImage.Visible = true;
                }
                else
                {
                    pbPerson.Image = (rbMale.Checked) ? Resources.teacher : Resources.teacher_female;
                    lilRemoveImage.Visible = false;
                }
            }
        }

        private void LoadCourses()
        {
            var dt = CoursesBusinessLayer.GetAllCourses();

            foreach (DataRow Row in dt.Rows)
            {
                cbCourses.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private void RadioButton_CheckedChanged(object sender, EventArgs e)
        {
            var Item = (RadioButton)sender;

            if (pbPerson.ImageLocation != null) return;

            pbPerson.Image = (rbMale.Checked) ? Resources.teacher : Resources.teacher_female;
        }

        private void lilSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;

            var selectedFilePath = openFileDialog1.FileName;

            pbPerson.ImageLocation = selectedFilePath;

            lilRemoveImage.Visible = true;
        }

        private void lilRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pbPerson.ImageLocation = null;
            pbPerson.Image = (rbMale.Checked) ? Resources.teacher : Resources.teacher_female;

            lilRemoveImage.Visible = false;
        }

        private void textBox_Validate(object sender, CancelEventArgs e)
        {
            var Temp = (TextBox)sender;
            if (string.IsNullOrEmpty(Temp.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(Temp, "This field is required!");
            }
            else
            {
                errorProvider1.SetError(Temp, null);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateChildren())
            {
                MessageBox.Show("Some fields are not valide!, put the mouse over the red icon(s) to see the erro",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var Name = txtName.Text.Trim();
            var CourseID = CoursesBusinessLayer.FindCourse(cbCourses.Text).CourseId;
            var Gender = Convert.ToInt16((rbMale.Checked) ? 1 : 0);
            var Email = txtEmail.Text.Trim();
            var BirthDate = DateTimePicker.Value;
            var Address = txtAddress.Text.Trim();
            var ImagePath = pbPerson.ImageLocation;

            if (TeachersBusinessLayer.SpecialityHasThreeTeachers(CourseID))
            {
                MessageBox.Show("You Can't Add More Than Three Teacher In This Speciality",
                    "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            lblTitleForm.Text = "Update Teachers";

            _Teacher1.Name = Name;
            _Teacher1.CourseID = CourseID;
            _Teacher1.Gender = Gender;
            _Teacher1.Email = Email;
            _Teacher1.DateOfBirth = BirthDate;
            _Teacher1.Address = Address;

            _HandleImage();

            _Teacher1.ImagePath = pbPerson.ImageLocation ?? "";

            MessageBox.Show(_Teacher1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblTeacherID.Text = Convert.ToString(_Teacher1.TeacherID);

            _TeacherID = _Teacher1.TeacherID;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void _HandleImage()
        {
            if (_Teacher1.ImagePath == pbPerson.ImageLocation) return;

            if (_Teacher1.ImagePath != "")
            {
                try
                {
                    File.Delete(_Teacher1.ImagePath);
                }
                catch (IOException ee)
                {
                    // MessageBox.Show(ee + "");
                }
            }

            if (pbPerson.ImageLocation != null)
            {
                var SourceImageFile = pbPerson.ImageLocation;

                var CurrentPath =
                    Directory.GetCurrentDirectory()+"\\Images\\"
                    + Guid.NewGuid() + Path.GetExtension(SourceImageFile);

                File.Copy(SourceImageFile, CurrentPath, true);

                pbPerson.ImageLocation = CurrentPath;
            }
        }
    }
}