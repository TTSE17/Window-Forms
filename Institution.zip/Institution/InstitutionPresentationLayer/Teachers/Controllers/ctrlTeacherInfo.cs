﻿using System;
using System.IO;
using System.Windows.Forms;
using InstitutionBusinessLayer;
using InstitutionPresentationLayer.Properties;

namespace InstitutionPresentationLayer.Teachers
{
    public partial class ctrlTeacherInfo : UserControl
    {
        public ctrlTeacherInfo()
        {
            InitializeComponent();
        }

        private int _TeacherID;
        private TeachersBusinessLayer _Teacher1;

        public void LoadTeacherInfo(int TeacherID)
        {
            _TeacherID = TeacherID;
            LoadData();
        }

        private void LoadData()
        {
            _Teacher1 = TeachersBusinessLayer.FindTeacher(_TeacherID);

            if (_Teacher1 == null) return;

            lblTeacherID.Text = Convert.ToString(_Teacher1.TeacherID);
            lblName.Text = _Teacher1.Name;
            lblSpecialization.Text = _Teacher1.CourseInfo.Subject;
            lblEmail.Text = _Teacher1.Email;
            lblGender.Text = (_Teacher1.Gender == 1) ? "Male" : "Female";
            lblDateOfBirth.Text = _Teacher1.DateOfBirth.ToString("dd/MM/yyyy");
            lblAddress.Text = _Teacher1.Address;

            if (_Teacher1.ImagePath != "" && File.Exists(_Teacher1.ImagePath))
                pbPerson.ImageLocation = _Teacher1.ImagePath;

            else
                pbPerson.Image = (_Teacher1.Gender == 1) ? Resources.teacher : Resources.teacher_female;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new AddEditTeacherScreen(_TeacherID);
            fr.ShowDialog();

            LoadTeacherInfo(_TeacherID);
        }
    }
}