﻿using System;
using System.Data;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.Teachers
{
    public partial class ctrlTeacherStudents : UserControl
    {
        public ctrlTeacherStudents()
        {
            InitializeComponent();
        }

        private DataTable DT;

        public void LoadTeacherStudents(int TeacherID)
        {
            LoadData(TeacherID);
        }

        private void LoadData(int TeacherID)
        {
            DT = TeachersBusinessLayer.GetAllTeacherStudents(TeacherID);
            if (DT.Columns.Count > 0)
                GridViewStudentCoursesList.DataSource = DT;
            else
                _SetDefaultColumns();

            lblRecords.Text = Convert.ToString(DT.Rows.Count);
        }

        private void _SetDefaultColumns()
        {
            DT.Columns.Add("Student Name");
            DT.Columns.Add("Course");
            DT.Columns.Add("Enrollment Date");
            DT.Columns.Add("Status");

            GridViewStudentCoursesList.DataSource = DT;

            // _SetWidthColumns();

            if (GridViewStudentCoursesList.Rows.Count > 0)
                GridViewStudentCoursesList.Rows.RemoveAt(0);
        }

        private void _SetWidthColumns()
        {
            GridViewStudentCoursesList.Columns[0].Width = 71;
            GridViewStudentCoursesList.Columns[1].Width = 71;
            GridViewStudentCoursesList.Columns[2].Width = 79;
            GridViewStudentCoursesList.Columns[3].Width = 59;
        }
    }
}