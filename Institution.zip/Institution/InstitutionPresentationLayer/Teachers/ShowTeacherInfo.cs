﻿using System;
using System.Windows.Forms;

namespace InstitutionPresentationLayer.Teachers
{
    public partial class ShowTeacherInfo : Form
    {
        public ShowTeacherInfo(int TeacherID)
        {
            InitializeComponent();
            ctrlTeacherInfo1.LoadTeacherInfo(TeacherID);
        }
    }
}