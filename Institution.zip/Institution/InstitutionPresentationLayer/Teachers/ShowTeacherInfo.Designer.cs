﻿using System.ComponentModel;

namespace InstitutionPresentationLayer.Teachers
{
    partial class ShowTeacherInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlTeacherInfo1 = new InstitutionPresentationLayer.Teachers.ctrlTeacherInfo();
            this.lblTitleForm = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ctrlTeacherInfo1
            // 
            this.ctrlTeacherInfo1.Location = new System.Drawing.Point(11, 83);
            this.ctrlTeacherInfo1.Name = "ctrlTeacherInfo1";
            this.ctrlTeacherInfo1.Size = new System.Drawing.Size(606, 290);
            this.ctrlTeacherInfo1.TabIndex = 0;
            // 
            // lblTitleForm
            // 
            this.lblTitleForm.AutoSize = true;
            this.lblTitleForm.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitleForm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTitleForm.Location = new System.Drawing.Point(189, 21);
            this.lblTitleForm.Name = "lblTitleForm";
            this.lblTitleForm.Size = new System.Drawing.Size(278, 36);
            this.lblTitleForm.TabIndex = 14;
            this.lblTitleForm.Text = "Teacher information";
            // 
            // ShowTeacherInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 394);
            this.Controls.Add(this.lblTitleForm);
            this.Controls.Add(this.ctrlTeacherInfo1);
            this.Name = "ShowTeacherInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ShowTeacherInfo";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblTitleForm;

        private InstitutionPresentationLayer.Teachers.ctrlTeacherInfo ctrlTeacherInfo1;

        #endregion
    }
}