﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.Teachers
{
    public partial class TeachersScreen : Form
    {
        public TeachersScreen()
        {
            InitializeComponent();
        }


        private DataTable _DataTable;

        private int _TeacherID;
        private TeachersBusinessLayer _Teacher1;

        private void TeachersScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void TeachersScreen_Shown(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = TeachersBusinessLayer.GetAllTeachers();

            comboBox1.Enabled = textBox1.Enabled = true;

            if (_DataTable.Columns.Count <= 0)
            {
                _SetDefaultColumns();
                return;
            }

            comboBox1.SelectedIndex = cbGender.SelectedIndex = 0;
            LoadData();

            _SetWidthColumns();
        }

        private void _SetDefaultColumns()
        {
            _DataTable.Columns.Add("TeacherID", typeof(int));
            _DataTable.Columns.Add("Name", typeof(string));
            _DataTable.Columns.Add("Specializtion", typeof(string));
            _DataTable.Columns.Add("Gender", typeof(byte));
            _DataTable.Columns.Add("Email", typeof(string));
            _DataTable.Columns.Add("DateOfBirth", typeof(DateTime));
            _DataTable.Columns.Add("Address", typeof(string));
            _DataTable.Columns.Add("ImagePath", typeof(string));

            GridViewTeachersList.DataSource = _DataTable;

            _SetWidthColumns();

            if (GridViewTeachersList.Rows.Count > 0)
                GridViewTeachersList.Rows.RemoveAt(0);

            comboBox1.Enabled = cbGender.Enabled = textBox1.Enabled = false;
        }

        private void _SetWidthColumns()
        {
            GridViewTeachersList.Columns[0].Width = 51;
            GridViewTeachersList.Columns[1].Width = 99;
            GridViewTeachersList.Columns[2].Width = 71;
            GridViewTeachersList.Columns[3].Width = 51;
            GridViewTeachersList.Columns[4].Width = 71;
            GridViewTeachersList.Columns[5].Width = 71;
            GridViewTeachersList.Columns[6].Width = 99;
            GridViewTeachersList.Columns[7].Width = 99;
        }

        private void LoadData(string Type = "TeacherID", string Text = "")
        {
            var _DataView1 = _DataTable.DefaultView;
            var DataFilter = "";

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "TeacherID" || Type == "Gender")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";
                _DataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                _DataView1.RowFilter = null;
            }

            GridViewTeachersList.DataSource = _DataView1;

            lblRecords.Text = Convert.ToString(GridViewTeachersList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsActiveChoice = comboBox1.SelectedIndex == 3;

            textBox1.Visible = !IsActiveChoice;
            cbGender.Visible = IsActiveChoice;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbGender_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbGender.SelectedItem);

            var GenderValue = Selection == "All" ? "" : Selection;

            LoadData("Gender", GenderValue);
        }

        private void btnNewTeacher_Click(object sender, EventArgs e)
        {
            var fr = new AddEditTeacherScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = GridViewTeachersList.Rows.Count <= 0;
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateTeacherInfo(Convert.ToInt32(GridViewTeachersList.CurrentRow.Cells[0].Value));

            var fr = new ShowTeacherInfo(_TeacherID);
            fr.ShowDialog();

            RefreshData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateTeacherInfo(Convert.ToInt32(GridViewTeachersList.CurrentRow.Cells[0].Value));

            var fr = new AddEditTeacherScreen(_TeacherID);
            fr.ShowDialog();

            RefreshData();
        }

        private void showStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateTeacherInfo(Convert.ToInt32(GridViewTeachersList.CurrentRow.Cells[0].Value));

            var fr = new ShowTeacherStudents(_TeacherID);
            fr.ShowDialog();

            RefreshData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateTeacherInfo(Convert.ToInt32(GridViewTeachersList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to delete [" + _TeacherID + "]", "Confirm Delete",
                    MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) !=
                DialogResult.OK)
                return;

            if (_Teacher1.Delete())
            {
                MessageBox.Show("Teacher Deleted Successfully.", "Deleted",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);

                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete Teacher, other data depends on it.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateTeacherInfo(int ID)
        {
            _TeacherID = ID;
            _Teacher1 = TeachersBusinessLayer.FindTeacher(_TeacherID);
        }
    }
}