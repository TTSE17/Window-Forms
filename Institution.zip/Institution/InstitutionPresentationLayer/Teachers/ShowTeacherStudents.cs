﻿using System.Windows.Forms;

namespace InstitutionPresentationLayer.Teachers
{
    public partial class ShowTeacherStudents : Form
    {
        public ShowTeacherStudents(int TeacherID)
        {
            InitializeComponent();
            ctrlTeacherInfo1.LoadTeacherInfo(TeacherID);
            ctrlTeacherStudents1.LoadTeacherStudents(TeacherID);
        }
    }
}