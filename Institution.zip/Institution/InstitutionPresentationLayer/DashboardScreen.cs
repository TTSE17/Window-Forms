﻿using System;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer
{
    public partial class DashboardScreen : Form
    {
        public DashboardScreen()
        {
            InitializeComponent();
        }

        private void DashboardScreen_Load(object sender, EventArgs e)
        {
            int countOfStudents = -1, countOfTeachers = -1, countOfEnrollments = -1;
            StudentsBusinessLayer.GetNumberStudents(ref countOfStudents);
            TeachersBusinessLayer.GetNumberTeachers(ref countOfTeachers);
            EnrollmentsBusinessLayer.GetNumberEnrollments(ref countOfEnrollments);

            lbCountStudents.Text = Convert.ToString(countOfStudents);
            lbCountEnrollments.Text = Convert.ToString(countOfEnrollments);
            lbCountTeachers.Text = Convert.ToString(countOfTeachers);
        }
    }
}