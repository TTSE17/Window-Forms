﻿using System;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.Courses
{
    public partial class CoursesScreen : Form
    {
        public CoursesScreen()
        {
            InitializeComponent();
        }

        private void CoursesScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            GridViewCoursesList.DataSource = CoursesBusinessLayer.GetAllCourses();
            lblRecords.Text = Convert.ToString(GridViewCoursesList.Rows.Count);

            GridViewCoursesList.Columns[0].Width = 71;
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var CourseID = Convert.ToInt32(GridViewCoursesList.CurrentRow.Cells[0].Value);

            var fr = new EditCourseScreen(CourseID);
            fr.ShowDialog();

            LoadData();
        }
    }
}