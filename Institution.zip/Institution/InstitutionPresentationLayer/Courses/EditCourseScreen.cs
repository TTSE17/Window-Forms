﻿using System;
using System.Windows.Forms;
using InstitutionBusinessLayer;

namespace InstitutionPresentationLayer.Courses
{
    public partial class EditCourseScreen : Form
    {
        private int _CourseID;
        private CoursesBusinessLayer _Course1;

        public EditCourseScreen(int courseID)
        {
            InitializeComponent();
            _CourseID = courseID;
        }

        private void EditCourseScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _Course1 = CoursesBusinessLayer.FindCourse(_CourseID);

            lblCourseID.Text = Convert.ToString(_CourseID);
            txtSubject.Text = _Course1.Subject;
            txtSessions.Text = Convert.ToString(_Course1.Sessions);
            numericUpDown1.Value = Convert.ToDecimal(_Course1.Cost);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var Cost = numericUpDown1.Value;
            if (_Course1.Cost == Cost)
            {
                MessageBox.Show("Data Saved Successfully");
                return;
            }

            _Course1.Cost = Cost;
            MessageBox.Show(_Course1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}