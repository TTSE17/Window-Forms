﻿using System;
using System.Drawing;
using System.Windows.Forms;
using InstitutionPresentationLayer.Courses;
using InstitutionPresentationLayer.Enrollments;
using InstitutionPresentationLayer.Students;
using InstitutionPresentationLayer.Teachers;

namespace InstitutionPresentationLayer
{
    public partial class MainScreen : Form
    {
        private Form fr;
        private ToolStripMenuItem LastItem ;

        public MainScreen()
        {
            InitializeComponent();

            lblDateTime.Text = GetDateTime();
            ChildForm.MainPanel = MainContainer;
        }

        private void MainScreen_Load(object sender, EventArgs e)
        {
            dashBoardToolStripMenuItem.PerformClick();
        }

        private void dashBoardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeActiveItem(dashBoardToolStripMenuItem);

            fr = new DashboardScreen();
            ChildForm.OpenChildFormInPanel(ref fr);
        }

        private void studentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeActiveItem(studentsToolStripMenuItem);

            fr = new StudentsScreen();
            ChildForm.OpenChildFormInPanel(ref fr);
        }

        private void teachersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeActiveItem(teachersToolStripMenuItem);

            fr = new TeachersScreen();
            ChildForm.OpenChildFormInPanel(ref fr);
        }

        private void enrollmentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeActiveItem(enrollmentsToolStripMenuItem);

            fr = new EnrollmentsScreen();
            ChildForm.OpenChildFormInPanel(ref fr);
        }

        private void coursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangeActiveItem(coursesToolStripMenuItem);

            fr = new CoursesScreen();
            ChildForm.OpenChildFormInPanel(ref fr);
        }

        private void ToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            Cursor = Cursors.Hand;
        }

        private void ToolStripMenuItem_MouseLeave(object sender, EventArgs e)
        {
            Cursor = Cursors.Default;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblDateTime.Text = GetDateTime();
        }

        private static string GetDateTime()
        {
            return DateTime.Now.ToString("hh:mm:ss\nyyyy/MM/dd");
        }

        private void ChangeActiveItem(ToolStripMenuItem ActiveItem)
        {
            if (LastItem != null)
                LastItem.BackColor = Color.Black;

            ActiveItem.BackColor = Color.MidnightBlue;
            LastItem = ActiveItem;
        }
    }
}