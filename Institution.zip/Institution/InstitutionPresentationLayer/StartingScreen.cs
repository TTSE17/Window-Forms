﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace InstitutionPresentationLayer
{
    public partial class StartingScreen : Form
    {
        public StartingScreen()
        {
            InitializeComponent();
        }


        private void StartingScreen_Load(object sender, EventArgs e)
        {
            Thread.Sleep(1000);
            timer1.Enabled = true;
            label1.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // while (progressBar1.Value < progressBar1.Maximum) 
            // {
            //     // progressBar1.PerformStep();
            //     // progressBar1.Increment(1);
            //     progressBar1.Refresh();
            //     progressBar1.Value += 1;
            //
            //     // label1.Text = progressBar1.Value + "%";
            //     // label1.Refresh();
            //
            //     // MessageBox.Show(progressBar1.Value + "");
            //     Thread.Sleep(30);
            // }

            // var i = 0;
            // for (i = 0; i <= progressBar1.Maximum + 1; i++)
            // {
            //     Thread.Sleep(50);
            //     progressBar1.Value = i;
            //     progressBar1.Value = Math.Max(i - 1, progressBar1.Minimum);
            //
            //
            //     progressBar1.Refresh();
            //     label1.Text = Convert.ToString(progressBar1.Value);
            //     label1.Refresh();
            // }
        }


        private const int Max_Width = 559;

        private void timer1_Tick(object sender, EventArgs e)
        {
            // if (i > 100)
            // {
            //     // Hide();
            //     // new StartingScreen().ShowDialog();
            //     // timer1.Enabled = false;
            //     return;
            // }

            // progressBar1.Value = i;
            //
            // if(i!=100)
            // progressBar1.Value = Math.Max(i - 1, progressBar1.Minimum);
            //
            // progressBar1.Refresh();
            // label1.Text = Convert.ToString(progressBar1.Value);
            // label1.Refresh();
            // i++;

            if (label2.Width >= Max_Width)
            {
                timer1.Enabled = false;

                Thread.Sleep(555);
                
                Hide();

                new MainScreen().ShowDialog();

                Close();

                return;
            }

            label2.Width++;
            label1.Location = new Point(label1.Location.X + 1, label1.Location.Y);

            var percent = (double)label2.Width / Max_Width * 100;

            label1.Text = Convert.ToString(Math.Round(percent) + "%");
            label1.Refresh();
        }
    }
}