﻿using System;
using System.Windows.Forms;
using InstitutionPresentationLayer.Courses;
using InstitutionPresentationLayer.Enrollments;
using InstitutionPresentationLayer.People;
using InstitutionPresentationLayer.Students;
using InstitutionPresentationLayer.Teachers;

namespace InstitutionPresentationLayer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Application.Run(new StudentsScreen());
            // Application.Run(new TeachersScreen());
            // Application.Run(new EnrollmentsScreen());
            Application.Run(new StartingScreen());
            // Application.Run(new MainScreen());
        }
    }
}