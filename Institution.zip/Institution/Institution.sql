
select * from Courses;

select PersonID , Name , Gender =
  CASE WHEN Gender=1 THEN 'Male' ELSE 'Female' End
,Email , DateOfBirth, Address, ImagePath=IsNull(ImagePath,'NULL') from People;

select  Students.StudentID , Name , Gender =
  CASE WHEN Gender=1 THEN 'Male' ELSE 'Female' End ,
  Email ,Payments,
  Courses=(Select Count(*) from Enrollments Where Students.StudentID=Enrollments.StudentID),
  DateOfBirth, Address,ImagePath=IsNull(ImagePath,'NULL') from Students 
Inner Join People on People.PersonID = Students.PersonID

select * from People;

select * from Students;

 DBCC CHECKIDENT (Students, RESEED,0);
 DBCC CHECKIDENT (People,RESEED, 0)

select * from People;

select * from Teachers;

select * from Courses;

select Teachers.TeacherID ,Name ,Subject ,Gender =
  CASE WHEN Gender=1 THEN 'Male' ELSE 'Female' End ,
  Email ,
  DateOfBirth, Address,ImagePath=IsNull(ImagePath,'NULL') from Teachers 
RIGHT Join People on People.PersonID = Teachers.PersonID
Inner Join Courses on Courses.CourseID = Teachers.CourseID

select * from Enrollments;

select * from Enrollments_View ;


--UPDATE Students
--   SET Payments += (select Cost from Courses where CourseID = 1)
--   WHERE StudentID =1;

select StudentName ,Course ,  enrollments.EnrollmentDate , Enrollments_View.Status from Enrollments
inner join Enrollments_View on Enrollments.EnrollmentID = Enrollments_View.EnrollmentID
Where Enrollments.TeacherID=6;



