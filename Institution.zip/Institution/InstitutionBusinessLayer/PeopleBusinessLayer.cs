﻿using System;
using System.Data;
using InstitutionDataAccessLayer;

namespace InstitutionBusinessLayer
{
    public class PeopleBusinessLayer
    {
        public int PersonID { get; set; }
        public string Name { get; set; }
        public short Gender { get; set; }
        public string Email { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public string ImagePath { get; set; }

        public PeopleBusinessLayer()
        {
            PersonID = -1;
        }

        private PeopleBusinessLayer(int personID, string name, short gender, string email, DateTime dateOfBirth,
            string address, string imagePath)
        {
            PersonID = personID;
            Name = name;
            Gender = gender;
            Email = email;
            DateOfBirth = dateOfBirth;
            Address = address;
            ImagePath = imagePath;
        }


        public static DataTable GetAllPeople()
        {
            return PeopleDataAccessLayer.GetAllPeople();
        }

        public static PeopleBusinessLayer FindPerson(int ID)
        {
            string name = "", address = "", email = "", imagePath = "";
            var dateOfBirth = default(DateTime);
            short gender = 0;

            if (PeopleDataAccessLayer.GetPersonByID(ID, ref name, ref gender, ref email,
                    ref dateOfBirth, ref address, ref imagePath))
                return new PeopleBusinessLayer(ID, name, gender, email, dateOfBirth, address, imagePath);

            return null;
        }

        private int _AddNewPerson()
        {
            return PeopleDataAccessLayer.AddNewPerson(Name, Gender, Email, DateOfBirth, Address, ImagePath);
        }

        private bool _UpdatePerson()
        {
            return PeopleDataAccessLayer.UpdatePerson(PersonID, Name, Gender, Email, DateOfBirth, Address, ImagePath);
        }

        public bool Save()
        {
            if (this.PersonID != -1) return _UpdatePerson();

            PersonID = _AddNewPerson();
            return true;
        }

        public bool DeletePerson(int ID)
        {
            return PeopleDataAccessLayer.DeletePerson(ID);
        }
    }
}