﻿using System;
using System.Data;
using InstitutionDataAccessLayer;

namespace InstitutionBusinessLayer
{
    public class StudentsBusinessLayer : PeopleBusinessLayer
    {
        public int StudentID { get; set; }
        public double Payments { get; set; }

        public StudentsBusinessLayer()
        {
            StudentID = PersonID = -1;
        }

        private StudentsBusinessLayer(int studentId, double payments, int personId)
        {
            StudentID = studentId;
            Payments = payments;
            PersonID = personId;
            var PersonInfo = FindPerson(PersonID);
            Name = PersonInfo.Name;
            Gender = PersonInfo.Gender;
            Email = PersonInfo.Email;
            DateOfBirth = PersonInfo.DateOfBirth;
            Address = PersonInfo.Address;
            ImagePath = PersonInfo.ImagePath;
        }

        public static DataTable GetAllStudents()
        {
            return StudentsDataAccessLayer.GetAllStudents();
        }

        public static DataTable GetAllStudentsNames()
        {
            return StudentsDataAccessLayer.GetAllStudentsNames();
        }

        public static DataTable GetAllStudentCourses(int studentID)
        {
            return StudentsDataAccessLayer.GetAllStudentCourses(studentID);
        }

        public static StudentsBusinessLayer FindStudent(int ID)
        {
            double payments = -1;
            var personID = -1;

            if (StudentsDataAccessLayer.GetStudentByID(ID, ref payments, ref personID))
                return new StudentsBusinessLayer(ID, payments, personID);

            return null;
        }

        public static StudentsBusinessLayer FindStudent(string name)
        {
            double payments = -1;
            var personID = -1;
            var studentID = -1;

            if (StudentsDataAccessLayer.GetStudentByName(name, ref studentID, ref payments, ref personID))
                return new StudentsBusinessLayer(studentID, payments, personID);

            return null;
        }

        private int _AddNewStudent()
        {
            return StudentsDataAccessLayer.AddNewStudent(Payments, PersonID);
        }

        private bool _UpdateStudent()
        {
            return StudentsDataAccessLayer.UpdateStudent(StudentID, Payments, PersonID);
        }

        public bool Save()
        {
            if (!base.Save())
                return false;

            if (this.StudentID != -1) return _UpdateStudent();

            StudentID = _AddNewStudent();
            return true;
        }

        public bool Delete()
        {
            var IsStudentDeleted = StudentsDataAccessLayer.DeleteStudent(StudentID);


            if (!IsStudentDeleted)
                return false;

            var IsPersonDeleted = DeletePerson(PersonID);
            return IsPersonDeleted;
        }

        public static bool ExistStudent(string name)
        {
            return StudentsDataAccessLayer.ExistStudent(name);
        }

        public static void GetNumberStudents(ref int count)
        {
            StudentsDataAccessLayer.GetNumberStudents(ref count);
        }
    }
}