﻿using System;
using System.Data;
using System.Windows.Forms;
using InstitutionDataAccessLayer;

namespace InstitutionBusinessLayer
{
    public class EnrollmentsBusinessLayer
    {
        public int EnrollmentID { get; set; }
        public int StudentID { get; set; }
        public StudentsBusinessLayer StudentInfo;
        public int CourseID { get; set; }
        public CoursesBusinessLayer CourseInfo;
        public int TeacherID { get; set; }
        public TeachersBusinessLayer TeacherInfo;
        public DateTime EnrollmentDate { get; set; }
        public bool Status { get; set; }

        public EnrollmentsBusinessLayer()
        {
            EnrollmentID = StudentID = CourseID = TeacherID = -1;
            StudentInfo = new StudentsBusinessLayer();
            CourseInfo = new CoursesBusinessLayer();
            TeacherInfo = new TeachersBusinessLayer();
        }

        private EnrollmentsBusinessLayer(int enrollmentId, int studentId, int courseId, int teacherId,
            DateTime enrollmentDate, bool status)
        {
            EnrollmentID = enrollmentId;
            StudentID = studentId;
            StudentInfo = StudentsBusinessLayer.FindStudent(StudentID);
            CourseID = courseId;
            CourseInfo = CoursesBusinessLayer.FindCourse(CourseID);
            TeacherID = teacherId;
            TeacherInfo = TeachersBusinessLayer.FindTeacher(TeacherID);
            EnrollmentDate = enrollmentDate;
            Status = status;
        }

        public static DataTable GetAllEnrollments()
        {
            return EnrollmentsDataAccessLayer.GetAllEnrollments();
        }

        public static EnrollmentsBusinessLayer FindEnrollment(int ID)
        {
            int studentID = -1, courseID = -1, teacherID = -1;
            var enrollmentDate = default(DateTime);
            var status = false;

            if (EnrollmentsDataAccessLayer.GetEnrollmentByID(ID, ref studentID, ref courseID, ref teacherID,
                    ref enrollmentDate, ref status))
                return new EnrollmentsBusinessLayer(ID, studentID, courseID, teacherID, enrollmentDate, status);

            return null;
        }

        private int _AddNewEnrollment()
        {
            return EnrollmentsDataAccessLayer.AddNewEnrollment(StudentID, CourseID, TeacherID, EnrollmentDate, Status);
        }

        private bool _UpdateEnrollment()
        {
            return EnrollmentsDataAccessLayer.UpdateEnrollment(EnrollmentID, StudentID, CourseID,
                TeacherID, EnrollmentDate, Status);
        }

        public bool Save()
        {
            if (this.EnrollmentID != -1) return _UpdateEnrollment();

            EnrollmentID = _AddNewEnrollment();
            return true;
        }

        public bool Cancel()
        {
            Status = false;
            return Save();
        }

        public bool Delete()
        {
            return EnrollmentsDataAccessLayer.DeleteEnrollment(EnrollmentID);
        }

        public static bool HasEnrollment(int studentID, int courseID, int teacherID)
        {
            return EnrollmentsDataAccessLayer.HasEnrollment(studentID, courseID, teacherID);
        }

        public static void GetNumberEnrollments(ref int count)
        {
            EnrollmentsDataAccessLayer.GetNumberEnrollments(ref count);
        }
    }
}