﻿using System.Data;
using InstitutionDataAccessLayer;

namespace InstitutionBusinessLayer
{
    public class TeachersBusinessLayer : PeopleBusinessLayer
    {
        public int TeacherID { get; set; }

        public int CourseID { get; set; }

        public CoursesBusinessLayer CourseInfo;

        public TeachersBusinessLayer()
        {
            TeacherID = PersonID = CourseID = -1;
            CourseInfo = new CoursesBusinessLayer();
        }

        private TeachersBusinessLayer(int TeacherId, int courseId, int personId)
        {
            TeacherID = TeacherId;
            CourseID = courseId;
            CourseInfo = CoursesBusinessLayer.FindCourse(courseId);
            PersonID = personId;
            var PersonInfo = PeopleBusinessLayer.FindPerson(PersonID);
            Name = PersonInfo.Name;
            Gender = PersonInfo.Gender;
            Email = PersonInfo.Email;
            DateOfBirth = PersonInfo.DateOfBirth;
            Address = PersonInfo.Address;
            ImagePath = PersonInfo.ImagePath;
        }

        public static DataTable GetAllTeachers()
        {
            return TeachersDataAccessLayer.GetAllTeachers();
        }


        public static DataTable GetAllTeachersNames()
        {
            return TeachersDataAccessLayer.GetAllTeachersNames();
        }

        public static DataTable GetAllTeachersNamesBySpeciality(int courseID)
        {
            return TeachersDataAccessLayer.GetAllTeachersNamesBySpeciality(courseID);
        }

        public static DataTable GetAllTeacherStudents(int TeacherID)
        {
            return TeachersDataAccessLayer.GetAllTeacherStudents(TeacherID);
        }

        public static TeachersBusinessLayer FindTeacher(int ID)
        {
            int personID = -1, courseID = -1;

            if (TeachersDataAccessLayer.GetTeacherByID(ID, ref courseID, ref personID))
                return new TeachersBusinessLayer(ID, courseID, personID);

            return null;
        }

        public static TeachersBusinessLayer FindTeacher(string name)
        {
            int personID = -1, courseID = -1, teacherID = -1;

            if (TeachersDataAccessLayer.GetTeacherByName(name, ref teacherID, ref courseID, ref personID))
                return new TeachersBusinessLayer(teacherID, courseID, personID);

            return null;
        }

        private int _AddNewTeacher()
        {
            return TeachersDataAccessLayer.AddNewTeacher(CourseID, PersonID);
        }

        private bool _UpdateTeacher()
        {
            return TeachersDataAccessLayer.UpdateTeacher(TeacherID, CourseID, PersonID);
        }

        public bool Save()
        {
            if (!base.Save())
                return false;

            if (this.TeacherID != -1) return _UpdateTeacher();

            TeacherID = _AddNewTeacher();
            return true;
        }

        public bool Delete()
        {
            var IsTeacherDeleted = TeachersDataAccessLayer.DeleteTeacher(TeacherID);

            if (!IsTeacherDeleted)
                return false;

            var IsPersonDeleted = DeletePerson(PersonID);
            return IsPersonDeleted;
        }

        public static bool SpecialityHasThreeTeachers(int courseID)
        {
            return TeachersDataAccessLayer.CountTeachersInSpeciality(courseID) >= 3;
        }

        public static void GetNumberTeachers(ref int count)
        {
            TeachersDataAccessLayer.GetNumberTeachers(ref count);
        }
    }
}