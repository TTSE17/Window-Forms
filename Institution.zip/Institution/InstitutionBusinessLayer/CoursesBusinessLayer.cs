﻿using System;
using System.Data;
using InstitutionDataAccessLayer;

namespace InstitutionBusinessLayer
{
    public class CoursesBusinessLayer
    {
        public int CourseId { get; private set; }
        public string Subject { get; set; }
        public int Sessions { get; set; }
        public decimal Cost { get; set; }

        public CoursesBusinessLayer()
        {
            CourseId = -1;
        }

        private CoursesBusinessLayer(int courseId, string subject, int sessions, decimal cost)
        {
            CourseId = courseId;
            Subject = subject;
            Sessions = sessions;
            Cost = cost;
        }


        public static DataTable GetAllCourses()
        {
            return CoursesDataAccessLayer.GetAllCourses();
        }

        public static CoursesBusinessLayer FindCourse(int ID)
        {
            var subject = "";
            var sessions = -1;
            decimal cost = -1;

            if (CoursesDataAccessLayer.GetCourseByID(ID, ref subject, ref sessions, ref cost))
                return new CoursesBusinessLayer(ID, subject, sessions, cost);

            return null;
        }

        public static CoursesBusinessLayer FindCourse(string subject)
        {
            var courseID = -1;
            var sessions = -1;
            decimal cost = -1;

            if (CoursesDataAccessLayer.GetCourseByName(ref courseID,  subject, ref sessions, ref cost))
                return new CoursesBusinessLayer(courseID, subject, sessions, cost);

            return null;
        }


        private int _AddNewCourse()
        {
            return CoursesDataAccessLayer.AddNewCourse(Subject, Sessions, Cost);
        }

        private bool _UpdateCourse()
        {
            return CoursesDataAccessLayer.UpdateCourse(CourseId, Subject, Sessions, Cost);
        }

        public bool Save()
        {
            if (this.CourseId != -1) return _UpdateCourse();

            CourseId = _AddNewCourse();
            return true;
        }

        public static bool DeleteCourse(int ID)
        {
            return CoursesDataAccessLayer.DeleteCourse(ID);
        }
    }
}