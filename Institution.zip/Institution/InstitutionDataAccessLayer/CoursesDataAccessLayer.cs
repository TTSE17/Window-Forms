﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InstitutionDataAccessLayer
{
    public class CoursesDataAccessLayer
    {
        public static DataTable GetAllCourses()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select * From Courses";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetCourseByID(int ID, ref string subject, ref int sessions, ref decimal cost)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Courses Where CourseID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    subject = (string)reader[1];
                    sessions = Convert.ToInt32(reader[2]);
                    cost = Convert.ToDecimal(reader[3]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetCourseByName(ref int courseID, string subject, ref int sessions, ref decimal cost)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Courses Where subject=@subject";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@subject", subject);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    courseID = (int)reader[0];
                    sessions = Convert.ToInt32(reader[2]);
                    cost = Convert.ToDecimal(reader[3]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }
        
        public static int AddNewCourse(string subject, int sessions, decimal cost)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Courses
                             VALUES (@subject,@sessions,@cost)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@subject", subject);
            command.Parameters.AddWithValue("@sessions", sessions);
            command.Parameters.AddWithValue("@cost", cost);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateCourse(int courseId, string subject, int sessions, decimal cost)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Courses
                            set subject=@subject,sessions=@sessions, cost= @cost 
                            where CourseId = @CourseId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@CourseId", courseId);
            command.Parameters.AddWithValue("@subject", subject);
            command.Parameters.AddWithValue("@sessions", sessions);
            command.Parameters.AddWithValue("@cost", cost);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteCourse(int CourseID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete from Courses Where CourseID=@CourseID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@CourseID", CourseID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}