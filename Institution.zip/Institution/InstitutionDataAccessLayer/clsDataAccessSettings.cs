﻿namespace InstitutionDataAccessLayer
{
    public class clsDataAccessSettings
    {
        public const string ConnectionString = "Server=.;Database=Institution;User Id=sa;Password=sa123456;";
    }
}