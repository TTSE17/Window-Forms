﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InstitutionDataAccessLayer
{
    public class EnrollmentsDataAccessLayer
    {
        public static DataTable GetAllEnrollments()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from Enrollments_View;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetEnrollmentByID(int ID, ref int studentID, ref int courseID, ref int teacherID,
            ref DateTime enrollmentDate, ref bool status)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Enrollments Where EnrollmentID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    studentID = (int)reader[1];
                    courseID = (int)reader[2];
                    teacherID = (int)reader[3];
                    enrollmentDate = (DateTime)reader[4];
                    status = (bool)reader[5];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewEnrollment(int studentId, int courseId, int teacherId,
            DateTime enrollmentDate, bool status)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Enrollments
                             VALUES (@studentId,@courseId,@teacherId,@enrollmentDate,@status)
                             SELECT SCOPE_IDENTITY();

                             UPDATE Students
                               SET Payments += (select Cost from Courses where CourseID = @courseId)
                               WHERE StudentID =@studentId;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@studentId", studentId);
            command.Parameters.AddWithValue("@courseId", courseId);
            command.Parameters.AddWithValue("@teacherId", teacherId);
            command.Parameters.AddWithValue("@enrollmentDate", enrollmentDate);
            command.Parameters.AddWithValue("@status", status);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateEnrollment(int EnrollmentId, int studentId, int courseId, int teacherId,
            DateTime enrollmentDate, bool status)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Enrollments
                            set studentId=@studentId,courseId=@courseId, teacherId= @teacherId ,
                                enrollmentDate=@enrollmentDate , status=@status
                            where EnrollmentId = @EnrollmentId;

                             UPDATE Students
                               SET Payments += (select Cost from Courses where CourseID = @courseId)
                               WHERE StudentID =@studentId;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@EnrollmentId", EnrollmentId);
            command.Parameters.AddWithValue("@studentId", studentId);
            command.Parameters.AddWithValue("@courseId", courseId);
            command.Parameters.AddWithValue("@teacherId", teacherId);
            command.Parameters.AddWithValue("@enrollmentDate", enrollmentDate);
            command.Parameters.AddWithValue("@status", status);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteEnrollment(int EnrollmentID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete from Enrollments Where EnrollmentID=@EnrollmentID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@EnrollmentID", EnrollmentID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool HasEnrollment(int studentId, int courseId, int teacherId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Select Found='1' From Enrollments
                              Where StudentID=@studentId And CourseID=@CourseID And TeacherID= @TeacherID And Status = 1";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@studentId", studentId);
            command.Parameters.AddWithValue("@courseId", courseId);
            command.Parameters.AddWithValue("@teacherId", teacherId);

            try
            {
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    isFound = reader.HasRows;
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isFound = false;
            }

            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static void GetNumberEnrollments(ref int count)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select count(1) from Enrollments";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    count = Convert.ToInt32(reader[0]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }
        }
    }
}