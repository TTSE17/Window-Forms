﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace InstitutionDataAccessLayer
{
    public class TeachersDataAccessLayer
    {
        public static DataTable GetAllTeachers()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select Teachers.TeacherID ,Name ,Subject ,Gender =
                              CASE WHEN Gender=1 THEN 'Male' ELSE 'Female' End ,
                              Email ,DateOfBirth, Address,ImagePath=IsNull(ImagePath,'NULL') from Teachers 
                             Inner Join People on People.PersonID = Teachers.PersonID
                             Inner Join Courses on Courses.CourseID = Teachers.CourseID;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable GetAllTeachersNames()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select Name from Teachers 
                             Inner Join People on People.PersonID = Teachers.PersonID;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable GetAllTeachersNamesBySpeciality(int courseID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select Name from Teachers 
                             Inner Join People on People.PersonID = Teachers.PersonID
                             Where CourseID = @CourseID;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("CourseID", courseID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable GetAllTeacherStudents(int TeacherID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select StudentName ,Course ,  enrollments.EnrollmentDate ,
                              Enrollments_View.Status from Enrollments
                              inner join Enrollments_View on Enrollments.EnrollmentID = Enrollments_View.EnrollmentID
                              Where Enrollments.TeacherID=@TeacherID;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@TeacherID", TeacherID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetTeacherByID(int ID, ref int courseID, ref int personID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Teachers Where TeacherID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    courseID = Convert.ToInt32(reader[1]);
                    personID = Convert.ToInt32(reader[2]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetTeacherByName(string name, ref int teacherID, ref int courseID, ref int personID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select * from Teachers 
                             INNER JOIN People On People.personID = Teachers.PersonID
                              Where name=@name";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@name", name);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    teacherID = Convert.ToInt32(reader[0]);
                    courseID = Convert.ToInt32(reader[1]);
                    personID = Convert.ToInt32(reader[2]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewTeacher(int courseID, int PersonID)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Teachers
                             VALUES (@courseID,@PersonID)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@courseID", courseID);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateTeacher(int TeacherId, int courseID, int personID)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Teachers
                            set courseID=@courseID,PersonID=@PersonID
                            where TeacherId = @TeacherId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TeacherId", TeacherId);
            command.Parameters.AddWithValue("@courseID", courseID);
            command.Parameters.AddWithValue("@PersonID", personID);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteTeacher(int TeacherID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete from Teachers Where TeacherID=@TeacherID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@TeacherID", TeacherID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static int CountTeachersInSpeciality(int courseID)
        {
            int Count = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Select Count(1) From Teachers Where CourseID = @CourseID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@CourseID", courseID);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int NumberOfTeachers))
                {
                    Count = NumberOfTeachers;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Count;
        }
        
        public static void GetNumberTeachers(ref int count)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select count(1) from Teachers";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    count = Convert.ToInt32(reader[0]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }
        }

    }
}