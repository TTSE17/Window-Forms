﻿using System;
using System.Windows.Forms;
using BusinessLayer;
using WindowsFormsApp1.Library;

namespace WindowsFormsApp1
{
    public partial class AddEditDonor : Form
    {
        private int _DonorId = -1;

        private DonorsBusinessLayer Donor1;

        private PersonBusinessLayer Perons1;

        public AddEditDonor(int ID = -1)
        {
            InitializeComponent();

            _DonorId = ID;
        }

        private void AddEditDonor_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_DonorId == -1)
            {
                Donor1 = new DonorsBusinessLayer();
                Perons1 = new PersonBusinessLayer();
                lbTitleForm.Text = "Add New Donor";
                lbDonorID.Text = "-";
            }

            else
            {
                Donor1 = DonorsBusinessLayer.FindDonor(_DonorId);
                Perons1 = PersonBusinessLayer.FindPerson(Donor1.PersonId);

                lbTitleForm.Text = "Edit Employee";
                lbDonorID.Text = Convert.ToString(Donor1.DonorId);
                tbAddress.Text = Perons1.Address;
                tbPhone.Text = Perons1.Phone;
                nupAge.Value = Perons1.Age;

                if (Perons1.Gender == "M")
                    rbMale.Checked = true;
                else
                    rbFemale.Checked = true;

                string[] Arr = Perons1.Name.Split(' ');
                tbFirstName.Text = Arr[0];
                tbLastName.Text = Arr[1];

                cbBloodGroup.SelectedIndex =
                    cbBloodGroup.FindString(BloodGroupsBusinessLayer.FindBlood(Perons1.BloodGroupID).BloodName);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Form fr = new Donors();
            OpenChildForm.OpenChildFormInPanel(ref fr);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int BloodGroupID = BloodGroupsBusinessLayer.FindBlood(cbBloodGroup.Text).BloodId;
            string Name = tbFirstName.Text.Trim() + " " + tbLastName.Text.Trim();
            string Phone = tbPhone.Text;
            string Address = tbAddress.Text;
            int Age = (int)nupAge.Value;
            string Gender = (rbMale.Checked) ? "M" : "F";

            // if (Username == "" || Password == "")
            // {
            //     MessageBox.Show("Enter Username , Password");
            //     return;
            // }

            lbTitleForm.Text = "Edit Donor";
            
            Perons1.Address = Address;
            Perons1.Age = Age;
            Perons1.Gender = Gender;
            Perons1.Name = Name;
            Perons1.Phone = Phone;
            Perons1.BloodGroupID = BloodGroupID;

            Perons1.Save();

            Donor1.PersonId = Perons1.PersonId;
            
            MessageBox.Show(Donor1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lbDonorID.Text = Convert.ToString(Donor1.DonorId);
            _DonorId = Donor1.DonorId;
        }
    }
}

//             cbCountry.SelectedIndex = cbCountry.FindString(clsCountry.Find(_Contact.CountryID).CountryName);
//             int CountryID = clsCountry.Find(cbCountry.Text).ID;