﻿using System;
using System.Drawing;
using System.Windows.Forms;
using BusinessLayer;
using WindowsFormsApp1.Employees;
using WindowsFormsApp1.Library;

namespace WindowsFormsApp1
{
    public partial class Donors : Form
    {
        public Donors()
        {
            InitializeComponent();
        }

        private void Donors_Load(object sender, EventArgs e)
        {
            cbBloodGroup.SelectedIndex = cbSearchDonor.SelectedIndex = 0;
        }

        private void LoadData()
        {
            FillDataGridView();
        }

        private void FillDataGridView()
        {
            var Text = tbSearch.Text.Trim();
            var Index = cbBloodGroup.SelectedIndex == -1 ? -1 : cbBloodGroup.SelectedIndex;

            dataGridView1.Columns.Clear();

            if (Text == "" && Index == -1)
                dataGridView1.DataSource = DonorsBusinessLayer.GetAllDonors();

            else if (cbSearchDonor.SelectedIndex == 1)
                dataGridView1.DataSource = DonorsBusinessLayer.FindDonorByName(Text, cbBloodGroup.Text);

            else
                dataGridView1.DataSource = DonorsBusinessLayer.FindDonorById(Text, cbBloodGroup.Text);

            if (dataGridView1.RowCount > 0)
                Util.AddEditAndRemoveColumns(dataGridView1, 7, 8);
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void cbBloodGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditDonor();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            FillDataGridView();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // MessageBox.Show(e.RowIndex + "-" + e.ColumnIndex + "=" + dataGridView1.CurrentRow.Cells[2].Value);

            if (e.ColumnIndex == 1 && e.RowIndex >= 0)
            {
                if (MessageBox.Show("Are you sure you want to delete Donor [" +
                                    dataGridView1.CurrentRow.Cells[2].Value + "]",
                        "Confirm Delete", MessageBoxButtons.OKCancel) != DialogResult.OK)
                    return;

                if (DonorsBusinessLayer.DeleteDonor((int)dataGridView1.CurrentRow.Cells[2].Value))
                {
                    MessageBox.Show("Deletion Successfully");
                    FillDataGridView();
                }
                else
                {
                    MessageBox.Show("Deletion Failed");
                }
            }

            else if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            {
                Form fr = new AddEditDonor((int)dataGridView1.CurrentRow.Cells[2].Value);
                OpenChildForm.OpenChildFormInPanel(ref fr);
                LoadData();
            }
        }

        private void cbSearchDonor_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void dataGridView1_CellToolTipTextNeeded(object sender, DataGridViewCellToolTipTextNeededEventArgs e)
        {
            if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            {
                e.ToolTipText = "Edit";
            }

            if (e.ColumnIndex == 1 && e.RowIndex >= 0)
            {
                e.ToolTipText = "Delete";
            }
        }
    }
}