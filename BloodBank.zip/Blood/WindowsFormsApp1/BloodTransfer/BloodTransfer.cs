﻿using System;
using System.Drawing;
using System.Windows.Forms;
using BusinessLayer;

namespace WindowsFormsApp1.BloodTransfer
{
    public partial class BloodTransfer : Form
    {
        public BloodTransfer()
        {
            InitializeComponent();
        }

        private void BloodTransfer_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dataGridView1.DataSource = PatientsBusinessLayer.GetAllPatients();
            LoadBloodGroupsList();
        }

        private void LoadBloodGroupsList()
        {
            dataGridView2.DataSource = BloodGroupsBusinessLayer.LoadBloodGroupsList();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if ((e.RowIndex < 0 || dataGridView1.Rows.Count <= 0) || dataGridView1.CurrentCell == null) return;

            lbName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            lbBloodGroup.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();

            bool HasQuantity = BloodGroupsBusinessLayer.HasQuantity(lbBloodGroup.Text);

            if (HasQuantity)
            {
                lbStatus.Text = "Stock is available";
                lbStatus.ForeColor = Color.LawnGreen;
            }
            else
            {
                lbStatus.Text = "Stock is not available";
                lbStatus.ForeColor = Color.Firebrick;
            }

            btnTransfer.Enabled = HasQuantity;
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            var PatientID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            var BloodGroupName = lbBloodGroup.Text;
            var TransferDate = DateTime.Now;

            BloodTransferBusinessLayer.AddTransfer(PatientID, BloodGroupName, TransferDate);

            MessageBox.Show(BloodGroupsBusinessLayer.DecreaseBloodGroup(BloodGroupName) + "");

            LoadBloodGroupsList();

            lbName.Text = lbStatus.Text = lbBloodGroup.Text = "";
            btnTransfer.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form fr = new BloodTransferHistory();
            fr.ShowDialog();
        }
    }
}