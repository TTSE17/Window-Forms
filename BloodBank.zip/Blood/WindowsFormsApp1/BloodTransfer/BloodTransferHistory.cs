﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace WindowsFormsApp1.BloodTransfer
{
    public partial class BloodTransferHistory : Form
    {
        public BloodTransferHistory()
        {
            InitializeComponent();
        }

        private void BloodTransferHistory_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dataGridView1.DataSource = BloodTransferBusinessLayer.GetAllTransfer();
        }
    }
}