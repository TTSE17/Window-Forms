﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class PersonDataAccessLayer
    {
        public static int AddNewPerson(string Name, int Age, string Gender,
            string Phone, string Address, int BloodGroupId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Persons (Name , Age , Gender , Phone , Address , BloodGroupId )
                             VALUES (@Name, @Age, @Gender , @Phone ,@Address , @BloodGroupId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@Name", Name);
            command.Parameters.AddWithValue("@Age", Age);
            command.Parameters.AddWithValue("@Gender", Gender);
            command.Parameters.AddWithValue("@Phone", Phone);
            command.Parameters.AddWithValue("@Address", Address);
            command.Parameters.AddWithValue("@BloodGroupId", BloodGroupId);


            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdatePerson(int ID, int BloodGroupID, string Name,
            string Address, int Age, string Phone, string Gender)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Persons  
                            set Name = @Name,Age =@Age,Gender=@Gender ,Phone=@Phone, Address=@Address,  BloodGroupId = @BloodGroupID
                            where PersonId = @ID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@ID", ID);
            command.Parameters.AddWithValue("@Name", Name);
            command.Parameters.AddWithValue("@BloodGroupID", BloodGroupID);
            command.Parameters.AddWithValue("@Address", Address);
            command.Parameters.AddWithValue("@Age", Age);
            command.Parameters.AddWithValue("@Phone", Phone);
            command.Parameters.AddWithValue("@Gender", Gender);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool FindPerson(int PersonID, ref string Name, ref int BloodGroupId, ref string Address,
            ref int Age, ref string Phone, ref string Gender)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Persons Where PersonID=@PersonID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = true;
                    Name = (string)reader[1];
                    Age = (int)reader[2];
                    Gender = (string)reader[3];
                    Phone = (reader[4] == DBNull.Value) ? "" : (string)reader[4];
                    Address = (reader[5] == DBNull.Value) ? "" : (string)reader[5];
                    BloodGroupId = (int)reader[6];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
        
        public static bool DeletePerson(int PersonID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete from Persons Where PersonID=@PersonID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

    }
}