﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public static class DashboardDataAccessLayer
    {
        public static int GetNumberOfPatients()
        {
            int _Rows = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select count(*) from Patients";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                var result = Convert.ToInt32(command.ExecuteScalar());

                _Rows = result;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return _Rows;
        }

        public static int GetNumberOfDonors()
        {
            int _Rows = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select count(*) from Donors";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                var result = Convert.ToInt32(command.ExecuteScalar());

                _Rows = result;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return _Rows;
        }

        public static int GetNumberOfUsers()
        {
            int _Rows = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select count(*) from Employees";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                var result = Convert.ToInt32(command.ExecuteScalar());

                _Rows = result;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return _Rows;
        }

        public static int GetNumberOfTransfer()
        {
            int _Rows = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select count(*) from Transfers";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                var result = Convert.ToInt32(command.ExecuteScalar());

                _Rows = result;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return _Rows;
        }
    }
}