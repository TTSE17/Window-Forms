﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class PatientsDataAccessLayer
    {
        public static DataTable GetAllPatients()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select PatientId , Name , Age ,Gender ,Phone ,Address ,BloodGroupName  from Persons
            Inner join Patients on Persons.PersonID = Patients.PersonID
            Inner join BloodGroups on BloodGroups.BloodGroupID = Persons.BloodGroupID";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindPatient(int PatientID, ref int PersonID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Patients Where PatientID=@PatientID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PatientID", PatientID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = true;
                    PersonID = (int)reader[1];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static DataTable FindPatientByName(string Name,string BloodGroupName)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query =
                @"select PatientID , Name , Age ,
                                    case 
                                    	 when Persons.Gender = 'M' then 'Male'
                                    	 when Persons.Gender = 'F' then 'Female'
                                    end as Gender
                                    ,Phone ,Address ,BloodGroupName  from Persons
                  Inner join Patients on Persons.PersonID = Patients.PersonID
                  Inner join BloodGroups on BloodGroups.BloodGroupID = Persons.BloodGroupID
                  where (Persons.Name) LIKE @Name + '%'
                  and (@BloodGroupName = 'All' OR BloodGroups.BloodGroupName = @BloodGroupName)";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@Name", Name);
            command.Parameters.AddWithValue("@BloodGroupName", BloodGroupName);


            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable FindPatientById(string ID,string BloodGroupName)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select PatientID , Name , Age ,
                                    case 
                                    	 when Persons.Gender = 'M' then 'Male'
                                    	 when Persons.Gender = 'F' then 'Female'
                                    end as Gender
                                    ,Phone ,Address ,BloodGroupName  from Persons
            Inner join Patients on Persons.PersonID = Patients.PersonID
            Inner join BloodGroups on BloodGroups.BloodGroupID = Persons.BloodGroupID
            where (PatientID) LIKE @ID + '%'
            and (@BloodGroupName = 'All' OR BloodGroups.BloodGroupName = @BloodGroupName)";
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);
            command.Parameters.AddWithValue("@BloodGroupName", BloodGroupName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable FindPatientByBloodName(string BloodName)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query =
                @"select PatientID , Name , Age ,Gender ,Phone ,Address ,BloodGroupName  from Persons
                  Inner join Patients on Persons.PersonID = Patients.PersonID
                  Inner join BloodGroups on BloodGroups.BloodGroupID = Persons.BloodGroupID
                  where BloodGroupName = @BloodName";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@BloodName", BloodName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static DataTable FindPatient(string Text, string BloodName, bool status)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
            string Query;

            Query = status
                ? @"select PatientID , Name , Age ,Gender ,Phone ,Address ,BloodGroupName  from Persons
                  Inner join Patients on Persons.PersonID = Patients.PersonID
                  Inner join BloodGroups on BloodGroups.BloodGroupID = Persons.BloodGroupID
                  where BloodGroupName = @BloodName and name=@Text"
                : @"select PatientID , Name , Age ,Gender ,Phone ,Address ,BloodGroupName  from Persons
                  Inner join Patients on Persons.PersonID = Patients.PersonID
                  Inner join BloodGroups on BloodGroups.BloodGroupID = Persons.BloodGroupID
                  where BloodGroupName = @BloodName and PatientID=@Text";


            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@BloodName", BloodName);
            command.Parameters.AddWithValue("@Text", Text);
            
            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }
        
        public static int AddNewPatient(int PersonID)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Patients (PersonID)
                             VALUES (@PersonID)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool DeletePatient(int PatientId)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete  from Patients Where PatientId=@PatientId";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PatientId", PatientId);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

    }
}