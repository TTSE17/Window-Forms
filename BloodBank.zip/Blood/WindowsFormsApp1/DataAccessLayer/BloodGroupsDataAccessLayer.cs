﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DataAccessLayer
{
    public class BloodGroupsDataAccessLayer
    {
        public static DataTable LoadBloodGroupsList()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from BloodGroups";
            
            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                
                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }
        
        public static DataTable FindBloodGroupByName(string BloodGroupName)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select * from BloodGroups
                  where BloodGroupName = @BloodGroupName";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@BloodGroupName", BloodGroupName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }
        
        public static bool FindBlood(int BloodId, ref string BloodName, ref decimal QuantityStock)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from BloodGroups Where BloodGroupId=@BloodId";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@BloodId", BloodId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = true;
                    BloodName = Convert.ToString(reader[1]);
                    QuantityStock = Convert.ToDecimal(reader[2]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool FindBlood(ref int BloodId, string BloodName, ref decimal QuantityStock)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from BloodGroups Where BloodGroupName=@BloodName";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@BloodName", BloodName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = true;
                    BloodId = (int)reader[0];
                    QuantityStock = Convert.ToDecimal(reader[2]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool IncreaseBloodGroup(string BloodGroupName,int Quantity)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update BloodGroups  
                             set QuantityInStock =QuantityInStock+@Quantity
                            where BloodGroupName = @BloodGroupName";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@BloodGroupName", BloodGroupName);
            command.Parameters.AddWithValue("@Quantity", Quantity);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            return isUpdated;
        }
        
    }
}