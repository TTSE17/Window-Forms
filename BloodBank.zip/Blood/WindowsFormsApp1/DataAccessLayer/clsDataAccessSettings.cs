﻿namespace DataAccessLayer
{
    public class clsDataAccessSettings
    {
        public static string ConnectionString = "Server=.;Database=BloodBank;User Id= ;Password= ;";
    }
}