﻿using System;
using System.Windows.Forms;
using BusinessLayer;
using WindowsFormsApp1.Library;

namespace WindowsFormsApp1.Patients
{
    public partial class Patients : Form
    {
        public Patients()
        {
            InitializeComponent();
        }

        private void Patients_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            cbBloodGroup.SelectedIndex = cbSearchPatient.SelectedIndex = 0;
        }

        private void FillDataGridView()
        {
            var Text = tbSearch.Text.Trim();
            var Index = cbBloodGroup.SelectedIndex == -1 ? -1 : cbBloodGroup.SelectedIndex;

            dataGridView1.Columns.Clear();

            if (Text == "" && Index == -1)
                dataGridView1.DataSource = PatientsBusinessLayer.GetAllPatients();

            else if (cbSearchPatient.SelectedIndex == 1)
                dataGridView1.DataSource = PatientsBusinessLayer.FindPatientByName(Text, cbBloodGroup.Text);

            else
                dataGridView1.DataSource = PatientsBusinessLayer.FindPatientById(Text, cbBloodGroup.Text);


            if (dataGridView1.RowCount > 0)
                Util.AddEditAndRemoveColumns(dataGridView1, 7, 8);
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void cbSearchPatient_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void cbBloodGroup_SelectedIndexChanged(object sender, EventArgs e)
        {
            FillDataGridView();
        }

        private void tbnAddNew_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditPatient();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            FillDataGridView();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex == 1 && e.RowIndex >= 0)
            {
                if (MessageBox.Show("Are you sure you want to delete Patient [" +
                                    dataGridView1.CurrentRow.Cells[2].Value + "]",
                        "Confirm Delete", MessageBoxButtons.OKCancel) != DialogResult.OK)
                    return;

                if (PatientsBusinessLayer.DeletePatient((int)dataGridView1.CurrentRow.Cells[2].Value))
                {
                    MessageBox.Show("Deletion Successfully");
                    FillDataGridView();
                }
                else
                {
                    MessageBox.Show("Deletion Failed");
                }
            }

            else if (e.ColumnIndex == 0 && e.RowIndex >= 0)
            {
                Form fr = new AddEditPatient((int)dataGridView1.CurrentRow.Cells[2].Value);
                OpenChildForm.OpenChildFormInPanel(ref fr);
                FillDataGridView();
            }
        }
    }
}