﻿using System;
using System.Windows.Forms;
using BusinessLayer;
using WindowsFormsApp1.Library;

namespace WindowsFormsApp1.Patients
{
    public partial class AddEditPatient : Form
    {
        private int _PatientId = -1;

        private PatientsBusinessLayer Patient1;

        private PersonBusinessLayer Perons1;

        public AddEditPatient(int ID = -1)
        {
            InitializeComponent();
            _PatientId = ID;
        }

        private void AddEditPatient_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_PatientId == -1)
            {
                Patient1 = new PatientsBusinessLayer();
                Perons1 = new PersonBusinessLayer();
                lbTitleForm.Text = "Add New Patient";
                lbPatientID.Text = "-";
            }

            else
            {
                Patient1 = PatientsBusinessLayer.FindPatient(_PatientId);
                Perons1 = PersonBusinessLayer.FindPerson(Patient1.PersonId);

                lbTitleForm.Text = "Edit Employee";
                lbPatientID.Text = Convert.ToString(Patient1.PatientId);
                tbAddress.Text = Perons1.Address;
                tbPhone.Text = Perons1.Phone;
                nupAge.Value = Perons1.Age;

                if (Perons1.Gender == "M")
                    rbMale.Checked = true;
                else
                    rbFemale.Checked = true;

                string[] Arr = Perons1.Name.Split(' ');
                tbFirstName.Text = Arr[0];
                tbLastName.Text = Arr[1];

                cbBloodGroup.SelectedIndex =
                    cbBloodGroup.FindString(BloodGroupsBusinessLayer.FindBlood(Perons1.BloodGroupID).BloodName);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Form fr = new Patients();
            OpenChildForm.OpenChildFormInPanel(ref fr);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            int BloodGroupID = BloodGroupsBusinessLayer.FindBlood(cbBloodGroup.Text).BloodId;
            string Name = tbFirstName.Text.Trim() + " " + tbLastName.Text.Trim();
            string Phone = tbPhone.Text;
            string Address = tbAddress.Text;
            int Age = (int)nupAge.Value;
            string Gender = (rbMale.Checked) ? "M" : "F";
            
            Perons1.Address = Address;
            Perons1.Age = Age;
            Perons1.Gender = Gender;
            Perons1.Name = Name;
            Perons1.Phone = Phone;
            Perons1.BloodGroupID = BloodGroupID;

            Perons1.Save();

            Patient1.PersonId = Perons1.PersonId;

            lbTitleForm.Text = "Edit Patient";

            MessageBox.Show(Patient1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lbPatientID.Text = Convert.ToString(Patient1.PatientId);
            _PatientId = Patient1.PatientId;
        }
    }
}