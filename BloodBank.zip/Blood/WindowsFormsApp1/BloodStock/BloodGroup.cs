﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace WindowsFormsApp1.BloodStock
{
    public partial class BloodGroup : Form
    {
        public BloodGroup()
        {
            InitializeComponent();
        }

        private void BloodStock_Load(object sender, EventArgs e)
        {
            cbFilter.SelectedIndex = 0;
        }

        private void LoadBloodGroupsList()
        {
            var TheSelection = cbFilter.SelectedItem.ToString();
            dataGridView1.DataSource = TheSelection == "All"
                ? BloodGroupsBusinessLayer.LoadBloodGroupsList()
                : BloodGroupsBusinessLayer.FindBloodGroupByName(TheSelection);
        }

        private void cbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadBloodGroupsList();
        }
    }
}