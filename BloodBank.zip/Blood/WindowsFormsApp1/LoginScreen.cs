﻿using System;
using System.Drawing;
using System.Windows.Forms;
using BusinessLayer;

namespace WindowsFormsApp1
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var Username = tbUsername.Text.Trim();
            var Password = tbPassword.Text.Trim();

            if (Username == "" || Password == "")
            {
                MessageBox.Show("Enter Username , Password");
                return;
            }

            if (EmployeesBusinessLayer.IsEmployeeExist(Username, Password))
            {
                Hide();
                Form fr = new MainMenu();
                fr.ShowDialog();
                Show();
            }

            else
                MessageBox.Show("Faild");
        }

        private void llAsAdmin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Hide();
            Form fr = new AdminMenu.AdminMenu();
            fr.ShowDialog();
            Show();
        }

        private void tbUsername_Enter(object sender, EventArgs e)
        {
            if (tbUsername.Text != "Username") return;

            tbUsername.Text = "";
            tbUsername.ForeColor = Color.LightGray;
        }

        private void tbPassword_Enter(object sender, EventArgs e)
        {
            if (tbPassword.Text != "Username") return;

            tbPassword.Text = " ";
            tbPassword.ForeColor = Color.DimGray;
        }

        private void tbPassword_Leave(object sender, EventArgs e)
        {
            if (tbPassword.Text != "") return;

            tbPassword.Text = "Username";
            tbPassword.ForeColor = Color.DimGray;
        }

        private void tbUsername_Leave(object sender, EventArgs e)
        {
            if (tbUsername.Text != "") return;
            tbUsername.Text = "Username";
            tbUsername.ForeColor = Color.DimGray;
        }
    }
}