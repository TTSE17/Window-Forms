﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1.AdminMenu
{
    public partial class AdminMenu : Form
    {
        public AdminMenu()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (tbPassword.Text == "123")
            {
                Hide();
                Form fr = new Employees.Employees();
                fr.ShowDialog();
                Close();
            }
            else
            {
                MessageBox.Show("Password Is Not Correct");
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void tbPassword_Enter(object sender, EventArgs e)
        {
            if (tbPassword.Text != "Password") return;
            tbPassword.Text = "";
            tbPassword.ForeColor = Color.LightGray;
            tbPassword.UseSystemPasswordChar = true;
        }

        private void tbPassword_Leave(object sender, EventArgs e)
        {
            if (tbPassword.Text != "") return;
            tbPassword.Text = "Password";
            tbPassword.ForeColor = Color.DimGray;
            tbPassword.UseSystemPasswordChar = false;
        }
    }
}