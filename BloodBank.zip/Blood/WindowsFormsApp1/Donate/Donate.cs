﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace WindowsFormsApp1.Donate
{
    public partial class Donate : Form
    {
        public Donate()
        {
            InitializeComponent();
        }


        private void Donate_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dataGridView1.DataSource = DonorsBusinessLayer.GetAllDonors();
            btnDonate.Enabled = false;
            LoadBloodGroupsList();
        }

        private void LoadBloodGroupsList()
        {
            dataGridView2.DataSource = BloodGroupsBusinessLayer.LoadBloodGroupsList();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if ((e.RowIndex < 0 ||  dataGridView1.Rows.Count <= 0) || dataGridView1.CurrentCell == null) return;

            lbName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            lbBloodGroup.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            btnDonate.Enabled = true;
        }

        private void btnDonate_Click(object sender, EventArgs e)
        {
            MessageBox.Show(BloodGroupsBusinessLayer.IncreaseBloodGroup(lbBloodGroup.Text) + "");

            lbName.Text = lbBloodGroup.Text = "";

            LoadBloodGroupsList();
            btnDonate.Enabled = false;
        }
    }
}