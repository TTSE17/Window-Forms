﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1.Library
{
    public class OpenChildForm
    {
        private static Form activeForm = null;
        private static string LastForm = "";
        public static Panel MainPanel = null;

        public static void OpenChildFormInPanel(ref Form childForm)
        {
            if (LastForm == childForm.Text)
                return;

            activeForm?.Close();

            activeForm = childForm;
            LastForm = childForm.Text;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            MainPanel.Controls.Add(childForm);
            MainPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
    }
}