﻿using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1.Library
{
    public class Util
    {
        public static void AddEditAndRemoveColumns(DataGridView dataGridView1, int Col1, int Col2)
        {

            DataGridViewImageColumn EditColumn = new DataGridViewImageColumn();
            EditColumn.Name = "     "; // Set the column name
            EditColumn.Image = Resources.Edit;
            EditColumn.ImageLayout = DataGridViewImageCellLayout.Zoom; // Adjust the image layout as needed
            dataGridView1.Columns.Insert(Col1, EditColumn);

            DataGridViewImageColumn DeleteColumn = new DataGridViewImageColumn();
            DeleteColumn.Name = "     ";
            DeleteColumn.Image = Resources.delete;
            DeleteColumn.ImageLayout = DataGridViewImageCellLayout.Zoom; // Adjust the image layout as needed
            dataGridView1.Columns.Insert(Col2, DeleteColumn);

            
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.Firebrick;
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            // dataGridView1.Columns.Add("Delete", "");
            // dataGridView1.Columns.Add("Update", "");
            
            // foreach (DataGridViewRow row in dataGridView1.Rows)
            // {
            //     row.Cells[Col1].Value = "E";
            //     row.Cells[Col2].Value = "D";
            // }
            
            // DataGGridViewCheckBoxColumn dgvCmb = new DataGGridViewCheckBoxColumn();     
            // dataGridView1.Columns.Insert(4, dgvCmb);
  

        }
    }
}