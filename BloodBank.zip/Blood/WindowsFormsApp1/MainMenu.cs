﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp1.BloodStock;
using WindowsFormsApp1.Library;

namespace WindowsFormsApp1
{
    public partial class MainMenu : Form
    {
        private Form fr = null;
        private Button LastButton = null;

        public MainMenu()
        {
            InitializeComponent();
            OpenChildForm.MainPanel = panelChildForm;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnDashboard.PerformClick();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnDashboard);

            fr = new Dashboard();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            Text = "Home";
        }

        private void btnDonors_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnDonors);

            fr = new Donors();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            Text = "Donors";
        }

        private void btnPatients_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnPatients);

            fr = new Patients.Patients();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            Text = "Patients";
        }

        private void btnDonate_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnDonate);

            fr = new Donate.Donate();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            Text = "Donate";
        }

        private void btnBloodStock_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnBloodStock);

            fr = new BloodGroup();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            Text = "Blood Stock";
        }

        private void btnBloodTransfer_Click(object sender, EventArgs e)
        {
            ChangeActiveButton(btnBloodTransfer);

            fr = new BloodTransfer.BloodTransfer();
            OpenChildForm.OpenChildFormInPanel(ref fr);
            Text = "Blood Transfer";
        }

        private void ChangeActiveButton(Button ActiveButton)
        {
            if (LastButton != null)
                LastButton.BackColor = Color.Black;

            ActiveButton.BackColor = Color.MidnightBlue;
            LastButton = ActiveButton;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}