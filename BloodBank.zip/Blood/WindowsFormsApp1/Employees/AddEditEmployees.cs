﻿using System;
using System.Windows.Forms;
using BusinessLayer;

namespace WindowsFormsApp1.Employees
{
    public partial class AddEditEmployees : Form
    {
        int _ID;

        private EmployeesBusinessLayer Employee1;

        public AddEditEmployees(int ID)
        {
            InitializeComponent();
            _ID = ID;
        }

        private void AddEditEmployees_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            if (_ID == -1)
            {
                Employee1 = new EmployeesBusinessLayer();
                lbTitleForm.Text = "Add New Employee";
                lbEmployeeID.Text = "-";
            }

            else
            {
                Employee1 = EmployeesBusinessLayer.FindEmployee(_ID);
                lbTitleForm.Text = "Edit Employee";
                lbEmployeeID.Text = Convert.ToString(Employee1.EmployeeId);
                tbUserName.Text = Employee1.Username;
                tbPassword.Text = Employee1.Password;
            }
        }

        private bool _IsDataCorrect()
        {
            if (string.IsNullOrEmpty(tbUserName.Text) || string.IsNullOrEmpty(tbPassword.Text))
            {
                MessageBox.Show("The input string is not in a valid format.",
                    "Data Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            if (_ID == -1 && EmployeesBusinessLayer.IsEmployeeExist(tbUserName.Text.Trim()))
            {
                MessageBox.Show("This username is already exists. Choose another one.", "Exists Username",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            if (_ID != -1 && Employee1.Username != tbUserName.Text.Trim() &&
                EmployeesBusinessLayer.IsEmployeeExist(tbUserName.Text.Trim()))
            {
                MessageBox.Show("This username is already exists. Choose another one.", "Exists Username",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                return false;
            }

            return true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!_IsDataCorrect())
                return;

            Employee1.Username = tbUserName.Text.Trim();
            ;
            Employee1.Password = tbPassword.Text.Trim();

            lbTitleForm.Text = "Edit Employee";

            MessageBox.Show(Employee1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lbEmployeeID.Text = Convert.ToString(Employee1.EmployeeId);
            _ID = Employee1.EmployeeId;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}