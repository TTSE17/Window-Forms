﻿using System;
using System.Data;
using System.Windows.Forms;
using BusinessLayer;
using WindowsFormsApp1.Library;

namespace WindowsFormsApp1.Employees
{
    public partial class Employees : Form
    {
        public Employees()
        {
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Employees_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            cbSearchEmployee.SelectedIndex = 1;
            FillDataGridView();
        }

        private void FillDataGridView(string Text = "")
        {
            dataGridView1.Columns.Clear();

            dataGridView1.DataSource = Text == ""
                ? EmployeesBusinessLayer.GetAllEmployees()
                : (cbSearchEmployee.SelectedIndex == 1)
                    ? EmployeesBusinessLayer.FindEmployeeByUsername(Text)
                    : EmployeesBusinessLayer.FindEmployeeById(Text);

            if (dataGridView1.RowCount > 0)
                Util.AddEditAndRemoveColumns(dataGridView1, 3, 4);
        }


        private void btnAddNew_Click(object sender, EventArgs e)
        {
            Form fr = new AddEditEmployees(-1);
            fr.ShowDialog();
            LoadData();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            tbSearch.Focus();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var EmployeeeID = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            if (e.ColumnIndex == 4 && e.RowIndex >= 0)
            {
                if (MessageBox.Show("Do you really want to delete this Employee?!", "Warning",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Warning,
                        MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                    return;

                if (EmployeesBusinessLayer.DeleteEmployee(EmployeeeID))
                {
                    MessageBox.Show("Deletion Successfully");
                    LoadData();
                }
                else
                {
                    MessageBox.Show("Deletion Failed");
                }
            }

            else if (e.ColumnIndex == 3 && e.RowIndex >= 0)
            {
                Form fr = new AddEditEmployees(EmployeeeID);
                fr.ShowDialog();
                LoadData();
            }
        }

        private void dataGridView1_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 3 || e.ColumnIndex == 4)
            {
                dataGridView1.Cursor = Cursors.Hand;
            }
            else
            {
                dataGridView1.Cursor = Cursors.Default;
            }
        }
    }
}