﻿using System;
using BusinessLayer;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e) 
        {
            lbNumberOfPatients.Text = DashboardBusinessLayer.GetNumberOfPatients().ToString();
            lbNumberOfDonors.Text = DashboardBusinessLayer.GetNumberOfDonors().ToString();
            lbNumberOfUsers.Text = DashboardBusinessLayer.GetNumberOfUsers().ToString();
            lbNumberOfTransfer.Text = DashboardBusinessLayer.GetNumberOfTransfer().ToString();
        }
    }
}