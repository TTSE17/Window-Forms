﻿using DataAccessLayer;

namespace BusinessLayer
{
    public static class DashboardBusinessLayer
    {
        public static int GetNumberOfPatients()
        {
            return DashboardDataAccessLayer.GetNumberOfPatients();
        }

        public static int GetNumberOfDonors()
        {
            return DashboardDataAccessLayer.GetNumberOfDonors();
        }

        public static int GetNumberOfUsers()
        {
            return DashboardDataAccessLayer.GetNumberOfUsers();
        }

        public static int GetNumberOfTransfer()
        {
            return DashboardDataAccessLayer.GetNumberOfTransfer();
        }
    }
}