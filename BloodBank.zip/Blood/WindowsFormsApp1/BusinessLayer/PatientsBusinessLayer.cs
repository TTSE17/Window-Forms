﻿using System.Data;
using DataAccessLayer;

namespace BusinessLayer
{
    public class PatientsBusinessLayer
    {
        public int PatientId { get; private set; }

        public int PersonId { get; set; }


        public PatientsBusinessLayer()
        {
            PatientId = -1;
        }

        private PatientsBusinessLayer(int PatientId, int PersonId)
        {
            this.PatientId = PatientId;
            this.PersonId = PersonId;
        }

        public static DataTable GetAllPatients()
        {
            return PatientsDataAccessLayer.GetAllPatients();
        }

        public static PatientsBusinessLayer FindPatient(int ID)
        {
            int PersonID = 0;

            if (PatientsDataAccessLayer.FindPatient(ID, ref PersonID))
                return new PatientsBusinessLayer(ID, PersonID);

            return null;
        }

        public static DataTable FindPatientByName(string Name, string BloodGroupName)
        {
            return PatientsDataAccessLayer.FindPatientByName(Name,BloodGroupName);
        }

        public static DataTable FindPatientById(string ID, string BloodGroupName)
        {
            return PatientsDataAccessLayer.FindPatientById(ID,BloodGroupName);
        }

        public static DataTable FindPatientByBloodName(string BloodName)
        {
            return PatientsDataAccessLayer.FindPatientByBloodName(BloodName);
        }

        public static DataTable FindPatient(string Text, string BloodName, bool status)
        {
            return PatientsDataAccessLayer.FindPatient(Text, BloodName, status);
        }

        private int _AddNewPatient()
        {
            return PatientsDataAccessLayer.AddNewPatient(PersonId);
        }

        public bool Save()
        {
            if (this.PatientId != -1) return true;

            PatientId = _AddNewPatient();
            return true;
        }

        public static bool DeletePatient(int PatientId)
        {
            var PersonID = FindPatient(PatientId).PersonId;

            return (PatientsDataAccessLayer.DeletePatient(PatientId) && PersonBusinessLayer.DeletePerson(PersonID));
        }
    }
}