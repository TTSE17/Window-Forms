﻿using System.Data;
using DataAccessLayer;

namespace BusinessLayer
{
    public class DonorsBusinessLayer
    {
        public int DonorId { get; private set; }

        public int PersonId { get; set; }


        public DonorsBusinessLayer()
        {
            DonorId = -1;
        }

        private DonorsBusinessLayer(int DonorId, int PersonId)
        {
            this.DonorId = DonorId;
            this.PersonId = PersonId;
        }

        public static DataTable GetAllDonors()
        {
            return DonorsDataAccessLayer.GetAllDonors();
        }

        public static DonorsBusinessLayer FindDonor(int ID)
        {
            int PersonID = 0;

            if (DonorsDataAccessLayer.FindDonor(ID, ref PersonID))
                return new DonorsBusinessLayer(ID, PersonID);

            return null;
        }

        public static DataTable FindDonorByName(string Name,string BloodGroupName)
        {
            return DonorsDataAccessLayer.FindDonorByName(Name,BloodGroupName);
        }

        public static DataTable FindDonorById(string ID, string BloodGroupName)
        {
            return DonorsDataAccessLayer.FindDonorById(ID, BloodGroupName);
        }

        public static DataTable FindDonorByBloodName(string BloodName)
        {
            return DonorsDataAccessLayer.FindDonorByBloodName(BloodName);
        }

        public static DataTable FindDonor(string Text, string BloodName, bool status)
        {
            return DonorsDataAccessLayer.FindDonor(Text, BloodName, status);
        }


        private int _AddNewDonor()
        {
            return DonorsDataAccessLayer.AddNewDonor(PersonId);
        }

        public bool Save()
        {
            if (this.DonorId != -1) return true;

            DonorId = _AddNewDonor();
            return true;
        }

        public static bool DeleteDonor(int DonorID)
        {
            var PersonID = FindDonor(DonorID).PersonId;

            return (DonorsDataAccessLayer.DeleteDonor(DonorID) && PersonBusinessLayer.DeletePerson(PersonID));
        }
    }
}