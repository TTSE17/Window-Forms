﻿using System;
using System.Data;
using System.Security.Policy;
using System.Windows.Forms;
using DataAccessLayer;

namespace BusinessLayer
{
    public class BloodGroupsBusinessLayer
    {
        public int BloodId { get; set; }

        public string BloodName { get; set; }

        public decimal QuantityStock { get; set; }

        private BloodGroupsBusinessLayer(int BloodId, string BloodName, decimal QuantityStock)
        {
            this.BloodId = BloodId;
            this.BloodName = BloodName;
            this.QuantityStock = QuantityStock;
        }

        public static BloodGroupsBusinessLayer FindBlood(int ID)
        {
            string BloodName = "";
            decimal QuantityStock = 0;

            if (BloodGroupsDataAccessLayer.FindBlood(ID, ref BloodName, ref QuantityStock))
                return new BloodGroupsBusinessLayer(ID, BloodName, QuantityStock);

            return null;
        }

        public static BloodGroupsBusinessLayer FindBlood(string BloodName)
        {
            int BloodId = 0;
            decimal QuantityStock = 0;

            if (BloodGroupsDataAccessLayer.FindBlood(ref BloodId, BloodName, ref QuantityStock))
                return new BloodGroupsBusinessLayer(BloodId, BloodName, QuantityStock);

            return null;
        }

        public static DataTable LoadBloodGroupsList()
        {
            return BloodGroupsDataAccessLayer.LoadBloodGroupsList();
        }

        public static DataTable FindBloodGroupByName(string BloodGroupName)
        {
            return BloodGroupsDataAccessLayer.FindBloodGroupByName(BloodGroupName);
        }

        public static bool IncreaseBloodGroup(string BloodGroupName)
        {
            return BloodGroupsDataAccessLayer.IncreaseBloodGroup(BloodGroupName, 1);
        }

        public static bool HasQuantity(string BloodGroupName)
        {
            BloodGroupsBusinessLayer Blood1 = FindBlood(BloodGroupName);
            return Blood1.QuantityStock > 0;
        }

        public static bool DecreaseBloodGroup(string BloodGroupName)
        {
            return BloodGroupsDataAccessLayer.IncreaseBloodGroup(BloodGroupName, -1);
        }
    }
}