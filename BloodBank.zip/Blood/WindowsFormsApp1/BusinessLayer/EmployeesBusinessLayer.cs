﻿using System.Data;
using DataAccessLayer;

namespace BusinessLayer
{
    public class EmployeesBusinessLayer
    {
        public int EmployeeId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public EmployeesBusinessLayer()
        {
            EmployeeId = -1;
            Username = "";
            Password = "";
        }

        private EmployeesBusinessLayer(int EmployeeId, string Username, string Password)
        {
            this.EmployeeId = EmployeeId;
            this.Username = Username;
            this.Password = Password;
        }

        public static bool IsEmployeeExist(string Username, string Password)
        {
            return EmployeesDataAccessLayer.IsEmployeeExist(Username, Password);
        }
        
        public static bool IsEmployeeExist(string Username)
        {
            return EmployeesDataAccessLayer.IsEmployeeExist(Username);
        }


        public static DataTable GetAllEmployees()
        {
            return EmployeesDataAccessLayer.GetAllEmployees();
        }

        public static EmployeesBusinessLayer FindEmployee(int ID)
        {
            string Username = "";
            string Passwpord = "";

            if (EmployeesDataAccessLayer.FindEmployee(ID, ref Username, ref Passwpord))
                return new EmployeesBusinessLayer(ID, Username, Passwpord);

            return null;
        }

        public static DataTable FindEmployeeByUsername(string Username)
        {
            return EmployeesDataAccessLayer.FindEmployeeByUsername(Username);
        }

        public static DataTable FindEmployeeById(string ID)
        {
            return EmployeesDataAccessLayer.FindEmployeeById(ID);
        }

        private int _AddNewEmployee()
        {
            return EmployeesDataAccessLayer.AddNewEmployee(Username,Password);
        }

        private bool _UpdateEmployee()
        {
            return EmployeesDataAccessLayer.UpdateEmployee(EmployeeId,Username,Password);
        }

        public static bool DeleteEmployee(int ID)
        {
            return EmployeesDataAccessLayer.DeleteEmployee(ID);
        }

        public bool Save()
        {
            if (this.EmployeeId == -1)
            {
                EmployeeId = _AddNewEmployee();
                return true;
            }
            else
            {
                return _UpdateEmployee();
            }

        }
    }
}