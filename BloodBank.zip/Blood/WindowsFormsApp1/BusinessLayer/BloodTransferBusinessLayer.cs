﻿using System;
using System.Data;
using DataAccessLayer;

namespace BusinessLayer
{
    public class BloodTransferBusinessLayer
    {
        public static DataTable GetAllTransfer()
        {
            return BloodTransferDataAccessLayer.GetAllTransfer();
        }

        public static void AddTransfer(int PatientID, string BloodGroupName, DateTime TransferDate)
        {
            BloodTransferDataAccessLayer.AddTransfer(PatientID, BloodGroupName, TransferDate);
        }
    }
}