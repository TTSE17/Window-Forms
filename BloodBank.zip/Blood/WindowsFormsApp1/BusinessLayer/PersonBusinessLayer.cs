﻿using System.Windows.Forms;
using System.Xml;
using DataAccessLayer;

namespace BusinessLayer
{
    public class PersonBusinessLayer
    {
        public int PersonId { get; set; }
        public int BloodGroupID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int Age { get; set; }
        public string Phone { get; set; }
        public string Gender { get; set; }

        public PersonBusinessLayer()
        {
            PersonId = -1;
        }

        private PersonBusinessLayer(int PersonId, int BloodGroupID, string Name,
            string Address, int Age, string Phone, string Gender)
        {
            this.PersonId = PersonId;
            this.BloodGroupID = BloodGroupID;
            this.Name = Name;
            this.Address = Address;
            this.Age = Age;
            this.Phone = Phone;
            this.Gender = Gender;
        }

        private int _AddNewPerson()
        {
            return PersonDataAccessLayer.AddNewPerson(Name, Age, Gender,
                Phone, Address, BloodGroupID);
        }

        private bool _UpdatePerson()
        {
            return PersonDataAccessLayer.UpdatePerson(PersonId, BloodGroupID, Name, Address, Age, Phone, Gender);
        }


        public static PersonBusinessLayer FindPerson(int PersonId)
        {
            string Name = "";
            int BloodGroupID = 0;
            string Address = "";
            int Age = 0;
            string Phone = "";
            string Gender = "";

            if (PersonDataAccessLayer.FindPerson(PersonId, ref Name, ref BloodGroupID, ref Address,
                    ref Age, ref Phone, ref Gender))
                return new PersonBusinessLayer(PersonId, BloodGroupID, Name, Address, Age, Phone, Gender);

            return null;
        }

        public bool Save()
        {
            if (this.PersonId == -1)
            {
                PersonId = _AddNewPerson();
                return true;
            }
            else
            {
                return _UpdatePerson();
            }
        }
        
        public static bool DeletePerson(int ID)
        {
            return PersonDataAccessLayer.DeletePerson(ID);
        }
    }
}