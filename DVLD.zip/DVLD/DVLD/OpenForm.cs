using System.Drawing;
using System.Windows.Forms;

namespace DVLD
{
    public class OpenForm
    {
        public static Form activeForm = null;
        public static string LastForm = "";
        public static Panel MainPanel = null;

        public static void OpenChildFormInPanel(ref Form childForm)
        {
            if (LastForm == childForm.Text)
                return;

            activeForm?.Close();

            activeForm = childForm;
            LastForm = childForm.Text;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            // childForm.Dock = DockStyle.Fill;
            childForm.Location = new Point((MainPanel.Width - childForm.Width) / 2,
                (MainPanel.Height - childForm.Height) / 2);
            MainPanel.Controls.Add(childForm);
            MainPanel.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
    }
}