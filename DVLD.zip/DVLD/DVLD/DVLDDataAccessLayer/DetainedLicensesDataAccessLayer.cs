using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class DetainedLicensesDataAccessLayer
    {
        public static DataTable GetAllDetainedLicenses()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"Select * From DetainedLicenses_View Order By IsReleased ,DetainID";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static int AddNewDetainedLicense(int licenseId, DateTime detainDate, decimal fineFees,
            int createdByUserId, bool isReleased, DateTime releaseDate, int releasedByUserId, int releaseApplicationId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO DetainedLicenses
                             VALUES (@licenseId, @detainDate,@fineFees,@createdByUserId,@isReleased,@releaseDate,
                                     @releasedByUserId,@releaseApplicationId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@licenseId", licenseId);
            command.Parameters.AddWithValue("@detainDate", detainDate);
            command.Parameters.AddWithValue("@fineFees", fineFees);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);
            command.Parameters.AddWithValue("@isReleased", isReleased);
            if (releaseDate != default(DateTime))
                command.Parameters.AddWithValue("@releaseDate", releaseDate);
            else
                command.Parameters.AddWithValue("@releaseDate", DBNull.Value);
            if (releasedByUserId != -1)
                command.Parameters.AddWithValue("@releasedByUserId", releasedByUserId);
            else
                command.Parameters.AddWithValue("@releasedByUserId", DBNull.Value);
            if (releaseApplicationId != -1)
                command.Parameters.AddWithValue("@releaseApplicationId", releaseApplicationId);
            else
                command.Parameters.AddWithValue("@releaseApplicationId", DBNull.Value);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                Id = -1;
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateDetainedLicense(int DetainID, int licenseId, DateTime detainDate, decimal fineFees,
            int createdByUserId, bool isReleased, DateTime releaseDate, int releasedByUserId, int releaseApplicationId)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update DetainedLicenses
                            set licenseId = @licenseId ,detainDate = @detainDate,fineFees =@fineFees,createdByUserId=@createdByUserId,
                            isReleased=@isReleased,releaseDate=@releaseDate,releasedByUserId=@releasedByUserId,releaseApplicationId=@releaseApplicationId
                            where DetainID = @DetainID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DetainID", DetainID);
            command.Parameters.AddWithValue("@licenseId", licenseId);
            command.Parameters.AddWithValue("@detainDate", detainDate);
            command.Parameters.AddWithValue("@fineFees", fineFees);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);
            command.Parameters.AddWithValue("@isReleased", isReleased);
            command.Parameters.AddWithValue("@releaseDate", releaseDate);
            command.Parameters.AddWithValue("@releasedByUserId", releasedByUserId);
            command.Parameters.AddWithValue("@releaseApplicationId", releaseApplicationId);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool IsDetained(int LicenseID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select 'Found'=1 from DetainedLicenses
                                Where LicenseID=@LicenseID And IsReleased=0";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LicenseID", LicenseID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = reader.HasRows;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetDetainedLicenseByDetainedLicenseID(int detainId, ref int licenseId, ref DateTime detainDate,
            ref decimal fineFees, ref int createdByUserId, ref bool isReleased, ref DateTime releaseDate,
            ref int releasedByUserId, ref int releaseApplicationId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from DetainedLicenses Where detainId=@detainId ";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@detainId", detainId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    licenseId = (int)reader[1];
                    detainDate = (DateTime)reader[2];
                    fineFees = (decimal)reader[3];
                    createdByUserId = (int)reader[4];
                    isReleased = (bool)reader[5];
                    releaseDate = reader[6] != DBNull.Value ? (DateTime)reader[6] : default;
                    releasedByUserId = reader[7] != DBNull.Value ? (int)reader[7] : -1;
                    releaseApplicationId = reader[7] != DBNull.Value ? (int)reader[8] : -1;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetDetainedLicenseByLicenseID(ref int detainId, int licenseId, ref DateTime detainDate,
            ref decimal fineFees, ref int createdByUserId, ref bool isReleased, ref DateTime releaseDate,
            ref int releasedByUserId, ref int releaseApplicationId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from DetainedLicenses Where licenseId=@licenseId And IsReleased=0 ";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@licenseId", licenseId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    detainId = (int)reader[0];
                    detainDate = (DateTime)reader[2];
                    fineFees = (decimal)reader[3];
                    createdByUserId = (int)reader[4];
                    isReleased = (bool)reader[5];
                    releaseDate = reader[6] != DBNull.Value ? (DateTime)reader[6] : default(DateTime);
                    releasedByUserId = reader[7] != DBNull.Value ? (int)reader[7] : -1;
                    releaseApplicationId = reader[7] != DBNull.Value ? (int)reader[8] : -1;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }
    }
}