using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class ApplicationsDataAccessLayer
    {
        public static DataTable GetAllApplications()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * From Applications";


            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetApplicationByID(int applicationId, ref int applicationPersonId, ref
            DateTime applicationDate, ref int applicationTypeId, ref short applicationStatus, ref
            DateTime lastStatusDate, ref decimal paidFees, ref int createdByUserId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Applications Where applicationId=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", applicationId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    applicationPersonId = (int)reader[1];
                    applicationDate = (DateTime)reader[2];
                    applicationTypeId = (int)reader[3];
                    applicationStatus = Convert.ToInt16(reader[4]);
                    lastStatusDate = (DateTime)reader[5];
                    paidFees = (decimal)reader[6];
                    createdByUserId = (int)(reader[7]);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewApplication(int applicationPersonId,
            DateTime applicationDate, int applicationTypeId, short applicationStatus,
            DateTime lastStatusDate, decimal paidFees, int createdByUserId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Applications
                             VALUES (@applicationPersonId, @applicationDate,@applicationTypeId,@applicationStatus,
                                     @lastStatusDate,@paidFees,@createdByUserId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@applicationPersonId", applicationPersonId);
            command.Parameters.AddWithValue("@applicationDate", applicationDate);
            command.Parameters.AddWithValue("@applicationTypeId", applicationTypeId);
            command.Parameters.AddWithValue("@applicationStatus", applicationStatus);
            command.Parameters.AddWithValue("@lastStatusDate", lastStatusDate);
            command.Parameters.AddWithValue("@paidFees", paidFees);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateApplication(int applicationId, int applicationPersonId,
            DateTime applicationDate, int applicationTypeId, short applicationStatus,
            DateTime lastStatusDate, decimal paidFees, int createdByUserId)
        {
            bool isUpdated = false;


            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Applications
                            set ApplicantPersonID = @applicationPersonId,applicationDate=@applicationDate,applicationTypeId =@applicationTypeId,
                                applicationStatus=@applicationStatus,lastStatusDate=@lastStatusDate,paidFees=@paidFees,createdByUserId=@createdByUserId
                            where applicationId = @applicationId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@applicationId", applicationId);
            command.Parameters.AddWithValue("@applicationPersonId", applicationPersonId);
            command.Parameters.AddWithValue("@applicationDate", applicationDate);
            command.Parameters.AddWithValue("@applicationTypeId", applicationTypeId);
            command.Parameters.AddWithValue("@lastStatusDate", lastStatusDate);
            command.Parameters.AddWithValue("@applicationStatus", applicationStatus);
            command.Parameters.AddWithValue("@paidFees", paidFees);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeleteApplication(int ApplicationID)
        {
            int rowsAffected = 0;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Delete Applications where ApplicationID = @ApplicationID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@ApplicationID", ApplicationID);

            try
            {
                connection.Open();

                rowsAffected = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return (rowsAffected > 0);
        }
    }
}