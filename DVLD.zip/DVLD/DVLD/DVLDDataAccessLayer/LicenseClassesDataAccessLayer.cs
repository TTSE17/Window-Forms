using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class LicenseClassesDataAccessLayer

    {
        public static DataTable GetAllLicenseClasses()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            DataTable dt = new DataTable();

            string Query = @"select * from LicenseClasses";

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindLicenseClass(int ID, ref string className, ref string classDescription,
            ref short minimumAllowedAge, ref short defaultValidityLength, ref decimal classFees)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from LicenseClasses Where LicenseClassID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    className = (string)reader[1];
                    classDescription = (string)reader[2];
                    minimumAllowedAge = Convert.ToInt16(reader[3]);
                    defaultValidityLength = Convert.ToInt16(reader[4]);
                    classFees = (decimal)reader[5];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool FindLicenseClass(ref int LicenseClassID, string className, ref string classDescription,
            ref short minimumAllowedAge, ref short defaultValidityLength, ref decimal classFees)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from LicenseClasses Where className=@className";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@className", className);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    LicenseClassID = (int)reader[0];
                    classDescription = (string)reader[2];
                    minimumAllowedAge = Convert.ToInt16(reader[3]);
                    defaultValidityLength = Convert.ToInt16(reader[4]);
                    classFees = (decimal)reader[5];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }
    }
}