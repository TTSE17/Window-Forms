﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class PersonDataAccessLayer
    {
        public static DataTable GetAllPeople()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query =
                @" Select PersonID ,  FirstName , SecondName , ThirdName , LastName ,NationalNo ,DateOfBirth ,
                                     Gender =
                                        CASE
                                        WHEN Gendor=0 THEN 'Male'
                                        ELSE 'Female'
                                        End
                                    , Address , Phone , Email ,
				                     Nationality= (select CountryName from Countries Where CountryID=NationalityCountryID)  
                                    , ImagePath  from People ";


            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetPersonByID(int ID, ref string firstName, ref string secondName,
            ref string thirdName, ref string lastName, ref string nationalNo, ref DateTime dateOfBirth,
            ref short gender, ref string address, ref string phone, ref string email,
            ref int nationalityCountryId, ref string imagePath)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from People Where PersonID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    nationalNo = (string)reader[1];
                    firstName = (string)reader[2];
                    secondName = (string)reader[3];
                    thirdName = (reader[4] != DBNull.Value) ? (string)reader[4] : "";
                    lastName = (string)reader[5];
                    dateOfBirth = (DateTime)reader[6];
                    gender = Convert.ToInt16(reader[7]);
                    address = (string)reader[8];
                    phone = (string)reader[9];
                    email = reader[10] != DBNull.Value ? (string)reader[10] : "";
                    nationalityCountryId = (int)reader[11];
                    imagePath = reader[12] != DBNull.Value ? (string)reader[12] : "";
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool IsNationalNoExist(string NationalNo)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select Found=1 from People Where NationalNo=@NationalNo";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@NationalNo", NationalNo);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    isFound = true;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewPerson(string firstName, string secondName,
            string thirdName, string lastName, string nationalNo, DateTime dateOfBirth,
            short gender, string address, string phone, string email,
            int nationalityCountryId, string imagePath)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            // MessageBox.Show(firstName + "_" + secondName + "_" + thirdName + "_" + lastName + "_" + nationalNo + "_" +
            //                 dateOfBirth + "_" + gender + "_" +
            //                 address + "_" + phone + "_" + email + "_" + nationalityCountryId + "_" + imagePath + "_");

            string query = @"INSERT INTO People
                             VALUES (@firstName, @secondName,@thirdName,@lastName,@nationalNo,@dateOfBirth,
                                     @gender,@address,@phone,@email,@nationalityCountryId,@imagePath)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@secondName", secondName);
            command.Parameters.AddWithValue("@thirdName", thirdName);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@nationalNo", nationalNo);
            command.Parameters.AddWithValue("@dateOfBirth", dateOfBirth);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@nationalityCountryId", nationalityCountryId);
            if (imagePath != "")
                command.Parameters.AddWithValue("@ImagePath", imagePath);
            else
                command.Parameters.AddWithValue("@ImagePath", DBNull.Value);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdatePerson(int personId, string firstName, string secondName,
            string thirdName, string lastName, string nationalNo, DateTime dateOfBirth,
            short gender, string address, string phone, string email,
            int nationalityCountryId, string imagePath)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update People
                            set firstName = @firstName,secondName =@secondName,thirdName=@thirdName,lastName=@lastName,nationalNo=@nationalNo
                                ,dateOfBirth=@dateOfBirth,gendor=@gender ,address=@address,phone=@phone, email= @email ,
                                 nationalityCountryId=@nationalityCountryId,imagePath = @imagePath
                            where PersonId = @PersonId";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonId", personId);
            command.Parameters.AddWithValue("@firstName", firstName);
            command.Parameters.AddWithValue("@secondName", secondName);
            command.Parameters.AddWithValue("@thirdName", thirdName);
            command.Parameters.AddWithValue("@lastName", lastName);
            command.Parameters.AddWithValue("@nationalNo", nationalNo);
            command.Parameters.AddWithValue("@dateOfBirth", dateOfBirth);
            command.Parameters.AddWithValue("@gender", gender);
            command.Parameters.AddWithValue("@address", address);
            command.Parameters.AddWithValue("@phone", phone);
            command.Parameters.AddWithValue("@email", email);
            command.Parameters.AddWithValue("@nationalityCountryId", nationalityCountryId);
            if (imagePath != "")
                command.Parameters.AddWithValue("@ImagePath", imagePath);
            else
                command.Parameters.AddWithValue("@ImagePath", DBNull.Value);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool DeletePerson(int PersonID)
        {
            bool isDeleted = false;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Delete from People Where PersonID=@PersonID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                var rows = command.ExecuteNonQuery();
                isDeleted = rows > 0;
            }
            catch (Exception e)
            {
                // MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}