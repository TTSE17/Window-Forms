using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class TestsDataAccessLayer
    {
        public static int AddNewTest(int testAppointmentId, bool testResult, string notes, int createdByUserId)
        {
            int Id = -1;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Tests
                             VALUES (@testAppointmentId, @testResult,@notes,@createdByUserId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@testAppointmentId", testAppointmentId);
            
            command.Parameters.AddWithValue("@testResult", testResult);

            if (notes == "")
                command.Parameters.AddWithValue("@notes", DBNull.Value);
            else
                command.Parameters.AddWithValue("@notes", notes);


            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                Id = -1;
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }
    }
}