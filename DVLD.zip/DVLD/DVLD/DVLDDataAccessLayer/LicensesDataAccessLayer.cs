using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class LicensesDataAccessLayer
    {
        public static bool GetLicenseByID(int licenseId, ref int applicationId, ref int driverId, ref int licenseClass,
            ref DateTime issueDate, ref DateTime expirationDate, ref string notes, ref decimal paidFees,
            ref bool isActive, ref short issueReason, ref int createdByUserId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Licenses Where licenseId=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", licenseId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    applicationId = (int)reader[1];
                    driverId = (int)reader[2];
                    licenseClass = (int)reader[3];
                    issueDate = (DateTime)reader[4];
                    expirationDate = (DateTime)reader[5];
                    notes = (reader[6] == DBNull.Value) ? "" : (string)reader[6];
                    paidFees = (decimal)reader[7];
                    isActive = (bool)reader[8];
                    issueReason = Convert.ToInt16(reader[9]);
                    createdByUserId = (int)reader[10];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        // This Is Wrong
        public static bool GetLicenseByApplicationID(ref int licenseId, int applicationId, ref int driverId,
            ref int licenseClass, ref DateTime issueDate, ref DateTime expirationDate, ref string notes,
            ref decimal paidFees, ref bool isActive, ref short issueReason, ref int createdByUserId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Licenses Where applicationId=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", applicationId);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    licenseId = (int)reader[0];
                    driverId = (int)reader[2];
                    licenseClass = (int)reader[3];
                    issueDate = (DateTime)reader[4];
                    expirationDate = (DateTime)reader[5];
                    notes = (reader[6] == DBNull.Value) ? "No" : (string)reader[6];
                    paidFees = (decimal)reader[7];
                    isActive = (bool)reader[8];
                    issueReason = Convert.ToInt16(reader[9]);
                    createdByUserId = (int)reader[10];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewLicense(int applicationId, int driverId, int licenseClass,
            DateTime issueDate, DateTime expirationDate, string notes, decimal paidFees,
            bool isActive, short issueReason, int createdByUserId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO Licenses
                             VALUES (@applicationId, @driverId,@licenseClass,@issueDate,@expirationDate,
                                     @notes,@paidFees,@isActive,@issueReason,@createdByUserId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@applicationId", applicationId);
            command.Parameters.AddWithValue("@driverId", driverId);
            command.Parameters.AddWithValue("@licenseClass", licenseClass);
            command.Parameters.AddWithValue("@issueDate", issueDate);
            command.Parameters.AddWithValue("@expirationDate", expirationDate);

            if (notes == "")
                command.Parameters.AddWithValue("@notes", DBNull.Value);
            else
                command.Parameters.AddWithValue("@notes", notes);

            command.Parameters.AddWithValue("@paidFees", paidFees);
            command.Parameters.AddWithValue("@isActive", isActive);
            command.Parameters.AddWithValue("@issueReason", issueReason);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateLicense(int licenseID, bool isActive)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update Licenses
                            set isActive=@isActive
                            where licenseID = @licenseID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@licenseID", licenseID);
            command.Parameters.AddWithValue("@isActive", isActive);

            try
            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }


        public static bool HaveLicense(int ApplicationPersonID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select 'Found'=1 from Licenses 
                             Inner Join Applications ON Licenses.ApplicationID = Applications.ApplicationID
                              Where Applications.ApplicantPersonID=@ApplicationPersonID";


            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ApplicationPersonID", ApplicationPersonID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = reader.HasRows;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static bool GetDriverID(int ApplicationPersonID, ref int DriverID)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select Drivers.DriverID from Licenses 
                              Inner Join Drivers on Drivers.DriverID = Licenses.DriverID
                                Where Drivers.PersonID=@ApplicationPersonID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ApplicationPersonID", ApplicationPersonID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = reader.HasRows;
                    DriverID = (int)reader[0];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static DataTable GetLocalLicenses(int PersonID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query =
                @"Select LicenseID,ApplicationID ,
                    'Class Name'=(select ClassName from LicenseClasses Where Licenses.LicenseClass=LicenseClasses.LicenseClassID),
                     IssueDate,ExpirationDate,IsActive from Licenses 
                      where Licenses.DriverID=(
                          select DriverID from Drivers
                          where PersonID=@PersonID )";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }
        
        public static DataTable GetInternationalLicenses(int PersonID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select InternationalLicenseID, IssuedUsingLocalLicenseID as 'L.LicenseID',ApplicationID,
                                IssueDate,ExpirationDate,IsActive from InternationalLicenses 
                                where InternationalLicenses.DriverID=(
                                select DriverID from Drivers
                                where PersonID=@PersonID)";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@PersonID", PersonID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static int GetLocalLicensesByApplicationID(int ApplicationID)
        {
            var _LicenseID = -1;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select LicenseID from Licenses
                               where Licenses.ApplicationID=@ApplicationID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ApplicationID", ApplicationID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    _LicenseID = (int)reader[0];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                _LicenseID = -1;
            }
            finally
            {
                connection.Close();
            }

            return _LicenseID;
        }

        public static int GetActiveLicenseIDByPersonID(int PersonID, int LicenseClassID)
        {
            int LicenseID = -1;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"SELECT Licenses.LicenseID FROM Licenses
                              INNER JOIN Drivers ON Licenses.DriverID = Drivers.DriverID
                              WHERE  Licenses.LicenseClass = @LicenseClass AND Drivers.PersonID = @PersonID And IsActive=1;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@PersonID", PersonID);
            command.Parameters.AddWithValue("@LicenseClass", LicenseClassID);

            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    LicenseID = insertedID;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

            finally
            {
                connection.Close();
            }

            return LicenseID;
        }
    }
}