using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class TestAppointmentsDataAccessLayer
    {
        public static DataTable GetAllTestAppointments(int LocalDrivingLicenseApplicationID, int TestTypeID)
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query =
                @"Select TestAppointments.TestAppointmentID , AppointmentDate , PaidFees , IsLocked From TestAppointments 
                    Where LocalDrivingLicenseApplicationID=@LocalDrivingLicenseApplicationID and TestTypeID=@TestTypeID ";

            // Left join Tests ON Tests.TestAppointmentID = TestAppointments.TestAppointmentID

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LocalDrivingLicenseApplicationID", LocalDrivingLicenseApplicationID);
            command.Parameters.AddWithValue("@TestTypeID", TestTypeID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool GetTestAppointmentByID(int ID, ref int testTypeId,
            ref int localDrivingLicenseApplicationID, ref DateTime appointmentDate,
            ref decimal paidFees, ref int createdByUserId, ref bool isLocked, ref int retakeTestApplicationId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from TestAppointments Where TestAppointmentID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    testTypeId = (int)reader[1];
                    localDrivingLicenseApplicationID = (int)reader[2];
                    appointmentDate = (DateTime)reader[3];
                    paidFees = (decimal)reader[4];
                    createdByUserId = (int)reader[5];
                    isLocked = (bool)reader[6];
                    retakeTestApplicationId = reader[7] != DBNull.Value ? (int)reader[7] : -1;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        public static int AddNewTestAppointment(int testTypeId,
            int localDrivingLicenseApplicationID, DateTime appointmentDate, decimal paidFees,
            int createdByUserId, bool isLocked, int retakeTestApplicationId)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"INSERT INTO TestAppointments
                             VALUES (@testTypeId, @localDrivingLicenseApplicationID,@appointmentDate,@paidFees,
                                     @createdByUserId,@isLocked,@retakeTestApplicationId)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@testTypeId", testTypeId);
            command.Parameters.AddWithValue("@localDrivingLicenseApplicationID", localDrivingLicenseApplicationID);
            command.Parameters.AddWithValue("@appointmentDate", appointmentDate);
            command.Parameters.AddWithValue("@paidFees", paidFees);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);
            command.Parameters.AddWithValue("@isLocked", isLocked);
            if (retakeTestApplicationId != -1)
                command.Parameters.AddWithValue("@retakeTestApplicationId", retakeTestApplicationId);
            else
                command.Parameters.AddWithValue("@retakeTestApplicationId", DBNull.Value);


            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool UpdateTestAppointment(int TestAppointmentID, int testTypeId,
            int localDrivingLicenseApplicationID, DateTime appointmentDate, decimal paidFees,
            int createdByUserId, bool isLocked, int RetakeTestApplicationID)
        {
            bool isUpdated = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update TestAppointments
                                     set  testTypeId =@testTypeId,localDrivingLicenseApplicationID=@localDrivingLicenseApplicationID,
                                          appointmentDate=@appointmentDate,paidFees=@paidFees,createdByUserId=@createdByUserId,
                                          isLocked=@isLocked, RetakeTestApplicationID=@RetakeTestApplicationID
                                     where TestAppointmentID = @TestAppointmentID";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@TestAppointmentID", TestAppointmentID);
            command.Parameters.AddWithValue("@testTypeId", testTypeId);
            command.Parameters.AddWithValue("@localDrivingLicenseApplicationID", localDrivingLicenseApplicationID);
            command.Parameters.AddWithValue("@appointmentDate", appointmentDate);
            command.Parameters.AddWithValue("@paidFees", paidFees);
            command.Parameters.AddWithValue("@createdByUserId", createdByUserId);
            command.Parameters.AddWithValue("@isLocked", isLocked);
            if (RetakeTestApplicationID == -1)
            {
                command.Parameters.AddWithValue("@RetakeTestApplicationID", DBNull.Value);
            }
            else
            {
                command.Parameters.AddWithValue("@RetakeTestApplicationID", RetakeTestApplicationID);
            }

            try

            {
                connection.Open();

                int rowsAffected = command.ExecuteNonQuery();

                isUpdated = rowsAffected > 0;

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex + "");
                isUpdated = false;
            }

            finally
            {
                connection.Close();
            }

            // MessageBox.Show(isUpdated + "");
            return isUpdated;
        }

        public static bool HaveTestAppointment(int localDrivingLicenseApplicationID, int typeTestID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select 'Found'=1 from  TestAppointments
                               left join Tests on Tests.TestAppointmentID=TestAppointments.TestAppointmentID
                               where LocalDrivingLicenseApplicationID=@localDrivingLicenseApplicationID 
                               and TestTypeID=@typeTestID and (IsLocked=0 or TestResult=1);";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@localDrivingLicenseApplicationID", localDrivingLicenseApplicationID);
            command.Parameters.AddWithValue("@typeTestID", typeTestID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = reader.HasRows;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }

        public static bool IsRetakeTest(int localDrivingLicenseApplicationID, int typeTestID)
        {
            bool isDeleted = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = @"select 'Found'=1 from  TestAppointments
                               left join Tests on Tests.TestAppointmentID=TestAppointments.TestAppointmentID
                                where LocalDrivingLicenseApplicationID=@localDrivingLicenseApplicationID 
                                and TestTypeID=@typeTestID and  TestResult=0;";
            
            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@localDrivingLicenseApplicationID", localDrivingLicenseApplicationID);
            command.Parameters.AddWithValue("@typeTestID", typeTestID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isDeleted = reader.HasRows;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isDeleted = false;
            }
            finally
            {
                connection.Close();
            }

            return isDeleted;
        }
    }
}