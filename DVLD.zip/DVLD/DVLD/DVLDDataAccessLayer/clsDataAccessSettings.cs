﻿namespace DVLDDataAccessLayer
{
    public class clsDataAccessSettings
    {
        public static readonly string ConnectionString = "Server=.;Database=DVLD;User Id= ;Password= ";
    }
}