using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class CountryDataAccessLayer
    {
        public static DataTable GetAllCountries()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            DataTable dt = new DataTable();

            string Query = @"select * from Countries";

            SqlCommand command = new SqlCommand(Query, connection);


            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static bool FindCountry(int ID, ref string CountryName)
        {
            bool isFoound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Countries Where CountryID=@ID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@ID", ID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFoound = true;
                    CountryName = (string)reader[1];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFoound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFoound;
        }

        public static bool FindCountry(ref int ID, string CountryName)
        {
            bool isFoound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from Countries Where CountryName=@CountryName";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@CountryName", CountryName);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFoound = true;
                    ID = (int)reader[0];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFoound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFoound;
        }
    }
}