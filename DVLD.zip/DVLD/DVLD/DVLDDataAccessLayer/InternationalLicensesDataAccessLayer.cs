using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace DVLDDataAccessLayer
{
    public class InternationalLicensesDataAccessLayer
    {
        public static DataTable GetAllInternationalLicensesApplications()
        {
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);
            
            string Query = @" select InternationalLicenseID , ApplicationID,DriverID,IssuedUsingLocalLicenseID,
                                IssueDate,ExpirationDate,IsActive from InternationalLicenses; ;";

            DataTable dt = new DataTable();

            SqlCommand command = new SqlCommand(Query, connection);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    dt.Load(reader);
                }

                reader.Close();
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
            }
            finally
            {
                connection.Close();
            }

            return dt;
        }

        public static int HaveInternationalLicense(int LicenseID)
        {
            int InternationalLicenseID = -1;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query =
                @"select InternationalLicenseID from InternationalLicenses
                   Where IssuedUsingLocalLicenseID=@LicenseID and GetDate() between IssueDate and ExpirationDate 
                   order by ExpirationDate Desc";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@LicenseID", LicenseID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    InternationalLicenseID = (int)reader[0];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                InternationalLicenseID = -1;
            }
            finally
            {
                connection.Close();
            }

            return InternationalLicenseID;
        }

        public static int AddInternationalLicense(int applicationId, int driverId, int issuedUsingLocalLicenseId,
            DateTime issueDate, DateTime expirationDate, bool isActive, int createdBy)
        {
            int Id = 0;
            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"Update InternationalLicenses 
                              Set isActive = 0 
                              Where DriverID = @driverId;
                              
                             INSERT INTO InternationalLicenses
                             VALUES (@applicationId, @driverId,@issuedUsingLocalLicenseId,@issueDate,@expirationDate,@isActive,@createdBy)
                             SELECT SCOPE_IDENTITY();";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@applicationId", applicationId);
            command.Parameters.AddWithValue("@driverId", driverId);
            command.Parameters.AddWithValue("@issuedUsingLocalLicenseId", issuedUsingLocalLicenseId);
            command.Parameters.AddWithValue("@issueDate", issueDate);
            command.Parameters.AddWithValue("@expirationDate", expirationDate);
            command.Parameters.AddWithValue("@isActive", isActive);
            command.Parameters.AddWithValue("@createdBy", createdBy);

            try
            {
                connection.Open();
                var result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    Id = insertedID;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                Id = -1;
            }
            finally
            {
                connection.Close();
            }

            return Id;
        }

        public static bool GetInternationalLicense(int InternationalLicenseID, ref int applicationId, ref int driverId,
            ref int issuedUsingLocalLicenseId, ref DateTime issueDate, ref DateTime expirationDate,
            ref bool isActive, ref int createdByUserId)
        {
            bool isFound = false;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string Query = "Select * from InternationalLicenses Where InternationalLicenseID=@InternationalLicenseID";

            SqlCommand command = new SqlCommand(Query, connection);
            command.Parameters.AddWithValue("@InternationalLicenseID", InternationalLicenseID);

            try
            {
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    isFound = true;
                    applicationId = (int)reader[1];
                    driverId = (int)reader[2];
                    issuedUsingLocalLicenseId = (int)reader[3];
                    issueDate = (DateTime)reader[4];
                    expirationDate = (DateTime)reader[5];
                    isActive = (bool)reader[6];
                    createdByUserId = (int)reader[7];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                isFound = false;
            }
            finally
            {
                connection.Close();
            }

            return isFound;
        }

        // HaveInternationalLicense()
        public static int GetActiveInternationalLicenseIDByDriverID(int DriverID)
        {
            int InternationalLicenseID = -1;

            SqlConnection connection = new SqlConnection(clsDataAccessSettings.ConnectionString);

            string query = @"  
                            SELECT Top 1 InternationalLicenseID
                            FROM InternationalLicenses 
                            where DriverID=@DriverID and GetDate() between IssueDate and ExpirationDate 
                            order by ExpirationDate Desc;";

            SqlCommand command = new SqlCommand(query, connection);

            command.Parameters.AddWithValue("@DriverID", DriverID);

            try
            {
                connection.Open();

                object result = command.ExecuteScalar();

                if (result != null && int.TryParse(result.ToString(), out int insertedID))
                {
                    InternationalLicenseID = insertedID;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

            finally
            {
                connection.Close();
            }


            return InternationalLicenseID;
        }
    }
}