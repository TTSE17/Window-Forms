using System;
using System.Drawing;
using System.Windows.Forms;
using DVLD.ApplicationTypes;
using DVLD.Drivers;
using DVLD.InternationalLicenses;
using DVLD.Licenses;
using DVLD.LocalLicenses;
using DVLD.People;
using DVLD.TestTypes;
using DVLD.Users;
using DVLDBusinessLayer;

namespace DVLD
{
    public partial class MainMenuScreen : Form
    {
        private ToolStripMenuItem LastButton;

        public MainMenuScreen()
        {
            InitializeComponent();

            // this.TopMost = true;
            // this.WindowState = FormWindowState.Maximized;
            // OpenForm.MainPanel = MainPanel;
            // OpenForm.LastForm = "";
            // OpenForm.activeForm = null;

            // lblLoggedInUser.Text=;
        }

        private void localLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddUpdateLocalDrivingLicenseScreen();
            fr.ShowDialog();
        }

        private void internationalLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new AddInternationalLicenseScreen();
            fr.ShowDialog();
        }

        private void renewDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new RenewLicenseScreen();
            fr.ShowDialog();
        }

        private void ReplacementLostOrDamagedDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new ReplacementLicenseScreen();
            fr.ShowDialog();
        }

        private void releaseDetainedDrivingLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new ReleaseDetainedLicenseScreen();
            fr.ShowDialog();
        }

        private void retakeTestToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var fr = new LocalLicensesApplicationsScreen();
            fr.ShowDialog();
        }

        private void manageLocalDrivingLicenseApplicationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new LocalLicensesApplicationsScreen();
            fr.ShowDialog();
        }

        private void ManageInternationalDrivingLicenseToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var fr = new InternationalLicensesApplicationsScreen();
            fr.ShowDialog();
        }

        private void ManageDetainedLicensesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var fr = new ListDetainedLicensesScreen();
            fr.ShowDialog();
        }

        private void detainLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new DetainLicenseScreen();
            fr.ShowDialog();
        }

        private void releaseDetainedLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new ReleaseDetainedLicenseScreen();
            fr.ShowDialog();
        }

        private void manageApplicationTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new ApplicationTypesScreen();
            fr.ShowDialog();
        }

        private void manageTestTypesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new TestTypesScreen();
            fr.ShowDialog();
        }

        private void peopleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fr = new PeopleScreen();
            fr.ShowDialog();
        }

        private void driversToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new DriversScreen();
            fr.ShowDialog();
        }

        private void employeesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fr = new UsersScreen();
            fr.ShowDialog();
        }

        private void currentUserInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fr = new UserCardDetailsScreen(clsGlobal.CurrentUser.UserID);
            fr.ShowDialog();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form fr = new ChangePasswordScreen(clsGlobal.CurrentUser.UserID);
            fr.ShowDialog();
        }

        private void signOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clsGlobal.CurrentUser = null;
            (Application.OpenForms["LoginScreen"] as LoginScreen)?.RestoreData();
            Close();
        }

        private void MainMenuScreen_FormClosing(object sender, FormClosingEventArgs e)
        {
            clsGlobal.CurrentUser = null;
            (Application.OpenForms["LoginScreen"] as LoginScreen)?.RestoreData();
        }

        private void MainMenuScreen_Load(object sender, EventArgs e)
        {
            BackColor = Color.White;
            lblLoggedInUser.Text = "LoggedIn User: " + clsGlobal.CurrentUser.Username;
            Refresh();
        }


        private void peopleToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            // ChangeActiveButton(peopleToolStripMenuItem);

            Form fr = new PeopleScreen();
            OpenForm.OpenChildFormInPanel(ref fr);
        }

        private void ChangeActiveButton(ToolStripMenuItem ActiveButton)
        {
            if (LastButton != null)
                LastButton.BackColor = Color.WhiteSmoke;

            ActiveButton.BackColor = Color.LightGray;
            LastButton = ActiveButton;
        }
    }
}