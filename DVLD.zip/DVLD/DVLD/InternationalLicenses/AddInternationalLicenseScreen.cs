using System;
using System.Windows.Forms;
using DVLD.Licenses;
using DVLDBusinessLayer;

namespace DVLD.InternationalLicenses
{
    public partial class AddInternationalLicenseScreen : Form
    {
        public AddInternationalLicenseScreen()
        {
            InitializeComponent();
        }

        private int _LicenseID = -1;
        private LicensesBusinessLayer _License1;

        private int _InternationalID = -1;

        private void AddInternationalLicenseScreen_Load(object sender, EventArgs e)
        {
            lblApplicationDate.Text = DateTime.Now.ToString();
            lblIssueDate.Text = DateTime.Now.ToString();
            lblExpirationDate.Text = DateTime.Now.AddYears(1).ToShortDateString();
            lblFees.Text = Convert.ToString(ApplicationTypesBusinessLayer.FindApplicationType(6).ApplicationFees);
            lblCreatedByUser.Text = clsGlobal.CurrentUser.Username;
        }

        private void ctrlSearchLicense1_OnSearchLicense(int LicenseID)
        {
            _LicenseID = LicenseID;
            _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);

            llShowLicensesHistory.Enabled = true;

            lblLocalLicenseID.Text = Convert.ToString(LicenseID);

            if (!_License1.IsActive)
            {
                MessageBox.Show("It Isn't Active");
                btnIssue.Enabled = llShowLicenseInfo.Enabled = false;

                return;
            }

            if ((DateTime.Now) > _License1.ExpirationDate)
            {
                MessageBox.Show("Expired");
                btnIssue.Enabled = llShowLicenseInfo.Enabled = false;

                return;
            }

            if (_License1.LicenseClass != 3)
            {
                MessageBox.Show("Selected License should be Class 3, select another one.", "Not allowed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnIssue.Enabled = llShowLicenseInfo.Enabled = false;

                return;
            }

            _InternationalID = InternationalLicensesBusinessLayer.HaveInternationalLicense(_LicenseID);

            if (_InternationalID != -1)
            {
                MessageBox.Show(
                    "Person already have an active international license with ID = " +
                    _InternationalID, "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);

                llShowLicenseInfo.Enabled = true;

                return;
            }

            llShowLicenseInfo.Enabled = false;
            btnIssue.Enabled = true;
        }

        private void llShowLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var PersonID = _License1.Application.ApplicationPersonID;

            var fr = new LicensesHistoryScreen(PersonID);
            fr.ShowDialog();

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }

        private void llShowNewLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new InternationalLicenseInfoScreen(_InternationalID);
            fr.ShowDialog();
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            var _Application1 = new ApplicationsBusinessLayer()
            {
                ApplicationPersonID = _License1.Application.ApplicationPersonID,
                ApplicationDate = DateTime.Now,
                ApplicationTypeID = 6,
                ApplicationStatus = 3,
                LastStatusDate = DateTime.Now,
                PaidFees = Convert.ToDecimal(lblFees.Text),
                CreatedByUserId = clsGlobal.CurrentUser.UserID
            };

            _Application1.Save();

            var _InternationalLicense1 = new InternationalLicensesBusinessLayer()
            {
                Application = _Application1,
                DriverID = _License1.DriverID,
                IssuedUsingLocalLicenseID = _License1.LicenseID,
                IssueDate = DateTime.Now,
                ExpirationDate = DateTime.Now.AddYears(1),
                IsActive = true,
                CreatedByUserID = clsGlobal.CurrentUser.UserID
            };

            MessageBox.Show(_InternationalLicense1.AddInternationalLicense()
                ? "International License Issued Successfully with ID=" +
                  _InternationalLicense1.InternationalLicenseID
                : "Failed", "License Issued", MessageBoxButtons.OK, MessageBoxIcon.Information);

            llShowLicenseInfo.Enabled = true;

            lblApplicationID.Text = Convert.ToString(_InternationalLicense1.Application.ApplicationId);
            lblInternationalLicenseID.Text = Convert.ToString(_InternationalLicense1.InternationalLicenseID);
        }
    }
}