using System;
using System.Windows.Forms;

namespace DVLD.InternationalLicenses
{
    public partial class InternationalLicenseInfoScreen : Form
    {
        private int _InternationalLicenseID = -1;

        public InternationalLicenseInfoScreen(int internationalLicenseId)
        {
            InitializeComponent();
            _InternationalLicenseID = internationalLicenseId;
        }

        private void InternationalLicenseInfoScreen_Load(object sender, EventArgs e)
        {
            ctrlInternationalLicenseInfo1.LoadInternationalLicenseInfo(_InternationalLicenseID);
        }
    }
}