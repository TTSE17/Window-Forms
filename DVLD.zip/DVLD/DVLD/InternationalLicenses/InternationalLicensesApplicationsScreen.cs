using System;
using System.Data;
using System.Windows.Forms;
using DVLD.Licenses;
using DVLD.People;
using DVLDBusinessLayer;

namespace DVLD.InternationalLicenses
{
    public partial class InternationalLicensesApplicationsScreen : Form
    {
        private DataTable _DataTable;

        private int _InternationalLicenseID = -1;
        private InternationalLicensesBusinessLayer _InternationalLicense1;

        public InternationalLicensesApplicationsScreen()
        {
            InitializeComponent();
        }

        private void InternationalLicensesApplicationsScreen_Load(object sender, EventArgs e)
        {
            RefreshData();

            if (GridViewInternationalLicensesList.Rows.Count <= 0) return;
            GridViewInternationalLicensesList.Columns[0].Width = 71;
            GridViewInternationalLicensesList.Columns[1].Width = 71;
            GridViewInternationalLicensesList.Columns[2].Width = 71;
            GridViewInternationalLicensesList.Columns[3].Width = 97;
            GridViewInternationalLicensesList.Columns[4].Width = 99;
            GridViewInternationalLicensesList.Columns[5].Width = 99;
            GridViewInternationalLicensesList.Columns[6].Width = 71;
        }

        private void RefreshData()
        {
            _DataTable = InternationalLicensesBusinessLayer.GetAllInternationalLicensesApplications();

            comboBox1.SelectedIndex = 0;

            LoadData();
        }

        private void LoadData(string Type = "InternationalLicenseID", string Text = "")
        {
            var EmployeesDataView1 = _DataTable.DefaultView;

            try
            {
                EmployeesDataView1.RowFilter = Text != "" ? $@"{Type} = '{Text}'" : null;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                EmployeesDataView1.RowFilter = null;
            }

            GridViewInternationalLicensesList.DataSource = EmployeesDataView1;

            lblRecords.Text = Convert.ToString(GridViewInternationalLicensesList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();
            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsReleased = comboBox1.SelectedIndex == 4;

            textBox1.Visible = !IsReleased;
            cbIsReleased.Visible = IsReleased;
            cbIsReleased.SelectedIndex = 0;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbIsReleased_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbIsReleased.SelectedItem);

            var IsReleasedValue = Selection == "All" ? "" : (Selection == "Yes" ? "true" : "false");

            LoadData("IsActive", IsReleasedValue);
        }

        private void showPersonDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewInternationalLicensesList.CurrentRow.Cells[0].Value));

            var fr = new PersonCardDetailsScreen(_InternationalLicense1.Application.ApplicationPersonID);
            fr.ShowDialog();

            RefreshData();
        }

        private void showLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewInternationalLicensesList.CurrentRow.Cells[0].Value));

            var fr = new InternationalLicenseInfoScreen(_InternationalLicenseID);
            fr.ShowDialog();
        }

        private void showLicensePersonHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewInternationalLicensesList.CurrentRow.Cells[0].Value));

            var fr = new LicensesHistoryScreen(_InternationalLicense1.DriverInfo.PersonInfo.PersonId);
            fr.ShowDialog();

            RefreshData();
        }

        private void UpdateInternationalInfo(int ID)
        {
            _InternationalLicenseID = Convert.ToInt32(ID);
            _InternationalLicense1 =
                InternationalLicensesBusinessLayer.FindInternationalLicense(_InternationalLicenseID);
        }

        private void btnNewApplication_Click(object sender, EventArgs e)
        {
            var fr = new AddInternationalLicenseScreen();
            fr.ShowDialog();
            RefreshData();
        }
    }
}