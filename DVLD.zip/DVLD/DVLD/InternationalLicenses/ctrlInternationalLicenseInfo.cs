using System;
using System.Windows.Forms;
using DVLD.Properties;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlInternationalLicenseInfo : UserControl
    {
        private int _InternationalLicenseID = -1;

        public ctrlInternationalLicenseInfo()
        {
            InitializeComponent();
        }

        public void LoadInternationalLicenseInfo(int InternationalLicenseID)
        {
            _InternationalLicenseID = InternationalLicenseID;
            LoadData();
        }

        private void LoadData()
        {
            var _InternationalLicense1 =
                InternationalLicensesBusinessLayer.FindInternationalLicense(_InternationalLicenseID);

            if (_InternationalLicense1 == null) return;

            lblFullName.Text = _InternationalLicense1.DriverInfo.PersonInfo.FullName();
            lblInternationalLicenseID.Text = Convert.ToString(_InternationalLicenseID);
            lblLocalLicenseID.Text = Convert.ToString(_InternationalLicense1.IssuedUsingLocalLicenseID);
            lblNationalNo.Text = _InternationalLicense1.Application.PersonInfo.NationalNo;
            lblGendor.Text = _InternationalLicense1.Application.PersonInfo.Gender == 0 ? "Male" : "Female";
            lblIssueDate.Text = _InternationalLicense1.IssueDate.ToShortDateString();
            lblApplicationID.Text = Convert.ToString(_InternationalLicense1.Application.ApplicationId);
            lblIsActive.Text = _InternationalLicense1.IsActive ? "Yes" : "No";
            lblDateOfBirth.Text = _InternationalLicense1.Application.PersonInfo.DateOfBirth.ToShortDateString();
            lblDriverID.Text = Convert.ToString(_InternationalLicense1.DriverID);
            lblExpirationDate.Text = _InternationalLicense1.ExpirationDate.ToShortDateString();

            var ImagePath = _InternationalLicense1.Application.PersonInfo.ImagePath;

            if (ImagePath != "")
                pbPersonImage.Load(ImagePath);
            else
                pbPersonImage.Image = (lblGendor.Text == "Male") ? Resources.user : Resources.user_female;
        }
    }
}