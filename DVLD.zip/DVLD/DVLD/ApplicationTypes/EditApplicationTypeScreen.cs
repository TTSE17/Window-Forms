using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.ApplicationTypes
{
    public partial class EditApplicationTypeScreen : Form
    {
        private int _ApplicationTypeID = -1;

        private ApplicationTypesBusinessLayer _ApplicationType1;

        public EditApplicationTypeScreen(int applicationTypeId)
        {
            InitializeComponent();

            _ApplicationTypeID = applicationTypeId;
        }

        private void EditApplicationTypeScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _ApplicationType1 = ApplicationTypesBusinessLayer.FindApplicationType(_ApplicationTypeID);

            lblID.Text = Convert.ToString(_ApplicationTypeID);
            txtTitle.Text = _ApplicationType1.ApplicationTypeTitle;
            txtFees.Text = Convert.ToString(_ApplicationType1.ApplicationFees);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var Title = txtTitle.Text.Trim();
            var Fees = txtFees.Text.Trim();

            if (string.IsNullOrEmpty(Title) || string.IsNullOrEmpty(Fees))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            _ApplicationType1.ApplicationTypeTitle = Title;
            try
            {
                _ApplicationType1.ApplicationFees = Convert.ToDecimal(Fees);
            }
            catch (Exception exception)
            {
                MessageBox.Show("Numrical Chars in Fees");
                // txtFees.Text = "";
                txtFees.Focus();
                return;
            }

            if (_ApplicationType1.UpdateApplicationType())
                MessageBox.Show("Data Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);

            else
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}