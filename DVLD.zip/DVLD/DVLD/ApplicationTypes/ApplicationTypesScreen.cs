using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.ApplicationTypes
{
    public partial class ApplicationTypesScreen : Form
    {
        public ApplicationTypesScreen()
        {
            InitializeComponent();
        }

        private void ApplicationTypesScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            GridViewApplicationTypesList.DataSource = ApplicationTypesBusinessLayer.GetApplicationTypes();
            lblRecords.Text = Convert.ToString(GridViewApplicationTypesList.Rows.Count);
            
            GridViewApplicationTypesList.Columns[0].Width = 111;

            GridViewApplicationTypesList.Columns[1].Width = 301;

            GridViewApplicationTypesList.Columns[2].Width = 111;
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var ApplicationTypeID = Convert.ToInt32(GridViewApplicationTypesList.CurrentRow.Cells[0].Value);
            Form fr = new EditApplicationTypeScreen(ApplicationTypeID);
            fr.ShowDialog();
            LoadData();
        }

    }
}