using System.ComponentModel;

namespace DVLD.People
{
    partial class SelectPersonScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectPerson1 = new DVLD.Controls.ctrlSelectPerson();
            this.ctrlSelectPerson1 = new DVLD.Controls.ctrlSelectPerson();
            this.SuspendLayout();
            // 
            // selectPerson1
            // 
            this.selectPerson1.Location = new System.Drawing.Point(12, 12);
            this.selectPerson1.Name = "selectPerson1";
            this.selectPerson1.Size = new System.Drawing.Size(791, 318);
            this.selectPerson1.TabIndex = 0;
            // 
            // ctrlSelectPerson1
            // 
            this.ctrlSelectPerson1.Location = new System.Drawing.Point(651, 365);
            this.ctrlSelectPerson1.Name = "ctrlSelectPerson1";
            this.ctrlSelectPerson1.Size = new System.Drawing.Size(742, 340);
            this.ctrlSelectPerson1.TabIndex = 1;
            // 
            // SelectPersonScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(815, 342);
            this.Controls.Add(this.ctrlSelectPerson1);
            this.Controls.Add(this.selectPerson1);
            this.Name = "SelectPersonScreen";
            this.Text = "SelectPersonScreen";
            this.ResumeLayout(false);
        }

        private DVLD.Controls.ctrlSelectPerson ctrlSelectPerson1;

        private DVLD.Controls.ctrlSelectPerson selectPerson1;

        #endregion
    }
}