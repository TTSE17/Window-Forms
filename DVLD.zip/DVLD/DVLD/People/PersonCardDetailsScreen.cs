using System;
using System.Windows.Forms;
using DVLD.Controls;

namespace DVLD.People
{
    public partial class PersonCardDetailsScreen : Form
    {
        private int _PersonID;
        public PersonCardDetailsScreen(int PersonID)
        {
            InitializeComponent();

            _PersonID = PersonID;
        }


        private void PersonCardDetailsScreen_Load(object sender, EventArgs e)
        {
            ctrlPersonCardDetails1.LoadPersonInfo(_PersonID);
        }
    }
}