using System;
using System.Windows.Forms;

namespace DVLD.People
{
    public partial class SelectPersonScreen : Form
    {
        public delegate void DataBackEventHandler(int ID);

        public event DataBackEventHandler DataBack;

        public SelectPersonScreen()
        {
            InitializeComponent();
        }

        public void Close(int PersonID)
        {
            DataBack?.Invoke(PersonID);
            Close();
        }
        
    }
}