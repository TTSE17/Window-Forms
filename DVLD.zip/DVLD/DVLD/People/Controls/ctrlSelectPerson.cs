using System;
using System.Data;
using System.Windows.Forms;
using DVLD.People;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlSelectPerson : UserControl
    {
        // Define a custom event handler delegate with parameters
        public event Action<int> OnPersonSelected;

        // Create a protected method to raise the event with a parameter
        protected virtual void PersonSelected(int PersonID)
        {
            Action<int> handler = OnPersonSelected;
            if (handler != null)
            {
                handler(PersonID); // Raise the event with the parameter
            }
        }

        public ctrlSelectPerson()
        {
            InitializeComponent();
        }

        public void LoadPersonInfo(string ID)
        {
            comboBox1.SelectedIndex = comboBox1.FindString(ID);
        }

        private void ctrlSelectPerson_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            comboBox1.Items.Clear();

            var DT = PersonBusinessLayer.GetAllPeople();

            var PersonID = -1;

            foreach (DataRow Row in DT.Rows)
            {
                PersonID = Convert.ToInt32(Row[0]);
                comboBox1.Items.Add(PersonID);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var PersonID = Convert.ToInt32(comboBox1.SelectedItem);

            ctrlPersonCardDetails1.LoadPersonInfo(PersonID);

            if (OnPersonSelected != null)
                // Raise the event with a parameter
                PersonSelected(PersonID);
        }

        private void btnNewPerson_Click(object sender, EventArgs e)
        {
            AddUpdatePerson fr = new AddUpdatePerson();

            fr.DataBack += DataBackPersonID;

            fr.ShowDialog();
        }

        private void DataBackPersonID(int ID)
        {
            if (ID == -1)
                return;

            LoadData();

            LoadPersonInfo((Convert.ToString(ID)));
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            var PersonID = Convert.ToInt32(comboBox1.SelectedItem);

            if (comboBox1.SelectedIndex == -1)
                MessageBox.Show("Please , Select");

            else if (UsersBusinessLayer.IsPersonRelatedToUser(PersonID))
                MessageBox.Show("This Person is Related To a User ! \nSelect Another");

            else
                (Application.OpenForms["SelectPersonScreen"] as SelectPersonScreen)?.Close(PersonID);
        }
        
        public int PersonID()
        {
            return ctrlPersonCardDetails1.GetPersonID();
        }
    }
}