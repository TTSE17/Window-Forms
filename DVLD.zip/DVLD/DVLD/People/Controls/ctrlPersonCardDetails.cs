using System;
using System.IO;
using System.Windows.Forms;
using DVLD.People;
using DVLD.Properties;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlPersonCardDetails : UserControl
    {
        private int _PersonID = -1;
        private PersonBusinessLayer _Person1;

        public ctrlPersonCardDetails()
        {
            InitializeComponent();
        }

        public void LoadPersonInfo(int PersonID)
        {
            _PersonID = PersonID;
            LoadData();
        }

        private void LoadData()
        {
            _Person1 = PersonBusinessLayer.FindPerson(_PersonID);

            if (_Person1 == null) return;

            lblPersonID.Text = Convert.ToString(_Person1.PersonId);
            lblFullName.Text = _Person1.FullName();
            lblNationalNo.Text = _Person1.NationalNo;
            lblDateOfBirth.Text = _Person1.DateOfBirth.ToString("yyyy/MM/dd");
            lblGendor.Text = (_Person1.Gender == 0) ? "Male" : "Female";
            lblAddress.Text = _Person1.Address;
            lblPhone.Text = _Person1.Phone;
            lblEmail.Text = _Person1.Email;
            lblCountry.Text = CountryBusinessLayer.FindCountry(_Person1.NationalityCountryID).CountryName;

            if (_Person1.ImagePath != "" && File.Exists(_Person1.ImagePath))
                pbPerson.ImageLocation = _Person1.ImagePath;

            else
                pbPerson.Image = (_Person1.Gender == 0) ? Resources.user : Resources.user_female;
        }

        public int GetPersonID()
        {
            return _PersonID;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
          //  pbPerson.ImageLocation = "";
            // pictureBox1.Load();

            var fr = new AddUpdatePerson(_PersonID);
            fr.ShowDialog();

            LoadPersonInfo(_PersonID);
        }
    }
}