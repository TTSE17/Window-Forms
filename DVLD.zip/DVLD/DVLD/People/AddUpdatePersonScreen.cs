using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using DVLD.Properties;
using DVLDBusinessLayer;

namespace DVLD.People
{
    public partial class AddUpdatePerson : Form
    {
        public delegate void DataBackEventHandler(int ID);

        public event DataBackEventHandler DataBack;

        private int _PersonID;
        private PersonBusinessLayer _Person1;

        private string _LastImage = "", _CurrentImage = "";


        public AddUpdatePerson(int PersonID = -1)
        {
            InitializeComponent();

            _PersonID = PersonID;
        }

        private void AddUpdatePerson_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadCountries();
            pbPerson.ImageLocation = null;

            DateTimePicker.MaxDate = DateTime.Now.AddYears(-18);
            DateTimePicker.MinDate = DateTime.Now.AddYears(-100);

            if (_PersonID == -1)
            {
                _Person1 = new PersonBusinessLayer();
                lblTitleForm.Text = "Add New Person";
                lblPersonID.Text = "N/A";
                lilRemoveImage.Visible = false;
            }

            else
            {
                _Person1 = PersonBusinessLayer.FindPerson(_PersonID);

                if (_Person1 == null) return;

                lblTitleForm.Text = "Update Person";
                lblPersonID.Text = Convert.ToString(_PersonID);
                txtFirstName.Text = _Person1.FirstName;
                txtSecondName.Text = _Person1.SecondName;
                txtThirdName.Text = _Person1.ThirdName;
                txtLastName.Text = _Person1.LastName;
                txtNationalNo.Text = _Person1.NationalNo;
                DateTimePicker.Value = _Person1.DateOfBirth;

                if (_Person1.Gender == 0)
                    rbMale.Checked = true;
                else
                    rbFemale.Checked = true;

                txtAddress.Text = _Person1.Address;
                txtPhone.Text = _Person1.Phone;
                txtEmail.Text = _Person1.Email;
                cmbCountry.SelectedIndex =
                    cmbCountry.FindString(CountryBusinessLayer.FindCountry(_Person1.NationalityCountryID).CountryName);


                if (_Person1.ImagePath != "" && File.Exists(_Person1.ImagePath))
                {
                    pbPerson.ImageLocation = _Person1.ImagePath;
                    // _CurrentImage = _LastImage = pbPerson.ImageLocation;
                    lilRemoveImage.Visible = true;
                }
                else
                {
                    pbPerson.Image = (rbMale.Checked) ? Resources.user : Resources.user_female;
                    lilRemoveImage.Visible = false;
                }
            }
        }

        private void LoadCountries()
        {
            DataTable dt = CountryBusinessLayer.GetAllCountries();

            foreach (DataRow Row in dt.Rows)
            {
                cmbCountry.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var FirstName = txtFirstName.Text.Trim();
            var SecondName = txtSecondName.Text.Trim();
            var ThirdName = txtThirdName.Text.Trim();
            var LastName = txtLastName.Text.Trim();
            var NationalNo = txtNationalNo.Text;
            var BirthDate = DateTimePicker.Value;
            short Gender = Convert.ToInt16((rbMale.Checked) ? 0 : 1);
            var Address = txtAddress.Text.Trim();
            var Phone = txtPhone.Text.Trim();
            var Email = txtEmail.Text.Trim();
            var NationalityCountryName = Convert.ToString(cmbCountry.SelectedItem);
            var ImagePath = pbPerson.ImageLocation;

            if (string.IsNullOrEmpty(FirstName) || string.IsNullOrEmpty(LastName) || string.IsNullOrEmpty(SecondName) ||
                string.IsNullOrEmpty(ThirdName) || string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Phone) ||
                string.IsNullOrEmpty(Address) || string.IsNullOrEmpty(NationalNo) ||
                (string.IsNullOrEmpty(NationalityCountryName)) || errorProvider1.GetError(txtNationalNo) != "")
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            lblTitleForm.Text = "Update Person";

            _Person1.FirstName = FirstName;
            _Person1.SecondName = SecondName;
            _Person1.ThirdName = ThirdName;
            _Person1.LastName = LastName;
            _Person1.NationalNo = NationalNo;
            _Person1.DateOfBirth = BirthDate;
            _Person1.Gender = Gender;
            _Person1.Address = Address;
            _Person1.Phone = Phone;
            _Person1.Email = Email;

            _Person1.NationalityCountryID = CountryBusinessLayer.FindCountry(NationalityCountryName).CountryID;

            _HandleImage();

            _Person1.ImagePath = pbPerson.ImageLocation ?? "";

            // if (_LastImage == "" && _CuurentImage == "") //_Person1.ImagePath == pbPerson.ImageLocation
            //     _Person1.ImagePath = "";
            //
            // else
            // {
            //     var CurrentPath =
            //         "C:\\Users\\Taha\\Documents\\ProgrammingAdvices\\18 - C# & Database Connectivity\\Projects\\DVLD\\Images\\"
            //         + Guid.NewGuid() + Path.GetExtension(_CuurentImage);
            //
            //     File.Copy(_CuurentImage, CurrentPath, true);
            //
            //     pbPerson.ImageLocation = CurrentPath;
            //     pbPerson.Load(CurrentPath);
            //
            //     if (File.Exists(_LastImage))
            //     {
            //         File.Delete(_LastImage);
            //     }
            //
            //     _LastImage = _CuurentImage = CurrentPath;
            //
            //     _Person1.ImagePath = CurrentPath;
            // }

            MessageBox.Show(_Person1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblPersonID.Text = Convert.ToString(_Person1.PersonId);

            _PersonID = _Person1.PersonId;
        }

        private void lilSetImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() != DialogResult.OK) return;
            
            var selectedFilePath = openFileDialog1.FileName;

            pbPerson.ImageLocation = selectedFilePath;

            _CurrentImage = pbPerson.ImageLocation;

            lilRemoveImage.Visible = true;
        }

        private void CheckedChanged(object sender, EventArgs e)
        {
            var Item = (RadioButton)sender;

            if (pbPerson.ImageLocation != null) return;

            pbPerson.Image = (rbMale.Checked) ? Resources.user : Resources.user_female;
        }

        private void lilRemoveImage_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pbPerson.ImageLocation = null;
            pbPerson.Image = (rbMale.Checked) ? Resources.user : Resources.user_female;

            lilRemoveImage.Visible = false;
        }

        private void txtNationalNo_Leave(object sender, EventArgs e)
        {
            var Item = txtNationalNo;
            var NationalNo = Item.Text.Trim();

            if (_Person1 != null && (_Person1.NationalNo).ToLower() == NationalNo.ToLower())
            {
                errorProvider1.SetError(Item, "");
                return;
            }

            if (!PersonBusinessLayer.IsNationalNoExist(NationalNo))
            {
                errorProvider1.SetError(Item, "");
                return;
            }

            errorProvider1.SetError(Item, "National Number is Used  For Another Person!");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void AddUpdatePerson_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (_PersonID == -1)
                return;
            DataBack?.Invoke(_PersonID);
        }

        private void _HandleImage()
        {
            if (_Person1.ImagePath == pbPerson.ImageLocation) return;

            if (_Person1.ImagePath != "")
            {
                try
                {
                    File.Delete(_Person1.ImagePath);
                }
                catch (IOException ee)
                {
                    MessageBox.Show(ee + "");
                }
            }

            if (pbPerson.ImageLocation != null)
            {
                //then we copy the new image to the image folder after we rename it
                string SourceImageFile = pbPerson.ImageLocation;

                var CurrentPath =
                    Directory.GetCurrentDirectory()+"\\Images\\"
                    + Guid.NewGuid() + Path.GetExtension(SourceImageFile);

                File.Copy(SourceImageFile, CurrentPath, true);

                pbPerson.ImageLocation = CurrentPath;
            }
        }
    }
}