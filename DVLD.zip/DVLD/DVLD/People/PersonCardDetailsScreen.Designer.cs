using System.ComponentModel;

namespace DVLD.People
{
    partial class PersonCardDetailsScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.ctrlPersonCardDetails1 = new DVLD.Controls.ctrlPersonCardDetails();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.99F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(262, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(257, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "Person Card Details";
            // 
            // ctrlPersonCardDetails1
            // 
            this.ctrlPersonCardDetails1.Location = new System.Drawing.Point(12, 82);
            this.ctrlPersonCardDetails1.Name = "ctrlPersonCardDetails1";
            this.ctrlPersonCardDetails1.Size = new System.Drawing.Size(784, 258);
            this.ctrlPersonCardDetails1.TabIndex = 1;
            // 
            // PersonCardDetailsScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 347);
            this.Controls.Add(this.ctrlPersonCardDetails1);
            this.Controls.Add(this.label1);
            this.Name = "PersonCardDetailsScreen";
            this.Text = "PersonCardDetailsScreen";
            this.Load += new System.EventHandler(this.PersonCardDetailsScreen_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private DVLD.Controls.ctrlPersonCardDetails ctrlPersonCardDetails1;

        private System.Windows.Forms.Label label1;

        #endregion
    }
}