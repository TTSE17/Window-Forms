﻿using System;
using System.ComponentModel;
using System.Data;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using DVLD.Controls;
using DVLDBusinessLayer;

namespace DVLD.People
{
    public partial class PeopleScreen : Form
    {
        public PeopleScreen()
        {
            InitializeComponent();
        }

        private DataTable _dtPeople;

        private void RefreshData()
        {
            _dtPeople = PersonBusinessLayer.GetAllPeople();

            comboBox1.SelectedIndex = 0;

            LoadData();

            // DataTable _dtPeople = _dtAllPeople.DefaultView.ToTable(false, "PersonID", "NationalNo",
            //     "FirstName", "SecondName", "ThirdName", "LastName",
            //     "GendorCaption", "DateOfBirth", "CountryName",
            //     "Phone", "Email");
        }

        private void PeopleScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
            
            if (GridViewPeopleList.Columns.Count <= 0) return;
            GridViewPeopleList.Columns[0].Width = 71;
            GridViewPeopleList.Columns[1].Width = 79;
            GridViewPeopleList.Columns[2].Width = 79;
            GridViewPeopleList.Columns[3].Width = 79;
            GridViewPeopleList.Columns[4].Width = 79;
            GridViewPeopleList.Columns[5].Width = 71;
            GridViewPeopleList.Columns[6].Width = 99;
            GridViewPeopleList.Columns[7].Width = 79;
            GridViewPeopleList.Columns[8].Width = 99;
            GridViewPeopleList.Columns[9].Width = 99;
            GridViewPeopleList.Columns[10].Width = 99;
        }

        private void LoadData(string Type = "PersonId", string Text = "")
        {
            var EmployeesDataView1 = _dtPeople.DefaultView;

            try
            {
                EmployeesDataView1.RowFilter =
                    Text == "" ? null : Type != "PersonID" ? $"{Type} LIKE '{Text}%'" : $"{Type} = '{Text}'";
                // EmployeesDataView1.RowFilter = Text != "" ? $@"{Type} LIKE '{Text}%'" : null;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                EmployeesDataView1.RowFilter = null;
            }

            GridViewPeopleList.DataSource = EmployeesDataView1;

            lblRecords.Text = Convert.ToString(GridViewPeopleList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Text = textBox1.Text.Trim();
            var Type = Convert.ToString(comboBox1.SelectedItem);

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.Focus();
        }

        private void btnNewPerson_Click(object sender, EventArgs e)
        {
            var fr = new AddUpdatePerson();
            fr.ShowDialog();
            RefreshData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var PersonID = Convert.ToInt32(GridViewPeopleList.CurrentRow.Cells[0].Value);
            Form fr = new AddUpdatePerson(PersonID);
            fr.ShowDialog();
            RefreshData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var PersonId = Convert.ToInt32(GridViewPeopleList.CurrentRow.Cells[0].Value);

            if (MessageBox.Show("Are you sure you want to delete Person [" +
                                PersonId + "]",
                    "Confirm Delete", MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (PersonBusinessLayer.DeletePerson(PersonId))
            {
                MessageBox.Show("Person Deleted Successfully");
                RefreshData();
            }
            else
            {
                MessageBox.Show("Person was not deleted because it has data linked to it");
            }
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var PersonId = Convert.ToInt32(GridViewPeopleList.CurrentRow.Cells[0].Value);

            var Card = new PersonCardDetailsScreen(PersonId);
            Card.ShowDialog();

            RefreshData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = GridViewPeopleList.Rows.Count <= 0;
        }
    }
}