using System;
using System.IO;
using System.Windows.Forms;
using DVLD.Controls;

namespace DVLD
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();
        }

        private void selectPerson1_OnPersonSelected(int obj)
        {
            // MessageBox.Show(obj + "");
        }

        private void Test_Load(object sender, EventArgs e)
        {
            // selectPerson1.LoadPersonInfo("1023");

            textBox1.Text = clsGlobal.Hash("12");
            var ImagePath =
                "C:\\Users\\Taha\\Documents\\ProgrammingAdvices\\18 - C# & Database Connectivity\\Projects\\DVLD\\Images\\user_female.png";

            // File.Delete(ImagePath);
            // if (File.Exists(ImagePath))
            // {
            // }
            // else
            // File.Copy(
            //     ImagePath,
            //     "C:\\Users\\Taha\\Documents\\ProgrammingAdvices\\18 - C# & Database Connectivity\\Projects\\DVLD\\Images\\" +
            //     Guid.NewGuid() + ".png");

            // MessageBox.Show(Path.GetFileName(ImagePath));

            // MessageBox.Show(Path.GetExtension(ImagePath));

            // var fs = File.OpenRead(
            //     @"Remember.txt");
            // var fr = new StreamReader(fs);
            //
            // string line;
            // while ((line = fr.ReadLine()) != null)
            // {
            //     MessageBox.Show(line);
            // }
            //
            // fr.Close();
        }
    }
}