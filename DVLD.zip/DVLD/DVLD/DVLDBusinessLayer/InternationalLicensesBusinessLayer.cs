using System;
using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class InternationalLicensesBusinessLayer
    {
        public int InternationalLicenseID { get; set; }

        public ApplicationsBusinessLayer Application { get; set; }
        public int DriverID { get; set; }

        public DriversBusinessLayer DriverInfo;
        public int IssuedUsingLocalLicenseID { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public bool IsActive { get; set; }
        public int CreatedByUserID { get; set; }

        public InternationalLicensesBusinessLayer()
        {
            InternationalLicenseID = -1;
            Application = new ApplicationsBusinessLayer();
            DriverID = -1;
            DriverInfo = new DriversBusinessLayer();
        }

        private InternationalLicensesBusinessLayer(int internationalLicenseId, ApplicationsBusinessLayer application,
            int driverId, int issuedUsingLocalLicenseId, DateTime issueDate, DateTime expirationDate,
            bool isActive, int createdByUserId)
        {
            InternationalLicenseID = internationalLicenseId;
            Application = application;
            DriverID = driverId;
            DriverInfo = DriversBusinessLayer.FindDriver(DriverID);
            IssuedUsingLocalLicenseID = issuedUsingLocalLicenseId;
            IssueDate = issueDate;
            ExpirationDate = expirationDate;
            IsActive = isActive;
            CreatedByUserID = createdByUserId;
        }

        public static DataTable GetAllInternationalLicensesApplications()
        {
            return InternationalLicensesDataAccessLayer.GetAllInternationalLicensesApplications();
        }

        public static int HaveInternationalLicense(int LicenseID)
        {
            return InternationalLicensesDataAccessLayer.HaveInternationalLicense(LicenseID);
        }

        public bool AddInternationalLicense()
        {
            InternationalLicenseID = InternationalLicensesDataAccessLayer.AddInternationalLicense(
                Application.ApplicationId, DriverID, IssuedUsingLocalLicenseID, IssueDate,
                ExpirationDate, IsActive, CreatedByUserID);

            return InternationalLicenseID != -1;
        }

        public static InternationalLicensesBusinessLayer FindInternationalLicense(int ID)
        {
            int applicationId = -1, driverId = -1, issuedUsingLocalLicenseId = -1, createdByUserId = -1;
            DateTime issueDate = DateTime.Now, expirationDate = DateTime.Now;
            var isActive = false;

            if (InternationalLicensesDataAccessLayer.GetInternationalLicense(ID, ref applicationId, ref driverId,
                    ref issuedUsingLocalLicenseId, ref issueDate, ref expirationDate,
                    ref isActive, ref createdByUserId))

            {
                var Application = ApplicationsBusinessLayer.FindApplication(applicationId);

                return new InternationalLicensesBusinessLayer(ID, Application, driverId, issuedUsingLocalLicenseId,
                    issueDate, expirationDate, isActive, createdByUserId);
            }

            return null;
        }

        public static int GetActiveInternationalLicenseIDByDriverID(int DriverID)
        {
            return InternationalLicensesDataAccessLayer.GetActiveInternationalLicenseIDByDriverID(DriverID);
        }
    }
}