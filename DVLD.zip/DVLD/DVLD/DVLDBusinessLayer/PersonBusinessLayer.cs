﻿using System;
using System.Data;
using System.Windows.Forms;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class PersonBusinessLayer
    {
        public int PersonId { get; private set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string ThirdName { get; set; }
        public string LastName { get; set; }

        public string FullName()
        {
            return FirstName + " " + SecondName + " " + ThirdName + " " + LastName;
        }

        public string NationalNo { get; set; }
        public DateTime DateOfBirth { get; set; }
        public short Gender { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public int NationalityCountryID { get; set; }
        public string ImagePath { get; set; }

        public PersonBusinessLayer()
        {
            PersonId = NationalityCountryID = -1;
            FirstName = SecondName = ThirdName = LastName = Address = Phone = Email = ImagePath = "";
            DateOfBirth = DateTime.Now;
        }

        private PersonBusinessLayer(int personId, string firstName, string secondName, string thirdName,
            string lastName, string nationalNo, DateTime dateOfBirth, short gender, string address, string phone,
            string email, int nationalityCountryId, string imagePath)
        {
            PersonId = personId;
            FirstName = firstName;
            SecondName = secondName;
            ThirdName = thirdName;
            LastName = lastName;
            NationalNo = nationalNo;
            DateOfBirth = dateOfBirth;
            Gender = gender;
            Address = address;
            Phone = phone;
            Email = email;
            NationalityCountryID = nationalityCountryId;
            ImagePath = imagePath;
        }


        public static DataTable GetAllPeople()
        {
            return PersonDataAccessLayer.GetAllPeople();
        }

        public static PersonBusinessLayer FindPerson(int ID)
        {
            string firstName = "",
                secondName = "",
                thirdName = "",
                lastName = "",
                nationalNo = "",
                address = "",
                phone = "",
                email = "",
                imagePath = "";

            var dateOfBirth = DateTime.Now;
            var nationalityCountryID = -1;
            short gender = 0;

            if (PersonDataAccessLayer.GetPersonByID(ID, ref firstName, ref secondName, ref thirdName, ref lastName,
                    ref nationalNo, ref dateOfBirth, ref gender, ref address, ref phone, ref email,
                    ref nationalityCountryID, ref imagePath))
                return new PersonBusinessLayer(ID, firstName, secondName, thirdName, lastName, nationalNo, dateOfBirth,
                    gender, address, phone, email, nationalityCountryID, imagePath);

            return null;
        }

        public static bool IsNationalNoExist(string NationalNo)
        {
            return PersonDataAccessLayer.IsNationalNoExist(NationalNo);
        }

        private int _AddNewPerson()
        {
            return PersonDataAccessLayer.AddNewPerson(FirstName, SecondName, ThirdName, LastName, NationalNo,
                DateOfBirth, Gender, Address, Phone, Email, NationalityCountryID, ImagePath);
        }

        private bool _UpdatePerson()
        {
            return PersonDataAccessLayer.UpdatePerson(PersonId, FirstName, SecondName, ThirdName, LastName, NationalNo,
                DateOfBirth, Gender, Address, Phone, Email, NationalityCountryID, ImagePath);
        }

        public bool Save()
        {
            if (this.PersonId != -1) return _UpdatePerson();

            PersonId = _AddNewPerson();
            return true;
        }

        public static bool DeletePerson(int ID)
        {
            return PersonDataAccessLayer.DeletePerson(ID);
        }
    }
}