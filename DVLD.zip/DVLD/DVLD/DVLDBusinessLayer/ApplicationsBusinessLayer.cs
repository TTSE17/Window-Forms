using System;
using System.Data;
using System.Security.Policy;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class ApplicationsBusinessLayer
    {
        public int ApplicationId { get; set; }

        public int ApplicationPersonID { get; set; }

        public PersonBusinessLayer PersonInfo;

        public DateTime ApplicationDate { get; set; }

        public int ApplicationTypeID { get; set; }

        public short ApplicationStatus { get; set; }

        public DateTime LastStatusDate { get; set; }

        public decimal PaidFees { get; set; }

        public int CreatedByUserId { get; set; }

        public UsersBusinessLayer UserInfo;

        public enum enApplicationType
        {
            NewDrivingLicense = 1,
            RenewDrivingLicense = 2,
            ReplaceLostDrivingLicense = 3,
            ReplaceDamagedDrivingLicense = 4,
            ReleaseDetainedDrivingLicense = 5,
            NewInternationalLicense = 6,
            RetakeTest = 7
        };

        public ApplicationsBusinessLayer()
        {
            ApplicationPersonID = ApplicationId = -1;
            UserInfo = new UsersBusinessLayer();
            PersonInfo = new PersonBusinessLayer();
        }

        private ApplicationsBusinessLayer(int applicationId, int applicationPersonId,
            DateTime applicationDate, int applicationTypeId, short applicationStatus,
            DateTime lastStatusDate, decimal paidFees, int createdByUserId)
        {
            ApplicationId = applicationId;
            ApplicationPersonID = applicationPersonId;
            PersonInfo=PersonBusinessLayer.FindPerson(applicationPersonId);
            ApplicationDate = applicationDate;
            ApplicationTypeID = applicationTypeId;
            ApplicationStatus = applicationStatus;
            LastStatusDate = lastStatusDate;
            PaidFees = paidFees;
            CreatedByUserId = createdByUserId;
            UserInfo = UsersBusinessLayer.FindUser(createdByUserId);
        }

        public static DataTable GetAllApplications()
        {
            return ApplicationsDataAccessLayer.GetAllApplications();
        }

        public static ApplicationsBusinessLayer FindApplication(int ID)
        {
            int applicationPersonId = -1, applicationTypeId = -1, createdByUserId = -1;
            DateTime applicationDate = System.DateTime.Now, lastStatusDate = DateTime.Now;
            short applicationStatus = -1;
            decimal paidFees = (decimal)0;

            if (ApplicationsDataAccessLayer.GetApplicationByID(ID, ref applicationPersonId, ref applicationDate,
                    ref applicationTypeId, ref applicationStatus,
                    ref lastStatusDate, ref paidFees, ref createdByUserId))
            {
                return new ApplicationsBusinessLayer(ID, applicationPersonId, applicationDate,
                    applicationTypeId, applicationStatus, lastStatusDate, paidFees, createdByUserId);
            }

            return null;
        }

        private int _AddNewApplication()
        {
            return ApplicationsDataAccessLayer.AddNewApplication(ApplicationPersonID, ApplicationDate,
                ApplicationTypeID, ApplicationStatus, LastStatusDate, PaidFees, CreatedByUserId);
        }

        private bool _UpdateApplication()
        {
            return ApplicationsDataAccessLayer.UpdateApplication(ApplicationId, ApplicationPersonID, ApplicationDate,
                ApplicationTypeID, ApplicationStatus, LastStatusDate, PaidFees, CreatedByUserId);
        }

        public bool Save()
        {
            if (ApplicationId != -1) return _UpdateApplication();

            ApplicationId = _AddNewApplication();
            return true;
        }

        public static bool Delete(int ApplicationID)
        {
            return ApplicationsDataAccessLayer.DeleteApplication(ApplicationID);
        }
    }
}