using System;
using System.Data;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLDDataAccessLayer
{
    public class TestAppointmentsBusinessLayer
    {
        public int TestAppointmentID { get; set; }
        public int TestTypeID { get; set; }
        public LocalLicensesBusinessLayer LocalDrivingLicenseApplication { get; set; }
        public DateTime AppointmentDate { get; set; }
        public decimal PaidFees { get; set; }
        public int CreatedByUserID { get; set; }
        public bool IsLocked { get; set; }
        public int RetakeTestApplicationID { get; set; }

        public TestAppointmentsBusinessLayer()
        {
            TestAppointmentID = -1;
            RetakeTestApplicationID = -1;
        }

        private TestAppointmentsBusinessLayer(int testAppointmentId, int testTypeId,
            LocalLicensesBusinessLayer localDrivingLicenseApplication, DateTime appointmentDate,
            decimal paidFees, int createdByUserId, bool isLocked, int retakeTestApplicationId)
        {
            TestAppointmentID = testAppointmentId;
            TestTypeID = testTypeId;
            LocalDrivingLicenseApplication = localDrivingLicenseApplication;
            AppointmentDate = appointmentDate;
            PaidFees = paidFees;
            CreatedByUserID = createdByUserId;
            IsLocked = isLocked;
            RetakeTestApplicationID = retakeTestApplicationId;
        }

        public static DataTable GetAllTestAppointments(int localDrivingLicenseApplicationID, int typeTestID)
        {
            return TestAppointmentsDataAccessLayer.GetAllTestAppointments(localDrivingLicenseApplicationID, typeTestID);
        }

        public static TestAppointmentsBusinessLayer FindTestAppointment(int ID)
        {
            var testTypeID = -1;
            var localDrivingLicenseApplicationID = -1;
            LocalLicensesBusinessLayer localDrivingLicenseApplication = null;
            var appointmentDate = DateTime.Now;
            var paidFees = (decimal)0;
            var createdByUserID = -1;
            var isLocked = false;
            var retakeTestApplicationId = -1;

            if (TestAppointmentsDataAccessLayer.GetTestAppointmentByID(ID, ref testTypeID,
                    ref localDrivingLicenseApplicationID, ref appointmentDate, ref paidFees,
                    ref createdByUserID, ref isLocked, ref retakeTestApplicationId))
            {
                localDrivingLicenseApplication =
                    LocalLicensesBusinessLayer.FindLocalLicense(localDrivingLicenseApplicationID);

                return new TestAppointmentsBusinessLayer(ID, testTypeID, localDrivingLicenseApplication,
                    appointmentDate, paidFees, createdByUserID, isLocked, retakeTestApplicationId);
            }

            return null;
        }

        private int _AddNewTestAppointment()
        {
            return TestAppointmentsDataAccessLayer.AddNewTestAppointment(TestTypeID,
                LocalDrivingLicenseApplication.LocalDrivingLicenseApplicationID, AppointmentDate,
                PaidFees, CreatedByUserID, IsLocked, RetakeTestApplicationID);
        }

        private bool _UpdateTestAppointment()
        {

            return TestAppointmentsDataAccessLayer.UpdateTestAppointment(TestAppointmentID, TestTypeID,
                LocalDrivingLicenseApplication.LocalDrivingLicenseApplicationID, AppointmentDate,
                PaidFees, CreatedByUserID, IsLocked, RetakeTestApplicationID);
        }

        public bool Save()
        {
            if (TestAppointmentID != -1) return _UpdateTestAppointment();

            TestAppointmentID = _AddNewTestAppointment();
            return true;
        }

        public static bool HaveTestAppointment(int localDrivingLicenseApplicationID, int typeTestID)
        {
            return TestAppointmentsDataAccessLayer.HaveTestAppointment(localDrivingLicenseApplicationID, typeTestID);
        }

        public static bool IsRetakeTest(int localDrivingLicenseApplicationID, int typeTestID)
        {
            return TestAppointmentsDataAccessLayer.IsRetakeTest(localDrivingLicenseApplicationID, typeTestID);
        }
    }
}