using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class LicenseClassesBusinessLayer
    {
        public int LicenseClassID { get; set; }
        public string ClassName { get; set; }
        public string ClassDescription { get; set; }
        public short MinimumAllowedAge { get; set; }
        public short DefaultValidityLength { get; set; }
        public decimal ClassFees { get; set; }

        public LicenseClassesBusinessLayer()
        {
            LicenseClassID = -1;
        }

        private LicenseClassesBusinessLayer(int licenseClassId, string className, string classDescription,
            short minimumAllowedAge, short defaultValidityLength, decimal classFees)
        {
            LicenseClassID = licenseClassId;
            ClassName = className;
            ClassDescription = classDescription;
            MinimumAllowedAge = minimumAllowedAge;
            DefaultValidityLength = defaultValidityLength;
            ClassFees = classFees;
        }

        public static DataTable GetAllLicenseClasses()
        {
            return LicenseClassesDataAccessLayer.GetAllLicenseClasses();
        }

        public static LicenseClassesBusinessLayer FindLicenseClass(int ID)
        {
            var ClassName = "";
            var ClassDescription = "";
            short MinimumAllowedAge = 0, DefaultValidityLength = 0;
            var ClassFees = (decimal)0;

            return LicenseClassesDataAccessLayer.FindLicenseClass(ID, ref ClassName, ref ClassDescription,
                ref MinimumAllowedAge, ref DefaultValidityLength, ref ClassFees)
                ? new LicenseClassesBusinessLayer(ID, ClassName, ClassDescription, MinimumAllowedAge,
                    DefaultValidityLength, ClassFees)
                : null;
        }

        public static LicenseClassesBusinessLayer FindLicenseClass(string ClassName)
        {
            var LicenseClassId = -1;
            var ClassDescription = "";
            short MinimumAllowedAge = 0, DefaultValidityLength = 0;
            var ClassFees = (decimal)0;

            return LicenseClassesDataAccessLayer.FindLicenseClass(ref LicenseClassId, ClassName,
                ref ClassDescription, ref MinimumAllowedAge, ref DefaultValidityLength, ref ClassFees)
                ? new LicenseClassesBusinessLayer(LicenseClassId, ClassName, ClassDescription, MinimumAllowedAge,
                    DefaultValidityLength, ClassFees)
                : null;
        }
    }
}