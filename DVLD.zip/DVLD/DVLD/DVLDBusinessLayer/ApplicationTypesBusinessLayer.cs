using System;
using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class ApplicationTypesBusinessLayer
    {
        public int ApplicationTypeId { get; set; }
        public string ApplicationTypeTitle { get; set; }
        public decimal ApplicationFees { get; set; }

        public static DataTable GetApplicationTypes()
        {
            return ApplicationTypesDataAccessLayer.GetApplicationTypes();
        }

        private ApplicationTypesBusinessLayer(int applicationTypeId, string applicationTypeTitle,
            decimal applicationFees)
        {
            ApplicationTypeId = applicationTypeId;
            ApplicationTypeTitle = applicationTypeTitle;
            ApplicationFees = applicationFees;
        }

        public static ApplicationTypesBusinessLayer FindApplicationType(int ID)
        {
            var applicationTypeTitle = "";
            var applicationFees = (decimal)0.0;

            if (ApplicationTypesDataAccessLayer.GetApplicationTypeByID(ID, ref applicationTypeTitle,
                    ref applicationFees))
                return new ApplicationTypesBusinessLayer(ID, applicationTypeTitle, applicationFees);

            return null;
        }

        public bool UpdateApplicationType()
        {
            return ApplicationTypesDataAccessLayer.UpdateApplicationType(ApplicationTypeId, ApplicationTypeTitle,
                ApplicationFees);
        }
    }
}