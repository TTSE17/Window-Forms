using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class TestsBusinessLayer
    {
        public int TestID { get; set; }
        public int TestAppointmentID { get; set; }
        public bool TestResult { get; set; }
        public string Notes { get; set; }
        public int CreatedByUserID { get; set; }

        public TestsBusinessLayer()
        {
            TestID = -1;
        }

        private TestsBusinessLayer(int testId, int testAppointmentId,
            bool testResult, string notes, int createdByUserId)
        {
            TestID = testId;
            TestAppointmentID = testAppointmentId;
            TestResult = testResult;
            Notes = notes;
            CreatedByUserID = createdByUserId;
        }

        public bool AddNewTest()
        {
            TestID = TestsDataAccessLayer.AddNewTest(TestAppointmentID, TestResult, Notes, CreatedByUserID);
            return TestID != -1;
        }
    }
}