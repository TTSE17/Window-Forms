using System;
using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class LicensesBusinessLayer
    {
        public int LicenseID { get; set; }

        public int ApplicationID { get; set; }
        public ApplicationsBusinessLayer Application { get; set; }
        public int DriverID { get; set; }

        public DriversBusinessLayer DriverInfo;
        public int LicenseClass { get; set; }

        public LicenseClassesBusinessLayer LicenseClassInfo;
        public DateTime IssueDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public string Notes { get; set; }
        public decimal PaidFees { get; set; }
        public bool IsActive { get; set; }
        public short IssueReason { get; set; }
        public int CreatedByUserID { get; set; }

        public LicensesBusinessLayer()
        {
            LicenseID = -1;
            Application = new ApplicationsBusinessLayer();
            DriverInfo = new DriversBusinessLayer();
            LicenseClassInfo = new LicenseClassesBusinessLayer();
        }

        private LicensesBusinessLayer(int licenseId, int applicationId, int driverId,
            int licenseClass, DateTime issueDate, DateTime expirationDate, string notes, decimal paidFees,
            bool isActive, short issueReason, int createdByUserId)
        {
            LicenseID = licenseId;
            Application = ApplicationsBusinessLayer.FindApplication(applicationId);
            DriverID = driverId;
            DriverInfo = DriversBusinessLayer.FindDriver(driverId);
            LicenseClass = licenseClass;
            LicenseClassInfo=LicenseClassesBusinessLayer.FindLicenseClass(licenseClass);
            IssueDate = issueDate;
            ExpirationDate = expirationDate;
            Notes = notes;
            PaidFees = paidFees;
            IsActive = isActive;
            IssueReason = issueReason;
            CreatedByUserID = createdByUserId;
        }

        public static LicensesBusinessLayer FindLicense(int ID)
        {
            int applicationId = -1, driverId = -1, licenseClass = -1, createdByUserId = -1;
            DateTime issueDate = DateTime.Now, expirationDate = DateTime.Now;
            var paidFees = (decimal)0;
            var isActive = false;
            short issueReason = 0;
            var notes = "";

            if (LicensesDataAccessLayer.GetLicenseByID(ID, ref applicationId, ref driverId, ref licenseClass,
                    ref issueDate, ref expirationDate, ref notes, ref paidFees, ref isActive, ref issueReason,
                    ref createdByUserId))
            {
                return new LicensesBusinessLayer(ID, applicationId, driverId, licenseClass,
                    issueDate, expirationDate, notes, paidFees, isActive, issueReason, createdByUserId);
            }

            return null;
        }

        public static LicensesBusinessLayer FindLicenseByApplicationID(int ID)
        {
            int licenseID = -1, driverId = -1, licenseClass = -1, createdByUserId = -1;
            DateTime issueDate = DateTime.Now, expirationDate = DateTime.Now;
            var paidFees = (decimal)0;
            var isActive = false;
            short issueReason = 0;
            var notes = "";

            if (LicensesDataAccessLayer.GetLicenseByApplicationID(ref licenseID, ID, ref driverId, ref licenseClass,
                    ref issueDate, ref expirationDate, ref notes, ref paidFees, ref isActive, ref issueReason,
                    ref createdByUserId))
            {
                return new LicensesBusinessLayer(licenseID, ID, driverId, licenseClass,
                    issueDate, expirationDate, notes, paidFees, isActive, issueReason, createdByUserId);
            }

            return null;
        }

        private int _AddNewLicense()
        {
            return LicensesDataAccessLayer.AddNewLicense(Application.ApplicationId, DriverID, LicenseClass,
                IssueDate, ExpirationDate, Notes, PaidFees, IsActive, IssueReason, CreatedByUserID);
        }

        private bool _UpdateLicense()
        {
            return LicensesDataAccessLayer.UpdateLicense(LicenseID, IsActive);
        }

        public static bool HaveLicense(int ApplicationPersonID)
        {
            return LicensesDataAccessLayer.HaveLicense(ApplicationPersonID);
        }

        public static bool GetDriverID(int ApplicationPersonID, ref int driverID)
        {
            return LicensesDataAccessLayer.GetDriverID(ApplicationPersonID, ref driverID);
        }

        public bool Save()
        {
            if (LicenseID != -1) return _UpdateLicense();

            LicenseID = _AddNewLicense();
            return true;
        }

        public static DataTable GetLocalLicenses(int PersonID)
        {
            return LicensesDataAccessLayer.GetLocalLicenses(PersonID);
        }

        public static DataTable GetInternationalLicenses(int PersonID)
        {
            return LicensesDataAccessLayer.GetInternationalLicenses(PersonID);
        }

        public static int GetLicenseBYApplicationID(int ApplicationID)
        {
            return LicensesDataAccessLayer.GetLocalLicensesByApplicationID(ApplicationID);
        }

        public static int GetActiveLicenseIDByPersonID(int PersonID, int LicenseClassID)
        {
            return LicensesDataAccessLayer.GetActiveLicenseIDByPersonID(PersonID, LicenseClassID);
        }
    }
}