using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class CountryBusinessLayer
    {
        public int CountryID { get; set; }
        public string CountryName { get; set; }

        private CountryBusinessLayer(int countryId, string countryName)
        {
            CountryID = countryId;
            CountryName = countryName;
        }

        public static DataTable GetAllCountries()
        {
            return CountryDataAccessLayer.GetAllCountries();
        }

        public static CountryBusinessLayer FindCountry(int ID)
        {
            var countryName = "";
            return CountryDataAccessLayer.FindCountry(ID, ref countryName)
                ? new CountryBusinessLayer(ID, countryName)
                : null;
        }

        public static CountryBusinessLayer FindCountry(string countryName)
        {
            var countryId = -1;
            return CountryDataAccessLayer.FindCountry(ref countryId, countryName)
                ? new CountryBusinessLayer(countryId, countryName)
                : null;
        }
    }
}