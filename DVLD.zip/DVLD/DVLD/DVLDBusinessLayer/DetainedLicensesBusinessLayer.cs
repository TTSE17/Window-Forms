using System;
using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class DetainedLicensesBusinessLayer
    {
        public int DetainID { get; set; }
        public int LicenseID { get; set; }

        public LicensesBusinessLayer LicenseInfo;
        public DateTime DetainDate { get; set; }
        public decimal FineFees { get; set; }
        public int CreatedByUserID { get; set; }

        public UsersBusinessLayer UserInfo;
        public bool IsReleased { get; set; }
        public DateTime ReleaseDate { get; set; }
        public int ReleasedByUserID { get; set; }
        public int ReleaseApplicationID { get; set; }

        public DetainedLicensesBusinessLayer()
        {
            DetainID = LicenseID = CreatedByUserID = -1;
            LicenseInfo = new LicensesBusinessLayer();
            UserInfo = new UsersBusinessLayer();
        }

        private DetainedLicensesBusinessLayer(int detainId, int licenseId, DateTime detainDate, decimal fineFees,
            int createdByUserId, bool isReleased, DateTime releaseDate, int releasedByUserId, int releaseApplicationId)
        {
            DetainID = detainId;
            LicenseID = licenseId;
            LicenseInfo = LicensesBusinessLayer.FindLicense(LicenseID);
            DetainDate = detainDate;
            FineFees = fineFees;
            CreatedByUserID = createdByUserId;
            UserInfo = UsersBusinessLayer.FindUser(createdByUserId);
            IsReleased = isReleased;
            ReleaseDate = releaseDate;
            ReleasedByUserID = releasedByUserId;
            ReleaseApplicationID = releaseApplicationId;
        }

        public static DataTable GetAllDetainedLicenses()
        {
            return DetainedLicensesDataAccessLayer.GetAllDetainedLicenses();
        }

        public static DetainedLicensesBusinessLayer FindDetainedLicense(int detainId)
        {
            int licenseId = -1, createdByUserId = -1, releasedByUserId = -1, releaseApplicationId = -1;
            DateTime detainDate = DateTime.Now, releaseDate = DateTime.Now;
            var isReleased = false;
            decimal fineFees = 0;

            if (DetainedLicensesDataAccessLayer.GetDetainedLicenseByDetainedLicenseID(detainId, ref licenseId,
                    ref detainDate, ref fineFees, ref createdByUserId, ref isReleased, ref releaseDate,
                    ref releasedByUserId, ref releaseApplicationId))
                return new DetainedLicensesBusinessLayer(detainId, licenseId, detainDate, fineFees,
                    createdByUserId, isReleased, releaseDate, releasedByUserId, releaseApplicationId);

            return null;
        }

        public static DetainedLicensesBusinessLayer FindDetainedLicenseByLicenseID(int licenseId)
        {
            int detainId = -1, createdByUserId = -1, releasedByUserId = -1, releaseApplicationId = -1;
            DateTime detainDate = DateTime.Now, releaseDate = DateTime.Now;
            var isReleased = false;
            decimal fineFees = 0;

            if (DetainedLicensesDataAccessLayer.GetDetainedLicenseByLicenseID(ref detainId, licenseId,
                    ref detainDate, ref fineFees, ref createdByUserId, ref isReleased, ref releaseDate,
                    ref releasedByUserId, ref releaseApplicationId))
                return new DetainedLicensesBusinessLayer(detainId, licenseId, detainDate, fineFees,
                    createdByUserId, isReleased, releaseDate, releasedByUserId, releaseApplicationId);

            return null;
        }

        private int _AddNewUser()
        {
            return DetainedLicensesDataAccessLayer.AddNewDetainedLicense(LicenseID, DetainDate, FineFees,
                CreatedByUserID, IsReleased, ReleaseDate, ReleasedByUserID, ReleaseApplicationID);
        }

        private bool _UpdateUser()
        {
            return DetainedLicensesDataAccessLayer.UpdateDetainedLicense(DetainID, LicenseID, DetainDate, FineFees,
                CreatedByUserID, IsReleased, ReleaseDate, ReleasedByUserID, ReleaseApplicationID);
        }

        public bool Save()
        {
            if (DetainID != -1) return _UpdateUser();

            DetainID = _AddNewUser();
            return true;
        }

        public static bool IsDetained(int LicenseID)
        {
            return DetainedLicensesDataAccessLayer.IsDetained(LicenseID);
        }
    }
}