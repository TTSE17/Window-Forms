using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class TestTypesBusinessLayer
    {
        public int TestTypeId { get; set; }
        public string TestTypeTitle { get; set; }
        public string TestTypeDescription { get; set; }

        public decimal TestTypeFees { get; set; }


        public static DataTable GetTestTypes()
        {
            return TestTypesDataAccessLayer.GetTestTypes();
        }

        private TestTypesBusinessLayer(int testTypeId, string testTypeTitle, string testTypeDescription,
            decimal testTypeFees)
        {
            TestTypeId = testTypeId;
            TestTypeTitle = testTypeTitle;
            TestTypeDescription = testTypeDescription;
            TestTypeFees = testTypeFees;
        }

        public static TestTypesBusinessLayer FindTestType(int ID)
        {
            var TestTypeTitle = "";
            var TestTypeDescription = "";
            var TestTypeFees = (decimal)0.0;

            if (TestTypesDataAccessLayer.GetTestTypeByID(ID, ref TestTypeTitle, ref TestTypeDescription,
                    ref TestTypeFees))
                return new TestTypesBusinessLayer(ID, TestTypeTitle, TestTypeDescription, TestTypeFees);

            return null;
        }

        public bool UpdateTestType()
        {
            return TestTypesDataAccessLayer.UpdateTestType(TestTypeId, TestTypeTitle, TestTypeDescription,
                TestTypeFees);
        }
    }
}