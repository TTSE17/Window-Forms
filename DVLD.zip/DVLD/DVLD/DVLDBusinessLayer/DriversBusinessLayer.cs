using System;
using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class DriversBusinessLayer
    {
        public int DriverID { get; set; }
        public int PersonID { get; set; }

        public PersonBusinessLayer PersonInfo;
        public int CreatedByUserId { get; set; }
        public DateTime CreatedDate { get; set; }

        public DriversBusinessLayer()
        {
            DriverID = -1;
            PersonInfo = new PersonBusinessLayer();
        }

        private DriversBusinessLayer(int driverId, int personId, int createdByUserId, DateTime createdDate)
        {
            DriverID = driverId;
            PersonID = personId;
            PersonInfo = PersonBusinessLayer.FindPerson(personId);
            CreatedByUserId = createdByUserId;
            CreatedDate = createdDate;
        }

        public static DataTable GetAllDrivers()
        {
            return DriversDataAccessLayer.GetAllDrivers();
        }

        public static DriversBusinessLayer FindDriver(int ID)
        {
            var createdDate = DateTime.Now;

            int personId = -1, createdByUserId = -1;

            if (DriversDataAccessLayer.GetDriverByID(ID, ref personId, ref createdByUserId, ref createdDate))
                return new DriversBusinessLayer(ID, personId, createdByUserId, createdDate);

            return null;
        }

        private int _AddNewDriver()
        {
            return DriversDataAccessLayer.AddNewDriver(PersonID, CreatedByUserId, CreatedDate);
        }

        private bool _UpdateDriver()
        {
            return DriversDataAccessLayer.UpdateDriver(DriverID, PersonID, CreatedByUserId, CreatedDate);
        }

        public bool Save()
        {
            if (this.DriverID != -1) return _UpdateDriver();

            DriverID = _AddNewDriver();
            return true;
        }
    }
}