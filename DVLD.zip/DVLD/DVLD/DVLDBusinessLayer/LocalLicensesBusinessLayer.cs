using System.Data;
using System.Windows.Forms;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class LocalLicensesBusinessLayer
    {
        public int LocalDrivingLicenseApplicationID { get; set; }
        public ApplicationsBusinessLayer Application { get; set; }
        public int LicenseClassId { get; set; }

        public LicenseClassesBusinessLayer LicenseClassInfo;

        public LocalLicensesBusinessLayer()
        {
            LocalDrivingLicenseApplicationID = -1;
            Application = new ApplicationsBusinessLayer();
            LicenseClassInfo = new LicenseClassesBusinessLayer();
        }

        private LocalLicensesBusinessLayer(int localDrivingLicenseApplicationId,
            ApplicationsBusinessLayer application, int licenseClassId)
        {
            LocalDrivingLicenseApplicationID = localDrivingLicenseApplicationId;
            Application = application;
            LicenseClassId = licenseClassId;
            LicenseClassInfo = LicenseClassesBusinessLayer.FindLicenseClass(licenseClassId);
        }

        public static DataTable GetAllLocalLicensesApplications()
        {
            return LocalLicensesDataAccessLayer.GetAllLocalLicensesApplications();
        }

        public static LocalLicensesBusinessLayer FindLocalLicense(int ID)
        {
            var ApplicationID = -1;
            var LicenseClassId = -1;
            ApplicationsBusinessLayer Application = null;

            if (LocalLicensesDataAccessLayer.GetLocalLicenseByID(ID, ref ApplicationID, ref LicenseClassId))
            {
                Application = ApplicationsBusinessLayer.FindApplication(ApplicationID);

                return new LocalLicensesBusinessLayer(ID, Application, LicenseClassId);
            }

            return null;
        }

        public static int IsFoundApplication(int PersonID, int LicenseClassID)
        {
            return LocalLicensesDataAccessLayer.IsFoundApplication(PersonID, LicenseClassID);
        }

        private int _AddNewLocalLicense()
        {
            return LocalLicensesDataAccessLayer.AddNewLocalLicenseApplication(Application.ApplicationId,
                LicenseClassId);
        }

        private bool _UpdateLocalLicense()
        {
            return LocalLicensesDataAccessLayer.UpdateLocalLicenseApplication(LocalDrivingLicenseApplicationID,
                Application.ApplicationId, LicenseClassId);
        }

        public bool Save()
        {
            if (LocalDrivingLicenseApplicationID != -1) return _UpdateLocalLicense();

            LocalDrivingLicenseApplicationID = _AddNewLocalLicense();
            return true;
        }

        public static bool CancelLocalDrivingLicenseApplication(int ID)
        {
            var LocalApplication = FindLocalLicense(ID);
            LocalApplication.Application.ApplicationStatus = 2;

            return LocalApplication.Application.Save();
        }

        public bool Delete()
        {
            bool IsLocalDrivingApplicationDeleted = false;
            bool IsApplicationDeleted = false;

            IsLocalDrivingApplicationDeleted =
                LocalLicensesDataAccessLayer.DeleteLocalLicenseApplication(LocalDrivingLicenseApplicationID);

            if (!IsLocalDrivingApplicationDeleted)
                return false;

            IsApplicationDeleted = ApplicationsBusinessLayer.Delete(Application.ApplicationId);
            return IsApplicationDeleted;
        }

        public static int GetPassedTestCount(int ID)
        {
            return LocalLicensesDataAccessLayer.GetPassedTestCount(ID);
        }

        public int GetActiveLicenseID()
        {
            //this will get the license id that belongs to this application
            return LicensesBusinessLayer.GetActiveLicenseIDByPersonID(Application.ApplicationPersonID, LicenseClassId);
        }

        public byte TotalTrialsPerTest(int TestTypeID)
        {
            return LocalLicensesDataAccessLayer.TotalTrialsPerTest(LocalDrivingLicenseApplicationID, TestTypeID);
        }
    }
}