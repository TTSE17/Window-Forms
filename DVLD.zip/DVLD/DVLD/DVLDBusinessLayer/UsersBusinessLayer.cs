using System.Data;
using DVLDDataAccessLayer;

namespace DVLDBusinessLayer
{
    public class UsersBusinessLayer
    {
        public int UserID { get; set; }
        public int PersonId { get; set; }

        public PersonBusinessLayer PersonInfo;
        public string Username { get; set; }
        public string Password { get; set; }
        public bool IsActive { get; set; }
        
        public UsersBusinessLayer()
        {
            UserID = -1;
            PersonInfo = new PersonBusinessLayer();
        }

        private UsersBusinessLayer(int userId, int personId, string username, string password, bool isActive)
        {
            UserID = userId;
            PersonId = personId;
            PersonInfo = PersonBusinessLayer.FindPerson(personId);
            Username = username;
            Password = password;
            IsActive = isActive;
        }

        public static DataTable GetAllUsers()
        {
            return UsersDataAccessLayer.GetAllUsers();
        }

        public static bool IsUserNameExist(string Username)
        {
            return UsersDataAccessLayer.IsUserNameExist(Username);
        }

        public static bool IsPersonRelatedToUser(int PersonID)
        {
            return UsersDataAccessLayer.IsPersonRelatedToUser(PersonID);
        }

        public static bool IsFound(string UserName, string Password)
        {
            return UsersDataAccessLayer.IsFound(UserName, Password);
        }

        public static UsersBusinessLayer FindUser(int ID)
        {
            string UserName = "", Password = "";
            var PersonID = -1;
            var Acitve = false;

            if (UsersDataAccessLayer.GetUserByID(ID, ref PersonID, ref UserName, ref Password, ref Acitve))
                return new UsersBusinessLayer(ID, PersonID, UserName, Password, Acitve);

            return null;
        }

        public static UsersBusinessLayer FindUser(string Username)
        {
            var Password = "";

            int UserID = -1, PersonID = -1;
            var Acitve = false;

            if (UsersDataAccessLayer.GetUserByUsername(ref UserID, ref PersonID, Username, ref Password, ref Acitve))
                return new UsersBusinessLayer(UserID, PersonID, Username, Password, Acitve);

            return null;
        }

        private int _AddNewUser()
        {
            return UsersDataAccessLayer.AddNewUser(PersonId, Username, Password, IsActive);
        }

        private bool _UpdateUser()
        {
            return UsersDataAccessLayer.UpdateUser(UserID, PersonId, Username, Password, IsActive);
        }

        public bool Save()
        {
            if (this.UserID != -1) return _UpdateUser();

            UserID = _AddNewUser();
            return true;
        }

        public static bool DeleteUser(int ID)
        {
            return UsersDataAccessLayer.DeleteUser(ID);
        }
    }
}