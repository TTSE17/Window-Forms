using System;
using System.Windows.Forms;

namespace DVLD.LocalLicenses
{
    public partial class LocalDrivingLicenseApplicationInfoScreen : Form
    {
        private readonly int _LocalLicenseID;

        public LocalDrivingLicenseApplicationInfoScreen(int localLicenseId)
        {
            InitializeComponent();
            _LocalLicenseID = localLicenseId;
        }

        private void LocalDrivingLicenseApplicationInfoScreen_Load(object sender, EventArgs e)
        {
            ctrlLocalLicenseApplicationDetails1.LoadLocalLicenseInfo(_LocalLicenseID);
        }
    }
}