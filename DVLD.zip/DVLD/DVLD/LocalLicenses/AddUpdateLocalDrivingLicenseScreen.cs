using System;
using System.Data;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.LocalLicenses
{
    public partial class AddUpdateLocalDrivingLicenseScreen : Form
    {
        private int _LocalLicenseID;
        private LocalLicensesBusinessLayer _LocalLicense1;

        public AddUpdateLocalDrivingLicenseScreen(int localLicenseId = -1)
        {
            InitializeComponent();
            _LocalLicenseID = localLicenseId;
        }

        private void AddUpdateLocalDrivingLicenseScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            LoadLicenseClasses();

            if (_LocalLicenseID == -1)
            {
                _LocalLicense1 = new LocalLicensesBusinessLayer();

                lblTitleForm.Text = "New Local Driving License Application";
                Text = "New Local Driving License Application";

                lbLocalLicenseID.Text = "[ ???? ]";
                lblApplicationDate.Text = DateTime.Now.ToShortDateString();
                cbLicenseClass.SelectedIndex = 1;
                lblApplicationFees.Text = Convert.ToString(ApplicationTypesBusinessLayer.FindApplicationType(
                    (int)ApplicationsBusinessLayer.enApplicationType.NewDrivingLicense).ApplicationFees);
                lblCreatedByUser.Text = clsGlobal.CurrentUser.Username;
            }

            else
            {
                _LocalLicense1 = LocalLicensesBusinessLayer.FindLocalLicense(_LocalLicenseID);

                lblTitleForm.Text = "Update Local Driving License Application";
                this.Text = "Update Local Driving License Application";

                ctrlSelectPerson1.LoadPersonInfo(Convert.ToString(_LocalLicense1.Application.ApplicationPersonID));

                lbLocalLicenseID.Text = Convert.ToString(_LocalLicenseID);
                lblApplicationDate.Text = _LocalLicense1.Application.ApplicationDate.ToString("dd/MMM/yyyy");
                cbLicenseClass.SelectedIndex = cbLicenseClass.FindString(_LocalLicense1.LicenseClassInfo.ClassName);
                lblApplicationFees.Text = Convert.ToString(_LocalLicense1.Application.PaidFees);
                lblCreatedByUser.Text = (_LocalLicense1.Application.UserInfo.Username);
            }
        }

        private void LoadLicenseClasses()
        {
            DataTable dt = LicenseClassesBusinessLayer.GetAllLicenseClasses();

            foreach (DataRow Row in dt.Rows)
            {
                cbLicenseClass.Items.Add(Convert.ToString(Row[1]));
            }
        }

        private bool CheckMoving()
        {
            var PersonID = ctrlSelectPerson1.PersonID();

            return (PersonID != -1);
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (CheckMoving()) return;

            e.Cancel = true;
            MessageBox.Show("Select Person");
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (CheckMoving())
                tabControl1.SelectedIndex = 1;

            else
                MessageBox.Show("Select Person");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var PersonID = ctrlSelectPerson1.PersonID();
            var LicenseClass = cbLicenseClass.SelectedIndex;

            if (PersonID == -1 || LicenseClass == -1)
            {
                MessageBox.Show("Enter Requirements");
                return;
            }

            var LicenseClassID = LicenseClassesBusinessLayer.FindLicenseClass(cbLicenseClass.Text).LicenseClassID;

            var ActiveApplicationID = LocalLicensesBusinessLayer.IsFoundApplication(PersonID, LicenseClassID);

            if (ActiveApplicationID != -1)
            {
                MessageBox.Show(
                    "Choose another License Class, the selected Person Already have an active application for the selected class with id=" +
                    ActiveApplicationID, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

                cbLicenseClass.Focus();
                return;
            }

            lblTitleForm.Text = "Update Local Driving License Application";
            Text = "Update Local Driving License Application";

            _LocalLicense1.Application.ApplicationPersonID = PersonID;

            if (_LocalLicenseID == -1)
            {
                _LocalLicense1.Application.ApplicationDate = DateTime.Now;
                _LocalLicense1.Application.ApplicationStatus = 1;
                _LocalLicense1.Application.LastStatusDate = DateTime.Now;
            }

            _LocalLicense1.Application.ApplicationTypeID = 1;
            _LocalLicense1.LicenseClassId = LicenseClassID;
            _LocalLicense1.Application.PaidFees = Convert.ToDecimal(lblApplicationFees.Text);
            _LocalLicense1.Application.CreatedByUserId = clsGlobal.CurrentUser.UserID;

            MessageBox.Show(_LocalLicense1.Application.Save()
                ? "Data Saved Successfully. Application" + _LocalLicense1.Application.ApplicationId
                : "Error: Data Is not Saved Successfully.");

            MessageBox.Show(_LocalLicense1.Save()
                ? "Data Saved Successfully. _LocalLicense1"
                : "Error: Data Is not Saved Successfully.");

            lbLocalLicenseID.Text = Convert.ToString(_LocalLicense1.LocalDrivingLicenseApplicationID);

            _LocalLicenseID = _LocalLicense1.LocalDrivingLicenseApplicationID;
        }
    }
}