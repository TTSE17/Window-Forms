using System.ComponentModel;

namespace DVLD.LocalLicenses
{
    partial class LocalDrivingLicenseApplicationInfoScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ctrlLocalLicenseApplicationDetails1 = new DVLD.Controls.ctrlLocalLicenseApplicationDetails();
            this.SuspendLayout();
            // 
            // ctrlLocalLicenseApplicationDetails1
            // 
            this.ctrlLocalLicenseApplicationDetails1.Location = new System.Drawing.Point(12, 12);
            this.ctrlLocalLicenseApplicationDetails1.Name = "ctrlLocalLicenseApplicationDetails1";
            this.ctrlLocalLicenseApplicationDetails1.Size = new System.Drawing.Size(687, 355);
            this.ctrlLocalLicenseApplicationDetails1.TabIndex = 0;
            // 
            // LocalDrivingLicenseApplicationInfoScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 366);
            this.Controls.Add(this.ctrlLocalLicenseApplicationDetails1);
            this.Name = "LocalDrivingLicenseApplicationInfoScreen";
            this.Text = "LocalDrivingLicenseApplicationInfoScreen";
            this.Load += new System.EventHandler(this.LocalDrivingLicenseApplicationInfoScreen_Load);
            this.ResumeLayout(false);
        }

        private DVLD.Controls.ctrlLocalLicenseApplicationDetails ctrlLocalLicenseApplicationDetails1;

        #endregion
    }
}