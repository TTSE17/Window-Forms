using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using DVLD.Appointments;
using DVLD.Licenses;
using DVLDBusinessLayer;

namespace DVLD.LocalLicenses
{
    public partial class LocalLicensesApplicationsScreen : Form
    {
        private DataTable _DataTable;

        private int _LocalDrivingLicenseApplicationID = -1;
        private LocalLicensesBusinessLayer _LocalLicense1;

        public LocalLicensesApplicationsScreen()
        {
            InitializeComponent();
        }

        private void LocalLicensesApplicationsScreen_Load(object sender, EventArgs e)
        {
            RefreshData();

            if (GridViewLocalLicensesList.Rows.Count <= 0) return;
            GridViewLocalLicensesList.Columns[0].Width = 131;
            GridViewLocalLicensesList.Columns[1].Width = 99;
            GridViewLocalLicensesList.Columns[2].Width = 79;
            GridViewLocalLicensesList.Columns[3].Width = 219;
            GridViewLocalLicensesList.Columns[4].Width = 199;
            GridViewLocalLicensesList.Columns[5].Width = 111;
            GridViewLocalLicensesList.Columns[6].Width = 99;
        }

        private void RefreshData()
        {
            _DataTable = LocalLicensesBusinessLayer.GetAllLocalLicensesApplications();

            comboBox1.SelectedIndex = 0;

            LoadData();
        }

        private void LoadData(string Type = "LocalDrivingLicenseApplicationID", string Text = "")
        {
            var EmployeesDataView1 = _DataTable.DefaultView;

            try
            {
                EmployeesDataView1.RowFilter =
                    Text == "" ? null :
                    Type != "LocalDrivingLicenseApplicationID" ? $"{Type} LIKE '{Text}%'" : $"{Type} = '{Text}'";
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                EmployeesDataView1.RowFilter = null;
            }

            GridViewLocalLicensesList.DataSource = EmployeesDataView1;

            lblRecords.Text = Convert.ToString(GridViewLocalLicensesList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            Type = Type == "ID"
                ? "LocalDrivingLicenseApplicationID"
                : (Type == "DrivingClass" ? "ClassName" : Type);

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.Focus();
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            var fr = new AddUpdateLocalDrivingLicenseScreen();
            fr.ShowDialog();
            RefreshData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            var Status = Convert.ToString(GridViewLocalLicensesList.CurrentRow.Cells[6].Value);

            var PassedTest = Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[5].Value);

            if (Status == "Completed" || Status == "Cancelled")
            {
                editApplicationToolStripMenuItem.Enabled = deleteApplicationToolStripMenuItem.Enabled =
                    cancelApplicationToolStripMenuItem.Enabled = issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled =
                        ScheduleToolStripMenuItem.Enabled = false;
            }

            else
            {
                editApplicationToolStripMenuItem.Enabled = deleteApplicationToolStripMenuItem.Enabled =
                    cancelApplicationToolStripMenuItem.Enabled = true;

                ScheduleToolStripMenuItem.Enabled = PassedTest != 3;
            }

            showLicenseToolStripMenuItem.Enabled = (Status == "Completed");

            issueDrivingLicenseFirstTimeToolStripMenuItem.Enabled = (PassedTest == 3 && Status == "New");
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            var fr = new LocalDrivingLicenseApplicationInfoScreen(_LocalDrivingLicenseApplicationID);
            fr.ShowDialog();

            RefreshData();
        }

        private void editApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            var fr = new AddUpdateLocalDrivingLicenseScreen(_LocalDrivingLicenseApplicationID);
            fr.ShowDialog();

            RefreshData();
        }

        private void deleteApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to delete [" + _LocalDrivingLicenseApplicationID + "]",
                    "Confirm Delete", MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (_LocalLicense1.Delete())
            {
                MessageBox.Show("Application Deleted Successfully.", "Deleted", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                RefreshData();
            }
            else
            {
                MessageBox.Show("Could not delete applicatoin, other data depends on it.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cancelApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            if (MessageBox.Show("Are you sure you want to Cancel Local Driving License Application [" +
                                _LocalDrivingLicenseApplicationID + "]",
                    "Confirm Cancel", MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (LocalLicensesBusinessLayer.CancelLocalDrivingLicenseApplication(_LocalDrivingLicenseApplicationID))
                MessageBox.Show("Cancelling Successfully");

            RefreshData();
        }

        private void ScheduleToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            var PassedTest = Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[5].Value);

            switch (PassedTest)
            {
                case 0:
                    scheduleVisionTestToolStripMenuItem.Enabled = true;
                    scheduleWritingTestToolStripMenuItem.Enabled = false;
                    scheduleStreetTestToolStripMenuItem.Enabled = false;
                    break;

                case 1:
                    scheduleVisionTestToolStripMenuItem.Enabled = false;
                    scheduleWritingTestToolStripMenuItem.Enabled = true;
                    scheduleStreetTestToolStripMenuItem.Enabled = false;
                    break;

                case 2:
                    scheduleVisionTestToolStripMenuItem.Enabled = false;
                    scheduleWritingTestToolStripMenuItem.Enabled = false;
                    scheduleStreetTestToolStripMenuItem.Enabled = true;
                    break;

                default:
                    scheduleVisionTestToolStripMenuItem.Enabled = scheduleWritingTestToolStripMenuItem.Enabled =
                        scheduleStreetTestToolStripMenuItem.Enabled = false;
                    break;
            }
        }

        private void scheduleTestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            var TestTypeID = Convert.ToInt32(((ToolStripItem)sender).Tag);

            var fr = new TestAppointmentsScreen(_LocalDrivingLicenseApplicationID, TestTypeID);
            fr.ShowDialog();

            RefreshData();
        }

        private void issueDrivingLicenseFirstTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            var fr = new IssueDrivingLicenseScreen(_LocalDrivingLicenseApplicationID);
            fr.ShowDialog();

            RefreshData();
        }

        private void showLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            var _LicenseID = _LocalLicense1.GetActiveLicenseID();

            var fr = new LicenseInfoScreen(_LicenseID);
            fr.ShowDialog();
        }

        private void showLicensePersonHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateLocalLicenseInfo(Convert.ToInt32(GridViewLocalLicensesList.CurrentRow.Cells[0].Value));

            var PersonID = _LocalLicense1.Application.ApplicationPersonID;

            var fr = new LicensesHistoryScreen(PersonID);
            fr.ShowDialog();

            RefreshData();
        }

        private void UpdateLocalLicenseInfo(int ID)
        {
            _LocalDrivingLicenseApplicationID = Convert.ToInt32(ID);
            _LocalLicense1 = LocalLicensesBusinessLayer.FindLocalLicense(_LocalDrivingLicenseApplicationID);
        }
    }
}