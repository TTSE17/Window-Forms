using System;
using System.Windows.Forms;
using DVLD.Licenses;
using DVLD.People;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlLocalLicenseApplicationDetails : UserControl
    {
        private int _LocalLicenseID;
        private LocalLicensesBusinessLayer _LocalLicense1;

        private int _LicenseID;

        public ctrlLocalLicenseApplicationDetails()
        {
            InitializeComponent();
        }

        public void LoadLocalLicenseInfo(int LocalLicenseID)
        {
            _LocalLicenseID = LocalLicenseID;
            LoadData();
        }

        private void LoadData()
        {
            _LocalLicense1 = LocalLicensesBusinessLayer.FindLocalLicense(_LocalLicenseID);

            if (_LocalLicense1 == null) return;

            _LicenseID = _LocalLicense1.GetActiveLicenseID();
            llShowLicenceInfo.Enabled = (_LicenseID != -1);

            lblLocalDrivingLicenseApplicationID.Text = Convert.ToString(_LocalLicenseID);
            lblAppliedFor.Text = (_LocalLicense1.LicenseClassInfo.ClassName);
            lblPassedTests.Text = LocalLicensesBusinessLayer.GetPassedTestCount(_LocalLicenseID) + "/3";
            lblApplicationID.Text = Convert.ToString(_LocalLicense1.Application.ApplicationId);
            lblDate.Text = _LocalLicense1.Application.ApplicationDate.ToString("dd/MMM/yyyy");
            lblStatus.Text = GetStatus(_LocalLicense1.Application.ApplicationStatus);
            lblStatusDate.Text = _LocalLicense1.Application.LastStatusDate.ToString("dd/MMM/yyyy");
            lblFees.Text = Convert.ToString(_LocalLicense1.Application.PaidFees);
            lblCreatedByUser.Text = (_LocalLicense1.Application.UserInfo.Username);
            lblType.Text = ApplicationTypesBusinessLayer.FindApplicationType
                (_LocalLicense1.Application.ApplicationTypeID).ApplicationTypeTitle;
            lblApplicant.Text = (_LocalLicense1.Application.PersonInfo.FullName());
        }

        private static string GetStatus(int Status)
        {
            return (Status == 1) ? "New" : (Status == 2 ? "Cancelled" : "Completed");
        }

        private void llShowLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            // var _LicenseID = LicensesBusinessLayer.GetLicenseBYApplicationID(_LocalLicense1.Application.ApplicationId);

            var fr = new LicenseInfoScreen(_LicenseID);

            fr.ShowDialog();
        }

        private void llViewPersonInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new PersonCardDetailsScreen(_LocalLicense1.Application.ApplicationPersonID);
            fr.ShowDialog();
            LoadData();
        }
    }
}