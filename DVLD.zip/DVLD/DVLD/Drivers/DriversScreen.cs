using System;
using System.Data;
using System.Windows.Forms;
using DVLD.Licenses;
using DVLD.People;
using DVLDBusinessLayer;

namespace DVLD.Drivers
{
    public partial class DriversScreen : Form
    {
        public DriversScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private void DriversScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = DriversBusinessLayer.GetAllDrivers();

            comboBox1.SelectedIndex = 0;

            LoadData();
        }

        private void LoadData(string Type = "DriverID", string Text = "")
        {
            var EmployeesDataView1 = _DataTable.DefaultView;

            var DataFilter = "";
            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "DriverID" || Type == "PersonID")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";
                
                EmployeesDataView1.RowFilter = DataFilter;            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                EmployeesDataView1.RowFilter = null;
            }

            GridViewDriversList.DataSource = EmployeesDataView1;

            lblRecords.Text = Convert.ToString(GridViewDriversList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }

        private void toolStripSeparator2_Click(object sender, EventArgs e)
        {
            var PersonID = Convert.ToInt32(GridViewDriversList.CurrentRow.Cells[1].Value);
            var frm = new PersonCardDetailsScreen(PersonID);
            frm.ShowDialog();
        }

        private void issueInternationalLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void showPersonLicenseHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var PersonID = Convert.ToInt32(GridViewDriversList.CurrentRow.Cells[1].Value);
            
            var frm = new LicensesHistoryScreen(PersonID);
            frm.ShowDialog();   
        }
    }
}