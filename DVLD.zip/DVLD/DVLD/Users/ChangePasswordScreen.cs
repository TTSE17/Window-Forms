using System;
using System.ComponentModel;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Users
{
    public partial class ChangePasswordScreen : Form
    {
        private readonly int _UserID;
        private UsersBusinessLayer _User1;

        public ChangePasswordScreen(int UserID)
        {
            InitializeComponent();

            _UserID = UserID;
        }

        private void ChangePasswordScreen_Load(object sender, EventArgs e)
        {
            ctrlUserCard1.LoadUserInfo(_UserID);
            _User1 = UsersBusinessLayer.FindUser(_UserID);

            txtCurrentPassword.Focus();
        }

        private void txtCurrentPassword_Validating(object sender, CancelEventArgs e)
        {
            var CuurentPassword = txtCurrentPassword.Text.Trim();

            errorProvider1.SetError(txtCurrentPassword, (CuurentPassword != _User1.Password) ? "Wrong Password" : "");
        }

        private void txtConfirmPassword_Leave(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtConfirmPassword,
                txtNewPassword.Text != txtConfirmPassword.Text ? "Same Password!" : "");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var CurrentPassword = txtCurrentPassword.Text.Trim();
            var NewPassword = txtNewPassword.Text.Trim();
            var ConfirmPassword = txtConfirmPassword.Text.Trim();

            if (string.IsNullOrEmpty(CurrentPassword) || errorProvider1.GetError(txtCurrentPassword) != "" ||
                string.IsNullOrEmpty(NewPassword) || string.IsNullOrEmpty(ConfirmPassword) ||
                errorProvider1.GetError(txtConfirmPassword) != "")
            {
                MessageBox.Show("Enter Requirements");
                return;
            }

            _User1.Password = NewPassword;

            MessageBox.Show(_User1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");
        }
    }
}