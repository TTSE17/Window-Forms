using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Users
{
    public partial class UsersScreen : Form
    {
        public UsersScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;

        private void UsersScreen_Load(object sender, EventArgs e)
        {
            RefreshData();

            if (GridViewUsersList.Columns.Count <= 0) return;
            GridViewUsersList.Columns[0].Width = 71;
            GridViewUsersList.Columns[1].Width = 71;
            GridViewUsersList.Columns[2].Width = 155;
            GridViewUsersList.Columns[3].Width = 99;
            GridViewUsersList.Columns[4].Width = 79;
            GridViewUsersList.Columns[5].Width = 71;
        }

        private void RefreshData()
        {
            _DataTable = UsersBusinessLayer.GetAllUsers();

            comboBox1.SelectedIndex = cbActive.SelectedIndex = 0;

            LoadData();
        }

        private void LoadData(string Type = "UserID", string Text = "")
        {
            var EmployeesDataView1 = _DataTable.DefaultView;

            var DataFilter = "";

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "UserID" || Type == "PersonID" || Type == "IsActive")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";
                EmployeesDataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                EmployeesDataView1.RowFilter = null;
            }

            GridViewUsersList.DataSource = EmployeesDataView1;

            lblRecords.Text = Convert.ToString(GridViewUsersList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsActiveChoice = comboBox1.SelectedIndex == 4;

            textBox1.Visible = !IsActiveChoice;
            cbActive.Visible = IsActiveChoice;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbActive_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbActive.SelectedItem);

            var IsActiveValue = Selection == "All" ? "" : (Selection == "Yes" ? "true" : "false");

            LoadData("IsActive", IsActiveValue);
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            var fr = new AddUpdateUserScreen();
            fr.ShowDialog();
            RefreshData();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var UserID = Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value);
            Form fr = new AddUpdateUserScreen(UserID);
            fr.ShowDialog();

            // RefreshData();
            UsersScreen_Load(null, null);
        }

        private void showDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var UserID = Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value);
            var fr = new UserCardDetailsScreen(UserID);
            fr.ShowDialog();

            RefreshData();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var UserID = Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value);
            var fr = new ChangePasswordScreen(UserID);
            fr.ShowDialog();
            RefreshData();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var UserID = Convert.ToInt32(GridViewUsersList.CurrentRow.Cells[0].Value);

            if (MessageBox.Show("Are you sure you want to delete User [" + UserID + "]",
                    "Confirm Delete", MessageBoxButtons.OKCancel) != DialogResult.OK)
                return;

            if (UsersBusinessLayer.DeleteUser(UserID))
            {
                MessageBox.Show("User has been deleted successfully", "Deleted", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                RefreshData();
            }
            else
            {
                MessageBox.Show("User is not delted due to data connected to it.", "Faild", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = GridViewUsersList.Rows.Count <= 0;
        }
    }
}