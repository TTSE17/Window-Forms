using System;
using System.Windows.Forms;

namespace DVLD.Users
{
    public partial class UserCardDetailsScreen : Form
    {
        private readonly int _UserID;

        public UserCardDetailsScreen(int UserID)
        {
            InitializeComponent();

            _UserID = UserID;
        }

        private void UserCardDetailsScreen_Load(object sender, EventArgs e)
        {
            ctrlUserCard1.LoadUserInfo(_UserID);
        }
    }
}