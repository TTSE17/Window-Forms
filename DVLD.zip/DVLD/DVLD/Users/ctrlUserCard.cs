using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlUserCard : UserControl
    {
        private int _UserID;
        private UsersBusinessLayer _User1;

        public ctrlUserCard()
        {
            InitializeComponent();
        }

        public void LoadUserInfo(int UserID)
        {
            _UserID = UserID;
            LoadData();
        }

        private void LoadData()
        {
            _User1 = UsersBusinessLayer.FindUser(_UserID);

            if (_User1 == null) return;

            lblUserID.Text = Convert.ToString(_User1.UserID);
            lblUsername.Text = _User1.Username;
            lblActive.Text = (_User1.IsActive) ? "Yes" : "No";

            ctrlPersonCardDetails1.LoadPersonInfo(_User1.PersonId);
        }

    }
}