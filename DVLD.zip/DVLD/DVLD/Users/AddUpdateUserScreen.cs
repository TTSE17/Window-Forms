using System;
using System.Windows.Forms;
using DVLD.People;
using DVLDBusinessLayer;

namespace DVLD.Users
{
    public partial class AddUpdateUserScreen : Form
    {
        private int _UserID;
        private UsersBusinessLayer _User1;

        public AddUpdateUserScreen(int UserID = -1)
        {
            InitializeComponent();

            _UserID = UserID;
        }

        private void AddUpdateUserScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            // tpLoginInfo.Enabled = false;
            if (_UserID == -1)
            {
                _User1 = new UsersBusinessLayer();
                lblTitleForm.Text = "Add New User";
                Text = "Add New User";
                lblUserID.Text = "[ ???? ]";
            }

            else
            {
                gbPerson.Enabled = false;

                _User1 = UsersBusinessLayer.FindUser(_UserID);

                lblTitleForm.Text = "Update User";
                Text = "Update User";

                lblUserID.Text = Convert.ToString(_UserID);
                txtUserName.Text = _User1.Username;
                txtPassword.Text = "";
                txtConfirmPassword.Text = "";
                cbIsActive.Checked = (_User1.IsActive);

                ctrlPersonCardDetails1.LoadPersonInfo(_User1.PersonId);
            }
        }

        private void btnSelectPerson_Click(object sender, EventArgs e)
        {
            SelectPersonScreen fr = new SelectPersonScreen();

            fr.DataBack += DataBackPersonID; // Subscribe to the event

            fr.ShowDialog();
        }

        private void DataBackPersonID(int ID)
        {
            ctrlPersonCardDetails1.LoadPersonInfo(ID);
        }

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            if (CheckMoving()) return;

            e.Cancel = true;
            MessageBox.Show("Select Person");
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (CheckMoving())
                tabControl1.SelectedIndex = 1;

            else
                MessageBox.Show("Select Person");
        }

        private bool CheckMoving()
        {
            var PersonID = ctrlPersonCardDetails1.GetPersonID();

            return (PersonID != -1);
        }

        private void txtUserName_TextChanged(object sender, EventArgs e)
        {
            var Username = txtUserName.Text.Trim();

            if (_User1 != null && _User1.Username.ToLower() == Username.ToLower())
            {
                errorProvider1.SetError(txtUserName, "");

                return;
            }

            errorProvider1.SetError(txtUserName, UsersBusinessLayer.IsUserNameExist(Username) ? "Enter Another" : "");
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtConfirmPassword,
                txtPassword.Text != txtConfirmPassword.Text ? "Same Password!" : "");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var PersonID = ctrlPersonCardDetails1.GetPersonID();
            var Username = txtUserName.Text.Trim();
            var Password = txtPassword.Text.Trim();
            var ConfirmPassword = txtConfirmPassword.Text.Trim();
            var Active = cbIsActive.Checked;

            if (PersonID == -1 || string.IsNullOrEmpty(Username) || errorProvider1.GetError(txtUserName) != "" ||
                string.IsNullOrEmpty(Password) || string.IsNullOrEmpty(ConfirmPassword) ||
                errorProvider1.GetError(txtConfirmPassword) != "")
            {
                MessageBox.Show("Enter Requirements");
                return;
            }

            lblTitleForm.Text = "Update User";

            _User1.PersonId = PersonID;
            _User1.Username = Username;
            _User1.Password = clsGlobal.Hash(Password);
            _User1.IsActive = Active;

            MessageBox.Show(_User1.Save() ? "Data Saved Successfully." : "Error: Data Is not Saved Successfully.");

            lblUserID.Text = Convert.ToString(_User1.UserID);

            _UserID = _User1.UserID;
        }
        
    }
}