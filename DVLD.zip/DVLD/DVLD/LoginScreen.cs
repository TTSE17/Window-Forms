using System;
using System.IO;
using System.Windows.Forms;
using DVLD.Users;
using DVLDBusinessLayer;
using Microsoft.Win32;

namespace DVLD
{
    public partial class LoginScreen : Form
    {
        public LoginScreen()
        {
            InitializeComponent();
            RestoreData();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var UserName = txtUserName.Text.Trim();
            var Password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(UserName) || string.IsNullOrEmpty(Password))
            {
                MessageBox.Show("Enter Username, Password !");
                return;
            }

            // clsGlobal.Hash(Password)
            if (UsersBusinessLayer.IsFound(UserName, Password))
            {
                var User1 = UsersBusinessLayer.FindUser(UserName);

                if (!User1.IsActive)
                {
                    txtUserName.Focus();
                    MessageBox.Show("Your account is not Active, Contact Admin.", "In Active Account",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                clsGlobal.CurrentUser = User1;

                UpdateFileRememberMe(chkRememberMe.Checked);

                Hide();
                var fr = new MainMenuScreen();
                fr.ShowDialog();

                Show();
            }

            else
            {
                txtUserName.Focus();

                MessageBox.Show("Invalid Username/Password.", "Wrong Credintials",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateFileRememberMe(bool Remember)
        {
            // File.WriteAllText(
            //     @"C:\Users\Taha\Documents\ProgrammingAdvices\18 - C# & Database Connectivity\Projects\DVLD\Remember.txt",
            //     "");

            var keyPath = @"HKEY_Current_User\SOFTWARE\YourSoftware"; // An error occurred: is denied
            var valueName = "Remember";
            string valueData = "";

            if (Remember)
            {
                // File.WriteAllText(
                //     @"C:\Users\Taha\Documents\ProgrammingAdvices\18 - C# & Database Connectivity\Projects\DVLD\Remember.txt",
                //     clsGlobal.CurrentUser.Username + "#//#" + clsGlobal.CurrentUser.Password);

                valueData = clsGlobal.CurrentUser.Username + "#//#" + txtPassword.Text;
            }

            try
            {
                Registry.SetValue(keyPath, valueName, valueData, RegistryValueKind.String);
            }
            catch (Exception e)
            {
            }

            txtUserName.Text = txtPassword.Text = "";
        }

        public void RestoreData()
        {
            // var fs = File.OpenRead(
            //     @"C:\Users\Taha\Documents\ProgrammingAdvices\18 - C# & Database Connectivity\Projects\DVLD\Remember.txt");
            // var fr = new StreamReader(fs);
            //
            // chkRememberMe.Checked = false;
            //
            // var line = "";
            // while ((line = fr.ReadLine()) != null)
            // {
            //     var vUserData = line.Split(new string[] { "#//#" }, StringSplitOptions.None);
            //     txtUserName.Text = vUserData[0];
            //     txtPassword.Text = vUserData[1];
            //     chkRememberMe.Checked = true;
            // }
            //
            // fr.Close();

            chkRememberMe.Checked = false;

            string keyPath = @"HKEY_Current_User\SOFTWARE\YourSoftware";

            string valueName = "Remember";

            try
            {
                string value = Registry.GetValue(keyPath, valueName, null) as string;

                if (value != null)
                {
                    var vUserData = value.Split(new string[] { "#//#" }, StringSplitOptions.None);
                    txtUserName.Text = vUserData[0];
                    txtPassword.Text = vUserData[1];
                    chkRememberMe.Checked = true;
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            var fr = new UsersScreen();
            fr.ShowDialog();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}