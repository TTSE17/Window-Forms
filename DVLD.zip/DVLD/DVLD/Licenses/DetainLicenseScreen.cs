using System;
using System.ComponentModel;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Licenses
{
    public partial class DetainLicenseScreen : Form
    {
        public DetainLicenseScreen()
        {
            InitializeComponent();
        }

        private int _LicenseID = -1;
        private LicensesBusinessLayer _License1;

        private void DetainLicenseScreen_Load(object sender, EventArgs e)
        {
            lblDetainDate.Text = DateTime.Now.ToShortDateString();
            lblCreatedByUser.Text = clsGlobal.CurrentUser.Username;
        }

        private void ctrlSearchLicense1_OnSearchLicense(int LicenseID)
        {
            _LicenseID = LicenseID;
            _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);

            llShowLicensesHistory.Enabled = true;
            llShowLicenseInfo.Enabled = true;

            lblLicenseID.Text = Convert.ToString(_LicenseID);

            if (!_License1.IsActive)
            {
                MessageBox.Show("It's Not Active");
                btnDetain.Enabled = false;

                return;
            }

            if (DateTime.Now > _License1.ExpirationDate)
            {
                MessageBox.Show("Expired");
                btnDetain.Enabled = false;

                return;
            }

            if (DetainedLicensesBusinessLayer.IsDetained(_LicenseID))
            {
                MessageBox.Show("Selected License i already detained, choose another one.", "Not allowed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnDetain.Enabled = false;
                return;
            }

            btnDetain.Enabled = true;
        }

        private void llShowLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var PersonID = _License1.Application.ApplicationPersonID;

            var fr = new LicensesHistoryScreen(PersonID);
            fr.ShowDialog();

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }

        private void llShowLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new LicenseInfoScreen(_LicenseID);
            fr.ShowDialog();
        }

        private void btnDetain_Click(object sender, EventArgs e)
        {
            if (errorProvider1.GetError(txtFineFees) != "")
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            var _DetainedLicense1 = new DetainedLicensesBusinessLayer()
            {
                LicenseID = _LicenseID,
                DetainDate = DateTime.Now,
                FineFees = Convert.ToDecimal(txtFineFees.Text.Trim()),
                CreatedByUserID = clsGlobal.CurrentUser.UserID,
                IsReleased = false,
                ReleaseDate = default,
                ReleasedByUserID = -1,
                ReleaseApplicationID = -1,
            };

            MessageBox.Show(_DetainedLicense1.Save()
                ? "License Detained Successfully with ID=" + _DetainedLicense1.DetainID.ToString()
                : "Failed");

            lblDetainID.Text = Convert.ToString(_DetainedLicense1.DetainID);

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
            ctrlSearchLicense1.groupBox2.Enabled = false;

            btnDetain.Enabled = false;
        }

        private void txtFineFees_TextChanged(object sender, EventArgs e)
        {
            var Text = txtFineFees.Text.Trim();

            try
            {
                var Number = Convert.ToDecimal(Text);
            }
            catch (Exception exp)
            {
                errorProvider1.SetError(txtFineFees, "Invalid Number");
                return;
            }

            errorProvider1.SetError(txtFineFees, "");
        }
    }
}