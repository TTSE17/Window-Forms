using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Licenses
{
    public partial class RenewLicenseScreen : Form
    {
        public RenewLicenseScreen()
        {
            InitializeComponent();
        }

        private int _LicenseID = -1;
        private LicensesBusinessLayer _License1;

        private void RenewLicenseScreen_Load(object sender, EventArgs e)
        {
            lblApplicationDate.Text = DateTime.Now.ToShortDateString();
            lblIssueDate.Text = DateTime.Now.ToShortDateString();
            lblExpirationDate.Text = "???";
            lblApplicationFees.Text =
                Convert.ToString(ApplicationTypesBusinessLayer.FindApplicationType(2).ApplicationFees);
            lblCreatedByUser.Text =clsGlobal.CurrentUser.Username;
        }

        private void ctrlSearchLicense1_OnSearchLicense(int LicenseID)
        {
            _LicenseID = LicenseID;
            _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);

            llShowLicensesHistory.Enabled = true;

            lblExpirationDate.Text =
                GetExpirationDate(_License1.LicenseClassInfo.DefaultValidityLength).ToShortDateString();
            lblLicenseFees.Text = Convert.ToString(_License1.LicenseClassInfo.ClassFees);

            lblTotalFees.Text =
                Convert.ToString(Convert.ToSingle(lblApplicationFees.Text) + Convert.ToSingle(lblLicenseFees.Text));

            lblOldLicenseID.Text = Convert.ToString(LicenseID);
            txtNotes.Text = _License1.Notes;

            if (!_License1.IsActive)
            {
                MessageBox.Show("Selected License is not Not Active, choose an active license."
                    , "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnIssue.Enabled = llShowLicenseInfo.Enabled = false;

                return;
            }

            if (DateTime.Now < _License1.ExpirationDate)
            {
                MessageBox.Show("Selected License is not yet expiared, it will expire on: " +
                                _License1.ExpirationDate.ToShortDateString(), "Not allowed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnIssue.Enabled = llShowLicenseInfo.Enabled = false;
                return;
            }

            btnIssue.Enabled = true;
        }

        private void llShowLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var PersonID = _License1.Application.ApplicationPersonID;

            var fr = new LicensesHistoryScreen(PersonID);
            fr.ShowDialog();

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }

        private void llShowLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new LicenseInfoScreen(_LicenseID);
            fr.ShowDialog();
        }

        private void btnIssue_Click(object sender, EventArgs e)
        {
            var _Application1 = new ApplicationsBusinessLayer()
            {
                ApplicationPersonID = _License1.Application.ApplicationPersonID,
                ApplicationDate = DateTime.Now,
                ApplicationTypeID = 2,
                ApplicationStatus = 3,
                LastStatusDate = DateTime.Now,
                PaidFees = Convert.ToDecimal(lblTotalFees.Text),
                CreatedByUserId = clsGlobal.CurrentUser.UserID
            };

            _Application1.Save();

            var _NewLicense1 = new LicensesBusinessLayer()
            {
                Application = _Application1,
                DriverID = _License1.DriverID,
                LicenseClass = _License1.LicenseClass,
                IssueDate = DateTime.Now,
                ExpirationDate = GetExpirationDate(_License1.LicenseClassInfo.DefaultValidityLength),
                Notes = txtNotes.Text.Trim(),
                PaidFees = Convert.ToDecimal(lblLicenseFees),
                IsActive = true,
                IssueReason = 2,
                CreatedByUserID = clsGlobal.CurrentUser.UserID
            };

            MessageBox.Show(_NewLicense1.Save()
                ? " Licensed Renewed Successfully with ID=" + _NewLicense1.LicenseID
                : "Failed");

            lblApplicationID.Text = Convert.ToString(_NewLicense1.Application.ApplicationId);
            lblRenewedLicenseID.Text = Convert.ToString(_NewLicense1.LicenseID);

            _License1.IsActive = false;
            _License1.Save();

            _LicenseID = _NewLicense1.LicenseID;

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
            ctrlSearchLicense1.groupBox2.Enabled = false;

            btnIssue.Enabled = false;
            llShowLicenseInfo.Enabled = true;
        }

        private static DateTime GetExpirationDate(short DefaultLength)
        {
            return DateTime.Now.AddYears(Convert.ToInt32(DefaultLength));
        }
    }
}