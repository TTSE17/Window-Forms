using System;
using System.Windows.Forms;
using DVLD.Controls;
using DVLDBusinessLayer;

namespace DVLD.Licenses
{
    public partial class ReleaseDetainedLicenseScreen : Form
    {
        public ReleaseDetainedLicenseScreen(int licenseId = -1)
        {
            InitializeComponent();
            _LicenseID = licenseId;
        }

        private int _LicenseID = -1;
        private LicensesBusinessLayer _License1;

        private DetainedLicensesBusinessLayer _DetainedLicense1;

        private void ReleaseDetainedLicenseScreen_Load(object sender, EventArgs e)
        {
            if (_LicenseID == -1) return;

            ctrlSearchLicense1.txtLicenseId.Text = Convert.ToString(_LicenseID);
            ctrlSearchLicense1.btnSearch.PerformClick();
            ctrlSearchLicense1.groupBox2.Enabled = false;
        }

        private void ctrlSearchLicense1_OnSearchLicense(int LicenseID)
        {
            _LicenseID = LicenseID;
            _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);

            llShowLicensesHistory.Enabled = true;
            llShowLicenseInfo.Enabled = true;

            lblLicenseID.Text = Convert.ToString(_LicenseID);

            if (!_License1.IsActive)
            {
                MessageBox.Show("Selected License is not Active, choose another one.", "Not allowed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnRelease.Enabled = false;

                return;
            }

            if (DateTime.Now > _License1.ExpirationDate)
            {
                MessageBox.Show("Selected License is Expired, choose another one.", "Not allowed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnRelease.Enabled = false;

                return;
            }

            if (!DetainedLicensesBusinessLayer.IsDetained(_LicenseID))
            {
                MessageBox.Show("Selected License is not detained, choose another one.", "Not allowed",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnRelease.Enabled = false;

                return;
            }

            _DetainedLicense1 = DetainedLicensesBusinessLayer.FindDetainedLicenseByLicenseID(_LicenseID);

            lblApplicationFees.Text =
                Convert.ToString(ApplicationTypesBusinessLayer.FindApplicationType(5).ApplicationFees);
            lblCreatedByUser.Text =_DetainedLicense1.UserInfo.Username;
            lblDetainID.Text = Convert.ToString(_DetainedLicense1.DetainID);
            lblDetainDate.Text = _DetainedLicense1.DetainDate.ToShortDateString();
            lblFineFees.Text = Convert.ToString(_DetainedLicense1.FineFees);
            lblTotalFees.Text =
                Convert.ToString(Convert.ToSingle(lblApplicationFees.Text) + Convert.ToSingle(lblFineFees.Text));

            btnRelease.Enabled = true;
        }

        private void llShowLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var PersonID = _License1.Application.ApplicationPersonID;

            var fr = new LicensesHistoryScreen(PersonID);
            fr.ShowDialog();

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }

        private void llShowLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new LicenseInfoScreen(_LicenseID);
            fr.ShowDialog();
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            var _Application1 = new ApplicationsBusinessLayer()
            {
                ApplicationPersonID = _License1.Application.ApplicationPersonID,
                ApplicationDate = DateTime.Now,
                ApplicationTypeID = 5,
                ApplicationStatus = 3,
                LastStatusDate = DateTime.Now,
                PaidFees = Convert.ToDecimal(lblApplicationFees.Text),
                CreatedByUserId = clsGlobal.CurrentUser.UserID
            };

            _Application1.Save();

            _DetainedLicense1.IsReleased = true;
            _DetainedLicense1.ReleaseDate = DateTime.Now;
            _DetainedLicense1.ReleasedByUserID = clsGlobal.CurrentUser.UserID; 
            _DetainedLicense1.ReleaseApplicationID = _Application1.ApplicationId;

            MessageBox.Show(_DetainedLicense1.Save() ? "Detained License released Successfully " : "Failed");

            lblApplicationID.Text = Convert.ToString(_Application1.ApplicationId);

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
            ctrlSearchLicense1.groupBox2.Enabled = false;

            btnRelease.Enabled = false;
        }
    }
}