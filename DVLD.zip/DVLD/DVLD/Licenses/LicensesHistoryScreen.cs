using System;
using System.Windows.Forms;

namespace DVLD.Licenses
{
    public partial class LicensesHistoryScreen : Form
    {
        private readonly int _PersonID;

        public LicensesHistoryScreen(int PersonID)
        {
            InitializeComponent();
            _PersonID = PersonID;
        }

        private void LicensesHistoryScreen_Load(object sender, EventArgs e)
        {
            ctrlLicenseHistory1.LoadLicensesHistory(_PersonID);
        }
    }
}