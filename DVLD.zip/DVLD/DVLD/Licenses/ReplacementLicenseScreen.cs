using System;
using System.Windows.Forms;
using DVLD.Licenses;
using DVLDBusinessLayer;

namespace DVLD.LocalLicenses
{
    public partial class ReplacementLicenseScreen : Form
    {
        public ReplacementLicenseScreen()
        {
            InitializeComponent();
            gbReplacementType.BringToFront();
        }

        private int _LicenseID = -1;
        private LicensesBusinessLayer _License1;

        private void ReplacementLicenseScreen_Load(object sender, EventArgs e)
        {
            rbLostLicense.Checked = true;

            lblApplicationDate.Text = DateTime.Now.ToShortDateString();
            lblCreatedByUser.Text = clsGlobal.CurrentUser.Username;
        }

        private void rb_CheckedChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(((RadioButton)sender).Tag);

            lblTitle.Text = $"Replacement For {Type} License";
            Text = lblTitle.Text;

            lblApplicationFees.Text = Convert.ToString(Type == "Lost"
                ? ApplicationTypesBusinessLayer.FindApplicationType(3).ApplicationFees
                : ApplicationTypesBusinessLayer.FindApplicationType(4).ApplicationFees);
        }

        private void ctrlSearchLicense1_OnSearchLicense(int LicenseID)
        {
            _LicenseID = LicenseID;
            _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);

            llShowLicensesHistory.Enabled = true;

            lblOldLicenseID.Text = Convert.ToString(LicenseID);

            if (!_License1.IsActive)
            {
                MessageBox.Show("Selected License is not Not Active, choose an active license."
                    , "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);

                btnIssue.Enabled = llShowNewLicenseInfo.Enabled = false;

                return;
            }

            if (DateTime.Now > _License1.ExpirationDate)
            {
                MessageBox.Show("Expired");
                btnIssue.Enabled = llShowNewLicenseInfo.Enabled = false;

                return;
            }

            btnIssue.Enabled = true;
        }

        private void llShowLicensesHistory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var PersonID = _License1.Application.ApplicationPersonID;

            var fr = new LicensesHistoryScreen(PersonID);
            fr.ShowDialog();

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }

        private void llShowNewLicenseInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var fr = new LicenseInfoScreen(_LicenseID);
            fr.ShowDialog();
        }

        private void btnIssueReplacement_Click(object sender, EventArgs e)
        {
            var _Application1 = new ApplicationsBusinessLayer()
            {
                ApplicationPersonID = _License1.Application.ApplicationPersonID,
                ApplicationDate = DateTime.Now,
                ApplicationTypeID = (rbLostLicense.Checked) ? 3 : 4,
                ApplicationStatus = 3,
                LastStatusDate = DateTime.Now,
                PaidFees = Convert.ToDecimal(lblApplicationFees.Text),
                CreatedByUserId = clsGlobal.CurrentUser.UserID
            };

            _Application1.Save();

            var _NewLicense1 = new LicensesBusinessLayer
            {
                Application = _Application1,
                DriverID = _License1.DriverID,
                LicenseClass = _License1.LicenseClass,
                IssueDate = DateTime.Now,
                ExpirationDate = GetExpirationDate(_License1.LicenseClassInfo.DefaultValidityLength),
                Notes = _License1.Notes,
                PaidFees = 0,
                IsActive = true,
                IssueReason = Convert.ToInt16(rbLostLicense.Checked ? 3 : 4),
                CreatedByUserID = clsGlobal.CurrentUser.UserID
            };

            MessageBox.Show(_NewLicense1.Save()
                ? "Licensed Replaced Successfully with ID=" + _NewLicense1.LicenseID + _NewLicense1.LicenseID
                : "Failed");

            _LicenseID = _NewLicense1.LicenseID;

            lblApplicationID.Text = Convert.ToString(_Application1.ApplicationId);
            lblRreplacedLicenseID.Text = Convert.ToString(_LicenseID);

            _License1.IsActive = false;
            _License1.Save();

            ctrlSearchLicense1.ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
            ctrlSearchLicense1.groupBox2.Enabled = false;
            gbReplacementType.Enabled = false;
            llShowNewLicenseInfo.Enabled = true;
            btnIssue.Enabled = false;
        }

        private static DateTime GetExpirationDate(short DefaultLength)
        {
            return DateTime.Now.AddYears(Convert.ToInt32(DefaultLength));
        }
    }
}