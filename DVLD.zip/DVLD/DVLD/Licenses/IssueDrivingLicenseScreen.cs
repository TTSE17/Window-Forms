using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Licenses
{
    public partial class IssueDrivingLicenseScreen : Form
    {
        private readonly int _LocalDrivingLicenseApplicationID;

        public IssueDrivingLicenseScreen(int localDrivingLicenseApplicationId)
        {
            InitializeComponent();

            _LocalDrivingLicenseApplicationID = localDrivingLicenseApplicationId;
        }

        private void IssueDrivingLicenseScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            ctrlLocalLicenseApplicationDetails1.LoadLocalLicenseInfo(_LocalDrivingLicenseApplicationID);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var _DriverID = -1;
            var _Driver1 = new DriversBusinessLayer();

            var _LocalLicenseApplication =
                LocalLicensesBusinessLayer.FindLocalLicense(_LocalDrivingLicenseApplicationID);

            if (!LicensesBusinessLayer.GetDriverID(_LocalLicenseApplication.Application.ApplicationPersonID,
                    ref _DriverID))
            {
                _Driver1.PersonID = _LocalLicenseApplication.Application.ApplicationPersonID;
                _Driver1.CreatedDate = DateTime.Now;
                _Driver1.CreatedByUserId = clsGlobal.CurrentUser.UserID;
                _Driver1.Save();
                _DriverID = _Driver1.DriverID;
            }

            var _License1 = new LicensesBusinessLayer
            {
                Application = _LocalLicenseApplication.Application,
                DriverID = _DriverID,
                LicenseClass = _LocalLicenseApplication.LicenseClassId,
                IssueDate = DateTime.Now,
                ExpirationDate = GetExpirationDate(_LocalLicenseApplication.LicenseClassInfo.DefaultValidityLength),
                Notes = txtNotes.Text.Trim(),
                PaidFees = _LocalLicenseApplication.LicenseClassInfo.ClassFees,
                IsActive = true,
                IssueReason = 1,
                CreatedByUserID = clsGlobal.CurrentUser.UserID,
            };

            MessageBox.Show(_License1.Save()
                ? "License Issued Successfully with License ID = " + _License1.LicenseID
                : "Error: Data Is not Saved Successfully.");

            var _Application =
                ApplicationsBusinessLayer.FindApplication(_LocalLicenseApplication.Application.ApplicationId);
            _Application.ApplicationStatus = 3;
            _Application.LastStatusDate = DateTime.Now;
            _Application.Save();

            Close();
        }

        private static DateTime GetExpirationDate(int DefaultLength)
        {
            return DateTime.Now.AddYears(DefaultLength);
        }
    }
}