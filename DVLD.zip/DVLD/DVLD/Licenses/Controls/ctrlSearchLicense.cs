using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlSearchLicense : UserControl
    {
        public ctrlSearchLicense()
        {
            InitializeComponent();
        }

        public event Action<int> OnSearchLicense;

        // Create a protected method to raise the event with a parameter
        protected virtual void SearchLicense(int LicenseID)
        {
            Action<int> handler = OnSearchLicense;
            if (handler != null)
            {
                handler(LicenseID); // Raise the event with the parameter
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            var _LicenseID = Convert.ToInt32(txtLicenseId.Text.Trim());
            var _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);

            if (_License1 == null)
            {
                MessageBox.Show("There is no");
                return;
            }

            ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);

            if (OnSearchLicense != null)
                SearchLicense(_License1.LicenseID);
        }
    }
}