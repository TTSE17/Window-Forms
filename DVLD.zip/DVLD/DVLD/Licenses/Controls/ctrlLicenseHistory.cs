using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlLicenseHistory : UserControl
    {
        private int _PersonID;

        public ctrlLicenseHistory()
        {
            InitializeComponent();
        }

        public void LoadLicensesHistory(int PersonID)
        {
            _PersonID = PersonID;
            LoadData();
        }

        private void LoadData()
        {
            ctrlPersonCardDetails1.LoadPersonInfo(_PersonID);

            GridViewLocalLicensesList.DataSource = LicensesBusinessLayer.GetLocalLicenses(_PersonID);
            lblLocalRecords.Text = Convert.ToString(GridViewLocalLicensesList.Rows.Count);

            GridViewInternationalLicensesList.DataSource = LicensesBusinessLayer.GetInternationalLicenses(_PersonID);
            lblInternationalRecords.Text = Convert.ToString(GridViewInternationalLicensesList.Rows.Count);
        }
    }
}