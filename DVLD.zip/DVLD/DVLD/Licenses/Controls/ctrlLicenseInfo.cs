using System;
using System.Windows.Forms;
using DVLD.Properties;
using DVLDBusinessLayer;

namespace DVLD.Controls
{
    public partial class ctrlLicenseInfo : UserControl
    {
        private int _LicenseID;

        public ctrlLicenseInfo()
        {
            InitializeComponent();
        }

        public void LoadLicenseInfo(int LicenseID)
        {
            _LicenseID = LicenseID;
            LoadData();
        }

        private void LoadData()
        {
            var _License1 = LicensesBusinessLayer.FindLicense(_LicenseID);
            var _IssueReason = _License1.IssueReason;

            if (_License1 == null) return;

            lblClass.Text = _License1.LicenseClassInfo.ClassName;
            lblFullName.Text = _License1.DriverInfo.PersonInfo.FullName();
            lblLicenseID.Text = Convert.ToString(_License1.LicenseID);
            lblNationalNo.Text = _License1.Application.PersonInfo.NationalNo;
            lblGendor.Text = _License1.DriverInfo.PersonInfo.Gender == 0 ? "Male" : "Female";
            lblIssueDate.Text = _License1.IssueDate.ToString("dd/MMM/yyyy");
            lblIssueReason.Text = (_IssueReason == 1)
                ? "First Time"
                : (_IssueReason == 2 ? "Renew" : (_IssueReason == 3 ? "Lost" : "Damaged"));
            lblNotes.Text = _License1.Notes == "" ? "No Notes" : _License1.Notes;
            lblIsActive.Text = _License1.IsActive ? "Yes" : "No";
            lblDateOfBirth.Text = (_License1.Application.PersonInfo.DateOfBirth).ToString("dd/MMM/yyyy");
            lblDriverID.Text = Convert.ToString(_License1.DriverID);
            lblExpirationDate.Text = _License1.ExpirationDate.ToString("dd/MMM/yyyy");
            lblIsDetained.Text = DetainedLicensesBusinessLayer.IsDetained(_LicenseID) ? "Yes" : "No";

            var ImagePath = _License1.DriverInfo.PersonInfo.ImagePath;

            if (ImagePath != "")
                pbPersonImage.Load(ImagePath);
            else
                pbPersonImage.Image = (lblGendor.Text == "Male") ? Resources.user : Resources.user_female;
        }
    }
}