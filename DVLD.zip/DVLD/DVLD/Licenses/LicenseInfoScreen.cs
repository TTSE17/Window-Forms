using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.Licenses
{
    public partial class LicenseInfoScreen : Form
    {
        private readonly int _LicenseID = -1;

        public LicenseInfoScreen(int licenseId)
        {
            InitializeComponent();
            _LicenseID = licenseId;
        }

        private void LicenseInfoScreen_Load(object sender, EventArgs e)
        {
            ctrlLicenseInfo1.LoadLicenseInfo(_LicenseID);
        }
    }
}