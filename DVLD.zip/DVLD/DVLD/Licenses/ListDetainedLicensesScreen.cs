using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using DVLD.People;
using DVLDBusinessLayer;

namespace DVLD.Licenses
{
    public partial class ListDetainedLicensesScreen : Form
    {
        public ListDetainedLicensesScreen()
        {
            InitializeComponent();
        }

        private DataTable _DataTable;
        private int _DetainedLicenseID = -1;
        private DetainedLicensesBusinessLayer _DetainedLicense1;

        private void ListDetainedLicensesScreen_Load(object sender, EventArgs e)
        {
            RefreshData();
        }

        private void RefreshData()
        {
            _DataTable = DetainedLicensesBusinessLayer.GetAllDetainedLicenses();

            comboBox1.SelectedIndex = 0;

            LoadData();
        }

        private void LoadData(string Type = "DetainID", string Text = "")
        {
            var EmployeesDataView1 = _DataTable.DefaultView;
            var DataFilter = "";

            try
            {
                if (Text == "")
                    DataFilter = null;
                else if (Type == "DetainID" || Type == "IsReleased" || Type == "ReleaseApplicationID")
                    DataFilter = $"{Type} = '{Text}'";
                else
                    DataFilter = $"{Type} LIKE '{Text}%'";

                EmployeesDataView1.RowFilter = DataFilter;
            }
            catch (Exception e)
            {
                MessageBox.Show("This textbox accepts only Numneric characters");
                textBox1.Text = Text.Substring(0, Text.Length - 1);
                EmployeesDataView1.RowFilter = null;
            }

            GridViewListDetainedLicensesList.DataSource = EmployeesDataView1;

            lblRecords.Text = Convert.ToString(GridViewListDetainedLicensesList.Rows.Count);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var Type = Convert.ToString(comboBox1.SelectedItem);
            var Text = textBox1.Text.Trim();

            LoadData(Type, Text);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var IsReleased = comboBox1.SelectedIndex == 1;

            textBox1.Visible = !IsReleased;
            cbIsReleased.Visible = IsReleased;
            cbIsReleased.SelectedIndex = 0;

            textBox1.Text = "";

            textBox1.Focus();
        }

        private void cbIsReleased_SelectedIndexChanged(object sender, EventArgs e)
        {
            var Selection = Convert.ToString(cbIsReleased.SelectedItem);

            var IsReleasedValue = Selection == "All" ? "" : (Selection == "Yes" ? "true" : "false");

            LoadData("IsReleased", IsReleasedValue);
        }

        private void btnRelease_Click(object sender, EventArgs e)
        {
            var fr = new ReleaseDetainedLicenseScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void btnDetain_Click(object sender, EventArgs e)
        {
            var fr = new DetainLicenseScreen();
            fr.ShowDialog();

            RefreshData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            var IsReleased = Convert.ToBoolean(GridViewListDetainedLicensesList.CurrentRow.Cells[3].Value);

            releaseToolStripMenuItem.Enabled = !IsReleased;
        }

        private void showPersonDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewListDetainedLicensesList.CurrentRow.Cells[0].Value));

            var fr = new PersonCardDetailsScreen(_DetainedLicense1.LicenseInfo.Application.ApplicationPersonID);

            fr.ShowDialog();

            RefreshData();
        }

        private void showLicenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewListDetainedLicensesList.CurrentRow.Cells[0].Value));

            var fr = new LicenseInfoScreen(_DetainedLicense1.LicenseID);
            fr.ShowDialog();
        }

        private void showLicensePersonHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewListDetainedLicensesList.CurrentRow.Cells[0].Value));

            var fr = new LicensesHistoryScreen(_DetainedLicense1.LicenseInfo.Application.ApplicationPersonID);

            fr.ShowDialog();

            RefreshData();
        }

        private void releaseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateInternationalInfo(Convert.ToInt32(GridViewListDetainedLicensesList.CurrentRow.Cells[0].Value));

            var fr = new ReleaseDetainedLicenseScreen(_DetainedLicense1.LicenseID);
            fr.ShowDialog();

            RefreshData();
        }

        private void UpdateInternationalInfo(int ID)
        {
            _DetainedLicenseID = ID;
            _DetainedLicense1 = DetainedLicensesBusinessLayer.FindDetainedLicense(_DetainedLicenseID);
        }
    }
}