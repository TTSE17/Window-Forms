using System;
using System.ComponentModel;
using System.Windows.Forms;
using DVLD.Properties;
using DVLDBusinessLayer;
using DVLDDataAccessLayer;

namespace DVLD.Appointments
{
    public partial class TestAppointmentsScreen : Form
    {
        private readonly int _LocalLicenseID;
        private readonly int _TestTypeID;

        public TestAppointmentsScreen(int localLicenseId, int Type)
        {
            InitializeComponent();

            _LocalLicenseID = localLicenseId;
            _TestTypeID = Type;
        }

        private void TestAppointmentsScreen_Load(object sender, EventArgs e)
        {
            LoadData();

            if (GridViewTestAppointmentsList.Rows.Count <= 0) return;

            GridViewTestAppointmentsList.Columns[0].Width = 79;
            GridViewTestAppointmentsList.Columns[1].Width = 211;
            GridViewTestAppointmentsList.Columns[2].Width = 133;
            GridViewTestAppointmentsList.Columns[3].Width = 111;
        }

        private void LoadData()
        {
            _LoadTestTypeImageAndTitle();

            ctrlLocalLicenseApplicationDetails1.LoadLocalLicenseInfo(_LocalLicenseID);

            GridViewTestAppointmentsList.DataSource =
                TestAppointmentsBusinessLayer.GetAllTestAppointments(_LocalLicenseID, _TestTypeID);

            lblRecords.Text = Convert.ToString(GridViewTestAppointmentsList.Rows.Count);
        }

        private void _LoadTestTypeImageAndTitle()
        {
            switch (_TestTypeID)
            {
                case 1:
                {
                    lblTitle.Text = "Vision Test Appointments";
                    Text = lblTitle.Text;
                    pbTestTypeImage.Image = Resources.Vision_512;
                    break;
                }

                case 2:
                {
                    lblTitle.Text = "Written Test Appointments";
                    Text = lblTitle.Text;
                    pbTestTypeImage.Image = Resources.Written_Test_512;
                    break;
                }

                case 3:
                {
                    lblTitle.Text = "Street Test Appointments";
                    Text = lblTitle.Text;
                    pbTestTypeImage.Image = Resources.driving_test_512;
                    break;
                }
            }
        }

        private void btnAddAppointment_Click(object sender, EventArgs e)
        {
            if (TestAppointmentsBusinessLayer.HaveTestAppointment(_LocalLicenseID, _TestTypeID))
            {
                MessageBox.Show(
                    "Person Already have an active appointment for this test, You cannot add new appointment",
                    "Not allowed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var fr = new ScheduleTestScreen(_LocalLicenseID, _TestTypeID);
            fr.ShowDialog();
            LoadData();
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            var IsLocked = Convert.ToBoolean(GridViewTestAppointmentsList.CurrentRow.Cells[3].Value);

            editToolStripMenuItem.Enabled = takeATestToolStripMenuItem.Enabled = !IsLocked;
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var TestAppointmentID = Convert.ToInt32(GridViewTestAppointmentsList.CurrentRow.Cells[0].Value);

            var fr = new ScheduleTestScreen(_LocalLicenseID, _TestTypeID, TestAppointmentID);
            fr.ShowDialog();
            LoadData();
        }

        private void takeATestToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var TestAppointmentID = Convert.ToInt32(GridViewTestAppointmentsList.CurrentRow.Cells[0].Value);
            var fr = new TakeTestScreen(TestAppointmentID);
            fr.ShowDialog();

            LoadData();
        }
    }
}