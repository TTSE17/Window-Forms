using System;
using System.Windows.Forms;
using DVLD.Properties;
using DVLDBusinessLayer;
using DVLDDataAccessLayer;

namespace DVLD.Appointments
{
    public partial class ScheduleTestScreen : Form
    {
        private int _TestAppointmentID = -1;
        private TestAppointmentsBusinessLayer _TestAppointment1;

        private readonly int _LocalLicenseID;
        private LocalLicensesBusinessLayer _LocalLicense1;

        private readonly int _TestTypeID;
        private readonly bool IsReTakeTest;

        public ScheduleTestScreen(int localLicenseId, int testTypeId, int testAppointmentId = -1)
        {
            InitializeComponent();
            _TestAppointmentID = testAppointmentId;
            _LocalLicenseID = localLicenseId;
            _TestTypeID = testTypeId;

            IsReTakeTest = TestAppointmentsBusinessLayer.IsRetakeTest(_LocalLicenseID, _TestTypeID);
        }

        private void ScheduleTestScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            dtpTestDate.MinDate = DateTime.Now;

            if (_TestAppointmentID != -1)
            {
                _TestAppointment1 = TestAppointmentsBusinessLayer.FindTestAppointment(_TestAppointmentID);

                dtpTestDate.MinDate = DateTime.Compare(DateTime.Now, _TestAppointment1.AppointmentDate) < 0
                    ? DateTime.Now
                    : _TestAppointment1.AppointmentDate;

                dtpTestDate.Value = _TestAppointment1.AppointmentDate;

                lblFees.Text = Convert.ToString(_TestAppointment1.PaidFees);
                if (_TestAppointment1.RetakeTestApplicationID != -1)
                    lblRetakeTestAppID.Text = Convert.ToString(_TestAppointment1.RetakeTestApplicationID);
            }

            else
            {
                _TestAppointment1 = new TestAppointmentsBusinessLayer();
                lblFees.Text = Convert.ToString(TestTypesBusinessLayer.FindTestType(_TestTypeID).TestTypeFees);
            }

            _LocalLicense1 = LocalLicensesBusinessLayer.FindLocalLicense(_LocalLicenseID);

            lblLocalDrivingLicenseAppID.Text = Convert.ToString(_LocalLicense1.LocalDrivingLicenseApplicationID);
            lblDrivingClass.Text = _LocalLicense1.LicenseClassInfo.ClassName;
            lblFullName.Text = _LocalLicense1.Application.PersonInfo.FullName();
            lblTrial.Text = Convert.ToString(_LocalLicense1.TotalTrialsPerTest(_TestTypeID));

            _LoadScheduleTestType();

            if (IsReTakeTest)
            {
                gbRetakeTestInfo.Enabled = true;
                lblRetakeAppFees.Text = ApplicationTypesBusinessLayer.FindApplicationType
                        (Convert.ToInt32(ApplicationsBusinessLayer.enApplicationType.RetakeTest))
                    .ApplicationFees.ToString();
                lblTitle.Text = "Schedule Retake Test";
            }

            else
            {
                gbRetakeTestInfo.Enabled = false;
                lblTitle.Text = "Schedule Test";
                lblRetakeAppFees.Text = "0";
            }

            lblTotalFees.Text =
                Convert.ToString(Convert.ToDecimal(lblRetakeAppFees.Text) + Convert.ToDecimal(lblFees.Text));
        }

        private void _LoadScheduleTestType()
        {
            switch (_TestTypeID)
            {
                case 1:
                {
                    groupBox1.Text = "Vision Test";
                    pbTestTypeImage.Image = Resources.Vision_512;
                    break;
                }

                case 2:
                {
                    groupBox1.Text = "Written Test";
                    pbTestTypeImage.Image = Resources.Written_Test_512;
                    break;
                }

                case 3:
                {
                    groupBox1.Text = "Street Test";
                    pbTestTypeImage.Image = Resources.driving_test_512;
                    break;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            _TestAppointment1.AppointmentDate = dtpTestDate.Value;

            if (_TestAppointment1.TestAppointmentID == -1)
            {
                _TestAppointment1.TestTypeID = _TestTypeID;
                _TestAppointment1.LocalDrivingLicenseApplication = _LocalLicense1;
                _TestAppointment1.PaidFees = Convert.ToDecimal(lblFees.Text);
                _TestAppointment1.CreatedByUserID = clsGlobal.CurrentUser.UserID;
                _TestAppointment1.IsLocked = false;

                if (IsReTakeTest)
                {
                    var _Application1 = new ApplicationsBusinessLayer
                    {
                        ApplicationPersonID = _LocalLicense1.Application.ApplicationPersonID,
                        ApplicationDate = DateTime.Now,
                        ApplicationTypeID = Convert.ToInt32(ApplicationsBusinessLayer.enApplicationType.RetakeTest),
                        ApplicationStatus = 3,
                        LastStatusDate = DateTime.Now,
                        PaidFees = ApplicationTypesBusinessLayer.FindApplicationType(7).ApplicationFees,
                        CreatedByUserId = clsGlobal.CurrentUser.UserID
                    };

                    _Application1.Save();

                    _TestAppointment1.RetakeTestApplicationID = _Application1.ApplicationId;

                    lblRetakeTestAppID.Text = Convert.ToString(_TestAppointment1.RetakeTestApplicationID);
                }

                else
                    _TestAppointment1.RetakeTestApplicationID = -1;
            }

            MessageBox.Show(_TestAppointment1.Save()
                ? $"Data Saved Successfully."
                : "Error: Data Is not Saved Successfully.");

            _TestAppointmentID = _TestAppointment1.TestAppointmentID;
        }
    }
}