using System;
using System.Windows.Forms;
using DVLD.Properties;
using DVLDBusinessLayer;
using DVLDDataAccessLayer;

namespace DVLD.Appointments
{
    public partial class TakeTestScreen : Form
    {
        private readonly int _TestAppointmentID = -1;
        private TestAppointmentsBusinessLayer _TestAppointment1;

        private int _TestTypeID = -1;

        public TakeTestScreen(int testAppointmentId)
        {
            InitializeComponent();
            _TestAppointmentID = testAppointmentId;
        }

        private void TakeTestScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _TestAppointment1 = TestAppointmentsBusinessLayer.FindTestAppointment(_TestAppointmentID);
            _TestTypeID = _TestAppointment1.TestTypeID;

            var _LocalLicense1 = LocalLicensesBusinessLayer.FindLocalLicense(_TestAppointment1
                .LocalDrivingLicenseApplication.LocalDrivingLicenseApplicationID);

            lblLocalDrivingLicenseAppID.Text = Convert.ToString(_LocalLicense1.LocalDrivingLicenseApplicationID);

            lblDrivingClass.Text = _TestAppointment1.LocalDrivingLicenseApplication.LicenseClassInfo.ClassName;

            lblFullName.Text = _TestAppointment1.LocalDrivingLicenseApplication.Application.PersonInfo.FullName();

            lblTrial.Text = Convert.ToString(_LocalLicense1.TotalTrialsPerTest(_TestTypeID));

            lblDate.Text = _TestAppointment1.AppointmentDate.ToString("MM/dd/yyyy");

            lblFees.Text = Convert.ToString(_TestAppointment1.PaidFees);

            lblTestID.Text = "Not Taken Yet";

            _LoadScheduleTestType();
        }

        private void _LoadScheduleTestType()
        {
            switch (_TestTypeID)
            {
                case 1:
                {
                    groupBox1.Text = "Vision Test";
                    pbTestTypeImage.Image = Resources.Vision_512;
                    break;
                }

                case 2:
                {
                    groupBox1.Text = "Written Test";
                    pbTestTypeImage.Image = Resources.Written_Test_512;
                    break;
                }

                case 3:
                {
                    groupBox1.Text = "Street Test";
                    pbTestTypeImage.Image = Resources.driving_test_512;
                    break;
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(
                    "Are you sure you want to save? After that you cannot change the Pass/Fail results after you save?.",
                    "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
                return;

            var _Test1 = new TestsBusinessLayer
            {
                TestAppointmentID = _TestAppointmentID,
                TestResult = (rbPass.Checked),
                Notes = txtNotes.Text.Trim(),
                CreatedByUserID = clsGlobal.CurrentUser.UserID
            };

            _TestAppointment1.IsLocked = true;

            var IsSaved = _Test1.AddNewTest();

            _TestAppointment1.Save();

            lblTestID.Text = _Test1.TestID.ToString();
            
            if (IsSaved)
                MessageBox.Show("Data Saved Successfully . :" + _Test1.TestID, "Saved", MessageBoxButtons.OK,
                    MessageBoxIcon.Information);

            else
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

            Close();
        }
    }
}