using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.TestTypes
{
    public partial class EditTestTypeScreen : Form
    {
        private int _TestTypeID = -1;

        private TestTypesBusinessLayer _TestType1;

        public EditTestTypeScreen(int testTypeId)
        {
            InitializeComponent();
            _TestTypeID = testTypeId;
        }

        private void EditTestTypeScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            _TestType1 = TestTypesBusinessLayer.FindTestType(_TestTypeID);

            if (_TestType1 == null) return;

            lblTestTypeID.Text = Convert.ToString(_TestTypeID);
            txtTitle.Text = _TestType1.TestTypeTitle;
            txtDescription.Text = _TestType1.TestTypeDescription;
            txtFees.Text = Convert.ToString(_TestType1.TestTypeFees);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var Title = txtTitle.Text.Trim();
            var Descriptions = txtDescription.Text.Trim();
            var Fees = txtFees.Text.Trim();

            if (string.IsNullOrEmpty(Title) || string.IsNullOrEmpty(Fees) || string.IsNullOrEmpty(Descriptions))
            {
                MessageBox.Show("Enter Requirments");
                return;
            }

            _TestType1.TestTypeTitle = Title;
            _TestType1.TestTypeDescription = Descriptions;
          
            try
            {
                _TestType1.TestTypeFees = Convert.ToDecimal(Fees);
            }
            catch (Exception exception)
            {
                MessageBox.Show("Numrical Chars");
                txtFees.Focus();
                return;
            }


            if (_TestType1.UpdateTestType())
            {
                MessageBox.Show("Data Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
                MessageBox.Show("Error: Data Is not Saved Successfully.", "Error", MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}