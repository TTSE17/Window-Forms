using System;
using System.Windows.Forms;
using DVLDBusinessLayer;

namespace DVLD.TestTypes
{
    public partial class TestTypesScreen : Form
    {
        public TestTypesScreen()
        {
            InitializeComponent();
        }

        private void TestTypesScreen_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void LoadData()
        {
            GridViewTestTypesList.DataSource = TestTypesBusinessLayer.GetTestTypes();
            lblRecords.Text = Convert.ToString(GridViewTestTypesList.Rows.Count);
            
            if (GridViewTestTypesList.Rows.Count <= 0) return;

            GridViewTestTypesList.Columns[0].Width = 119;
            GridViewTestTypesList.Columns[1].Width = 179;
            GridViewTestTypesList.Columns[2].Width = 399;
            GridViewTestTypesList.Columns[3].Width = 119;
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var TestTypeID = Convert.ToInt32(GridViewTestTypesList.CurrentRow.Cells[0].Value);
            Form fr = new EditTestTypeScreen(TestTypeID);
            fr.ShowDialog();
            LoadData();
        }
    }
}